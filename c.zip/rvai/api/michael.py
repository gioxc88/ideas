import copy
import datetime as dt
import pandas as p
import math as m
import dateExcelPython as dtxl
import numpy as np

import bhutils as bh
import bhutilscommon as bhc
import config as cfg
bh.bhInit('macroalpha')

config = bhc.Config(murex_cals_name="MUREX")


config = bhc.Config(murex_cals_name="MUREX")
print(config.db.tradereporter)
print(bh.bhVersion())

print("run date = " + str(config.run_date))
print("cob date = " + str(config.cob_date))
calculated_cob_date = bh.bhBump(_date=config.run_date, _term="-1b", _bump="n")
print("calculated cob date = " + str(calculated_cob_date))

global DBfolderPath

DBfolderPath = cfg.masterFolder + "Data/"

def DFLookup(df, lookupValue, lookupCol, resultCol, ifNA=None):
    if lookupValue in df[lookupCol].values:
        return df.loc[df[lookupCol][df[lookupCol] == lookupValue].index[0], [resultCol]].iloc[0]
    else:
        if ifNA is not None:
            return ifNA
        else:
            return '#Value not found'



def initializeFutDatabase():
    global futDB
    SQLst = "select Ticker, * from dbo.uvw_Comdty  where yellowkey = 'Comdty' and baseticker IN ('ED','L', 'ER') and LongTicker not like '%ELEC%' and FUT_LAST_TRADE_DT between " + dtxl.add_period(config.cob_date, '-4M').strftime(
        '%Y%m%d') + " and " + dtxl.add_period(config.cob_date, '10Y').strftime(
        '%Y%m%d') + " order by baseticker, FUT_LAST_TRADE_DT"
    futDB = p.DataFrame(bh.bhDbGet(bh.bhDbReadSql('ir.raw.Db', curveSvr, "Products", SQLst), 'a'))
    futDB.columns = futDB.iloc[0]
    futDB = futDB.drop(0)
    futDB['FUT_LAST_TRADE_DT'] = futDB['FUT_LAST_TRADE_DT'].apply(dtxl.convertYYYYMMDD)
    futDB = futDB[['Ticker', 'FUT_LAST_TRADE_DT']]
    futDB['Ticker'] = futDB['Ticker'].str.replace('L ', 'LL')
    futDB = futDB.rename(columns={'Ticker': 'Ticker', 'FUT_LAST_TRADE_DT': 'expDate'})


def initializeGlobalVariables():
    global staticSt1
    global staticSt2
    global curveSvr
    global Type
    global IrbtDbName
    global IrbtDbSvrName
    global RemoteServerName
    global RemoteServerPort
    global timeout
    global MktDefs
    global calendar
    global volExpTermTab
    global UserMetricMap
    global swapGeneratorMap
    global curveGeneratorMap
    global cashSettleMap
    global IrbtMetricMap
    global startDate
    global endDate
    global defStartDate
    global DBfolderPath
    global DBpaths
    global futCodeToCcyMap
    global loadedDatabase
    global FutLetterToMonthMap
    global annualizedFactorMap
    global DB_ccy_to_load
    global pricerCount
    pricerCount=0
    staticSt1 = 'tsCrv'
    staticSt2 = 'Sec'
    curveSvr = 'SQLP1-A'
    Type = 'sw'
    IrbtDbName = 'FITradePricer'
    IrbtDbSvrName = 'SQLP1-A'
    RemoteServerName = bh.bhDbGetValues(bh.bhDbReadSql('0', curveSvr, IrbtDbName,
                                                       "SELECT [value] FROM Config WHERE name='" + curveSvr + ".RemoteServer'",
                                                       '', '', "Y"), 0)[0, 0]
    RemoteServerPort = 5557
    timeout = 120

    MktDefs = bh.bhDbMktDefs('static.mkt.defs', "LiveCurves", IrbtDbSvrName, "Quants")

    cal = bh.bhDbCalendars('0', 'CURRENCY', curveSvr, 'Quants')
    calendar = bh.bhCalendarProviderDb('locus.pds.calendars', cal, 'Currency', 'Calendar')

    volExpTermTab = p.DataFrame(
        {'Implied': ['1M', '3M', '6M', '9M', '12M', '24M', '36M', '48M', '5Y', '7Y', '10Y', '15Y', '20Y', '30Y'],
         'Realised': ['1M', '3M', '6M', '9M', '12M', '24M', '36M', '48M', '5Y', '7Y', '10Y', '15Y', '20Y', '30Y'],
         'Full Realised Term': ['1M', '3M', '6M', '9M', '12M', '2Y', '3Y', '4Y', '5Y', '7Y', '10Y', '15Y', '20Y','30Y'],
         'Display': ['1M', '3M', '6M', '9M', '1Y', '2Y', '3Y', '4Y', '5Y', '7Y', '10Y', '15Y', '20Y', '30Y']})
    UserMetricMap = p.DataFrame(
        {'UserMetric': ['pv', 'strike', 'rate', 'spotpremium', 'fwdpremium', 'vol', 'bpvol', 'ann01'],
         'Scaleing': [0.001, 100, 100, 0.001, -0.001, 100, 10000 / m.sqrt(252), 1]})
    swapGeneratorMap = p.DataFrame(
        {'ccy': ['USD', 'EUR', 'GBP', 'GBP.SONIA', 'GBP.1M', 'GBP.3M', 'GBP.6M', 'USD.OIS', 'USD.3M',
                 'USD.6M', 'EUR.EONIA', 'EUR.1M', 'EUR.3M', 'EUR.6M', 'ED', 'ER', 'LL',
                 'JPY', 'CHF', 'AUD', 'CAD', 'NZD', 'SEK', 'NOK'],
         'generator': ['USD LIBOR S 3M*', 'EURIBOR A 6M*', 'GBP LIBOR S 6M*', 'GBP SONIA', 'GBP LIBOR A 1M',
                       'GBP LIBOR A 3M', 'GBP LIBOR S 6M*', 'USD OIS', 'USD LIBOR S 3M*', 'USD LIBOR S 6M',
                       'EUR EONIA', 'EURIBOR A 1M', 'EURIBOR A 3M', 'EURIBOR A 6M*', 'USD LIBOR S 3M*', 'EURIBOR A 3M',
                       'GBP LIBOR A 3M',
                       'JPY LIBOR S 6M*', 'CHF LIBOR A 6M*', 'AUD BBSW S 6M*', 'CAD CDOR S 3M', 'NZD BKBM 3M*', 'SEK STIBO A 3M', 'NOK OIBOR A 6M*' ]})
    curveGeneratorMap = p.DataFrame({'curve': ['2S10S', '5S10S', '10S30S', '2S30S', '5S30S', '2S5S'],
                                     'generator': [' CMS 10Y-2Y SIN', ' CMS 10Y-5Y SIN', ' CMS 30Y-10Y SIN',
                                                   ' CMS 30Y-2Y SIN', ' CMS 30Y-5Y SIN', ' CMS 5Y-2Y SIN']})
    cashSettleMap = p.DataFrame(
        {'id': ['C', 'CP', 'P', 'PC'], 'cashSettle': ['Cash', 'CashZC', 'Physical', 'PhysicalCleared']})
    IrbtMetricMap = p.DataFrame({'UserMetric': ['spotpremium', 'fwdpremium', 'rate', 'strike', 'vol', 'bpvol', 'ann01'],
                                 'IrbtMetric': ['PV', 'Premium', 'Rate', 'Strike', 'Vol', 'Vol', 'Ann01']})

    startDate = dt.date(2018, 1, 1)
    endDate = config.cob_date

    defStartDate = dt.date(1995, 1, 1)
    DB_ccy_to_load = ['EUR', 'USD', 'GBP', 'ER', 'ED', 'LL']
    DBpaths = p.DataFrame({'DBname': ['EUR', 'USD', 'GBP', 'ER', 'ED', 'LL', 'FX', 'JPY', 'CHF', 'AUD', 'CAD', 'NZD', 'SEK', 'NOK'],
                           'Path': [DBfolderPath + 'EUR.csv', DBfolderPath + 'USD.csv', DBfolderPath + 'GBP.csv',
                                    DBfolderPath + 'ER.csv', DBfolderPath + 'ED.csv', DBfolderPath + 'LL.csv',
                                    DBfolderPath + 'FX.csv',
                                    DBfolderPath + 'JPY.csv', DBfolderPath + 'CHF.csv', DBfolderPath + 'AUD.csv',
                                    DBfolderPath + 'CAD.csv', DBfolderPath + 'NZD.csv', DBfolderPath + 'SEK.csv', DBfolderPath + 'NOK.csv']})

    futCodeToCcyMap = p.DataFrame({'futCode': ['ER', 'ED', 'LL'], 'ccy': ['EUR', 'USD', 'GBP']})

    loadedDatabase = p.DataFrame()

    FutLetterToMonthMap = p.DataFrame({'Letter': ['F', 'G', 'H', 'J', 'K', 'M', 'N', 'Q', 'U', 'V', 'X', 'Z'],
                                       'Month': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]})
    annualizedFactorMap = p.DataFrame({'ccy': ['EUR', 'USD', 'GBP'], 'factor': [252, 252, 252]})

    initializeFutDatabase()


initializeGlobalVariables()


def loadHardDataBase(ccy):
    d = p.read_csv(DFLookup(DBpaths, ccy.upper(),'DBname', 'Path'),sep=",", header=0)
    d = d.rename(columns={d.columns[0]:'date'}) #rename first column
    try:
        d['date'] = d['date'].apply(dtxl.excel_to_python_date)  # transform Excel dates to Python
    except:
        d = d.set_index('date')
        d.index = p.to_datetime(d.index)
        return d
    if len(ccy)==2:
        d = d.rename(columns = lambda x : str(x).split('_')[0])
    return d.set_index('date')


def initializeHardDatabase():
    global hardDatabase
    hardDatabase = {}
    for ccy in DB_ccy_to_load:
        hardDatabase[ccy.upper()] = loadHardDataBase(ccy.upper())

initializeHardDatabase()


def getOptionUnderlyingFuture(ccyCode, expiryCode, undlCode):
    if undlCode.upper()[-1:] == 'E' or undlCode.upper()[-1:] == 'R' or undlCode.upper()[-1:] == 'L':
        expiryDate = getOptionExpiryDate(ccyCode, expiryCode, undlCode)
        return DFLookup(FutLetterToMonthMap, int((expiryDate.month - 1) / 3 + 1) * 3, 'Month', 'Letter') + str(
            (expiryDate.year + max(int(undlCode[0]), 1)) % 10)
    return undlCode.upper()


def getOptionExpiryDate(ccyCode, expiryCode, undlCode):
    global futTab

    if expiryCode[0].isdigit():
        return dtxl.add_period(dt.date.today(), expiryCode)

    if expiryCode.upper() != undlCode.upper():
        monthInt = int(DFLookup(FutLetterToMonthMap, expiryCode[0].upper(), 'Letter', 'Month'))
        yearInt = int(expiryCode[1:])
        if yearInt > dt.date.today().year % 10:
            yearInt = yearInt + int(dt.date.today().year / 10) * 10
        elif yearInt == (dt.date.today().year % 10) and monthInt >= dt.date.today().month:
            yearInt = dt.date.today().year
        else:
            yearInt = yearInt + int(dt.date.today().year / 10) * 10 + 10

        return dtxl.add_period(bh.bhPthQday(3, "Wed", monthInt, yearInt), '-5d').date()
    else:
        ccyCode = DFLookup(futCodeToCcyMap, ccyCode.upper(), 'ccy', 'futCode', ccyCode.upper())
        return DFLookup(futDB, (ccyCode + expiryCode).upper(), 'Ticker', 'expDate')


def convertEToptionToCalendar(ccyCode, expiryCode, undlCode):
    expSt = str((getOptionExpiryDate(ccyCode, expiryCode, undlCode) - dt.date.today()).days) + 'D'

    if undlCode == '':
        tailSt = '3M'
    elif undlCode[0].isdigit():
        tailSt = str(max(int(undlCode[0]), 1)) + 'YX3M'
    else:
        y = int(round((getOptionExpiryDate(ccyCode, undlCode, undlCode) -
                       getOptionExpiryDate(ccyCode, expiryCode, undlCode)).days / 365, 0))
        if y == 0:
            tailSt = '3M'
        else:
            tailSt = str(y) + 'YX3M'

    ccySt = DFLookup(swapGeneratorMap, ccyCode.upper(), 'ccy', 'generator')[0:3] + '.3M'

    return (ccySt, expSt, tailSt)


def getFwdOfMidcurve(ccy, effOrFwd, mtyOrTenor):
    if len(ccy) == 2:
        return getOptionUnderlyingFuture(ccy, effOrFwd, mtyOrTenor)

    if not 'X' in mtyOrTenor.upper():
        tailSt = mtyOrTenor
        if type(effOrFwd) == str:
            return effOrFwd.upper() + 'X' + mtyOrTenor.upper()
        else:
            expiryDate = effOrFwd
            if expiryDate.day == dt.date.today().day:
                nMonths = dtxl.roundMonthsDifference(dt.date.today(), expiryDate)
                if nMonths % 12 == 0:
                    return str(int(nMonths / 12)) + 'YX' + tailSt
                else:
                    return str(nMonths) + 'MX' + tailSt
            else:
                return str(dtxl.roundDaysDifference(dt.date.today(), expiryDate)) + 'DX' + tailSt

    i = mtyOrTenor.upper().index('X')

    tailSt = mtyOrTenor[i + 1:].upper()
    expSt = mtyOrTenor[:i].upper()

    if type(effOrFwd) == str:
        if effOrFwd[-1].isdigit():
            expiryDate = getOptionExpiryDate(ccy, effOrFwd, '')
        else:
            expiryDate = dtxl.add_period(dt.date.today(), effOrFwd)
    else:
        expiryDate = effOrFwd
    expiryDate = dtxl.add_period(expiryDate, expSt)

    if expiryDate.day == dt.date.today().day:
        nMonths = dtxl.roundMonthsDifference(dt.date.today(), expiryDate)
        if nMonths % 12 == 0:
            return str(int(nMonths / 12)) + 'YX' + tailSt
        else:
            return str(nMonths) + 'MX' + tailSt
    else:
        return str(dtxl.roundDaysDifference(dt.date.today(), expiryDate)) + 'DX' + tailSt


def addTStoLoadedDatabase(ts, instrLoadedName):
    global loadedDatabase
    if not ts.empty:
        loadedDatabase=p.concat([loadedDatabase, ts.rename(columns = {ts.columns[0]:instrLoadedName})], axis=1).sort_index(ascending=False)


class prodObj:
    def __init__(self, ccy, effOrFwd, mtyOrTenor, prodType, userMetric, ccy2='', swaptionSettleType='', payRec='rec',
                 paySettleType='', strike='a', underlyingClearingHouse='LCH', collateralCcy=''):
        self.ccy = ccy.upper()
        if type(effOrFwd) == str:
            self.effOrFwd = effOrFwd.upper()
            self.effOrFwdSt = self.effOrFwd
        else:
            self.effOrFwd = effOrFwd
            self.effOrFwdSt = self.effOrFwd.strftime('%Y%m%d')

        if type(mtyOrTenor) == str:
            self.mtyOrTenor = mtyOrTenor.upper()
            self.mtyOrTenorSt = self.mtyOrTenor
        else:
            self.mtyOrTenor = mtyOrTenor
            self.mtyOrTenorSt = self.mtyOrTenor.strftime('%Y%m%d')

        self.prodType = prodType.upper()
        self.userMetric = userMetric.upper()
        self.strike = strike
        self.underlyingClearingHouse = underlyingClearingHouse.upper()

        if payRec[0].upper() == 'R' or payRec[0].upper() == 'F':
            self.payRec = 'REC'
        elif payRec[0].upper() == 'P' or payRec[0].upper() == 'C':
            self.payRec = 'PAY'
        elif payRec[0].upper() == 'S':
            self.payRec = 'STR'
        else:
            self.payRec = payRec.upper()

        if ccy2 == '':
            self.ccy2 = ccy.upper()
        else:
            self.ccy2 = ccy2.upper()

        if swaptionSettleType == '':
            if prodType == 'oswp':
                self.swaptionSettleType = 'pc_lch'
            elif prodType == 'cf':
                self.swaptionSettleType = 'c'
            else:
                self.swaptionSettleType = 'pc_lch'
        else:
            self.swaptionSettleType = swaptionSettleType

        if collateralCcy == '':
            if prodType.lower() == 'irs':
                self.collateralCcy = ccy.upper()[0:3]
            else:
                self.collateralCcy = 'USD'
        else:
           self.collateralCcy = collateralCcy.upper()

        if paySettleType == '':
            if prodType == 'irs':
                self.paySettleType = 's'
            else:
                self.paySettleType = 'x'
        else:
            self.paySettleType = paySettleType

        self.instrDatabaseName = ''
        self.instrLoadedName = ''

        self.getObjFwdOfMidcurve()
        self.ann01 = ''
        self.lastValue = ''
        self.annualizingFactor = DFLookup(annualizedFactorMap,
                                          DFLookup(futCodeToCcyMap, self.ccy.upper()[:3], 'futCode', 'ccy',
                                                   self.ccy.upper()[:3])
                                          , 'ccy', 'factor')

    def getObjFwdOfMidcurve(self):
        self.underlyingFwd = getFwdOfMidcurve(self.ccy, self.effOrFwd, self.mtyOrTenor)

    def getInstrDatabaseName(self):

        if self.prodType == 'IRS' and self.userMetric == 'RATE' and str(
                self.strike).upper() == 'A' and self.collateralCcy == self.ccy:
            if len(self.ccy) > 2:
                self.instrDatabaseName = 'FWD' + self.ccy2 + str(self.effOrFwdSt) + 'X' + self.mtyOrTenorSt
                return self.instrDatabaseName
            else:
                self.instrDatabaseName = self.ccy2 + self.effOrFwd
                return self.instrDatabaseName
        elif (self.prodType == 'OSWP' or self.prodType == 'CF') and self.userMetric == 'BPVOL' and str(self.strike).upper() == 'A':
            if 'X' in self.mtyOrTenorSt:
                self.instrDatabaseName = 'MID' + self.ccy2 + self.effOrFwdSt + 'X' + self.mtyOrTenorSt
                return self.instrDatabaseName
            else:
                self.instrDatabaseName = 'VOL' + self.ccy2 + self.effOrFwdSt + 'X' + self.mtyOrTenorSt
                return self.instrDatabaseName
        else:
            self.instrDatabaseName = ''
            return self.instrDatabaseName

    def getInstrLoadedName(self):
        self.instrLoadedName = self.ccy2 + '|' + self.effOrFwdSt + '|' + self.mtyOrTenorSt + '|' + self.prodType + '|' + self.userMetric + '|' + self.swaptionSettleType + '|' + self.payRec + '|' + self.paySettleType + '|' + str(
            self.strike) + '|' + self.underlyingClearingHouse + '|' + self.collateralCcy
        return self.instrLoadedName

    def findInstrInHardDataBase(self):
        global hardDatabase
        if self.instrDatabaseName in hardDatabase[self.ccy]:
            return p.DataFrame(hardDatabase[self.ccy][self.instrDatabaseName])
        else:
            return p.DataFrame()

    def findInstrInLoadedDatabase(self):
        global loadedDatabase
        if self.instrLoadedName in loadedDatabase:
            return p.DataFrame(loadedDatabase[self.instrLoadedName])
        else:
            return p.DataFrame()

    def getInstrAnn01(self, asOfDate=calculated_cob_date):
        if self.mtyOrTenorSt[-1:].upper() == 'S' and self.prodType.upper() == 'IRS':
            self.ann01 = 1
            return self.ann01
        memoryMetric = self.userMetric
        self.userMetric = 'Ann01'
        self.ann01 = getHistoO(self, asOfDate, asOfDate).iloc[0, 0]
        self.userMetric = memoryMetric
        return self.ann01


class prodObjFX:
    def __init__(self, ccyPair, userMetric, effOrFwd='', strike='0'):
        self.ccyPair = ccyPair.upper()
        if type(effOrFwd) == str:
            self.effOrFwd = effOrFwd.upper()
            self.effOrFwdSt = self.effOrFwd
        else:
            self.effOrFwd = effOrFwd
            self.effOrFwdSt = self.effOrFwd.strftime('%Y%m%d')

        self.userMetric = userMetric.upper()
        self.strike = strike

        self.instrDatabaseName = ''
        self.instrLoadedName = ''

        self.ccyL = ccyPair[0:3]
        self.ccyR = ccyPair[-3:]
        self.lastValue = ''

    def getInstrDatabaseName(self):
        self.instrDatabaseName = self.userMetric + self.ccyPair + self.effOrFwd
        if self.strike != '0':
            self.instrDatabaseName = self.instrDatabaseName + '|' + self.strike
        return self.instrDatabaseName

    def getInstrLoadedName(self):
        self.instrLoadedName = self.ccyPair + '|' + self.userMetric + '|' + self.effOrFwd + '|' + self.strike
        return self.instrLoadedName

    def findInstrInHardDataBase(self):
        global hardDatabase
        if 'FX' in hardDatabase.keys() and self.instrDatabaseName in hardDatabase['FX']:
            return p.DataFrame(hardDatabase['FX'][self.instrDatabaseName])
        else:
            return p.DataFrame()

    def findInstrInLoadedDatabase(self):
        global loadedDatabase
        if self.instrLoadedName in loadedDatabase:
            return p.DataFrame(loadedDatabase[self.instrLoadedName])
        else:
            return p.DataFrame()


def getObjectFromInstrDatabaseName(instrDatabaseName):
    prodType = instrDatabaseName[0:3]
    ccy = instrDatabaseName[3:6]
    effOrFwdSt, mtyOrTenorSt = instrDatabaseName[6:].split('X', 1)
    collateralCcySt = 'USD'

    if prodType.upper() == 'FWD':
        prodType = 'IRS'
        userMetric = 'RATE'
        collateralCcySt = ccy
    elif prodType.upper() == 'MID':
        prodType = 'OSWP'
        userMetric = 'BPVOL'
    elif prodType.upper() == 'VOL':
        userMetric = 'BPVOL'
        if 'S' in mtyOrTenorSt:
            prodType = 'CF'
        else:
            prodType = 'OSWP'
    return prodObj(ccy, effOrFwdSt, mtyOrTenorSt, prodType, userMetric, collateralCcy=collateralCcySt)

def getObjectFromInstrLoadedName(instrLoadedName):
    tempTab = instrLoadedName.split('|')
    return prodObj(ccy = tempTab[0], effOrFwd = tempTab[1], mtyOrTenor = tempTab[2], prodType = tempTab[3], userMetric = tempTab[4],
                   swaptionSettleType = tempTab[5], payRec = tempTab[6], paySettleType = tempTab[7], strike = tempTab[8],
                   underlyingClearingHouse = tempTab[9], collateralCcy = tempTab[10])

def getFXObjectFromInstrLoadedName(instrLoadedName):
    tempTab = instrLoadedName.split('|')
    return prodObjFX(ccyPair=tempTab[0], userMetric=tempTab[1], effOrFwd=tempTab[2], strike=tempTab[3])

def getFXObjectFromInstrDatabaseName(instrDatabaseName):
    tempTab = instrDatabaseName.upper().split('|')
    ccy = tempTab[0][3:9]
    fxType = tempTab[0][0:3]
    effOrFwd = tempTab[0][9:]
    smileVal = tempTab[1] if len(tempTab) > 1 else '0'
    return prodObjFX(ccyPair=ccy, userMetric=fxType, effOrFwd=effOrFwd, strike=smileVal)

def getFXSpotHistoryTs(ccyPair, sDate, eDate):
    return bh.bhTsRead('FXspotSec', 'SNAP', 'FX.SPOT', 'FX', 'O', ccyPair[0:3] + '/' + ccyPair[-3:], 'Mid', sDate, eDate, curveSvr)

def getFXSpotHistory(ccyPair, sDate=defStartDate, eDate=config.cob_date):
    s = getFXSpotHistoryTs(ccyPair, sDate, eDate)
    try:
        return p.DataFrame(bh.bhTsGet(s, "v", '', '', '', "Y"), bh.bhTsGet(s, "d", '', '', '', "Y"), ['FXS' + ccyPair])
    except:
        return p.DataFrame()

def getCalendar(ccy):
    return bh.bhDbLookUp(calendar, ccy, 'Currency', 'Calendar', 0)

def getFXCrv(ccy, startDate, endDate):
    return bh.bhTsCrvRead(ccy + '.fx', 'CRV', 'BHCURVE', ccy + '.FX', 'O', 'ff', '', startDate, endDate, curveSvr)

def getStdCrv(ccy, startDate, endDate):
    return bh.bhTsCrvRead(ccy + '.std', 'CRV', 'BHCURVE', ccy + '.STD', 'O', 's4f', '', startDate, endDate, curveSvr)

def getBsCrv(ccy, startDate, endDate, stdCrvId):
    return bh.bhTsCrvRead(ccy + '.bs', 'CRV', 'BHCURVE', ccy + '.BS', 'O', 's4f', '', startDate, endDate, curveSvr,
                          stdCrvId)

def getFwdTsCurve(ccyPair, startDate, endDate, leftCrvTs, rightCrvTs, idNb):
    spotHisto = getFXSpotHistoryTs(ccyPair, startDate, endDate)
    leftCal = getCalendar(ccyPair[0:3])
    rightCal = getCalendar(ccyPair[-3:])
    usdCal = getCalendar('USD')
    return bh.bhCreateTsFwdCrv('fwdtscrv' + idNb, ccyPair, spotHisto, leftCrvTs, rightCrvTs, leftCal, rightCal, usdCal,
                               MktDefs)

def mergeFwdTs(ts1, ts2):
    return bh.bhTsMerge('fwdSec', ts1, ts2, '', 'newoverwrites')

def getFwdTs(ccyPair, startDate, endDate, tenor, fwdTsCrv, fwdTsid):
    leftCal = getCalendar(ccyPair[0:3])
    rightCal = getCalendar(ccyPair[-3:])
    usdCal = getCalendar("USD")
    return bh.bhTsFwdCrvRate('fwdTs' + fwdTsid, fwdTsCrv, ccyPair, tenor, leftCal, rightCal, usdCal, MktDefs)

def getFwdHistoTs(ccyPair, tenor, startDate, endDate):
    fwdTsCurve2 = getFwdTsCurve(ccyPair, startDate, endDate, getFXCrv(ccyPair[0:3], startDate, endDate),
                                getFXCrv(ccyPair[-3:], startDate, endDate), '2')
    try:
        fwdTsCurve1 = getFwdTsCurve(ccyPair, startDate, endDate, getBsCrv(ccyPair[0:3], startDate, endDate,
                                                                          getStdCrv(ccyPair[0:3], startDate, endDate)),
                                    getBsCrv(ccyPair[-3:], startDate, endDate,
                                             getStdCrv(ccyPair[-3:], startDate, endDate)), '1')
        return mergeFwdTs(getFwdTs(ccyPair, startDate, endDate, tenor, fwdTsCurve1, '1'),
                          getFwdTs(ccyPair, startDate, endDate, tenor, fwdTsCurve2, '2'))
    except:
        return getFwdTs(ccyPair, startDate, endDate, tenor, fwdTsCurve2, '2')


def getFXFwdHistory(ccyPair, tenor, sDate=defStartDate, eDate=config.cob_date):
    s = getFwdHistoTs(ccyPair, tenor, sDate, eDate)
    try:
        return p.DataFrame(bh.bhTsGet(s, "v", '', '', '', "Y"), bh.bhTsGet(s, "d", '', '', '', "Y"),
                           ['FXF' + ccyPair + tenor])
    except:

        return p.DataFrame()

def getFXVolHistoTs(ccyPair, tenor, startDate, endDate, smileDelta):
    return bh.bhTsRead('fxSecVol', 'SNAP', 'FX.SMILE', ccyPair[0:3] + '/' + ccyPair[-3:], 'O', tenor + '_' + smileDelta,
                       'Vol', startDate, endDate, curveSvr)

def getFXVolHisto(ccyPair, tenor, sDate=defStartDate, eDate=config.cob_date, smileDelta="0"):
    s = getFXVolHistoTs(ccyPair, tenor, sDate, eDate, smileDelta)
    try:
        smileSt = '' if smileDelta == '0' else '|' + smileDelta
        return p.DataFrame(bh.bhTsGet(s, "v", '', '', '', "Y"), bh.bhTsGet(s, "d", '', '', '', "Y"),
                           ['FXV' + ccyPair + tenor + smileSt])
    except:
        return p.DataFrame()

def getFXFwdHistoryO(prodObjFX, sDate=defStartDate, eDate=config.cob_date):
    return getFXFwdHistory(prodObjFX.ccyPair, prodObjFX.effOrFwd, sDate, eDate)

def getFXSpotHistoryO(prodObjFX, sDate=defStartDate, eDate=config.cob_date):
    return getFXSpotHistory(prodObjFX.ccyPair, sDate, eDate)

def  getFXVolHistoyO(prodObjFX, sDate=defStartDate, eDate=config.cob_date):
    return getFXVolHisto(prodObjFX.ccyPair, prodObjFX.effOrFwd, sDate, eDate, smileDelta = prodObjFX.strike)

def updateFXDatabase(databaseDf):
    lastDateReal = databaseDf.first_valid_index()
    startDate = databaseDf.first_valid_index()
    endDate = config.cob_date
    df = p.DataFrame()
    for instSt in databaseDf.columns:
        print(instSt)
        prodObj = getFXObjectFromInstrDatabaseName(instSt)
        ts1 = getHistoO(prodObj, sDate = startDate, eDate = endDate, addToLoadedDatabase=False, getFromDataBase=False)
        if not ts1.empty:
            df = p.concat([df, ts1], axis=1).sort_index(ascending=False)
        else:
            pass
    databaseDf =p.concat([databaseDf, df[:lastDateReal+dt.timedelta(days=1)]])
    return databaseDf[~databaseDf.index.duplicated(keep='first')].sort_index(ascending=False)


def updateAndSaveFXDatabase():
    if 'FX' not in hardDatabase.keys():
        hardDatabase['FX'] = loadHardDataBase('FX')
    updateFXDatabase(hardDatabase['FX']).to_csv(DBfolderPath + 'FX' + '.csv', na_rep='#N/A')

def updateDatabase(databaseDf):
    lastDateReal = databaseDf.first_valid_index()
    startDate = databaseDf.first_valid_index()
    endDate = config.cob_date
    df = p.DataFrame()
    for instSt in databaseDf.columns:
        print(instSt)
        prodObj = getObjectFromInstrDatabaseName(instSt)
        ts1 = getHistoO(prodObj, sDate = startDate, eDate = endDate, addToLoadedDatabase=False, getFromDataBase=False)
        if not ts1.empty:
            ts1.columns = [prodObj.getInstrDatabaseName()]
            df = p.concat([df, ts1], axis=1).sort_index(ascending=False)
        else:
            pass
    databaseDf =p.concat([databaseDf, df[:lastDateReal+dt.timedelta(days=1)]])
    databaseDf.index = p.to_datetime(databaseDf.index).map(dtxl.python_to_excel_date).astype(int)

    return databaseDf[~databaseDf.index.duplicated(keep='first')].sort_index(ascending=False).round(9)

def updateAndSaveDatabase(ccy):
    if ccy not in hardDatabase.keys():
        hardDatabase[ccy.upper()] = loadHardDataBase(ccy.upper())
    updateDatabase(hardDatabase[ccy]).to_csv(DBfolderPath + ccy + '.csv', na_rep='#N/A')


def getFWDSwapHisto(ccy, EffOrFwd, MtyOrTenor, Curve=''):
    if not isinstance(EffOrFwd, str) or not isinstance(MtyOrTenor, str):
        return p.DataFrame()

    if len(ccy)==2:
        ccy, EffOrFwd, MtyOrTenor  = convertEToptionToCalendar(ccy, EffOrFwd, MtyOrTenor)
        Curve = ccy[0:3]

    if Curve == '':
        Curve = ccy
    else:
        Curve = Curve

    RSId2 = bh.bhDbCreate("dbExpr" + Curve + EffOrFwd + 'X' + MtyOrTenor, ('CCY', 'TERMSTRING', 'FIELD'),
                          "S", "F", (Curve, EffOrFwd + 'X' + MtyOrTenor, ''))

    RsId = bh.bhReadMergedTsCurves("S_merged_ts_STD",
                                   staticSt1 + Curve + EffOrFwd + 'X' + MtyOrTenor + staticSt2 + '_STD',
                                   startDate, endDate, "COB", Curve + '.STD', "CRV", "O", "BHCURVE", 'Curves',
                                   curveSvr, 'Histories', curveSvr)
    Curve = Curve + '.STD'

    if bh.bhIfNA(bh.bhTsCrvGet(bh.bhDbGetColValues(RsId, 'TsCurve'), "s") + 0, 0) <= 0:
        Curve = Curve[:-4]
        RsId = bh.bhReadMergedTsCurves("S_merged_ts", staticSt1 + Curve + EffOrFwd + 'X' + MtyOrTenor + staticSt2,
                                       startDate, endDate, "COB", Curve, "CRV", "O", "BHCURVE", 'Curves',
                                       curveSvr, 'Histories', curveSvr)

    CrvsTSId = bh.bhDbGetColValues(RsId, "TsCurve")
    s = bh.bhTsRate(staticSt1 + staticSt2 + Curve + EffOrFwd + 'X' + MtyOrTenor, CrvsTSId, EffOrFwd, MtyOrTenor, Type,
                    Curve, MktDefs, calendar, '', 1)
    return p.DataFrame(bh.bhTsGet(s, "v", '', '', '', "Y"), bh.bhTsGet(s, "d", '', '', '', "Y"),
                       ['FWD' + ccy + EffOrFwd + 'X' + MtyOrTenor])


def getBPVOL(ccy, EffOrFwd, MtyOrTenor):
    impDispSt = DFLookup(volExpTermTab, EffOrFwd.upper(), 'Display', 'Implied', EffOrFwd)
    s = bh.bhTsCalcM('SwapBpVols' + staticSt2 + ccy + EffOrFwd + 'X' + MtyOrTenor,
                     bh.bhTsRead("SwapVols" + staticSt2 + ccy + EffOrFwd + 'X' + MtyOrTenor + 'BPVOL', 'SNAP',
                                 "IR.SABR", ccy, 'O', impDispSt + '_' + MtyOrTenor, 'AtmVol',
                                 startDate, endDate, curveSvr), 'mult', (100 / m.sqrt(252)))
    try:
        return p.DataFrame(bh.bhTsGet(s, "v", '', '', '', "Y"), bh.bhTsGet(s, "d", '', '', '', "Y"),
                           ['VOL' + ccy + EffOrFwd + 'X' + MtyOrTenor])
    except:
        return p.DataFrame()


def getPricerHisto(ccy, ccyGenerator, EffOrFwd, MtyOrTenor, UserMetric, prodType, PayRec, Strike='a',
                   PaySettleType='s', UnderlyingClearingHouse='LCH', SwaptionSettleType='', CollateralCcy='USD'):
    global  pricerCount

    ccy = ccy.upper()
    ccyGenerator = ccyGenerator.upper()
    Handle = '1'

    if type(EffOrFwd) == str:
        EffOrFwdSt = EffOrFwd.upper()
    else:
        EffOrFwdSt = EffOrFwd.strftime('%Y%m%d')
        EffOrFwd = dtxl.python_to_excel_date(EffOrFwd)

    if type(MtyOrTenor) == str:
        MtyOrTenorSt = MtyOrTenor.upper()
    else:
        MtyOrTenorSt = MtyOrTenor.strftime('%Y%m%d')
        MtyOrTenor = dtxl.python_to_excel_date(MtyOrTenor)

    if len(ccy) == 2:
        ccy, EffOrFwd, MtyOrTenor = convertEToptionToCalendar(ccy, EffOrFwdSt, MtyOrTenor)
        CollateralCcy = ccy[0:3]

    if MtyOrTenorSt[-1:] == 'S':
        Generator = ccyGenerator + DFLookup(curveGeneratorMap, MtyOrTenorSt, 'curve', 'generator')
        MtyOrTenor = ''
        UnderlyingClearingHouse = ''
    else:
        Generator = DFLookup(swapGeneratorMap, ccyGenerator.upper(), 'ccy', 'generator')

    # ccy = ccy[0:3]
    if SwaptionSettleType != '':
        SwaptionSettleType = DFLookup(cashSettleMap, bh.bhSplitString(SwaptionSettleType, '_', 0).item(0).upper(), 'id',
                                      'cashSettle', True)

    IrbtMetric = DFLookup(IrbtMetricMap, UserMetric.lower(), 'UserMetric', 'IrbtMetric')

    TradeLabel = ccy + '|' + EffOrFwdSt + MtyOrTenorSt + '|' + UserMetric + '|' + prodType + '|' + PayRec + '|' + str(
        Strike)
    NewId = ccy + EffOrFwdSt + MtyOrTenorSt + '.filtered'

    columnNames = ['TradeId', 'ccy', 'SVMInstrument', 'Generator', 'EffExp', 'MtyTnr', 'Strike', 'PayoutType',
                   'Nominal', 'SwaptionSettleType', 'PaySettleType', 'TradeLabel', 'UnderlyingClearingHouse',
                   'CollateralCcy']
    Data2 = [1, ccy, prodType, Generator, EffOrFwd, MtyOrTenor, Strike, PayRec,
             1000000, SwaptionSettleType, PaySettleType, TradeLabel, UnderlyingClearingHouse.upper(),
             CollateralCcy.upper()]
    TradesDb = bh.bhDbRange('a', [columnNames, Data2], True)

    OldId = bh.bhTsFiRemoteRiskCalc("fws", TradesDb, None, [IrbtMetric],
                                    startDate, endDate, None, IrbtDbName, curveSvr, RemoteServerName, RemoteServerPort,
                                    timeout,
                                    None, None, None, None, None)
    pricerCount =  pricerCount +1
    try:
        TSIds = bh.bhTsFilter(NewId,
                              bh.bhDbLookUp(bh.bhDbFilter('0', OldId, "Status='OK'"), IrbtMetric.lower(), 'Metric',
                                            'TS'), 'v')
    except:
        return p.DataFrame()

    NewId = ccy + EffOrFwdSt + 'X' + MtyOrTenorSt + '.scaled'
    s = bh.bhTsCalcM(NewId, TSIds, "mult", DFLookup(UserMetricMap, UserMetric.lower(), 'UserMetric',
                                                    'Scaleing'))  # Scale by factor  chart.metrics.scaleing.tbl
    print('pricer:' + str(pricerCount))
    return p.DataFrame(bh.bhTsGet(s, "v", '', '', '', "Y"), bh.bhTsGet(s, "d", '', '', '', "Y"), [TradeLabel])


def getPricerHistoO(prodObj, sDate=defStartDate, eDate=config.cob_date):
    global startDate
    global endDate

    startDate = sDate
    endDate = eDate

    return getPricerHisto(prodObj.ccy, prodObj.ccy2, prodObj.effOrFwd, prodObj.mtyOrTenor, prodObj.userMetric,
                          prodObj.prodType, prodObj.payRec, prodObj.strike, prodObj.paySettleType,
                          prodObj.underlyingClearingHouse, prodObj.swaptionSettleType, prodObj.collateralCcy)


def getFWDSwapHistoO(prodObj):
    return getFWDSwapHisto(prodObj.ccy, prodObj.effOrFwd, prodObj.mtyOrTenor, prodObj.ccy2)


def getBPVOLO(prodObj):
    return getBPVOL(prodObj.ccy, prodObj.effOrFwd, prodObj.mtyOrTenor)


def getHistoO(prodObj, sDate=defStartDate, eDate=config.cob_date, addToLoadedDatabase = True, getFromDataBase=True):
    global startDate
    global endDate

    prodObj.getInstrDatabaseName()
    if getFromDataBase:
        ts1 = prodObj.findInstrInHardDataBase()
        if not ts1.empty:
            try:
                ts1.index = p.MultiIndex.from_tuples(ts1.index)
                ts1.index = ts1.index.levels[0].sort_values(ascending=False)
            except:
                pass
            ts1.index = p.to_datetime(ts1.index)
            return ts1

    prodObj.getInstrLoadedName()
    if getFromDataBase:
        ts1 = prodObj.findInstrInLoadedDatabase()
        if not ts1.empty:
            try:
                ts1.index = p.MultiIndex.from_tuples(ts1.index)
                ts1.index = ts1.index.levels[0].sort_values(ascending=False)
            except:
                pass
            ts1.index = p.to_datetime(ts1.index)
            return ts1
        ######NEW FX PART######
    if prodObj.userMetric[0:2] == 'FX':
        if prodObj.userMetric == 'FXS':
            ts1 = getFXSpotHistoryO(prodObj, sDate, eDate)
        elif prodObj.userMetric == 'FXF':
            ts1 = getFXFwdHistoryO(prodObj, sDate, eDate)
        else:
            ts1 = getFXVolHistoyO(prodObj, sDate, eDate)

        try:
            ts1.index = p.MultiIndex.from_tuples(ts1.index)
            ts1.index = ts1.index.levels[0].sort_values(ascending=False)
        except:
            pass
        ts1.index = p.to_datetime(ts1.index)
        if addToLoadedDatabase:
            addTStoLoadedDatabase(ts1, prodObj.instrLoadedName)
        return ts1

    if prodObj.mtyOrTenorSt[-1:].upper() == 'S' and prodObj.prodType.upper() == 'IRS':
        curveSt = prodObj.mtyOrTenorSt.upper()
        tempObj = copy.copy(prodObj)
       tailSt = curveSt[curveSt.index('S') + 1:-1] + 'Y'
        tempObj.mtyOrTenor = tailSt
        tempObj.mtyOrTenorSt = tailSt
        ts1 = getHistoO(tempObj, sDate, eDate, addToLoadedDatabase, getFromDataBase)
        tailSt = curveSt[0:curveSt.index('S')] + 'Y'
        tempObj.mtyOrTenor = tailSt
        tempObj.mtyOrTenorSt = tailSt
        ts2 = getHistoO(tempObj, sDate, eDate)
        ts1= ts1.sub(ts2.iloc[:, 0], axis=0).rename(columns = { ts1.columns[0]: prodObj.instrLoadedName}) # new 11Feb20
        ts1.index = p.to_datetime(ts1.index) # new 11Feb20
        return ts1#ts1.sub(ts2.iloc[:, 0], axis=0).rename(columns = { ts1.columns[0]: prodObj.instrLoadedName}) # new 11Feb20

    startDate = sDate
    endDate = eDate

    ts1 = getPricerHistoO(prodObj, sDate, endDate)
    if not ts1.empty:
        try:
            ts1.index = p.MultiIndex.from_tuples(ts1.index)
            ts1.index = ts1.index.levels[0].sort_values(ascending=False)
        except:
            pass
    else:
        TradeLabel = prodObj.ccy + '|' + prodObj.effOrFwdSt + prodObj.mtyOrTenorSt + '|' + prodObj.userMetric + '|' + prodObj.prodType + '|' + prodObj.payRec + '|' + str(
            prodObj.strike)
        ts1 = p.DataFrame(columns=[TradeLabel])

    if not ts1.empty:
        endDate = ts1.index[-1].date()
    if prodObj.userMetric.upper() == 'RATE' and prodObj.prodType.upper() == 'IRS':

        if endDate > sDate:

            ts2 = getFWDSwapHistoO(prodObj)
            if not ts2.empty:
                try:
                    ts2.index = p.MultiIndex.from_tuples(ts2.index)
                    ts2.index = ts2.index.levels[0].sort_values(ascending=False)
                except:
                    pass
                ts2 = ts2.rename(columns={ts2.columns[0]: ts1.columns[0]})
                ts1 = ts1.append(ts2[~ts2.index.isin(ts1.index)])

    if prodObj.userMetric.upper() == 'BPVOL' and prodObj.prodType.upper() == 'OSWP' and 'X' not in prodObj.mtyOrTenor.upper():
        if endDate > sDate:

            ts2 = getBPVOLO(prodObj)
            if not ts2.empty:
                try:
                    ts2.index = p.MultiIndex.from_tuples(ts2.index)
                    ts2.index = ts2.index.levels[0].sort_values(ascending=False)
                except:
                    pass
                ts2 = ts2.rename(columns={ts2.columns[0]: ts1.columns[0]})
                ts1 = ts1.append(ts2[~ts2.index.isin(ts1.index)])

    ts1.index = p.to_datetime(ts1.index)
    if addToLoadedDatabase:
        addTStoLoadedDatabase(ts1, prodObj.instrLoadedName)
    return ts1

def convertToyymmdd(s):
    if type(s) == str:
        return s.upper()
    else:
        return s.strftime('%Y%m%d')


def divideListIntoChunks(l, n):
    return [l[i:i + n] for i in range(0, len(l), n)]

def getPricerHistoBatch(prodObjListFull, startDate, endDate, addToLoadedDatabase = True):
    N_MAX_REQUEST = 900
    bulkResults = p.DataFrame()

    for prodObjList in divideListIntoChunks(prodObjListFull, N_MAX_REQUEST):

        ccy = [x.ccy for x in prodObjList]
        ccyGenerator = [x.ccy2 for x in prodObjList]
        EffOrFwd = [x.effOrFwd for x in prodObjList]
        MtyOrTenor = [x.mtyOrTenor for x in prodObjList]
        UserMetric = [x.userMetric for x in prodObjList]
        prodType = [x.prodType for x in prodObjList]
        PayRec = [x.payRec for x in prodObjList]
        Strike = [x.strike for x in prodObjList]
        PaySettleType = [x.paySettleType for x in prodObjList]
        UnderlyingClearingHouse = [x.underlyingClearingHouse for x in prodObjList]
        SwaptionSettleType = [x.swaptionSettleType for x in prodObjList]
        CollateralCcy = [x.collateralCcy for x in prodObjList]
        tradeList = p.DataFrame({'tradeId': [x.getInstrLoadedName() for x in prodObjList]})

        ccy = [x.upper() for x in ccy]
        ccyGenerator = [x.upper() for x in ccyGenerator]
        Handle = [str(x) for x in range(1, len(ccy), 1)]

        EffOrFwdSt = [convertToyymmdd(x) for x in EffOrFwd]

        MtyOrTenorSt = [x.upper() for x in MtyOrTenor]

        # if len(ccy)==2:
        #    ccy, EffOrFwd, MtyOrTenor  = convertEToptionToCalendar(ccy, EffOrFwdSt, MtyOrTenor)
        CollateralCcy = [x[0:3].upper() for x in ccy]

        Generator = ccyGenerator

        for x in range(0, len(MtyOrTenorSt)):
            if MtyOrTenorSt[x][-1:] == 'S':
                Generator[x] = ccyGenerator[x] + DFLookup(curveGeneratorMap, MtyOrTenorSt[x], 'curve', 'generator')
                MtyOrTenor[x] = ''
                UnderlyingClearingHouse[x] = ''
            else:
                Generator[x] = DFLookup(swapGeneratorMap, ccyGenerator[x].upper(), 'ccy', 'generator')
                UnderlyingClearingHouse[x] = UnderlyingClearingHouse[x].upper()

            # ccy = ccy[0:3]
            if SwaptionSettleType[x] != '':
                SwaptionSettleType[x] = DFLookup(cashSettleMap,
                                                 bh.bhSplitString(SwaptionSettleType[x], '_', 0).item(0).upper(), 'id',
                                                 'cashSettle', True)

        IrbtMetric = [DFLookup(IrbtMetricMap, x.lower(), 'UserMetric', 'IrbtMetric') for x in UserMetric]

        # TradeLabel = ccy + '|' + EffOrFwdSt + MtyOrTenorSt + '|' +  UserMetric + '|' +  prodType + '|' +  PayRec + '|' + str(Strike)
        TradeLabel = list(map('|'.join, zip(ccy, EffOrFwdSt, )))
        TradeLabel = list(map(''.join, zip(TradeLabel, MtyOrTenorSt)))
        TradeLabel = list(map('|'.join, zip(TradeLabel, UserMetric, prodType, PayRec, [str(s) for s in Strike])))

        # NewId =  list(map(''.join, zip(ccy , EffOrFwdSt, [s + '.filtered' for s in MtyOrTenorSt])))

        columnNames = ['TradeId', 'ccy', 'SVMInstrument', 'Generator', 'EffExp', 'MtyTnr', 'Strike', 'PayoutType',
                       'Nominal', 'SwaptionSettleType', 'PaySettleType', 'TradeLabel', 'UnderlyingClearingHouse',
                       'CollateralCcy']
        columntypes = ['int', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'double', 'string',
                       'string', 'string', 'string', 'string']

        Data2 = p.DataFrame(
            np.transpose(np.array([tradeList.index, ccy, prodType, Generator, EffOrFwd, MtyOrTenor, Strike, PayRec,
                                   [1000000 for s in ccy], SwaptionSettleType, PaySettleType, TradeLabel,
                                   UnderlyingClearingHouse, CollateralCcy])), columns=columnNames)

        TradesDb = bh.bhDbCreate('a', _columnnames=columnNames, _data=Data2)
        # list(range(1,len(ccy)+1))

        OldId = bh.bhTsFiRemoteRiskCalc(_handle="1", _tradesdb=TradesDb, _pblevals=IrbtMetric[0], _startdate=startDate,
                                        _enddate=endDate,
                                        _irbtdbname=IrbtDbName, _irbtdbsrvname=curveSvr, _remoteservername=RemoteServerName,
                                        _remoteserverport=RemoteServerPort, _timeout=timeout)
        OldId = p.DataFrame(bh.bhDbGet(OldId, 'a'))  # .set_index('Tradeid')
       OldId.columns = OldId.iloc[0]

        scaleFactor = DFLookup(UserMetricMap, UserMetric[0].lower(), 'UserMetric', 'Scaleing')

        for index, row in OldId.iterrows():
            if row['Status'] == 'OK':
                bulkResults = p.concat([bulkResults, p.DataFrame(
                    {tradeList.loc[row['TradeId']][0]: bh.bhTsGet(_tsid=row['TS'], _outputtype='v').flatten()*scaleFactor},
                    index=bh.bhTsGet(_tsid=row['TS'], _outputtype='d').flatten())], axis=1, sort=False)

   if addToLoadedDatabase:
        global loadedDatabase
        if not bulkResults.empty:
            loadedDatabase = p.concat([loadedDatabase, bulkResults], axis=1).sort_index(ascending=False)

    return bulkResults
