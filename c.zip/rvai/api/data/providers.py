from gioutils.blpw import BlpQuery

bq = BlpQuery(timeout=50000).start()
