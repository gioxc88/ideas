from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from sqlalchemy import create_engine
import platform


def get_engine(server='SQLP-A', db='master'):
    server = server.upper()
    driver = 'SQL+Server' if platform.system() == 'Windows' else 'ODBC+Driver+17+for+SQL+Server'

    engine = create_engine(f'mssql+pyodbc://{server}/{db}?trusted_connection=yes&driver={driver}')
    return engine


# Base = automap_base()
# engine = get_engine(db='Curves')
# engine.connect()
# Base.prepare(autoload_with=engine)


