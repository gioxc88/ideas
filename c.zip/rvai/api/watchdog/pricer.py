from functools import partial

import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay

from gioutils.gui.pandas import millifyp as millify
from gioutils.ezutils import (
    bh,
)
from gioutils.utils import (
    today,
)

pd.options.plotting.backend = "plotly"
pd.options.display.float_format = partial(millify, pct=None, decimal=4)

SEP = '__'


group_transform = {
    'trade': lambda index, group, ccy, target_mult: index,
    'id': lambda index, group, ccy, target_mult: 'total',
    'currency': lambda index, group, ccy, target_mult: ccy.index[0] if len(ccy) == 1 else "",
    'local_pv': lambda index, group, ccy, target_mult: group['local_pv'].sum(),
    'pv': lambda index, group, ccy, target_mult: group['pv'].sum(),
    'price_cents': lambda index, group, ccy, target_mult: (group['price_cents'] * group['notional']).sum() /
                                                           group['notional'].abs().iloc[0],
    'fwd_price_cents': lambda index, group, ccy, target_mult: (group['fwd_price_cents'] * group['notional']).sum() /
                                                               group['notional'].abs().iloc[0],
    'price_bps': lambda index, group, ccy, target_mult: (group['price_bps'] * group['notional']).sum() /
                                                         group['notional'].abs().iloc[0],
    'price_unit': lambda index, group, ccy, target_mult: (group['price_unit'] * group['notional']).sum() /
                                                          group['notional'].abs().iloc[0],
    'size': lambda index, group, ccy, target_mult: ' x '.join([millify(x) for x in group['notional']]),
    'strikes': lambda index, group, ccy, target_mult: ' x '.join([str(round(x, 3)) for x in group['strike']]) if not
    group['strike'].isna().all() else '-',
    'fwd_rate': lambda index, group, ccy, target_mult: (
            group['fwd_rate'] * np.sign(group['notional'])).sum() if not target_mult.get(
        "fwd_rate") else (group['fwd_rate'] * np.sign(group['delta']) * np.asarray(
        target_mult.get("fwd_rate"))).sum(),
    'fx_spot': lambda index, group, ccy, target_mult: group['fx_spot'].iloc[0],
    'fx_fwd': lambda index, group, ccy, target_mult: group['fx_fwd'].iloc[0],
    'delta': lambda index, group, ccy, target_mult: group['delta'].sum(),
}


class Pricer:

    def get_data(self, runner, trades, targets, metrics=None, start_date=None, more_columns=None, ):
        more_columns = more_columns or []
        start_date = start_date or today() + BDay() - BDay()
        all_trades = []
        i = 0
        for key, val in trades.items():
            if isinstance(val, dict):
                for key2, trade in val.items():
                    trade.id = f"{key}{SEP}{key2}"
                    all_trades.append(trade)
                    i += 1
            elif isinstance(val, list):
                for trade in val:
                    trade.id = f"{key}{SEP}{i}"
                    all_trades.append(trade)
                    i += 1
        self.trades = all_trades
        if today() + BDay() - BDay() != today():
            start_date = start_date or today() + BDay() - BDay()
            df = runner.run(metrics, all_trades, start_date=start_date, attach_params=True)
        else:
            df = runner.run(metrics, all_trades, attach_params=True)

        # df = df.set_index('id').loc[[t.id  for t in all trades]]
        res = pd.concat(
            [pd.DataFrame(df['id'].str.split(SEP).to_list(), columns=['trade', 'id']), runner.df.drop('id', axis=1)],
            axis=1)
        self._res = res
        col_order = [
            *res.columns[
                (~res.columns.isin([metric.label for metric in metrics])) & (~res.columns.str.startswith('_'))],
            *[metric.label for metric in metrics],
            *res.columns[res.columns.str.startswith('_')]
        ]
        col_order = [col for col in col_order if col in res]
        res['notional'] = res['notional'].replace('', np.nan).astype(float)

        res = res.loc[:, col_order]
        res = res.set_index('trade').loc[[*trades], :].reset_index().replace('', np.nan).infer_objects()
        self.data = res

        ress = []
        all_totals = []
        for index, group in res.groupby('trade', sort=False):
            # display(group)

            target_mult = targets.get(index, {}).get('mult', {})
            ccy = group['_currency'].value_counts()
            totals = {}
            for key in group_transform:
                try:
                    totals[key] = group_transform[key](index, group, ccy, target_mult)
                except:
                    pass
            totals = pd.Series(totals).to_frame().T
            r = pd.concat([totals, group])[['size', 'strikes', *col_order]]
            ress.append(r)
            all_totals.append(totals)
        ress = pd.concat(ress)
        all_totals = pd.concat(all_totals)
        self.all_totals = all_totals

        self.res = ress.infer_objects().reset_index(drop=True).drop('period', axis=1)
        total = all_totals.dropna(axis=1, how='all').drop("id", axis=1).set_index('trade')
        # ress._total = total

        targets_ = pd.DataFrame(targets).T
        if 'mult' in targets_:
            targets_ = targets_.drop('mult', axis=1)
        exprs = {}
        for col in total:
            exprs[col] = bh.bhTsCalcExpression(
                resultnames=range(len(targets_)),  # if omitted it doesn't work with multiple expressions at once,
                expressions=[*targets_.index],
                varnamesorhndl=[*total.index],
                varvalues=total[col]
            )
        exprs = pd.DataFrame(exprs, index=targets_.index)

        watch = pd.concat([exprs, targets_], axis=1)
        # total.merge(exprs, right_index=True, left_index=True, how='right')

        watch = watch.assign(breach=watch.apply(
            lambda row: eval(f"{row[row['var']]} {row['op']} {row['target']}") if not pd.isnull(
                row['target']) else False, axis=1))
        watch_col_order = ['size', 'strikes', 'var', 'op', 'target']
        watch_col_order = [*watch_col_order, *[col for col in watch if col not in watch_col_order]]
        watch = watch[watch_col_order]
        self.watch = watch.infer_objects()
