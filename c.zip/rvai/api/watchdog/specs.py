

def get_trades(clarion):
    trades = dict(
        sfr_u3u4_er_z3z4=[
            clarion.instruments.RatesShortTermFuture(
                currency='USD',
                instrument_name='SOFR 3M CME',
                tenor='U3',
                notional=1,
            ),
            clarion.instruments.RatesShortTermFuture(
                currency='USD',
                instrument_name='SOFR 3M CME',
                tenor='U4',
                notional=-1,
            ),
            clarion.instruments.RatesShortTermFuture(
                currency='EUR',
                instrument_name='EURIBOR 3M ICE',
                tenor='Z3',
                notional=-1,
            ),
            clarion.instruments.RatesShortTermFuture(
                currency='EUR',
                instrument_name='EURIBOR 3M ICE',
                tenor='Z4',
                notional=1,
            ),
        ],
        er_sfr_m4=[
            clarion.instruments.RatesShortTermFuture(
                currency='EUR',
                instrument_name='EURIBOR 3M ICE',
                tenor='M4',
                notional=1,
            ),
            clarion.instruments.RatesShortTermFuture(
                currency='USD',
                instrument_name='SOFR 3M CME',
                tenor='M4',
                notional=-1,
            ),
        ],
        ff_q3z3_er_h4h5=[
            clarion.instruments.RatesShortTermFuture(
                currency='USD',
                instrument_name='FEDFUNDS AVG 1M CME',
                tenor='Q3',
                notional=1,
            ),
            clarion.instruments.RatesShortTermFuture(
                currency='USD',
                instrument_name='FEDFUNDS AVG 1M CME',
                tenor='Z3',
                notional=-1,
            ),
            clarion.instruments.RatesShortTermFuture(
                currency='EUR',
                instrument_name='EURIBOR 3M ICE',
                tenor='H4',
                notional=-1,
            ),
            clarion.instruments.RatesShortTermFuture(
                currency='EUR',
                instrument_name='EURIBOR 3M ICE',
                tenor='H5',
                notional=1,
            ),
        ],
        srf_z3z4z5=[
            clarion.instruments.RatesShortTermFuture(
                currency='USD',
                instrument_name='SOFR 3M CME',
                tenor='Z3',
                notional=1,
            ),
            clarion.instruments.RatesShortTermFuture(
                currency='USD',
                instrument_name='SOFR 3M CME',
                tenor='Z4',
                notional=-1.9,
            ),
            clarion.instruments.RatesShortTermFuture(
                currency='USD',
                instrument_name='SOFR 3M CME',
                tenor='Z5',
                notional=1,
            ),
        ],
        eur_bear_flat_9m1y_9m2y=[
            clarion.instruments.RatesSwaption(
                currency='EUR',
                instrument_name='EURIBOR A 3M',
                expiry='9m',
                tenor='1y',
                strike='3.65',
                swaption_type='Pay',
                notional=2e9,
                settle_type='Cash Price',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
            clarion.instruments.RatesSwaption(
                currency='EUR',
                instrument_name='EURIBOR A 6M',
                expiry='9m',
                tenor='2y',
                strike='3.4',
                swaption_type='Pay',
                notional=-1e9,
                settle_type='Cash Price',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),

            clarion.instruments.RatesSwaption(
                currency='EUR',
                instrument_name='EURIBOR A 6M',
                expiry='9m',
                tenor='2y',
                strike='2.8',
                swaption_type='Rec',
                notional=1e9,
                settle_type='Cash Price',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),

            clarion.instruments.RatesSwaption(
                currency='EUR',
                instrument_name='EURIBOR A 6M',
                expiry='9m',
                tenor='2y',
                strike='2.0',
                swaption_type='Rec',
                notional=-1e9,
                settle_type='Cash Price',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
        ],
        eur3m_bull_steep_15m1y_15m1y1y=[
            clarion.instruments.RatesSwaption(
                currency='EUR',
                instrument_name='EURIBOR A 3M',
                expiry='2024-05-13',
                tenor='1y',
                strike='1.96',
                swaption_type='Rec',
                notional=1e9,
                settle_type='Cash Price',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
            clarion.instruments.RatesSwaption(
                currency='EUR',
                instrument_name='EURIBOR A 3M',
                expiry='2024-05-13',
                tenor='1yx1y',
                strike='1.5',
                swaption_type='Rec',
                notional=-1e9,
                settle_type='Cash Price',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
        ],
        eur6m_bull_steep_30m2y_30m7y=[
            clarion.instruments.RatesSwaption(
                currency='EUR',
                instrument_name='EURIBOR A 6M',
                expiry='30m',
                tenor='2y',
                strike='1.8',
                swaption_type='Rec',
                notional=400e6,
                settle_type='Cash Price',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
            clarion.instruments.RatesSwaption(
                currency='EUR',
                instrument_name='EURIBOR A 6M',
                expiry='30m',
                tenor='7y',
                strike='1.8',
                swaption_type='Rec',
                notional=-120e6,
                settle_type='Cash Price',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
        ],
        eur6m_payer_spead_18m2y=[
            clarion.instruments.RatesSwaption(
                currency='EUR',
                instrument_name='EURIBOR A 6M',
                expiry='2024-08-24',
                tenor='2y',
                strike='3.50',
                swaption_type='Pay',
                notional=400e6,
                settle_type='Physical Cleared LCH',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
            clarion.instruments.RatesSwaption(
                currency='EUR',
                instrument_name='EURIBOR A 6M',
                expiry='2024-08-24',
                tenor='2y',
                strike='4.20',
                swaption_type='Pay',
                notional=-520e6,
                settle_type='Physical Cleared LCH',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
        ],
        eur6m_fly_2y2y_4y2y_6y2y=[
            clarion.instruments.RatesSwap(
                currency='EUR',
                instrument_name='EURIBOR A 6M',
                notional=256e6,
                strike='a',
                start_date='2y',
                tenor='2y',
                swap_type='Rec',
                clearing_house='LCH',
            ),
            clarion.instruments.RatesSwap(
                currency='EUR',
                instrument_name='EURIBOR A 6M',
                notional=547e6,
                strike='a',
                start_date='4y',
                swap_type='Pay',
                tenor='2y',
                clearing_house='LCH',
            ),
            clarion.instruments.RatesSwap(
                currency='EUR',
                instrument_name='EURIBOR A 6M',
                notional=288e6,
                strike='a',
                start_date='6y',
                tenor='2y',
                swap_type='Rec',
                clearing_house='LCH',
            )
        ],
        ester_fly_6m1y_3y2y_5y2y=[
            clarion.instruments.RatesSwap(
                currency='EUR',
                instrument_name='ESTER A',
                notional=233e6,
                strike='a',
                start_date='2023-07-13',
                tenor='1y',
                swap_type='Rec',
                clearing_house='LCH',
            ),
            clarion.instruments.RatesSwap(
                currency='EUR',
                instrument_name='ESTER A',
                notional=261e6,
                strike='a',
                start_date='2026-01-13',
                tenor='2y',
                swap_type='Pay',
                clearing_house='LCH',
            ),
            clarion.instruments.RatesSwap(
                currency='EUR',
                instrument_name='ESTER A',
                notional=137e6,
                strike='a',
                start_date='2028-01-13',
                tenor='2y',
                swap_type='Rec',
                clearing_house='LCH',
            )
        ],
        # ecb_mar_may_spread=[
        #     clarion.instruments.RatesSwap(
        #         currency='EUR',
        #         instrument_name='ESTER A',
        #         notional=2.5e9,
        #         strike='a',
        #         start_date='2023-03-22',
        #         tenor='2023-05-10',
        #         swap_type='Rec',
        #         clearing_house='LCH',
        #     ),
        #     clarion.instruments.RatesSwap(
        #         currency='EUR',
        #         instrument_name='ESTER A',
        #         notional=2.9e9,
        #         strike='a',
        #         start_date='2023-05-10',
        #         tenor='2023-06-21',
        #         swap_type='Pay',
        #         clearing_house='LCH',
        #     ),
        # ],
        sofr_bull_steep_2y7y_2y30y=[
            clarion.instruments.RatesSwaption(
                currency='USD',
                instrument_name='SOFR A',
                expiry='2025-02-21',  # '2y',
                tenor='7y',
                strike='2.3',
                swaption_type='Rec',
                notional=80e6,
                settle_type='Cash Price',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
            clarion.instruments.RatesSwaption(
                currency='USD',
                instrument_name='SOFR A',
                expiry='2025-02-21',  # '2y',
                tenor='30y',
                strike='2.4',
                swaption_type='Rec',
                notional=-18e6,
                settle_type='Cash Price',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
        ],
        sofr_cms_2y10_vs_1y30y_straddle=[
            clarion.instruments.RatesCmsSpreadSingleLook(
                currency='USD',
                instrument_name='SOFR CMS 10Y-2Y',
                start_date='1y',
                notional=-1.6e9,
                strike='a + 124',
                cap_floor_type='Cap',
                collateral_currency='USD',
                pay_settle='Spot',
            ),
            clarion.instruments.RatesCmsSpreadSingleLook(
                currency='USD',
                instrument_name='SOFR CMS 10Y-2Y',
                start_date='1y',
                notional=-1.6e9,
                strike='a - 111',
                cap_floor_type='Floor',
                collateral_currency='USD',
                pay_settle='Spot',
            ),
            clarion.instruments.RatesSwaption(
                currency='USD',
                instrument_name='SOFR A',
                expiry='1y',
                tenor='30y',
                strike='a + 101',
                swaption_type='Pay',
                notional=75e6,
                settle_type='Physical Cleared LCH',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
            clarion.instruments.RatesSwaption(
                currency='USD',
                instrument_name='SOFR A',
                expiry='1y',
                tenor='30y',
                strike='a - 114',
                swaption_type='Rec',
                notional=75e6,
                settle_type='Physical Cleared LCH',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
        ],
        sofr_cms_2y10_vs_1y30y_straddle_tight=[
            clarion.instruments.RatesCmsSpreadSingleLook(
                currency='USD',
                instrument_name='SOFR CMS 10Y-2Y',
                start_date='1y',
                notional=-1.6e9,
                strike='a + 119',
                cap_floor_type='Cap',
                collateral_currency='USD',
                pay_settle='Spot',
            ),
            clarion.instruments.RatesCmsSpreadSingleLook(
                currency='USD',
                instrument_name='SOFR CMS 10Y-2Y',
                start_date='1y',
                notional=-1.6e9,
                strike='a - 106',
                cap_floor_type='Floor',
                collateral_currency='USD',
                pay_settle='Spot',
            ),
            clarion.instruments.RatesSwaption(
                currency='USD',
                instrument_name='SOFR A',
                expiry='1y',
                tenor='30y',
                strike='a + 106',
                swaption_type='Pay',
                notional=75e6,
                settle_type='Physical Cleared LCH',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
            clarion.instruments.RatesSwaption(
                currency='USD',
                instrument_name='SOFR A',
                expiry='1y',
                tenor='30y',
                strike='a - 119',
                swaption_type='Rec',
                notional=75e6,
                settle_type='Physical Cleared LCH',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
        ],
        sofr_cms_2y10_vs_1y30y_straddle_fixed=[
            clarion.instruments.RatesCmsSpreadSingleLook(
                currency='USD',
                instrument_name='SOFR CMS 10Y-2Y',
                start_date='1y',
                notional=-1.6e9,
                strike='1',
                cap_floor_type='Cap',
                collateral_currency='USD',
                pay_settle='Spot',
            ),
            clarion.instruments.RatesCmsSpreadSingleLook(
                currency='USD',
                instrument_name='SOFR CMS 10Y-2Y',
                start_date='1y',
                notional=-1.6e9,
                strike='-1',
                cap_floor_type='Floor',
                collateral_currency='USD',
                pay_settle='Spot',
            ),
            clarion.instruments.RatesSwaption(
                currency='USD',
                instrument_name='SOFR A',
                expiry='1y',
                tenor='30y',
                strike='3.8',
                swaption_type='Pay',
                notional=72e6,
                settle_type='Physical Cleared LCH',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
            clarion.instruments.RatesSwaption(
                currency='USD',
                instrument_name='SOFR A',
                expiry='1y',
                tenor='30y',
                strike='1.50',
                swaption_type='Rec',
                notional=72e6,
                settle_type='Physical Cleared LCH',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
        ],
        sofr_1y30y_payer_spread=[
            clarion.instruments.RatesSwaption(
                currency='USD',
                instrument_name='SOFR A',
                expiry='2024-02-24',
                tenor='30y',
                strike='3.75',
                swaption_type='Pay',
                notional=35e6,
                settle_type='Physical Cleared LCH',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
            clarion.instruments.RatesSwaption(
                currency='USD',
                instrument_name='SOFR A',
                expiry='2024-02-24',
                tenor='30y',
                strike='4.75',
                swaption_type='Pay',
                notional=-49e6,
                settle_type='Physical Cleared LCH',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
        ],
        sonia_rec_fly_18m1y=[
            clarion.instruments.RatesSwaption(
                currency='GBP',
                instrument_name='SONIA A',
                expiry='18m',
                tenor='1y',
                strike='2.5',
                swaption_type='Rec',
                notional=800e6,
                settle_type='Cash Price',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
            clarion.instruments.RatesSwaption(
                currency='GBP',
                instrument_name='SONIA A',
                expiry='18m',
                tenor='1y',
                strike='1.5',
                swaption_type='Rec',
                notional=-1600e6,
                settle_type='Cash Price',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
            clarion.instruments.RatesSwaption(
                currency='GBP',
                instrument_name='SONIA A',
                expiry='18m',
                tenor='1y',
                strike='1.0',
                swaption_type='Rec',
                notional=800e6,
                settle_type='Cash Price',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
        ],
        spx_nov23_put_spread=[
            clarion.instruments.EquityCashOption(
                instrument_name='SPX',
                contract_type='US',
                expiry='2023-11-17',
                strike=3000,
                option_type='Put',
                exercise_type='European',
                quantity=1082

            ),
            clarion.instruments.EquityCashOption(
                instrument_name='SPX',
                contract_type='US',
                expiry='2023-11-17',
                strike=2900,
                option_type='Put',
                exercise_type='European',
                quantity=-1082

            )
        ],
        spx_nov23_put_spread2=[
            clarion.instruments.EquityCashOption(
                instrument_name='SPX',
                contract_type='US',
                expiry='2023-11-17',
                strike=3100,
                option_type='Put',
                exercise_type='European',
                quantity=1082

            ),
            clarion.instruments.EquityCashOption(
                instrument_name='SPX',
                contract_type='US',
                expiry='2023-11-17',
                strike=3000,
                option_type='Put',
                exercise_type='European',
                quantity=-1082

            )
        ],
        jpy_payer_fly_1y10y=[
            clarion.instruments.RatesSwaption(
                currency='JPY',
                instrument_name='TONAR A',
                expiry='2024-02-20',
                tenor='10y',
                strike='1.25',
                swaption_type='Pay',
                notional=8e9,
                settle_type='Physical Cleared JSCC',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
            clarion.instruments.RatesSwaption(
                currency='JPY',
                instrument_name='TONAR A',
                expiry='2024-02-20',
                tenor='10y',
                strike='2.0',
                swaption_type='Pay',
                notional=-12e9,
                settle_type='Physical Cleared JSCC',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
            clarion.instruments.RatesSwaption(
                currency='JPY',
                instrument_name='TONAR A',
                expiry='2024-02-20',
                tenor='10y',
                strike='3.0',
                swaption_type='Pay',
                notional=4e9,
                settle_type='Physical Cleared JSCC',
                collateral_currency='USD',
                pay_settle='Spot',
                # id='eur_9m_bear_flat'
            ),
        ],
        # usd_ils=[
        #     clarion.instruments.FxForward(
        #         currency_pair='USDILS',
        #         expiry='0d',
        #         # strike='a',
        #         notional=1
        #     )
        # ],
    )
    return trades


def get_targets():
    targets = {
        'sfr_u3u4_er_z3z4': {
            "var": "fwd_rate",
            "op": "<=",
            "target": -0.93,
            "notes": ""
        },
        # 'er_sfr_m4': {
        #     "var": "fwd_rate",
        #     "op": "<=",
        #     "target": 0.30,
        #     "notes": ""
        # },
        'srf_z3z4z5': {
            "var": "fwd_rate",
            "op": "<=",
            "target": 8.425,
            "notes": "",
            'mult': {"fwd_rate": (-1, -1.9, -1)}
        },
        'ff_q3z3_er_h4h5': {
            "var": "fwd_rate",
            "op": "<=",
            "target": -0.28,
            "notes": "",
            'mult': {"fwd_rate": (-1.196, -1.196, -1, -1)}
        },
        'eur_bear_flat_9m1y_9m2y': {
            "var": "local_pv",
            "op": ">=",
            "target": 4.2e6,
            "notes": ""
        },
        'eur3m_bull_steep_15m1y_15m1y1y': {
            "var": "local_pv",
            "op": ">=",
            "target": 2e6,
            "notes": ""
        },
        'eur6m_bull_steep_30m2y_30m7y': {
            "var": "local_pv",
            "op": "<=",
            "target": -100e3,
            "notes": ""
        },
        'eur6m_payer_spead_18m2y': {
            "var": "local_pv",
            "op": "<=",
            "target": 540e3,
            "notes": "",
        },
        'eur6m_fly_2y2y_4y2y_6y2y': {
            "var": "fwd_rate",
            "op": "<=",
            "target": -0.32,
            "notes": "",
            'mult': {"fwd_rate": (1, 2, 1)}
        },
        'ester_fly_6m1y_3y2y_5y2y': {
            "var": "fwd_rate",
            "op": ">=",
            "target": -0.48,
            "notes": "",
            'mult': {"fwd_rate": (1, 2, 1)}
        },
        'sofr_bull_steep_2y7y_2y30y': {
            "var": "local_pv",
            "op": "<=",
            "target": 100e3,
            "notes": ""
        },
        'sofr_1y30y_payer_spread': {
            "var": "local_pv",
            "op": ">=",
            "target": 5e6,
            "notes": "",
        },
        # 'sofr_cms_2y10_vs_1y30y_straddle': {
        #     "var": "local_pv",
        #     "op": "<=",
        #     "target": 0,
        #     "notes": "",
        #     # 'mult': {"fwd_rate": (1, 2, 1)}
        # },
        # 'sofr_cms_2y10_vs_1y30y_straddle_tight': {
        #     "var": "local_pv",
        #     "op": "<=",
        #     "target": -160e3,
        #     "notes": "",
        #     # 'mult': {"fwd_rate": (1, 2, 1)}
        # },
        'sofr_cms_2y10_vs_1y30y_straddle_fixed': {
            "var": "local_pv",
            "op": "<=",
            "target": -1.48e6,
            "notes": "",
            # 'mult': {"fwd_rate": (1, 2, 1)}
        },
        'sonia_rec_fly_18m1y': {
            "var": "price_bps",
            "op": "<=",
            # "target": 6.75,
            "notes": ""
        },
        'jpy_payer_fly_1y10y': {
            "var": "local_pv",
            "op": "<=",
            "target": 0,
            "notes": "",
        },
        'spx_nov23_put_spread': {
            "var": "price_unit",
            "op": "<=",
            "target": 4.0,
            "notes": ""
        },
        'spx_nov23_put_spread2': {
            "var": "price_unit",
            "op": "<=",
            "target": 4.0,
            "notes": ""
        },
        # 'ecb_mar_may_spread': {
        #     "var": "fwd_rate",
        #     "op": "<=",
        #     "target": 0.36,
        #     "notes": "",
        #     'mult': {"fwd_rate": (1, 1)}
        # },
        # 'usd_ils': {
        #     "var": "fx_spot",
        #     "op": ">=",
        #     "target": 3.63,
        #     "notes": ""
        # },
        # 'sofr_bull_steep_2y7y_2y30y - sofr_bull_steep_2y7y_2y30y': {
        #     "var": "local_pv",
        #     "op":  ">=",
        #     "target": 3e6,
        #     "notes": "we sell 30y pay -640k"
        # },
        # 'sofr_1y30y_payer_spread': {
        #     "var": "local_pv",
        #     "op":  "<=",
        #     "target": 1.75e6,
        #     "notes": "we PAY 2.00 or better",
        #     # 'mult': {"fwd_rate": (1, 2, 1)}
        # },
        # 'jpy_payer_fly_1y10y': {
        #     "var": "price_bps",
        #     "op":  "<=",
        #     "target": 6.5,
        #     "notes": "we PAY 7.3 or better",
        # },
    }
    return targets



def get_metrics(clarion):
    metrics = dict(
        pv=clarion.metric('pv', 'PresentValue', 'Any'),
        local_pv=clarion.metric('local_pv', 'LocalPresentValue', 'Any'),
        # currency = clarion.metric('currency', 'PayCurrency', 'Any'),
        strike=clarion.metric('strike', 'Strike', 'Any'),
        notional=clarion.metric('notional', 'Notional', 'Any'),
        expiry=clarion.metric('expiry', 'ExpiryDate', 'Any'),
        maturity=clarion.metric('maturity_date', 'MaturityDate', 'Rates', {'Type': 'Bumped'}),
        start=clarion.metric('start_date', 'StartDate', 'Rates', {'Type': 'Bumped'}),
        fwd_rate=clarion.metric('fwd_rate', 'Forward', 'Rates'),
        delta=clarion.metric('delta', 'Delta', 'Rates',
                             {'VolSpotDynamic': 'StickyDelta', 'RiskSpace': 'Par', 'RiskBuckets': 'Default'}),
        gamma=clarion.metric('gamma', 'Gamma', 'Rates',
                             {'VolSpotDynamic': 'StickyDelta', 'RiskSpace': 'Par', 'RiskBuckets': 'Default'}),
        theta=clarion.metric('theta', 'OptionTheta', 'Rates', {'Period': '1'}),
        price_cents=clarion.metric('price_cents', 'Price', 'Rates', {'Unit': 'Cents'}),
        fwd_price_cents=clarion.metric('fwd_price_cents', 'ForwardPrice', 'Rates', {'Unit': 'Cents'}),
        price_bps=clarion.metric('price_bps', 'Price', 'Rates', {'Unit': 'BasisPoints'}),
        price_pct=clarion.metric('price_pct', 'Price', 'Equity', {'Unit': 'PercentLocal'}),
        price_unit=clarion.metric('price_unit', 'Price', 'Equity', {'Unit': 'Local'}),
        spot=clarion.metric('spot', 'Spot', 'Rates'),
        # vega = clarion.metric('vega', 'Vega', 'Rates', {'Period': 'Daily'}),
        # atm_vol_day = clarion.metric('atm_vol_day', 'Volatility', 'Rates', {'Type': 'ATM', 'Period': 'Daily'}),
        atm_vol_ann=clarion.metric('atm_vol_ann', 'Volatility', 'Rates', {'Type': 'ATM', 'Period': 'Annual'}),
        # strike_vol_day = clarion.metric('strike_vol_day', 'Volatility', 'Rates', {'Type': 'Strike', 'Period': 'Daily'}),
        strike_vol_ann=clarion.metric('strike_vol_ann', 'Volatility', 'Rates', {'Type': 'Strike', 'Period': 'Annual'}),
        fx_spot=clarion.metric('fx_spot', 'Spot', 'Fx'),
        fx_fwd=clarion.metric('fx_fwd', 'Forward', 'Fx'),
        # carry_day = clarion.metric('carry_day', 'Carry', 'Credit', {'Horizon': '1d'}),
    )

    return metrics
