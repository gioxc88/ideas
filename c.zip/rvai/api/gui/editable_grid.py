from functools import partial

import ipywidgets as w
import ipyvuetify as v
import pandas as pd

from .theme import bg_color

from gioutils.gui.datagrid import DataGridGio
from gioutils.gui.base import View


def make_action_button(
    tooltip_position='top',
    tooltip_text='',
    button_icon=None,
    button_color=None,
    button_size='x_small',
    margin=2,
):
    btn_ = v.Btn(
        v_on='tooltip.on',
        fab=True,
        plain=True,
        class_=f'ma-{margin}',
        children=[v.Icon(children=[f'mdi-{button_icon}'])],
        color=button_color,
        **{button_size: True}
    )
    btn = v.Container(
        children=[
            v.Tooltip(
                v_slots=[
                    {
                        'name': 'activator',
                        'variable': 'tooltip',
                        'children': btn_,
                    }
                ],
                children=[tooltip_text],
                **{tooltip_position: True}
            ),
        ],
        class_='ma-0 pa-0',
        fluid=True
    )
    return btn


def get_tooltip_button(tooltip):
    return tooltip.children[0].v_slots[0]['children']


class EditableGrid(View):
    def __init__(
            self,
            data=None,
            new_data=None,
            grid_kwargs=None,
            **kwargs,
    ):
        self._data = data
        self._new_data = new_data
        self._grid_kwargs = {**grid_kwargs} if grid_kwargs else {}
        self._grid_kwargs.setdefault('selection_mode', 'cell')
        self._grid_kwargs.setdefault('editable', True)
        self._grid_kwargs.setdefault('index_name', '')
        self.dg = self.make_dg(data, **self._grid_kwargs)
        super().__init__(**kwargs)

    def update_dg(self, data=None):
        self.dg = self.make_dg(data, **self._grid_kwargs)

    def make_widgets(self, **kwargs):
        add_btn = v.Btn(
            fab=True,
            # small=True,
            x_small=True,
            plain=True,
            class_='ma-2',
            children=[v.Icon(children=['mdi-plus'])]
        )

        rmv_btn = v.Btn(
            fab=True,
            # small=True,
            x_small=True,
            plain=True,
            class_='ma-2',
            children=[v.Icon(children=['mdi-minus'])]
        )

        above_btn = v.Btn(
            fab=True,
            # small=True,
            x_small=True,
            plain=True,
            class_='ma-2',
            children=[v.Icon(children=['mdi-arrow-up-bold'])]
        )

        below_btn = v.Btn(
            fab=True,
            # small=True,
            x_small=True,
            plain=True,
            class_='ma-2',
            children=[v.Icon(children=['mdi-arrow-down-bold'])]
        )

        duplicate_below_btn = v.Btn(
            fab=True,
            # small=True,
            x_small=True,
            plain=True,
            class_='ma-2',
            children=[v.Icon(children=['mdi-content-duplicate'])]
        )

        display_btn = v.Btn(
            fab=True,
            # small=True,
            x_small=True,
            plain=True,
            class_='ma-2',
            children=[v.Icon(children=['mdi-eye'])]
        )


        copy_btn = v.Btn(
            fab=True,
            # small=True,
            x_small=True,
            plain=True,
            class_='ma-2',
            children=[v.Icon(children=['mdi-content-copy'])]
        )

        paste_btn = v.Btn(
            fab=True,
            # small=True,
            x_small=True,
            plain=True,
            class_='ma-2',
            children=[v.Icon(children=['mdi-content-paste'])]
        )

        add_btn = make_action_button(tooltip_text='add bottom rows', button_icon='plus')
        rmv_btn = make_action_button(tooltip_text='remove rows', button_icon='minus')
        above_btn = make_action_button(tooltip_text='add rows above', button_icon='arrow-up-bold')
        below_btn = make_action_button(tooltip_text='add rows below', button_icon='arrow-down-bold')
        duplicate_below_btn = make_action_button(tooltip_text='duplicate rows below', button_icon='content-duplicate')
        display_btn = make_action_button(tooltip_text='show / hide', button_icon='eye')
        copy_btn = make_action_button(tooltip_text='copy', button_icon='content-copy')
        paste_btn = make_action_button(tooltip_text='paste', button_icon='content-paste')

        self.add_btn = add_btn
        self.rmv_btn = rmv_btn
        self.above_btn = above_btn
        self.below_btn = below_btn
        self.duplicate_below_btn = duplicate_below_btn
        self.display_btn = display_btn
        self.copy_btn = copy_btn
        self.paste_btn = paste_btn
        self.btn_box = w.HBox(
            [
                add_btn,
                rmv_btn,
                above_btn,
                below_btn,
                duplicate_below_btn,
                copy_btn,
                display_btn,
                # paste_btn
            ]
        )

    def make_view(self, **kwargs):
        self.param_box = v.Row(
            children=[
                v.Col(
                    cols=6,
                    # lg=3,
                    children=[self.btn_box],
                    class_="my-0 py-0"
                ),
            ]
        )
        self.view = v.Container(
            children=[w.VBox([self.param_box, self.dg])],
            class_="ma-0 pa-0", style_=f"background: {bg_color}",
            fluid=True
        )

    @property
    def data(self):
        return self.dg.data

    @data.setter
    def data(self, data):
        current_data = self.dg.data
        new_data = pd.concat([current_data, data])[len(current_data):].reset_index(drop=True)
        self.dg.data = new_data

    @property
    def new_data(self):
        new_data = self._new_data
        new_data = [[*new_data]] if new_data is not None else None
        return new_data

    @property
    def columns(self):
        if self._new_data is None:
            return self._data.columns
        return [*self._new_data]

    @property
    def row(self):
        if self._new_data is None:
            return
        return [[*self._new_data.values()]]

    def make_dg(self, data=None, **kwargs):
        data = pd.DataFrame(self.row, columns=self.columns).reindex([0]) if data is None else data
        dg = DataGridGio(
            data,
            **kwargs
        )
        # dg.grid_style = grid_style
        return dg

    def link(self, **kwargs):
        get_tooltip_button(self.add_btn).on_event(
            'click',
            partial(on_click_add, dg=self.dg, new_data=self.row)
        )

        get_tooltip_button(self.rmv_btn).on_event(
            'click',
            partial(on_click_remove, dg=self.dg)
        )

        get_tooltip_button(self.above_btn).on_event(
            'click',
            partial(on_click_add_above, dg=self.dg, new_data=self.row)
        )

        get_tooltip_button(self.below_btn).on_event(
            'click',
            partial(on_click_add_below, dg=self.dg, new_data=self.row)
        )

        get_tooltip_button(self.duplicate_below_btn).on_event(
            'click',
            partial(on_click_add_below, dg=self.dg, new_data=self.row, duplicate=True)
        )

        get_tooltip_button(self.display_btn).on_event(
            'click',
            partial(on_click_show_hide, self=self)
        )

        get_tooltip_button(self.copy_btn).on_event(
            'click',
            partial(on_click_copy, self=self)
        )

        get_tooltip_button(self.paste_btn).on_event(
            'click',
            partial(on_click_paste, self=self)
        )

        super().link(**kwargs)


def remove_row(dg):
    current_data = dg.data
    selections = dg.selections
    if not selections:
        new_data = current_data[:-1]
    else:
        rows = []
        for sel in selections:
            sel_rows = [*range(sel['r1'], sel['r2'] + 1)]
            rows.extend(sel_rows)
        to_drop = pd.Series(rows).drop_duplicates().to_list()
        new_data = current_data.drop(current_data.index[to_drop]).reset_index(drop=True)
    dg.data = new_data


def add_row(dg, new_data=None):
    current_data = dg.data
    new_row = pd.DataFrame(
        data=new_data,
        columns=current_data.columns,
        index=[0]
    )

    new_data = pd.concat([current_data, new_row]).reset_index(drop=True)
    dg.data = new_data


def add_above(dg, new_data=None, duplicate=False):
    current_data = dg.data
    selections = dg.selections
    if not selections:
        return

    r1, r2 = selections[0]['r1'], selections[0]['r2']

    if duplicate:
        new_row = current_data.iloc[r1:r2 + 1]
    else:
        new_row = pd.DataFrame(
            data=new_data,
            columns=current_data.columns,
            index=[0]
        )

        n_rows = r2 - r1 + 1
        if n_rows:
            new_row = pd.concat([new_row for i in range(n_rows)])

    above = current_data.iloc[:r1]
    below = current_data.iloc[r1:]
    new_data = pd.concat([above, new_row, below]).reset_index(drop=True)
    dg.data = new_data


def add_below(dg, new_data=None, duplicate=False):
    current_data = dg.data
    selections = dg.selections
    if not selections:
        return

    r1, r2 = selections[0]['r1'], selections[0]['r2']

    if duplicate:
        new_row = current_data.iloc[r1:r2 + 1]
    else:
        new_row = pd.DataFrame(
            data=new_data,
            columns=current_data.columns,
            index=[0]
        )

        n_rows = r2 - r1 + 1
        if n_rows:
            new_row = pd.concat([new_row for i in range(n_rows)])

    above = current_data.iloc[:r2 + 1]
    below = current_data.iloc[r2 + 1:]
    new_data = pd.concat([above, new_row, below]).reset_index(drop=True)
    dg.data = new_data


def copy_data(dg):
    sels = dg.selections
    data = dg.data
    if sels:
        sel = sels[0]
        sel_data = data.iloc[sel['r1']: sel['r2'] + 1, sel['c1']: sel['c2'] + 1]
        if sel_data.shape == (1, 1):
            copy_data = data
        else:
            copy_data = sel_data
    else:
        copy_data = data

    copy_data.to_clipboard()


def paste_data(dg):
    try:
        paste_data = pd.read_clipboard(header=None)
    except:
        return

    sels = dg.selections
    data = dg.data
    if sels:
        sel = sels[0]
        r1 = sel['r1']
        c1 = sel['c1']
    else:
        r1, c1 = 0, 0

    r2 = r1 + paste_data.shape[0]
    c2 = c1 + paste_data.shape[1]

    data.iloc[r1:r2, c1:c2] = paste_data
    dg.data = data


def on_click_add(widgent, event, payload, dg, new_data=None):
    add_row(dg, new_data=new_data)


def on_click_remove(widgent, event, payload, dg):
    remove_row(dg)


def on_click_add_above(widgent, event, payload, dg, new_data=None, duplicate=False):
    add_above(dg, new_data=new_data, duplicate=duplicate)


def on_click_add_below(widgent, event, payload, dg, new_data=None, duplicate=False):
    add_below(dg, new_data=new_data, duplicate=duplicate)


def on_click_show_hide(widget, event, payload, self):
    # this is if tou want to hide but still mantain the space it originally occupies in the page
    # self.dg.layout.visibility = 'hidden'
    # self.dg.layout.visibility = 'visible'
    if self.dg.layout.display:
        self.dg.layout.display = None
    else:
        self.dg.layout.display = 'none'


def on_click_copy(widget, event, payload, self):
    dg = self.dg
    copy_data(dg)


def on_click_paste(widget, event, payload, self):
    dg = self.dg
    paste_data(dg)


