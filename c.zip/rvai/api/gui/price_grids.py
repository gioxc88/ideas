import logging
import os
from functools import partial

import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
from ipydatagrid import TextRenderer, Expr, VegaExpr

from ..data.base import radar_path
from .theme import bg_color
from .editable_grid import EditableGrid

from gioutils.ezutils import bh, ensure_series, get_price_info, get_generators
from gioutils.gui.base import View
from gioutils.gui.pandas import millify1

from ..collectors import CollectorStoreMixin

# from api.ezutils2 import bh, mkt_defs, ccy_cals, mx_cals, mtg_dts, gens
# from api.utils import parse_offset, RepeatedTimer
# from api.data.base import data_path, radar_path
# from api.gui.base import View
# from api.gui.params import curves, bbg_params


gens_curves_mapping = {
    'USD': 'USD SOFR',
    'USDL': 'USD LIBOR S 3M*',
    'EUR': 'EURIBOR A 6M*', 'GBP': 'GBP SONIA'
}

RATE_MULT = 100
VOL_MULT = 10000


class PricingGrid(View, CollectorStoreMixin):
    input_cols = [
        'name',
        'instr',
        'generator',
        'exp',
        'tnr',
        'payout',
        'strike',
        'notional',
        'wgt',
    ]

    expr_input_cols = [
        'expression',
        'sign',
        'target',
    ]

    params_map = {
        'instr': 'instrument',
        # 'generator':,
        'exp': 'eff_exp',
        'tnr': 'mty_tnr',
        'payout': 'payout_type'
        # 'notional':
    }

    output_map = {
        'Rate': 'rate',
        'AtmVol': 'vol',
        'PV': 'pv',
        'Ann01': 'ann01'
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def make_widgets(self, **kwargs):

        gens_ac = v.Autocomplete(
            items=[*get_generators()],
            dense=True,
            outlined=True,
            label='generators lookup',
            clearable=True
        )

        file_tf = v.TextField(
            label='file name',
            v_model=None,
            clearable=True,
            # prepend_icon='mdi-content-save',
            outlined=True,
            dense=True
        )

        save_btn = v.Btn(
            fab=True,
            # small=True,
            x_small=True,
            plain=True,
            class_='ma-2',
            children=[v.Icon(children=['mdi-content-save'])]
        )

        load_btn = v.Btn(
            fab=True,
            # small=True,
            x_small=True,
            plain=True,
            class_='ma-2',
            children=[v.Icon(children=['mdi-file-upload'])]
        )

        self.file_tf = file_tf
        self.load_btn = load_btn
        self.save_btn = save_btn
        self.gens_ac = gens_ac

        self.file_box = w.HBox(
            [
                self.file_tf,
                self.load_btn,
                self.save_btn,
            ]
        )

        self.box = v.Row(
            children=[
                v.Col(
                    cols=3,
                    children=[self.file_box]
                ),
                v.Spacer(),
                v.Col(cols=3, children=[self.gens_ac])
            ]
        )

        self.make_grids()

    def make_grids(self):
        wgt_renderer = TextRenderer(
            text_value=Expr("format(cell.value, '.2f')"),
            text_color=Expr('"red" if cell.value < 0 else default_value'),
        )

        live_renderer = TextRenderer(
            text_value=Expr("format(cell.value, '.3%')"),
            # text_color=Expr('"red" if cell.value < 0 else default_value'),
            background_color=VegaExpr(
                "(cell.value >= cell.metadata.data['target'] && cell.metadata.data['sign'] == '+') || \
                (cell.value <= cell.metadata.data['target'] && cell.metadata.data['sign'] == '-')  ? 'red' : default_value"
            )
        )

        dollar_renderer = TextRenderer(
            text_value=Expr(millify1),
            text_color=Expr('"red" if cell.value < 0 else default_value')
        )

        rate_renderer = TextRenderer(
            text_value=Expr(f'format(cell.value * {RATE_MULT}, ".3f")'),
            text_color=Expr('"red" if cell.value < 0 else default_value'),
        )

        vol_renderer = TextRenderer(
            text_value=Expr(f'format(cell.value * {VOL_MULT}, ".1f")'),
            text_color=Expr('"red" if cell.value < 0 else default_value'),
        )

        renderers = {
            'notional': dollar_renderer,
            'pv': dollar_renderer,
            'rate': rate_renderer,
            'vol': vol_renderer,
            'wgt': wgt_renderer,
            'ann01': TextRenderer(format='.3f'),
            'prem': TextRenderer(format='.2%'),
            'live': TextRenderer(format='.3%')
        }

        column_widths = {
            'name': 150,
            # 'group': 100,
            'instr': 60,
            'payout': 72,
            'generator': 130,
            'exp': 50,
            'tnr': 50,
            'notional': 75
        }

        dg = EditableGrid(
            new_data={
                'name': '',
                # 'group': '',
                'instr': '',
                'generator': '',
                'exp': '',
                'tnr': '',
                'payout': 'pay',
                'strike': 'a',
                'notional': 10e6,
                'wgt': 1,
                'rate': np.nan,
                'vol': np.nan,
                'pv': np.nan,
                'ann01': np.nan,
                'prem': np.nan,
                'live': np.nan
            },
            grid_kwargs=dict(
                renderers=renderers,
                column_widths=column_widths
            )
        )
        self.price_grid = dg

        expr_renderers = {
            'target': TextRenderer(),
            'live': live_renderer,
            'rate': rate_renderer,
            'pv': dollar_renderer,
            'vol': vol_renderer,
        }

        self.expr_dg = EditableGrid(
            new_data={
                'expression': "",
                'sign': "+",
                'target': np.nan,
                'live': np.nan,
                'rate': np.nan,
                'pv': np.nan,
                'vol': np.nan,
            },
            grid_kwargs=dict(
                base_column_size=75,
                renderers=expr_renderers,
                column_widths={
                    'expression': 350,
                    'sign': 60
                }
            ),
        )

    @property
    def dg(self):
        return self.price_grid.dg

    def make_view(self, **kwargs):
        self.price_view = w.VBox([self.box, self.expr_dg.view, self.price_grid.view])
        self.view = v.Container(
            children=[w.VBox([self.price_view])],
            class_="ma-0 pa-0", style_=f"background: {bg_color}"
        )
        # self.view = v.Container(
        #     children=[w.VBox([self.fly_view, self.expr_dg.view])],
        #     class_="ma-0 pa-0", style_=f"background: {bg_color}"
        # )

    def link(self, **kwargs):

        self.load_btn.on_event(
            'click',
            partial(on_click_upload, self=self)
        )

        self.save_btn.on_event(
            'click',
            partial(on_click_save, self=self)
        )
        super().link(**kwargs)

    def _get_ir_data(self, data=None, curves=None, vols=None, infl=None, **kwargs):
        data = self.dg.data if data is None else data
        output_map = self.output_map
        input_cols = self.input_cols
        params_map = self.params_map

        inputs_ = data[input_cols].rename(params_map, axis=1)
        price = get_price_info(
            inputs=inputs_,
            curves=curves,
            vols=vols,
            # infl=None,
            # date=None,
            # hist='1y',
            # vol_model='Normal',
        )
        outputs = price.py
        if isinstance(outputs, pd.Series):
            outputs = outputs.to_frame().T
        outputs = outputs.set_index('TradeId')[[*output_map]].rename(output_map, axis=1)
        outputs = outputs.set_axis(outputs.index - 1)
        new_data = data.drop([*output_map.values(), 'prem', 'live'], axis=1).merge(
            outputs,
            how='left',
            right_index=True,
            left_index=True
        )
        new_data['prem'] = new_data['pv'] / new_data['notional']
        mask = new_data['instr'] == 'oswp'
        new_data.loc[~mask, 'prem'] = np.nan
        new_data['live'] = new_data['rate']
        new_data.loc[mask, 'live'] = new_data.loc[mask, 'prem']

        return new_data

    def get_groups(self, data=None):
        data = data if data is not None else self.dg.data
        res = []
        for index, group in data.groupby('name', sort=False):
            d = dict(
                name=index,
                rate=group['rate'] @ group['wgt'].fillna(1),
                vol=group['vol'] @ group['wgt'].fillna(1),
                pv=group['pv'].sum(),
                prem=group['prem'] @ group['wgt'].fillna(1),
                live=group['live'] @ group['wgt'].fillna(1)
            )
            res.append(d)
        res = pd.DataFrame(res)
        return res

    def get_file_path(self, suffix='', user=True):
        return radar_path / 'save' / f'{f"{os.getlogin()}_" if user else ""}pricer_{self.file_tf.v_model}{f"_{suffix}" if suffix else ""}.csv'

    def upload_file(self):
        file_name = self.get_file_path('trades')
        data = pd.read_csv(file_name)
        current_data = self.dg.data
        self.dg.data = pd.concat([current_data, data])[len(current_data):].reset_index(drop=True)

        try:
            file_name = self.get_file_path('expressions')
            data = pd.read_csv(file_name)
            expr_data = self.expr_dg.dg.data
            self.expr_dg.dg.data = pd.concat([expr_data, data])[len(expr_data):].reset_index(drop=True)
        except FileNotFoundError:
            pass

    def save_to_file(self):
        file_name = self.get_file_path('trades')
        current_data = self.dg.data
        current_data[self.input_cols].to_csv(file_name, index=False)

        file_name = self.get_file_path('expressions')
        expr_data = self.expr_dg.dg.data
        expr_data[self.expr_input_cols].to_csv(file_name, index=False)

    def get_data(self, **kwargs):
        data = self.dg.data.dropna(subset='generator')

        if not (len(data) == 1 and not data['generator'].squeeze()):
            print(data)
            snaps = kwargs.get('snaps')
            curves = snaps.get('live')
            vols = snaps.get('live_vol')
            infl = snaps.get('live_infl')
            try:
                new_data = self._get_ir_data(data=data, curves=curves, vols=vols, infl=infl)
                self._new_data = new_data
                self.dg.data = new_data
                expr_data = self.calc_expressions()
                self.expr_dg.dg.data = expr_data
            except Exception as e:
                logging.error(e)

    def calc_expressions(self):
        expr_data = self.expr_dg.dg.data
        expr_data = expr_data.loc[expr_data['expression'] != ""]
        expr_data = expr_data.dropna(subset='expression')

        dg_data = self.get_groups()

        if not expr_data.empty and not dg_data.empty:
            cols = [
                'live',
                'rate',
                'pv',
                'vol',
            ]
            res = {}
            for col in cols:
                c = bh.bhTsCalcExpression(
                    resultnames=range(len(expr_data)),  # if omitted it doesn't work with multiple expressions at once
                    expressions=expr_data['expression'].to_list(),
                    varnamesorhndl=dg_data['name'].to_list(),
                    varvalues=dg_data[col].to_list()
                )
                c = ensure_series(c)
                res[col] = c
            res = pd.DataFrame(res)
            expr_data = pd.concat([expr_data[['expression', 'sign', 'target']], res], axis=1)
            return expr_data


def on_click_upload(widget, event, payload, self):
    widget.loading = True
    try:
        self.upload_file()
    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False


def on_click_save(widget, event, payload, self):
    widget.loading = True
    try:
        self.save_to_file()
    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False

v.TextField