from functools import partial
from itertools import chain

import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
from ipydatagrid import TextRenderer, Expr, VegaExpr

from ..data.base import radar_path
from .theme import bg_color
from api.collectors import get_rate_from_generator, get_vol_from_generator
from .editable_grid import EditableGrid

from gioutils.ezutils import bh, ensure_series
from gioutils.gui.base import View

# from api.ezutils2 import bh, mkt_defs, ccy_cals, mx_cals, mtg_dts, gens
# from api.utils import parse_offset, RepeatedTimer
# from api.data.base import data_path, radar_path
# from api.gui.base import View
# from api.gui.params import curves, bbg_params

gens_curves_mapping = {
    'USD': 'USD SOFR',
    'USDL': 'USD LIBOR S 3M*',
    'EUR': 'EURIBOR A 6M*',
    'GBP': 'GBP SONIA'
}

RATE_MUL = 100
VOL_MUL = 10000


def get_sw_rate_from_params(
        params: [list, pd.DataFrame],
        db_curves
):
    '''
    param can be a list of dictionaries with keys 'ccy' and tenor or a dataframe with columns ccy and tenor
    '''

    if isinstance(params, list):
        params = pd.DataFrame(params)

    rates = []
    for index, row in params.iterrows():
        effofwd = row['tenor'].lower().split('x')[0]
        try:
            mtyortenor = row['tenor'].lower().split('x')[1]
        except IndexError:
            effofwd, mtyortenor = None, effofwd
        if effofwd and len(effofwd) > 4:
            effofwd = pd.to_datetime(effofwd)
        if len(mtyortenor) > 4:
            mtyortenor = pd.to_datetime(mtyortenor)
        rate = get_rate_from_generator(
            generator=gens_curves_mapping.get(row['ccy'].upper(), row['ccy'].upper()),
            efforfwd=effofwd,
            mtyortenor=mtyortenor,
            db_curves=db_curves
        )
        rates.append(rate)

    return rates


def get_sw_vol_from_params(
        params: [list, pd.DataFrame],
        db_curves,
        vol_cubes
):
    '''
    param can be a list of dictionaries with keys 'ccy' and tenor or a dataframe with columns ccy and tenor
    '''

    if isinstance(params, list):
        params = pd.DataFrame(params)

    rates = []
    for index, row in params.iterrows():
        effofwd = row['tenor'].lower().split('x')[0]
        try:
            mtyortenor = row['tenor'].lower().split('x')[1]
        except IndexError:
            effofwd, mtyortenor = None, effofwd
        if effofwd and len(effofwd) > 4:
            effofwd = pd.to_datetime(effofwd)
        if len(mtyortenor) > 4:
            mtyortenor = pd.to_datetime(mtyortenor)
        rate = get_vol_from_generator(
            generator=gens_curves_mapping.get(row['ccy'].upper(), row['ccy'].upper()),
            expiry=effofwd,
            tenor=mtyortenor,
            db_curves=db_curves,
            vol_cubes=vol_cubes
        )
        rates.append(rate)

    return rates


def parse_params_df(data):
    df = data
    params = []
    for index, row in df.iterrows():
        name, ccy, typ = row['name'], row['ccy'], row['type']
        row = row.dropna()
        row_sub = row.loc['type':][1:]
        grouper = [l[0] for l in row_sub.index.str.findall('\d+')]
        g = row_sub.groupby(grouper, sort=False)
        row_params = []
        for index, group in g:
            try:
                param = {
                    'name': name,
                    'ccy': ccy,
                    'type': typ,
                    'tenor': group[f'leg{index}'],
                    'wgt': group[f'wgt{index}'],
                    'group': index
                }
                row_params.append(param)
            except Exception as e:
                print(e, group, index, '\n')

        params.extend(row_params)

    return params


def update_flies_data(data, db_curves):
    des_cols = [
        'name',
        'ccy',
        'type'
    ]

    params = parse_params_df(data)
    flat_data = pd.DataFrame(params)
    print(flat_data)
    new_data = []
    for index, group in flat_data.groupby('type', sort=False):
        if index.lower() in ['i', 'irs']:
            group = group.assign(
                rate=get_sw_rate_from_params(group, db_curves['live']),
                cob=get_sw_rate_from_params(group, db_curves['cob'])
            )
            group[['rate', 'cob']] = group[['rate', 'cob']] * RATE_MUL
            new_data.append(group)
        elif index.lower() in ['s', 'oswp']:
            group = group.assign(
                rate=get_sw_vol_from_params(group, db_curves['live'], db_curves['live_vol']),
                cob=get_sw_vol_from_params(group, db_curves['cob'], db_curves['cob_vol'])
            )
            group[['rate', 'cob']] = group[['rate', 'cob']] * VOL_MUL
            new_data.append(group)

    flat_data = pd.concat(new_data)
    print(flat_data)
    new_rows = []
    g = flat_data.groupby('name', sort=False)
    for index, group in g:
        group['group'] = group['group'].astype(int)
        group = group.sort_values('group')
        new_row = {col: group.iloc[0][col] for col in des_cols}

        for _, row in group.iterrows():
            new_row[f"wgt{row['group']}"] = row['wgt']
            new_row[f"leg{row['group']}"] = row['tenor']

        for _, row in group.iterrows():
            new_row[f"rate{row['group']}"] = row['rate']
        new_row['live'] = group['wgt'] @ group['rate']

        for _, row in group.iterrows():
            new_row[f"change{row['group']}"] = row['rate'] - row['cob']
        new_row['change'] = group['wgt'] @ (group['rate'] - group['cob'])
        new_rows.append(new_row)
    new_data = pd.DataFrame(new_rows)

    cols = [
        *des_cols,
        *chain.from_iterable([
            *zip(
                new_data.columns[new_data.columns.str.contains('wgt')],
                new_data.columns[new_data.columns.str.contains('leg')]
            )
        ]),

        *new_data.columns[new_data.columns.str.contains('rate')],
        'live',
        *new_data.columns[new_data.columns.str.contains('change') & new_data.columns.str.contains('\d+')],
        'change'
    ]

    return new_data[cols]


class FlyGrid(View):
    fly_input_cols = [
        'name',
        'ccy',
        'type',
        'wgt1',
        'leg1',
        'wgt2',
        'leg2',
        'wgt3',
        'leg3',
    ]
    expr_input_cols = [
        'expression',
        'sign',
        'target',
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def make_widgets(self, **kwargs):
        file_tf = v.TextField(
            label='file name',
            v_model=None,
            clearable=True,
            # prepend_icon='mdi-content-save',
            outlined=True,
            dense=True
        )

        save_btn = v.Btn(
            fab=True,
            # small=True,
            x_small=True,
            plain=True,
            class_='ma-2',
            children=[v.Icon(children=['mdi-content-save'])]
        )

        load_btn = v.Btn(
            fab=True,
            # small=True,
            x_small=True,
            plain=True,
            class_='ma-2',
            children=[v.Icon(children=['mdi-file-upload'])]
        )

        self.file_tf = file_tf
        self.load_btn = load_btn
        self.save_btn = save_btn

        self.file_box = w.HBox(
            [
                self.file_tf,
                self.load_btn,
                self.save_btn,
            ]
        )
        self.make_grids()

    def make_grids(self):

        wgt_renderer = TextRenderer(
            text_value=Expr("format(cell.value, '.2f')"),
            text_color=Expr('"red" if cell.value < 0 else default_value'),
        )

        float_renderer = TextRenderer(
            text_value=Expr("format(cell.value, '.3f')"),
            # text_color=Expr('"red" if cell.value < 0 else default_value'),
        )

        fly_frid_renderers = {
            'wgt1': wgt_renderer,
            'wgt2': wgt_renderer,
            'wgt3': wgt_renderer,
            'rate1': float_renderer,
            'rate2': float_renderer,
            'rate3': float_renderer,
            'live': float_renderer,
            'change1': float_renderer,
            'change2': float_renderer,
            'change3': float_renderer,
            'change': float_renderer
        }

        self.fly_grid = EditableGrid(
            new_data={
                'name': "",
                'ccy': "",
                'type': "i",
                'wgt1': np.nan,
                'leg1': "",
                'wgt2': np.nan,
                'leg2': "",
                'wgt3': np.nan,
                'leg3': "",
                'rate1': np.nan,
                'rate2': np.nan,
                'rate3': np.nan,
                'live': np.nan,
                'change1': np.nan,
                'change2': np.nan,
                'change3': np.nan,
                'change': np.nan,
            },
            grid_kwargs=dict(
                ase_column_size=75,
                renderers=fly_frid_renderers,
                column_widths={
                    'name': 150,
                    'type': 55,
                    'leg1': 90,
                    'leg2': 90,
                    'leg3': 90,
                }
            ),
        )

        change_renderer = TextRenderer(
            text_value=Expr("format(cell.value, '.3f')"),
            text_color=Expr('"red" if cell.value < 0 else default_value'),
        )

        live_renderer = TextRenderer(
            text_value=Expr("format(cell.value, '.3f')"),
            # text_color=Expr('"red" if cell.value < 0 else default_value'),
            background_color=VegaExpr(
                "(cell.value >= cell.metadata.data['target'] && cell.metadata.data['sign'] == '+') || \
                (cell.value <= cell.metadata.data['target'] && cell.metadata.data['sign'] == '-')  ? 'red' : default_value"
            )
        )

        expr_renderers = {
            'target': float_renderer,
            'live': live_renderer,
            'change': change_renderer,
        }

        self.expr_dg = EditableGrid(
            new_data={
                'expression': "",
                'sign': "+",
                'target': np.nan,
                'live': np.nan,
                'change': np.nan,
            },
            grid_kwargs=dict(
                base_column_size=75,
                renderers=expr_renderers,
                column_widths={
                    'expression': 350,
                    'sign': 60
                }
            ),
        )

    @property
    def dg(self):
        return self.fly_grid.dg

    def make_view(self, **kwargs):

        self.fly_view = w.VBox([self.file_box, self.fly_grid.view])
        self.view = v.Container(
            children=[w.VBox([self.fly_view, self.expr_dg.view])],
            class_="ma-0 pa-0", style_=f"background: {bg_color}"
        )

    def link(self, **kwargs):

        self.load_btn.on_event(
            'click',
            partial(on_click_upload, self=self)
        )

        self.save_btn.on_event(
            'click',
            partial(on_click_save, self=self)
        )

        super().link(**kwargs)

    def upload_file(self):
        file_name = radar_path / 'save' / f'{self.file_tf.v_model}_flies.csv'
        data = pd.read_csv(file_name)
        print(data)
        current_data = self.dg.data
        self.dg.data = pd.concat([current_data, data])[len(current_data):].reset_index(drop=True)

        try:
            file_name = radar_path / 'save' / f'{self.file_tf.v_model}_expr.csv'
            data = pd.read_csv(file_name)
            expr_data = self.expr_dg.dg.data
            self.expr_dg.dg.data = pd.concat([expr_data, data])[len(expr_data):].reset_index(drop=True)
        except FileNotFoundError:
            pass

    def save_to_file(self):
        file_name = radar_path / 'save' / f'{self.file_tf.v_model}_flies.csv'
        current_data = self.dg.data
        current_data[self.fly_input_cols].to_csv(file_name, index=False)

        file_name = radar_path / 'save' / f'{self.file_tf.v_model}_expr.csv'
        expr_data = self.expr_dg.dg.data
        expr_data[self.expr_input_cols].to_csv(file_name, index=False)

    def get_data(self, **kwargs):
        data = self.dg.data
        if not (data.isna().sum().sum() == 11 and len(data) == 1):
            new_data = update_flies_data(
                data=self.dg.data[self.fly_input_cols],
                db_curves=kwargs.get('db_curves')
            )
            self._new_data = new_data
            self.dg.data = new_data
            self.calc_expressions()

    def calc_expressions(self):
        expr_data = self.expr_dg.dg.data
        expr_data = expr_data.loc[expr_data['expression'] != ""]
        expr_data = expr_data.dropna(subset='expression')
        if not expr_data.empty:
            live = bh.bhTsCalcExpression(
                resultnames=range(len(expr_data)),  # if omitted it doesn't work with multiple expressions at once
                expressions=expr_data['expression'].to_list(),
                varnamesorhndl=self.dg.data['name'].to_list(),
                varvalues=self.dg.data['live'].to_list()
            )
            live = ensure_series(live)

            change = bh.bhTsCalcExpression(
                resultnames=range(len(expr_data)),
                expressions=expr_data['expression'].to_list(),
                varnamesorhndl=self.dg.data['name'].to_list(),
                varvalues=self.dg.data['change'].to_list()
            )
            change = ensure_series(change)
            expr_data = expr_data.assign(
                live=live,
                change=change
            )

            self.expr_dg.dg.data = expr_data


def on_click_upload(widget, event, payload, self):
    self.upload_file()


def on_click_save(widget, event, payload, self):
    self.save_to_file()


def on_click_refresh(widget, event, payload, self):
    self.refresh_data()
