import base64
import smtplib
from itertools import combinations
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart

import bhutils
import blpapi
import ipyvuetify as v
import ipywidgets as w
import dataframe_image as dfi
import numpy as np
import pandas as pd
from IPython.display import display, clear_output
from scipy.optimize import minimize, linprog
from scipy.special import comb

from api.risk.var import (
    VaRPnl,
    get_db_from_clarion_positions,
    get_fut_trade_spec,
    get_var_ts,
    get_db_from_specs,
    var_ptf,
    cvar_ptf,
    get_clarion_fut_trade_spec,
)

from api.email import smtp_server, to_email_test, to_email_all, df_to_html, from_email, to_email_ext, get_email

from gioutils.tools_clarion import get_clarion_positions
from gioutils.clarion_ext import Runner
from gioutils.gui.pandas import millifyp as millify
from gioutils.utils import encode_df_as_image_tag, get_specific_future, filter_high_corr

rng = np.random.default_rng()

# max_size = 10e3
# max_iter = 1
# corr_threshold = 0.97
# n_trades = 5
#
# new_trades_list = [
#     ('er', 'u24'),
#     ('sfr', 'm24'),
#     ('rx', 'm23'),
#     ('ty', 'm23'),
# ]

stirs = [
    'er',
    'sfr',
    'sfi',
    #'ff'
]

govts = [
    'tu',
    'fv',
    'ty',
    'us',
    'du',
    'oe',
    'rx',
    'ub',
]


def bbg_stir_to_clarion(code, date=None):
    date = date or pd.Timestamp.now()
    year = str(date.year)[-2]
    return f"{code[:-1]}{year}{code[-1]}"


def min_cvar_linprog(current_ptf, new_trades, q=0.05, min_size=None, max_size=None):
    X = pd.concat([current_ptf, new_trades], axis=1).dropna()
    t, n = X.shape
    c = np.concatenate(
        [
            np.zeros(shape=n),
            np.full(shape=t, fill_value=(q * t) ** -1),
            np.ones(shape=1)
        ]
    )
    A_ub = np.concatenate(
        [
            -X.to_numpy(),
            -np.eye(t),
            -np.ones(shape=(t, 1)),
        ],
        axis=1
    )
    b_ub = np.zeros(t)
    A_eq = np.zeros(shape=(1, A_ub.shape[1]))
    A_eq[0, 0] = 1
    b_eq = 1
    bounds = [
        # None,
        (1.0, 1.0),
        *[(min_size, max_size) for col in X.columns[1:]],
        *[(0, None) for i in range(t)],
        (None, None)
    ]

    r = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq, bounds=bounds)
    wgt = r['x'][1:X.shape[1]]
    return r, wgt


def send_live_var_email(var_close, var_intraday, var_new, intraday_group, trades_show, to=None):
    to_email = get_email(to)
    font_family = 'Helvetica, Arial, Sans-Serif'

    message = MIMEMultipart("alternative")
    message["Subject"] = f'LIVE VaR REDUCTION - {pd.Timestamp.now(): %d%b%y %H:%M}'
    message["From"] = from_email
    message["To"] = ','.join(to_email)

    # dfs = [encode_df_as_image_tag(s) for s in [intraday_group, trades_show]]

    dfs = [df_to_html(s.style.format(millify)) for s in [intraday_group, trades_show]]
    html_body = f"<h3 style=\"font-family:{font_family};\">Close VaR:{'&nbsp;' * 40}{var_close: .2%}</h3>"
    html_body = html_body + f"<h3 style=\"font-family:{font_family};\">VaR with Intraday (below): {'&nbsp;' * 13}{var_intraday: .2%}</h3>"
    html_body = html_body + dfs[0] + '<br>' * 3
    html_body = html_body + f"<h3 style=\"font-family:{font_family};\">VaR after the below trades:{'&nbsp;' * 11}{var_new: .2%}</h3>"
    html_body = html_body + dfs[1]
    html_ = MIMEText(html_body, "html")
    message.attach(html_)
    smtp = smtplib.SMTP(smtp_server)
    # smtp.set_debuglevel(1)
    smtp.sendmail(from_email, to_email, message.as_string())


# VAR
def var_reduction_email(clarion, mod_cob_fn=None):
    runner = Runner(clarion)
    clarion_delta = clarion.metric(
        'delta',
        'Delta',
        'Rates',
        {'VolSpotDynamic': 'StickyDelta', 'RiskSpace': 'Par', 'RiskBuckets': 'Default'}
    )
    flag = 4.5e6
    dv = VaRPnl()
    dv.get_data()

    cob_ptf = dv.hist.sum(axis=1).rename('ptf')

    if mod_cob_fn:
        dv, cob_ptf = mod_cob_fn(dv).sum(axis=1).rename('ptf')


    ### UPDATE POSITIONS
    df = get_clarion_positions(clarion)
    # df.loc[df.query("Description == 'USD SOFR CME 3M MAR23JUN24 C 95.500'").index[0], 'Notional'] = - 2000
    intraday = df.query('isIntraday == True')
    intraday_group = intraday.groupby('Description')['Notional'].sum().replace(0, np.nan).dropna().to_frame()
    rates_mask = intraday.loc[intraday['Category'] == 'rates', 'Description'].drop_duplicates().to_list()
    intraday_rates = intraday_group.loc[intraday_group.index.isin(rates_mask)]

    ### NEW TRADES VAR
    db = get_db_from_clarion_positions(intraday)
    intraday_trades, res = get_var_ts(db)

    current_ptf = pd.concat([cob_ptf, intraday_trades], axis=1).sum(axis=1)

    new_trades_specs = [get_fut_trade_spec(underlying, contract) for underlying, contract in new_trades_list]
    new_trades_clarion = [get_clarion_fut_trade_spec(clarion, underlying, contract) for underlying, contract in
                          new_trades_list]

    deltas = runner.run(metrics=[clarion_delta], data_list=new_trades_clarion).loc[:, ['id', 'delta']]
    new_trades_db = get_db_from_specs(new_trades_specs)
    new_trades, res = get_var_ts(new_trades_db)

    ### MINIMIZE
    # # x0 = rng.normal(size=new_trades.shape[1])
    # x0 = np.full(shape=new_trades.shape[1], fill_value=-100)
    # x0 = rng.normal(size=new_trades.shape[1]) * 1000

    scales = [*np.hstack([10 ** np.arange(0, np.log10(max_size) + 1), - 10 ** np.arange(0, np.log10(max_size) + 1)])]
    max_try = max_iter * len(scales)

    k = 0
    res_opt = None
    for i in range(max_iter):
        for scale in scales:
            k = k + 1
            x0 = rng.normal(size=new_trades.shape[1]) * scale
            x0[x0 < -max_size] = -max_size
            x0[x0 > max_size] = max_size
            res_opt_ = minimize(
                lambda wgt: var_ptf(
                    current_ptf=current_ptf,
                    new_trades=new_trades,
                    wgt=wgt
                ),
                bounds=[(-max_size, max_size) for col in new_trades],
                x0=x0,
                # tol=0.001,
                method='Nelder-Mead',
                # method='L-BFGS-B',
                # constraints=[
                #     {
                #         'type': 'ineq',
                #         'fun': lambda wgt: 0.3 + var(df=d1, wgt=wgt, periods=522, diff=True, scale=-1)
                #     },
                #     {
                #         'type': 'ineq',
                #         'fun': lambda wgt: 1 + var(df=d1, wgt=wgt, periods=522, agg=True, diff=True, scale=-1)
                #     },
                # ],
                # options={
                #     'maxiter': 10000000000000,
                # }
            )
            if res_opt is None:
                res_opt = res_opt_

            if res_opt_['fun'] < res_opt['fun']:
                res_opt = res_opt_

            print(f"{k} - {max_try}", res_opt['x'], round(res_opt['fun'], 4), end='\r')

    var_close = - dv.var() / flag
    var_intraday = - current_ptf.quantile(0.05, interpolation='weibull') / flag

    trades = pd.Series(res_opt['x'].round(0), index=new_trades.columns.str.upper(), name='quantity')
    var_new = res_opt['fun']
    deltas_opt = pd.Series(deltas['delta'].to_numpy(), index=deltas['id'].str.upper())
    delta_usd = (trades * deltas_opt).rename('delta$')

    trades_show = pd.concat([trades, delta_usd], axis=1)
    sum_ = trades_show.sum().rename('TOTAL')
    sum_.iloc[0] = np.nan
    sum_ = sum_.to_frame().T
    trades_show = pd.concat([trades_show, sum_])

    display(w.HTML(f"<h3>Close VaR:{'&nbsp;' * 40}{var_close: .2%}</h3>"))
    display(w.HTML(f"<h3>VaR with Intraday (below): {'&nbsp;' * 11}{var_intraday: .2%}</h3>"))
    display(intraday_rates)
    display(w.HTML(f"<h3>VaR after the below trades:{'&nbsp;' * 11}{var_new: .2%}</h3>"))
    display(trades_show)

    send_live_var_email(var_close, var_intraday, var_new, intraday_rates, trades_show)


def var_reduction_email2(
        clarion,
        bq,
        book='MM',
        n_trades=5,
        corr_threshold=0.97,
        max_size=10e3,
        use_best_var=False,
        mod_cob_fn=None,
        new_trades_list=None,
        send_email=False,
):
    bq.start()
    capital = 300e6 if book.lower() == 'mm' else 200e6
    flag = 1.5 / 100 * capital
    runner = Runner(clarion)
    clarion_delta = clarion.metric(
        'delta',
        'Delta',
        'Rates',
        {'VolSpotDynamic': 'StickyDelta', 'RiskSpace': 'Par', 'RiskBuckets': 'Default'}
    )

    dv = VaRPnl()
    dv.get_data(book=book)

    cob_ptf = dv.hist.sum(axis=1).rename('ptf')

    if mod_cob_fn:
        dv, cob_ptf = mod_cob_fn(dv).sum(axis=1).rename('ptf')

    ### INTRADAY POSITIONS
    df = get_clarion_positions(clarion, book=f"{book}-BAL")
    # df.loc[df.query("Description == 'USD SOFR CME 3M MAR23JUN24 C 95.500'").index[0], 'Notional'] = - 2000
    intraday = df.query('isIntraday == True')
    intraday_group = intraday.groupby('Description')['Notional'].sum().replace(0, np.nan).dropna().to_frame()
    rates_mask = intraday.loc[intraday['Category'] == 'rates', 'Description'].drop_duplicates().to_list()
    intraday_rates = intraday_group.loc[intraday_group.index.isin(rates_mask)]
    if not intraday_rates.empty:
        db = get_db_from_clarion_positions(intraday)
        intraday_trades, res = get_var_ts(db)
        current_ptf = pd.concat([cob_ptf, intraday_trades], axis=1).sum(axis=1)
    else:
        current_ptf = cob_ptf

    ### ALL STIRS AND GOVT FUTURES
    if not new_trades_list:
        gen_futs = [
            *[f"{code}{i}" for code in stirs for i in range(2, 16 + 1)],
            *[f"{code}{i}" for code in govts for i in range(1, 1 + 1)]
        ]
        spec_futs = get_specific_future(gen_futs, bq=bq)
        spec_fut_clarion = [fut.split(' ')[0] for fut in spec_futs]
        spec_fut_clarion = [bbg_stir_to_clarion(fut) for fut in spec_fut_clarion]
        all_fut_list = [(fut[:-3].lower(), fut[-3:].lower()) for fut in spec_fut_clarion]
        all_fut_specs = [get_fut_trade_spec(underlying, contract) for underlying, contract in all_fut_list]

        all_fut_db = get_db_from_specs(all_fut_specs)
        all_fut_ts, res = get_var_ts(all_fut_db)
        new_trades = filter_high_corr(all_fut_ts, all_fut_ts.corrwith(current_ptf).abs(), threshold=corr_threshold)
    else:
        new_trades_specs = [get_fut_trade_spec(underlying, contract) for underlying, contract in new_trades_list]
        new_trades_db = get_db_from_specs(new_trades_specs)
        new_trades, res = get_var_ts(new_trades_db)

    ### MINIMISE
    n_trades_ = n_trades if not new_trades_list else len(new_trades_list)
    min_ = 1e9
    total = comb(new_trades.shape[1], n_trades_, exact=True)
    for i, comb_ in enumerate(
            combinations(
                new_trades.columns,
                min(n_trades_, new_trades.shape[1]) if n_trades_ > 0 else new_trades.shape[1]
            )
    ):
        new_trades_ = new_trades.loc[:, comb_]
        r, wgt = min_cvar_linprog(
            current_ptf=current_ptf,
            new_trades=new_trades_,
            min_size=-max_size,
            max_size=max_size
        )
        cvar_ = cvar_ptf(current_ptf=current_ptf, new_trades=new_trades_, wgt=wgt, flag=flag)
        var_ = var_ptf(current_ptf=current_ptf, new_trades=new_trades_, wgt=wgt, flag=flag)
        best = var_ if use_best_var else cvar_

        if best < min_:
            min_ = best
            wgt_ = wgt
            ress = new_trades_, r, wgt, cvar_, var_

        print(f"{i + 1}/{total} // {new_trades.shape[1]}_choose_{n_trades_} - {wgt_.round()} {round(ress[-2], 4)} {round(ress[-1], 4)}", end='\r')

    new_trades_ = ress[0]
    new_trades_clarion = [get_clarion_fut_trade_spec(clarion, underlying, contract) for underlying, contract in
                          [(fut[:-3], fut[-3:]) for fut in new_trades_]]
    deltas = runner.run(metrics=[clarion_delta], data_list=new_trades_clarion).loc[:, ['id', 'delta']]
    clear_output()

    var_close = - cob_ptf.quantile(0.05, interpolation='weibull') / flag
    var_intraday = - current_ptf.quantile(0.05, interpolation='weibull') / flag

    trades = pd.Series(wgt_.round(0), index=new_trades_.columns.str.upper(), name='quantity')
    var_new = var_ptf(current_ptf=current_ptf, new_trades=new_trades_, wgt=wgt_, flag=flag)
    deltas_opt = pd.Series(deltas['delta'].to_numpy(), index=deltas['id'].str.upper())
    delta_usd = (trades * deltas_opt).rename('delta$')

    trades_show = pd.concat([trades, delta_usd], axis=1)
    sum_ = trades_show.sum().rename('TOTAL')
    sum_.iloc[0] = np.nan
    sum_ = sum_.to_frame().T
    trades_show = pd.concat([trades_show, sum_])

    display(w.HTML(f"<h3>Close VaR:{'&nbsp;' * 40}{var_close: .2%}</h3>"))
    display(w.HTML(f"<h3>VaR with Intraday (below): {'&nbsp;' * 11}{var_intraday: .2%}</h3>"))
    display(intraday_rates)
    display(w.HTML(f"<h3>VaR after the below trades:{'&nbsp;' * 11}{var_new: .2%}</h3>"))
    display(trades_show)

    if send_email:
        send_live_var_email(var_close, var_intraday, var_new, intraday_rates, trades_show, to=send_email)


