import sys
from pathlib import Path

base_path = Path(__file__).resolve().parents[1]
sys.path.append(str(base_path))
sys.path.append(str(base_path.parent / 'gioutils'))
