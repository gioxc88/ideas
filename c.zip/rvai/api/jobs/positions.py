import clarion
import pandas as pd
import smtplib
import win32com.client as win32

from gioutils.blpw import BlpParser, BlpQuery
from gioutils.tools_clarion import get_history_plotter_book

from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart

from_email = 'gioreports@brevanhoward.com'
smtp_server = "smtp.rivagecapital.com"
to_email = [
    'giovambattista.perciaccante@brevanhoward.com',
    # 'menashe.banit@brevanhoward.com'
]


def send_history_plotter_email(df):
    message = MIMEMultipart("alternative")
    message["Subject"] = f'HISTORY PLOTTER - Rates {pd.Timestamp.now(): %d%b%y %H:%M}'
    message["From"] = from_email
    message["To"] = ','.join(to_email)
    html_body = df.reset_index().to_html(header=False, index=False)
    html_ = MIMEText(html_body, "html")
    message.attach(html_)
    smtp = smtplib.SMTP(smtp_server)
    # smtp.set_debuglevel(1)
    smtp.sendmail(from_email, to_email, message.as_string())


def history_plotter_email(clarion, bq, delta_mul=-1, delta_tol=499, **kwargs):
    d = get_history_plotter_book(clarion, bq, delta_mul=delta_mul, delta_tol=delta_tol, **kwargs)
    send_history_plotter_email(d[1])
    print('SUCCESS')
    return d


