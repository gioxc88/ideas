import json
import base64
import smtplib
import logging
import os
import re
import sys
from copy import deepcopy
from functools import cache, cached_property, partial
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from pathlib import Path

import ipyvuetify as v
import ipywidgets as w
import numpy as np
import pandas as pd
import dataframe_image as dfi
from plotly import graph_objects as go
from plotly.subplots import make_subplots
from pandas.tseries.offsets import BDay

from gioutils.blpw import BlpQuery
from gioutils.gui.pandas import millifyp as millify
from gioutils.utils import (
    parse_offset,
    today,
    read_pickle,
    encode_df_as_image_tag,
    encode_plotly_fig_as_image_tag,
    filter_high_corr
)

from IPython.display import display

from api.instruments import config as c
from api.instruments.cache import data_cache, get_key
from api.instruments.future import FutureChain, FutureFly, FutureSpread
from api.instruments.signals import EnsambleSignal, MACDHistCrossover, ZScoreThreshold
from api.instruments.signals2 import BaseSignal, MACDCustomSignal, get_crossover_signal
from api.instruments.strategies import FutureStrategy
from api.instruments.strategies2 import MACDCustomStrategy
from api.instruments.swap import Fly, RealSwap, RollingSwap, Spread
from api.instruments.utils import ez_bump, parse_dates, parse_number
from api.data.base import root_path
from api.email import smtp_server, to_email_test, to_email_all, df_to_html, from_email, to_email_ext

pd.options.plotting.backend = "plotly"
pd.options.display.float_format = partial(millify, pct=None)
c.USE_T_COST = True


nn = 4
notional = 1000
hist = "10y"
strategy_hist = "1y"
file_path = root_path / 'notebooks/strategy'
start_hist = '10y'
end_hist = today()

stirs = read_pickle(file_path / 'top_stirs.pickle')
govt = read_pickle(file_path / 'top_govt.pickle')
stir_spreads = read_pickle(file_path / 'top_stir_spreads.pickle')
stir_flies = read_pickle(file_path / 'top_stir_flies.pickle')

ress = {**stirs, **govt, **stir_spreads, **stir_flies}
strategies = {k: deepcopy(ss.iloc[0]) for k, ss in ress.items()}


def make_plotly_fig(strategy):
    data = strategy._data.iloc[-260:, :]
    quote = data['quote']

    layout = go.Layout(
        template='plotly_dark',
        title=dict(
            text=strategy.instrument.name,
            x=0.5,
            xanchor='center'
        ),
        width=1200,
        height=600,
        paper_bgcolor='#1e222d',
        plot_bgcolor='#1e222d',
        margin=dict(t=30, b=15),
        xaxis_rangeslider_visible=False,
        xaxis_rangebreaks=[dict(bounds=["sat", "mon"])]
    )

    if isinstance(quote, pd.DataFrame):
        quote = quote.iloc[:, 0]

    asset_trace = go.Scatter(
        x=data.index,
        y=quote,
        name='quote',
        line_color='yellow',
        line_width=2
    )
    macd_trace = go.Scatter(
        x=data.index,
        y=data['macd'],
        name='macd',
        line_color='white',
        line_width=1.5
    )
    macdsignal_trace = go.Scatter(
        x=data.index,
        y=data['macdsignal'],
        name='macdsignal',
        line_color='#ff7f0e',
        line_width=1.5
    )

    color_mask = (data['macdhist'] > 0).astype(int)
    macdhist_trace = go.Bar(
        x=data.index,
        y=data['macdhist'],
        name='macdhist',
        marker_line_width=1,
        marker_line_color=(color_mask).replace({1: '#3d986f', 0: '#d83b33'}),
        marker_color=(color_mask).replace({1: 'lime', 0: '#a83532'})
    )

    traces = [macd_trace, macdsignal_trace, macdhist_trace]
    fig = make_subplots(
        rows=2,
        cols=1,
        row_heights=[0.7, 0.3],
        shared_xaxes=True,
        vertical_spacing=0.01
    ).update_layout(layout)
    fig.add_trace(asset_trace, row=1, col=1)
    for trace in traces:
        fig.add_trace(trace, row=2, col=1)
    return fig


def send_macd_email(df, df_sub, img_tags=None, to=None):
    if df is None:
        html_body = "<h2>NO SIGNALS</h2>"
    else:
        img_tags = img_tags or []
        html_body = df_to_html(df_sub.style.format(
            partial(millify, decimal=4, pct=None),
            subset=[*df_sub.drop('date', axis=1).columns]
        ).format('{:%d%b%Y}', subset='date'))

        html_body = html_body + '<br>' + df_to_html(df.style.format(
            partial(millify, decimal=4, pct=None),
            subset=[*df.drop('date', axis=1).columns]
        ).format('{:%d%b%Y}', subset='date'))
        for tag in img_tags:
            html_body = html_body + ('<br>' * 3) + tag

    to_email = to_email_test if to == 'test' else to_email_ext if to == 'ext' else to_email_all
    message = MIMEMultipart("alternative")
    message["Subject"] = f'MACD SIGNALS {pd.Timestamp.now(): %d%b%y %H:%M}'
    message["From"] = from_email
    message["To"] = ','.join(to_email)

    html_ = MIMEText(html_body, "html")
    message.attach(html_)
    smtp = smtplib.SMTP(smtp_server)
    # smtp.set_debuglevel(1)
    smtp.sendmail(from_email, to_email, message.as_string())


# bq = BlpQuery(timeout=50000).start()


# setting the history
def macd_signals_email(bq, send_email=True, filter_=True, chart=True):
    bq.start()
    all_instruments = {}
    for k, strategy in strategies.items():
        _instruments = getattr(strategy.instrument, 'instruments', [strategy.instrument])
        for instrument in _instruments:
            instrument.start_hist = start_hist
            instrument.end_hist = end_hist
            all_instruments.setdefault(instrument.ticker, instrument)

    fields = {
        'px_last': 'quote',
        'yld_ytm_mid': 'yld'
    }

    ref_fields = {
        'fut_tick_size': 'tick_size',
        'fut_tick_val': 'tick_value',
        'fut_val_pt': 'point_value'

    }

    symbols = {instrument.symbol: instrument for key, instrument in all_instruments.items()}

    # History download
    hist = bq.bdh(
        securities=[*symbols.keys()],
        fields=fields,
        start_date=today() - parse_offset(start_hist),
    )
    hist = hist.set_index('date')

    # Updating history
    for symbol, instrument in symbols.items():
        for attr in fields.values():
            series = hist.query(f'security == "{symbol}"')[attr]
            series = instrument._rename_attr(series, attr)
            key = get_key(instrument, attr, keys=['start_hist', 'end_hist'])
            data_cache[key] = series

    # Reference download
    ref = bq.bdp(
        securities=[*symbols.keys()],
        fields=ref_fields,
    )

    # Updating reference
    for symbol, instrument in symbols.items():
        for attr in ref_fields.values():
            val = ref.query(f'security == "{symbol}"')[attr].squeeze()
            try:
                val = float(val)
            except:
                pass
            key = get_key(instrument, attr)
            data_cache[key] = val

    # Last donwload
    last = bq.bdp(
        securities=[*symbols.keys()],
        fields=fields,
    )

    # Updating last
    for symbol, instrument in symbols.items():
        for attr in fields.values():
            value = last.query(f'security == "{symbol}"')[attr].squeeze()
            getattr(instrument, attr).iloc[-1] = value

    # Running strats for entire history
    for key, self in strategies.items():
        # print(key)
        self.run()


    pattern = re.compile(r'\d+')

    # for key, self in strategies.items():
    #     legs_ = [int(i) for i in re.findall(pattern, self.instrument.name)]
    #     if self._running and self._summary.iloc[-1]['entry_date'] == today() and legs_[0] >= nn:
    #         last_trade = self._summary['trade'].iloc[-1]
    #         display(v.Html(children=key.upper(), tag='h2'))
    #         out = w.Output()
    #         out_chart = w.Output()
    #         with out:
    #             display(self._pnl.query(f"trade == {last_trade}"))
    #         with out_chart:
    #             display(self._pnl['pv'].plot())
    #         display(w.VBox([out, out_chart]))
    # pattern = re.compile(r'\d+')

    send = []
    send_strategies = {}
    legs = []
    roots = []
    types = []
    scores = []
    for key, self in strategies.items():
        legs_ = [int(i) for i in re.findall(pattern, self.instrument.name)]
        if self._running and self._summary.iloc[-1]['entry_date'] >= (today() - BDay(2)) and legs_[0] >= nn:
            instr_name = self.instrument.name
            infos = self._pnl.loc[self._summary.iloc[-1:]['entry_date']].reset_index().squeeze()
            infos = infos[
                [
                    'date',
                    'signal',
                    'quote',
                    'stop_loss'
                ]
            ]
            infos['stop_loss'] = infos['stop_loss'] / 2
            infos['take_profit'] = infos['stop_loss'] * 2.5
            infos['stop_loss'] = infos['quote'] - infos['stop_loss'] * infos['signal']
            infos['take_profit'] = infos['quote'] + infos['take_profit'] * infos['signal']
            infos['signal'] = 'BUY' if infos['signal'] == 1 else 'SELL' if \
                infos['signal'] == -1 else 'error'
            # send.append(infos.rename(self.instrument.name).to_frame().T)
            infos['tickers'] = '  '.join(self.instrument.real_future_tickers).upper()
            # infos['type'] = instr_name.split(' ')[0] if len(instr_name.split(' ')) > 1 else 'fut'
            send.append(infos.rename(key).to_frame().T)
            types.append(instr_name.split(' ')[0] if len(instr_name.split(' ')) > 1 else 'fut')
            legs.append(legs_)
            roots.append(self.instrument.root)
            scores.append(np.abs(
                (self._data['macd'].iloc[-1] - self._data['macd'].iloc[-195:].mean()) / self._data['macd'].iloc[-195:].std()))
            send_strategies[key] = self

    if not send:
        send_macd_email(
            None,
            None,
            to=send_email
        )
        return

    to_send = pd.concat(send)
    infos = pd.concat([pd.Series(to_send.index, name='name'), pd.Series(types, name='type'), pd.Series(roots, name='root'),
                       pd.DataFrame(legs), pd.Series(scores, name='score')], axis=1)
    to_send['score'] = infos['score'].to_list()
    to_send = to_send.sort_values(by='date', ascending=False)

    img_tags = []
    if chart:
        for key, strat in {kk: send_strategies[kk] for kk in to_send.index}.items():
            fig = make_plotly_fig(strat)
            img_tags.append(encode_plotly_fig_as_image_tag(fig))

    to_send = to_send \
                .rename({key: strat.instrument.name for key, strat in send_strategies.items()}, axis=0)

    if filter_:
        # to_keep = []
        # for index, group in infos.groupby(['type', 'root'], sort=False, dropna=False):
        #     if len(group) > 1:
        #         to_keep.append(group.loc[group['score'].idxmax(), 'name'])
        #     else:
        #         to_keep.append(group.squeeze()['name'])
        allq = pd.concat([strat._data['quote'].rename(strat.instrument.name).diff() for key, strat in send_strategies.items()], axis=1)
        to_keep = filter_high_corr(df=allq, scores=to_send['score'], threshold=0.8, return_df=False)
    else:
        to_keep = []

    if send_email:
        send_macd_email(
            to_send.set_index('tickers', append=True),
            to_send.loc[to_keep].sort_values(by='date', ascending=False).set_index('tickers', append=True),
            img_tags=img_tags,
            to=send_email
        )
    return strategies, send_strategies, to_send, infos, to_keep



