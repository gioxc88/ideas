import numpy as np
import pandas as pd
import QuantLib as ql

from gioutils.utils import (
    parse_offset, today,
    get_next_n,
    date_from_offset,
    get_bday,
    parse_swap_tenor_expr
)
from gioutils.blpw import BlpQuery
from gioutils.ezutils import bh, bhs


mult_map = {
    'k': 1e3,
    'm': 1e6,
}


def parse_number(x):
    if isinstance(x, str):
        if len(x) == 1:
            x_, m = float(x), None
        else:
            x_, m = float(x[:-1]), x[-1]
        if m not in mult_map:
            x_ = float(x)
            mult = 1
        else:
            mult = mult_map[m]
        x_ = x_ * mult
        return int(x_) if x_.is_integer() else x_
    return x


def ez_bday(date=None, ccy=None, bump=None, eom=None, cals_prov_db=None, previous=False):
    b1, b2 = ("-1b", "1b") if not previous else ("1b", "-1b")

    date = bh.bhBump(
        date=date,
        term=b1,
        hols=bh.bhDbLookUp(
            rsid=cals_prov_db,
            lookupvalues=ccy.upper(),
            lookupcols="Currency",
            returncols="Calendar",
            matchtype=0
        ),
        bump=bump,
        eom=eom
    )

    date = bh.bhBump(
        date=date,
        term=b2,
        hols=bh.bhDbLookUp(
            rsid=cals_prov_db,
            lookupvalues=ccy.upper(),
            lookupcols="Currency",
            returncols="Calendar",
            matchtype=0
        ),
        bump=bump,
        eom=eom
    )
    return pd.to_datetime(date)


def ez_bump(date=None, term=None, ccy=None, bump=None, eom=None, cals_prov_db=None, ensure_bday=False, previous=False):
    cals_prov_db = cals_prov_db or bhs.ccy_cals_prov_db

    if ensure_bday and not term:
        return ez_bday(date=date, ccy=ccy, bump=bump, eom=eom, cals_prov_db=cals_prov_db, previous=previous)

    else:
        date = bh.bhBump(
            date=date,
            term=term,
            hols=bh.bhDbLookUp(
                rsid=cals_prov_db,
                lookupvalues=ccy.upper(),
                lookupcols="Currency",
                returncols="Calendar",
                matchtype=0
            ),
            bump=bump,
            eom=eom
        )
        date = ez_bday(date=date, ccy=ccy, bump=bump, eom=eom, cals_prov_db=cals_prov_db, previous=previous)
        return pd.to_datetime(date)


def parse_dates(start, end, b=True):
    '''
    Assuming either start or end is an actual date
    '''
    start, end = parse_offset(start, b=b), parse_offset(end, b=b)
    if isinstance(start, pd.Timestamp) and isinstance(end, pd.Timestamp):
        res = (start, end)
    else:
        res = (end - start, end) if isinstance(start, pd.tseries.offsets.BaseOffset) else (start, start + end)
    if b:
        return get_bday(res[0], previous=False), get_bday(res[1], previous=False)
    return res


def get_notional_from_weights(notional, weight):
    n = notional
    mult = weight
    if isinstance(n, str):
        if n[0] == 'd':
            n0 = 'd'
            n = n[1:]
        else:
            n0 = ''

        if n[-1] in mult_map:
            n1 = n[-1]
            n = n[:-1]
        else:
            n1 = ''

        n = float(n) * mult
        if n.is_integer():
            n = int(n)
        return f"{n0}{n}{n1}"
    else:
        n = float(n) * mult
        if n.is_integer():
            n = int(n)
        return n