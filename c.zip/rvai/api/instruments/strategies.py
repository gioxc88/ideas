import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay


def get_sltp_dates(quote, signal, value, stop=False):
    c = 1 if stop else -1
    to_check = (quote - quote.iloc[0]) * signal
    reached = value + c * to_check <= 0
    if not reached.sum():
        return reached.index[-1] + BDay()
    else:
        return reached.idxmax()


def static_sltp(
        sl,
        tp,
        instrument,
        signal,
        grouper=None,
):
    df = pd.concat([instrument.quote, signal.signal], axis=1)
    grouper = grouper if grouper is not None else signal.trade_grouper
    g = df.groupby(grouper, sort=False)
    new_signals = []
    if sl and tp:
        for index, trade in g:
            if index > 0:
                ns = trade['signal'].copy()
                d1 = get_sltp_dates(trade['quote'], trade['signal'], tp, stop=False)
                d2 = get_sltp_dates(trade['quote'], trade['signal'], sl, stop=True)
                d = min(d1, d2)
                ns.loc[ns.index > d] = 0
                new_signals.append(ns)
    elif tp:
        for index, trade in g:
            if index > 0:
                ns = trade['signal'].copy()
                d = get_sltp_dates(trade['quote'], trade['signal'], tp, stop=False)
                ns.loc[ns.index > d] = 0
                new_signals.append(ns)
    elif sl:
        for index, trade in g:
            if index > 0:
                ns = trade['signal'].copy()
                d = get_sltp_dates(trade['quote'], trade['signal'], sl, stop=True)
                ns.loc[ns.index > d] = 0
                new_signals.append(ns)
    else:
        return signal.signal

    new_signals = pd.concat(new_signals)
    return new_signals


class FutureStrategy:
    def __init__(
            self,
            signal,
            sl=None,
            tp=None,
            sltp=None,
            **kwargs
    ):
        self.signal = signal
        self.trade_eop = kwargs.pop('trade_eop', False)
        self._sl = sl
        self._tp = tp
        self._sl_kwargs = kwargs.pop('_sl_kwargs', {})
        self._tp_kwargs = kwargs.pop('_tp_kwargs', {})
        self.sltp = sltp or static_sltp

    def _get_sl_tp(self, value, **kwargs):
        if not value:
            return value
        if callable(value):
            return value(self, **kwargs)
        else:
            return self.instrument.get_points(value)

    @property
    def sl(self):
        return self._get_sl_tp(self._sl, **self._sl_kwargs)

    @property
    def tp(self):
        return self._get_sl_tp(self._tp, **self._tp_kwargs)

    @property
    def instrument(self):
        return self.signal.instrument

    @property
    def pnl(self):
        return self.get_pnl().rename('pnl')

    @property
    def pv(self):
        pv = self.pnl.cumsum().rename('pv')
        idx = pv.index.get_loc(pv.first_valid_index()) - 1
        pv.iloc[idx] = 0
        return pv

    def get_pnl(self, **kwargs):
        instr = self.instrument
        signal = self.signal
        signal_ = signal.signal
        sltp = kwargs.pop('sltp', True)

        if sltp:
            signal_ = self.sltp(
                self.sl,
                self.tp,
                instr,
                signal,
            )

        if self.trade_eop:
            signal_ = signal_.dropna().shift(fill_value=0)

        # if True:
        #     signal_ = signal_.mask(signal.trades.fillna(0) != 0, 0)

        pnl = instr.pv.diff() * signal_
        t_cost = instr.t_cost

        if t_cost:
            pnl = pnl - (self.slippage * np.abs(signal_))
        return pnl

    @property
    def slippage(self):
        t_cost = self.instrument.t_cost
        if t_cost:
            slip = self.instrument.contract_tick_value(t_cost) * self.signal.trades.abs()
        else:
            slip = pd.Series(0, index=self.instrument.quote.index)
        return slip.rename('slippage')
