import numpy as np
import pandas as pd
from IPython.display import display
from pandas.tseries.offsets import BDay
from termcolor import colored

from gioutils.utils import (
    today,
    get_bbg_fut_chain_ticker
)

from .signals2 import get_crossover_signal
from .utils import parse_dates


def get_next_signal(signals, index=None, last=False):
    ss = signals.copy()
    if last:
        ss = ss.sort_index(ascending=False)
    if index:
        ss.iloc[:index + 1] = 0
    signal_date = (ss.fillna(0) != 0).idxmax()
    signal_index = ss.index.get_loc(signal_date)
    return ss.loc[signal_date], signal_date, signal_index


def get_base_stop(quote, periods=7, mult=2):
    return quote[-periods:].diff().std() * mult


def barrier_hit(quote, stop_loss, take_profit):
    pass


class BaseStrategy:
    def __init__(self, **kwargs):
        self._start_hist = kwargs.pop('start_hist', None)
        self._end_hist = kwargs.pop('end_hist', None)

    @property
    def stats(self):
        series = self._pnl['pnl']
        cumsum = series.cumsum()
        std = series.std()
        var = series.quantile(0.05)
        cond_var = series.loc[series <= var].mean()
        median = series.quantile(0.5)
        mean = series.mean()
        sharpe_ratio = mean / std
        hit_ratio = (self._summary['pnl'] > 0).sum() / len(self._summary)
        drawdown = (cumsum - cumsum.cummax()).min()
        pnl = series.sum()
        n_trades = self._summary.shape[0]

        stats = dict(
            std=std,
            var=var,
            cond_var=cond_var,
            median=median,
            mean=mean,
            sharpe_ratio=sharpe_ratio,
            hit_ratio=hit_ratio,
            drawdown=drawdown,
            pnl=pnl,
            n_trades=n_trades
        )
        return stats


class MACDCustomStrategy(BaseStrategy):
    def __init__(
            self,
            instrument,
            signal,
            time_barrier=4,  # range(4, 7 + 1)
            time_barrier_general=10,
            q=0.6,  # range(0.4, 0.9 + q_step, q_step)
            k=2.5,  # range(2, 3 + k_step, k_step)
            crossover_days=1,  # range(0, 2 + 1)
            base_stop_periods=7,
            base_stop_mult=2,
            **kwargs,
    ):
        '''
        This is a custom Strategy based on MACD that works as follows:
        - ENTRY: The entry signal is generated when the MACD reaches a certain level and the MACD SLOPE changes sign
                 from previous day (moving towards the direction of the trade) and is above a certain threshold
                 (the slope change has to be more than the prescribed threshold).
        
        Once we enter trade, BASE STOP LOSS and TAKE PROFIT are set based on the past volatility of the instrument.
        If there is a CROSSOVER of the MACD (MACD crosses the SIGNAL line) before the TIME BARRIER is reached, new
        DYNAMIC STOP LOSS and TAKE PROFIT are calculated every day(see below for details)

        The EXIT signal is generated if one of the following conditions is met:
            If there is NO CROSSOVER before the TIME BARRIER is reached:
                - TIME BARRIER: the time since ENTRY is > than time barrier
                - The BASE STOP LOSS is hit before the TIME BARRIER is reached.

            If there is CROSS:
                We keep track of the MAX change between ENTRY PRICE and CURRENT PRICE for a certain number of days
                after crossover happened (CROSSOVER DAYS).
                - MAX CHANGE AFTER CROSSOVER: if this is against the direction of the trade we EXIT
                - STOP LOSS is the MAX CHANGE AFTER CROSSOVER * Q
                - TAKE PROFIT is the MAX CHANGE AFTER CROSSOVER * P where P = Q * K

        :param instrument:
        :param signal:
        :param time_barrier: number of days after which we exit the trade if there was no crossover
        :param time_barrier_general: number of days after which we exit the trade in general
                                     (even if there is a crossover). Must be grater than time barrier
        :param q: used for calculation of dynamic stop loss: stop loss = q * max_change_after_crossover
        :param k: used for calculation of take profit: take profit = k * q * max_change_after_crossover
        :param crossover_days: number of days after the crossover to keep updating stop loss and take profit levels
        '''

        self.instrument = instrument
        self.signal = signal
        self.time_barrier = time_barrier
        self.time_barrier_general = time_barrier_general
        self.q = q
        self.k = k
        self.crossover_days = crossover_days
        self.verbose = kwargs.get('verbose', False)
        self.base_stop_periods = base_stop_periods
        self.base_stop_mult = base_stop_mult
        super().__init__(**kwargs)

    def _get_p(self, q, k):
        return k * q

    @property
    def pnl(self):
        self.run()
        return self._data['pnl']

    @property
    def data(self):
        self.run()
        return self._data

    @property
    def summary(self):
        self.run()
        return self._summary

    def get_date_range(self, data, start=None, end=None):
        start = start or self._start_hist or data.index[0]
        end = end or self._end_hist or data.index[-1]
        return parse_dates(start, end, b=True)

    def run(self, start=None, end=None):
        try:
            signals = self.signal.get_signals(self.instrument)
        except:
            self._failed = True
            return

        if not signals.abs().sum():
            self._failed = True
            return

        data = self.signal._data

        if start == -1:
            # start = self._summary.iloc[-1]['entry_date'] if self._running else today()
            start = (signals.sort_index(ascending=False).fillna(0) != 0).idxmax() if self._running else today()

        run_dates = self.get_date_range(data, start=start, end=end)

        instrument = self.instrument
        time_barrier = self.time_barrier
        time_barrier_general = self.time_barrier_general
        q = self.q
        k = self.k
        crossover_days = self.crossover_days
        p = self._get_p(q, k)
        data['crossover'] = get_crossover_signal(data['macdhist'], threshold=False, fill=0)
        data['quote'] = instrument.quote
        v = self.verbose
        running = False

        i = signals.index.get_loc(run_dates[0]) - 1
        # debug = False
        trade_count = 0
        # this is the start date of the last signal
        end_date = get_next_signal(signals.loc[:run_dates[1]], last=True)[1]
        end_run = run_dates[1]
        end = len(data)
        summary = []
        pnl = []

        if end_date < run_dates[0]:
            self._failed = True
            return

        while True:
            current_signal, signal_date, signal_index = get_next_signal(signals, index=i)

            crossover = False
            crossover_date = None
            crossover_index = None
            max_change_after_crossover = None
            # current_signal = data['signal'].iloc[signal_index]
            start_price = data['quote'].iloc[signal_index]
            entry_price = start_price + current_signal * instrument.slippage(instrument.t_cost)
            base_stop_loss = get_base_stop(data['quote'].iloc[:signal_index + 1], self.base_stop_periods,
                                           self.base_stop_mult)
            base_take_profit = base_stop_loss
            stop_loss = base_stop_loss
            take_profit = base_take_profit
            first_cross = True
            trade_count += 1

            # print(signal_date, signal_index, base_stop_loss, self.base_stop_periods, self.base_stop_mult)
            # print(data['quote'].iloc[:signal_index + 1])

            pnl.append(
                {
                    'date': signal_date,
                    'trade': trade_count,
                    'signal': current_signal,
                    'entry_price': entry_price,
                    'quote': start_price,
                    'quote_chg': (start_price - entry_price) * current_signal,
                    'stop_loss': stop_loss,
                    'take_profit': take_profit,
                }
            )

            current_price = start_price
            current_date = signal_date
            reason = None
            running = True
            first_day = True
            if v:
                text = f'START {signal_date:%Y%b%d} trading signal {current_signal} @ {start_price}'
                print(colored(text, attrs=['bold']))

            # print(signal_index + 1, end)
            for j, i in enumerate(range(signal_index + 1, end), 1):

                # if run_dates[0] == run_dates[1]:
                #     break
                first_day = False
                data_ = data[:i + 1]
                current_price = data_['quote'].iloc[-1]
                current_date = data_.index[-1]
                pnl_ltd = (current_price - start_price) * current_signal
                current_pnl = (current_price - data_['quote'].iloc[-2]) * current_signal

                # if we just engaged in a trade
                if j == 1:
                    pass

                #         if signal_date == pd.Timestamp(2022, 9, 30):
                #             debug = True
                #             break

                #         if current_date == pd.Timestamp(2022, 10, 18):
                #             debug = True
                #             break

                # if we hit the base stop before the time barrier (possibly add take profit as well)
                if j < time_barrier and pnl_ltd <= - stop_loss:
                    if v:
                        text = f'\t{current_date:%Y%b%d} stop loss {stop_loss:.4f} ' \
                               f'hit before the crossing time barrier: exit'
                        print(colored(text, color='red', attrs=['bold']))
                    running = False
                    reason = 'static stop hit before time barrier'
                    break

                # flag if crossover occurs for the first time, to avoid too much noise
                if np.abs(data_.iloc[-1]['crossover']) == 1 and first_cross:
                    crossover = True
                    first_cross = False
                    crossover_date = data.index[i]
                    crossover_index = i

                # if we hit time barrier in general
                if j >= time_barrier_general:
                    if v:
                        text = f'\t{current_date:%Y%b%d} time barrier general hit'
                        if pnl_ltd >= 0:
                            text = f'{text}: profit {pnl_ltd:.4f}'
                            print(colored(text, color='green', attrs=['bold']))
                        else:
                            text = f'{text}: loss {pnl_ltd:.4f}'
                            print(colored(text, color='red', attrs=['bold']))
                    running = False
                    reason = 'time barrier general hit'
                    break

                # if we hit time barrier without crossover
                if j >= time_barrier and not crossover:
                    if v:
                        text = f'\t{current_date:%Y%b%d} time barrier hit'
                        if pnl_ltd >= 0:
                            text = f'{text}: profit {pnl_ltd:.4f}'
                            print(colored(text, color='green', attrs=['bold']))
                        else:
                            text = f'{text}: loss {pnl_ltd:.4f}'
                            print(colored(text, color='red', attrs=['bold']))
                    running = False
                    reason = 'time barrier hit with no crossover'
                    break

                # if we have crossover before the time barrier and we didn't hit stop loss
                elif crossover:
                    # text = f'\t{current_date:%Y%b%d} crossover'
                    # print(text)
                    max_change_after_crossover = (
                            (
                                    data_['quote'].iloc[crossover_index:crossover_index + crossover_days + 1] -
                                    data_['quote'].iloc[signal_index]
                            ) * current_signal
                    ).max()
                    # here I stop if after entering there is a cross, but it's against my trade
                    if max_change_after_crossover <= 0:
                        if v:
                            text = f'\tchange since crossover < 0 loss {pnl_ltd:.4f}: exit'
                            print(colored(text, color='red', attrs=['bold']))
                        running = False
                        reason = 'after crossover move against trade'
                        break

                    stop_loss = q * max_change_after_crossover
                    take_profit = p * max_change_after_crossover
                    if pnl_ltd <= - stop_loss:
                        if v:
                            text = f'\tcrossover: stop loss since {stop_loss:.4f} hit: exit'
                            print(colored(text, color='red', attrs=['bold']))
                        running = False
                        reason = 'after crossover stop loss'
                        break

                    if pnl_ltd >= take_profit:
                        if v:
                            text = f'\tcrossover: take profit since {take_profit:.4f} hit: exit'
                            print(colored(text, color='green', attrs=['bold']))
                        running = False
                        reason = 'after crossover take profit'
                        break

                pnl.append(
                    {
                        'date': current_date,
                        'trade': trade_count,
                        'signal': current_signal,
                        'quote': current_price,
                        'quote_chg': current_pnl,
                        'stop_loss': stop_loss,
                        'take_profit': take_profit,
                    }
                )

                if current_date == end_run:
                    break

            exit_price = current_price - current_signal * instrument.slippage(instrument.t_cost)
            exit_price = exit_price if not running else np.nan
            # print(run_dates)
            if run_dates[1] > run_dates[0] and not first_day:
                last_pnl = {
                    'date': current_date,
                    'trade': trade_count,
                    'signal': current_signal,
                    'exit_price': exit_price,
                    'quote': current_price,
                    'quote_chg': ((exit_price if not running else current_price) - data_['quote'].iloc[
                        -2]) * current_signal,
                    'stop_loss': stop_loss,
                    'take_profit': take_profit,
                    'notes': reason
                }

                if pnl[-1]['date'] == current_date:
                    pnl[-1] = last_pnl
                else:
                    if last_pnl['date'] > pnl[-1]['date']:
                        pnl.append(last_pnl)

            new_summary = {
                'trade': trade_count,
                'signal': current_signal,
                'entry_date': signal_date,
                'exit_date': current_date if not running else np.nan,
                'entry_price': entry_price,
                'exit_price': exit_price,
                'start_price': start_price,
                'end_price': current_price,
                'quote_chg': (exit_price - entry_price) * current_signal,
                'notes': reason,
            }

            if pd.isnull(new_summary['exit_date']) or new_summary['exit_date'] < new_summary['entry_date']:
                new_summary['exit_date'] = np.nan
                new_summary['exit_price'] = np.nan
                new_summary['start_price'] = start_price
                new_summary['end_price'] = current_price
                new_summary['quote_chg'] = (start_price - current_price) * current_signal

            summary.append(new_summary)
            if signal_date == end_date or current_date >= end_date or current_date == end_run:
                break

        summary = pd.DataFrame(summary)
        summary['pnl'] = instrument.get_pnl(
            (summary['exit_price'].fillna(summary['end_price']) - summary['entry_price']) * summary['signal']
        )
        summary['pv'] = summary['pnl'].cumsum()
        pnl = pd.DataFrame(pnl).set_index('date')
        pnl['pnl'] = instrument.get_pnl(pnl['quote_chg'])
        pnl['pv'] = pnl['pnl'].cumsum()
        pnl['quote_chg_per_trade'] = pnl.groupby('trade')['quote_chg'].cumsum()
        pnl['pv_per_trade'] = instrument.get_pnl(pnl['quote_chg_per_trade'])

        self._pnl = pnl
        self._summary = summary
        self._data = pd.concat([data, pnl.drop('quote', axis=1)], axis=1)
        self._running = running

    def update(self):
        pass

    def _get_repr_params(self):
        params = [
            'time_barrier',
            'time_barrier_general',
            'q',
            'k',
            'crossover_days',
            'base_stop_periods',
            'base_stop_mult',
            '_start_hist',
            '_end_hist'
        ]
        params = {param: getattr(self, param) for param in params}
        params['signal'] = self.signal._get_repr_params()
        return params

    def __repr__(self):
        return str(self._get_repr_params())

    def _ipython_display_(self):
        display(self._get_repr_params())

