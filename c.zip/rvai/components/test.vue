<template>

    <v-text-field
        label="label"
        outlined
        height="5px"

    ></v-text-field>

</template>

<style scoped>

/*.v-text-field .v-input__control .v-input__slot {*/
/*  min-height: auto !important;*/
/*  display: flex !important;*/
/*  align-items: center !important;*/
/*}*/
</style>