import re
from uuid import uuid4

import pandas as pd

import bhutils
from api.blpw import BlpQuery
from api.history_plotter import get_expressions_data
from api.tools import get_history_plotter_strings
# from api.mappings import strategy_map

r = get_history_plotter_strings(
    delta_mul=-1,
    delta_tol=499
)

expressions = r[-1].to_dict()
data = get_expressions_data(expressions, history='10y')
