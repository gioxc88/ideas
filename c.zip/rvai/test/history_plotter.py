import numpy as np
import pandas as pd

from api.history_plotter_v2 import ExpressionHandler
from gioutils.blpw import BlpParser, BlpQuery

bq = BlpQuery(timeout=50000, parser=BlpParser(raise_security_errors=False)).start()

expressions = {
    'bh1': dict(ccy='usd', instrument='irs', generator='usd sofr', eff_exp='11m', tenor_mty='2y', pay_receive='pay', metric='rate'),
    'EURHE': '[s usd 11mx2y] + [s usd.sofr 11mx2y]',
    'bh2': 'bh1 * 100',
    'nh3': '[BBG TY1 Comdty yld_ytm_mid]'
}


expressions = {
    '3m1y': dict(ccy='eur', instrument='irs', generator='eur ester', eff_exp='2023-07-13', tenor_mty='1y', strike='3.255', nominal=233e6, pay_receive='rec', metric='PV'),
    '3y2y': dict(ccy='eur', instrument='irs', generator='eur ester', eff_exp='2026-01-13', tenor_mty='2y', strike='2.343', nominal=261e6, pay_receive='pay', metric='PV'),
    '5y2y': dict(ccy='eur', instrument='irs', generator='eur ester', eff_exp='2028-01-13', tenor_mty='2y', strike='2.384', nominal=137e6, pay_receive='rec', metric='PV'),
}


eh = ExpressionHandler()  # create the ExpressionHandler object

# expressions = {
#     'EURHE': '[s eur.ester 1yx1y]',
#     # 'a': '[s usd.sofr 1yx1y]',
# }

eh.get_data(expressions, history='10y', bq=bq) # call get_data();