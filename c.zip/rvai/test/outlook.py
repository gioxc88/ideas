import win32com.client as win32
import os

outlook = win32.Dispatch("Outlook.Application").GetNamespace("MAPI")



# root_folder = outlook.Folders.Item(1)

for folder in outlook.Folders[0].Folders:
    if folder.name == 'Inbox':
        break


folder.Items.Restrict("[SenderEmailAddress]='Steven.Crowley@brevanhoward.com'")


rates_metrics = [clarion.metric('PresentValue', 'PresentValue', 'Any')]

rates_swaption = clarion.create_trade('swaption_1', 'ratesSwaption', {'InstrumentName': 'EURIBOR A 3M',
                                                                 'Currency': 'EUR',
                                                                 'Expiry': '3-May-24',
                                                                 'Notional': 1e9,
                                                                 'Tenor':'1y',
                                                                 'Strike': '2.425',
                                                                 'SwaptionType': 'Rec',
                                                                 'CollateralCurrency': 'USD',
                                                                 'SettleType': 'Cash Price',
                                                                 'PaySettle': 'Fwd'})

response = clarion.price.run(rates_metrics, rates_swaption, market_mode='live')
if response['ERROR']:
    print(response['ERROR'])
    print(response['IS_ERROR'])
    print(response['HAS_ERROR'])
else:
    display(response['DFRAME'])



"UNITED STATES", "EUROZONE", "BRITAIN", "GERMANY", "ITALY", "SPAIN", "FRANCE", "NETHERLANDS", "JAPAN",


import smtplib, ssl
password = "qesbpipeiczgujdj"
email = 'bhgioreports@gmail.com'


# port = 465  # For SSL
#
#
# # Create a secure SSL context
# context = ssl.create_default_context()
#
# with smtplib.SMTP_SSL("smtp.gmail.com", port, context=context) as server:
#     server.login(email, password)


import smtplib
import ssl

from_email = 'gioreports@brevanhoward.com'
to_email = 'giovambattista.perciaccante@brevanhoward.com'
password = "tlvozidfblyhunoy"
#
# email = "giovambattista.perciaccante@brevanhoward.com"
# password = "RelativeValue0203!"

smtp_server = "smtp.rivagecapital.com"
# smtp_server = "smtp-mail.outlook.com"
port = 587  # For starttls




# Create a secure SSL context
# context = ssl.create_default_context()

# Try to log in to server and send email

# with smtplib.SMTP(smtp_server, port) as smtp:
smtp = smtplib.SMTP(smtp_server)
smtp.sendmail(from_email, to_email, 'Ciao')

from email.message import EmailMessage
import smtplib

sender = "sender@outlook.com"
recipient = "recipient@example.com"
message = "Hello world!"

import schedule