cd /c/dev/projects/rvai && git pull
cd /c/dev/projects/gioutils && git pull