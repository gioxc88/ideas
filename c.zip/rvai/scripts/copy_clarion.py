try:
    import config
except ImportError:
    pass

import pandas as pd


from gioutils.tools import get_history_plotter_strings


strategy_map = {
    'MM:EUR FLY SPRD': 'eurfly',
    'MM:EUR OPEN OPT': 'europt',
    'MM:EUR SHORT CU': 'eursht',
    'MM:EURUSD BOX': 'eurbox',
    'MM:USD OPEN OPT': 'usdopt',
    'MM:USD SHORT CU': 'usdsht'
}


if __name__ == '__main__':
    r = get_history_plotter_strings(delta_mul=-1, delta_tol=499)
    ### Send Email


