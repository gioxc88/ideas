source ../venv/Scripts/activate
python copy_clarion.py