from dotenv import load_dotenv
load_dotenv()

try:
    import config
except ImportError:
    pass

import clarion
import pandas as pd
import win32com.client as win32

from gioutils.blpw import BlpParser, BlpQuery
from gioutils.tools_clarion import get_history_plotter_book

clarion.server_login()
bq = BlpQuery(timeout=50000, parser=BlpParser(raise_security_errors=False)).start()


d = get_history_plotter_book(clarion, bq, delta_mul=-1, delta_tol=499)

outlook = win32.Dispatch('outlook.application')
mail = outlook.CreateItem(0)
mail.To = 'giovambattista.perciaccante@brevanhoward.com;' # menashe.banit@brevanhoward.com'
# mail.To = 'giovambattista.perciaccante@brevanhoward.com'
mail.Subject = f'History Plotter as of {pd.Timestamp.today(): %d%b%y}'
mail.Body = d[1].to_csv(header=False, sep=',')
mail.HTMLBody = d[1].reset_index().to_html(header=False, index=False)  # this field is optional
# mail.HTMLBody = d[1].reset_index().to_csv(header=False, index=False)
# To attach a file to the email (optional)
# attachment  = "Path to the attachment"
# mail.Attachments.Add(attachment)
mail.Send()

print('SUCCESS')

