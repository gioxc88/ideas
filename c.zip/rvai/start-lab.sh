source venv/Scripts/activate && jupyter-lab
