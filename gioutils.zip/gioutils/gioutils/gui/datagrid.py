import logging
from copy import deepcopy

import numpy as np
import pandas as pd
from ipydatagrid import DataGrid


class DataGridGio(DataGrid):
    _max_width = None
    _max_height = 600
    _adjustment = 25

    def rerender(self):
        if hasattr(self, '_current_layout'):
            self.layout = self._current_layout

    def __init__(self, dataframe, **kwargs):

        if "index_name" in kwargs:
            self._index_name = kwargs["index_name"]
        else:
            self._index_name = None

        self._first_call = True
        self._layout_init = kwargs.get('layout', {})

        self._max_width = kwargs.pop('max_width', self._max_width)
        self._max_height = kwargs.pop('max_height', self._max_height)
        self._adjustment = kwargs.pop('adjustment', self._adjustment)

        self.data = dataframe
        df = self.data
        kwargs = self.auto_resize_grid(df, **kwargs)

        super().__init__(dataframe, **kwargs)

    def auto_resize_grid(self, data, **kwargs):
        df = data
        max_width = kwargs.pop('max_width', self._max_width)
        max_height = kwargs.pop('max_height', self._max_height)
        adjustment = kwargs.pop('adjustment', self._adjustment)

        column_widths = kwargs.get('column_widths', {})
        base_row_size = kwargs.get('base_row_size', 20)
        base_column_size = kwargs.get('base_column_size', 64)
        base_row_header_size = kwargs.get('base_row_header_size', 64)
        base_column_header_size = kwargs.get('base_column_header_size', 20)
        index_names = [*df.index.names]
        index_size = np.sum([column_widths.get(v, base_row_header_size) for v in index_names])
        columns_size = np.sum([column_widths.get(v, base_column_size) for v in df.columns])
        # (column_widths)
        # print([column_widths.get(v, base_column_size) for v in df.columns])

        width = index_size + columns_size + adjustment
        height = len(df) * base_row_size + df.columns.nlevels * base_column_header_size + adjustment
        layout = kwargs.pop('layout', {})
        lo_width = layout.get('width', f"{width if not max_width or (width < max_width) else max_width if max_width else ''}px")
        lo_height = layout.get('height', f"{height if not max_height or (height < max_height) else max_height if max_height else ''}px")

        if lo_width != 'px':
            layout['width'] = lo_width
        if lo_height != 'px':
            layout['height'] = lo_height
        layout["align-content"] = "center"
        kwargs['layout'] = layout
        self._current_layout = layout
        # print(layout)

        return kwargs

    @DataGrid.data.setter
    def data(self, dataframe):
        # Reference for the original frame column and index names
        # This is used to when returning the view data model
        if not self._first_call:
            old_data = self.data

        self._DataGrid__dataframe_reference_index_names = dataframe.index.names
        self._DataGrid__dataframe_reference_columns = dataframe.columns
        dataframe = dataframe.copy()

        # Primary key used
        index_key = self.get_dataframe_index(dataframe)

        self._data = self.generate_data_object(
            dataframe, "ipydguuid", index_key
        )

        if not self._first_call:
            new_data = self.data
            if new_data.shape != old_data.shape:
                kwargs = self.auto_resize_grid(
                    self.data,
                    column_widths=self.column_widths,
                    base_row_size=self.base_row_size,
                    base_column_size=self.base_column_size,
                    base_row_header_size=self.base_row_header_size,
                    base_column_header_size=self.base_column_header_size,
                    layout=deepcopy(self._layout_init)
                )
                logging.warning(kwargs['layout'])
                self.layout = kwargs['layout']
        else:
            self._first_call = False

    # def __setattr__(self, attr, value):
    #     if attr == 'layout':
    #         logging.warning(value)
    #
    #     super().__setattr__(attr, value)
