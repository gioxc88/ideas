import ipywidgets as w
import pandas as pd
import numpy as np

from plotly import graph_objects as go
from plotly.subplots import make_subplots
from .pandas import DFOutput, negative_red
from .params import fwd_tenors
from .base import View


class BaseTable(View):
    def __int__(self, *args, **kwargs):
        if 'dc' not in kwargs:
            kwargs['build'] = False
        super().__init__(*args, **kwargs)

    @property
    def view(self):
        if hasattr(self, 'widget'):
            return self.widget.view


class SpotTable(BaseTable):
    def __init__(self, gen, title=None, **kwargs):
        self.gen = gen
        self.out = w.Output()
        self.title = title
        super().__init__(**kwargs)

    def get_table(self, data, gen):
        return data['live']['spot'].loc[gen].set_index('in.mty')[['rate', 'change']].rename_axis(None)

    def get_widget(self, dc, **kwargs):
        margin = kwargs.pop('margin', {})
        gen = self.gen
        title = self.title or gen
        data = self.get_table(dc['sf'].data, gen).rename({'rate': title}, axis=1)
        self.data = data
        widget = DFOutput(
            df=data,
            # out=self.out,
            styler_kwargs=dict(
                formatters={title: '{:.3%}', 'change': '{:.2f}'},
                multipliers={'change': 10000},
                applymap={'func': negative_red, 'subset': 'change'}
            ),
            margin=margin
        )
        self.widget = widget
        return widget.view


class FutureTable(BaseTable):
    def __init__(self, gen, ccy, title=None, **kwargs):
        self.gen = gen
        self.ccy = ccy
        self.title = title
        self.out = w.Output()
        super().__init__(**kwargs)

    def get_widget(self, dc, **kwargs):
        margin = kwargs.pop('margin', {})
        ccy = self.ccy
        gen = self.gen
        title = f"{self.title} Fut" if self.title else f"{gen} Fut"

        fut_df = dc['fut'].data.loc[dc['fut'].get_tickers(return_dict=True)[ccy], ['live', 'change']].rename(
            {'live': title}, axis=1)
        fut_df = fut_df.set_index(
            fut_df.index.str.replace(' Comdty', '').str[-2:].str.replace('ex', 'spot')).rename_axis(None)
        fut_df.loc['spot', title] = 100 - fut_df.loc['spot', title]
        fut_df.loc['spot', "change"] = np.nan
        self.data = fut_df
        widget = DFOutput(
            df=fut_df,
            # out=self.out,
            styler_kwargs=dict(
                formatters={title: '{:.3f}', 'change': '{:.2f}'},
                applymap={'func': negative_red, 'subset': 'change'}
            )
            ,
            margin=margin
        )
        self.widget = widget
        return widget.view


class KeyChart(BaseTable):
    def __init__(self, gen, chart_kwargs=None, **kwargs):
        self.gen = gen
        self.chart_kwargs = chart_kwargs or {}
        super().__init__(**kwargs)

    def get_widget(self, dc):
        data = dc['sf'].data
        widget = self.make_fwd_plot(data, self.gen, **self.chart_kwargs)
        self.widget = widget
        return widget

    def make_fwd_plot(self, data, gen, scale=100, fmt='.2f', **kwargs):
        plot_df = pd.concat(
            [
                data['live']['fwd'].set_index(['in.eff', 'in.mty'], append=True).droplevel(1).rename_axis(3 * [None])[
                    'rate'].rename('live'),
                data['cob']['fwd'].set_index(['in.eff', 'in.mty'], append=True).droplevel(1).rename_axis(3 * [None])[
                    'rate'].rename('cob')
            ],
            axis=1
        )
        plot_df['change'] = plot_df['live'] - plot_df['cob']
        plot_df = plot_df.loc[
            [(gen, elm[0], elm[1]) for gen in plot_df.index.get_level_values(0).unique() for elm in fwd_tenors]]
        plot_df = plot_df.set_index(
            pd.MultiIndex.from_arrays(
                [
                    plot_df.index.get_level_values(0),
                    plot_df.index.get_level_values(1).astype(str) + 'x' + plot_df.index.get_level_values(2).astype(str)
                ],
            )
        )
        plot_df_ = plot_df.loc[gen] * scale
        fig = make_subplots(specs=[[{"secondary_y": True}]])
        fig2 = plot_df_[['live', 'cob']].plot(markers=True)
        fig2.data[0].line.color = 'red'
        fig2.data[1].line.color = 'orange'
        fig3 = plot_df_['change'].plot.bar()
        # fig3.data[0].width = [2] * len(plot_df_)
        # fig3.data[0].offset = 0
        fig3.data[0].marker.line = dict(width=1, color='white')
        fig.add_traces([*fig2.data, *fig3.data], secondary_ys=[True, True, False]) \
            .update_yaxes(showgrid=False, tickformat=fmt, nticks=10) \
            .update_xaxes(tickangle=45) \
            .update_layout(
            template='plotly_white',
            height=kwargs.get('height', 500),
            title=gen,
            bargap=0,
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            )
        )
        return go.FigureWidget(fig)


class GroupMktTalbe(BaseTable):
    def __init__(
            self,
            group,
            pct=True,
            precision=2,
            change_precision=2,
            field=None,
            title=None,
            styler_kwargs=None,
            **kwargs
    ):
        self.group = group
        self.pct = pct
        self.styler_kwargs = styler_kwargs or {}
        self.precision = precision
        self.change_precision = change_precision
        self.field = field
        self.title = title
        self.out = w.Output()
        super().__init__(**kwargs)

    def get_table(self, data, group):
        return

    def get_widget(self, dc, **kwargs):
        margin = kwargs.pop('margin', {})
        live, cob, change = ['live', 'cob', 'change'] if not self.field \
            else [f'{self.field} live', f'cob', f'{self.field} change']

        data = dc['mkt'].data.copy()
        if self.pct:
            data[change] = data[change] / data[cob]

        group = self.group
        title = self.title or group
        df = data.query(f'group == "{group}"').set_index('display_name')[[live, change]] \
            .rename({live: title, change: 'change'}, axis=1).rename_axis(None)
        self.data = df
        widget = DFOutput(
            df=df,
            # out=self.out,
            styler_kwargs=dict(
                formatters={title: f'{{:.{self.precision}f}}',
                            'change': f'{{:.{self.change_precision}f}}' if not self.pct else f'{{:.{self.change_precision}%}}'},
                applymap={'func': negative_red, 'subset': 'change'},
                **self.styler_kwargs
            ),
            margin=margin
        )
        self.widget = widget
        return widget.view


def mixed_formatter(v):
    try:
        return f"{v:%d-%b-%y}"
    except:
        return v


class MtgTable(BaseTable):
    def __init__(self, ccy, show=9, **kwargs):
        self.ccy = ccy
        self.show = show
        self.out = w.Output()
        super().__init__(**kwargs)

    def get_table(self, dc):
        ccy = self.ccy
        show = self.show
        data = dc['mtgs'].data.query(f"Currency == '{ccy.upper()}'")[:show]
        data = data.set_index('MeetingDate')
        data.loc['fixing', 'hikes'] = data.loc['fixing', 'rate']
        data['cum'] = data['hikes'].cumsum()
        data = data[['hikes', 'cum']].rename({'hikes': f"{ccy} hikes"}).rename_axis(None)
        return data

    def get_widget(self, dc, **kwargs):
        margin = kwargs.pop('margin', {})
        data = self.get_table(dc)
        self.data = data
        widget = DFOutput(
            df=data,
            # out=self.out,
            styler_kwargs=dict(
                multipliers=100,
                precision=2,
                # applymap={'func': negative_red, 'subset': 'change'}
                format_index={'formatter': mixed_formatter}
            ),
            margin=margin
        )
        self.widget = widget
        return widget.view


class MatTable(BaseTable):
    def __init__(self, ccy, curve_type, title, **kwargs):
        self.ccy = ccy
        self.curve_type = curve_type
        self.title = title
        self.out = w.Output()
        super().__init__(**kwargs)

    def get_widget(self, dc, **kwargs):
        margin = kwargs.pop('margin', {})
        ccy = self.ccy
        curve_type = self.curve_type
        title = self.title
        data = dc['mat'].data.loc[curve_type, ccy].rename_axis(f"{ccy} {title}", axis=1)
        self.data = data
        widget = DFOutput(
            df=data,
            # out=self.out,
            styler_kwargs=dict(
                multipliers=100,
                precision=3,
            ),
            applymap={'func': negative_red},
            margin=margin
        )
        self.widget = widget
        return widget.view


def custom_format_govt_bond_fut(x, precision=2):
    sec, val = x.split('__')
    val = float(val)
    if sec in ['TUA', 'FVA', 'TYA', 'USA']:
        decimal = val % 1
        integer = int(val)
        decimal = round(32 * decimal, precision)
        return f"{integer}-{decimal}"
    return f"{val:.{precision}f}"


class CustomGovtBondFutTable(BaseTable):
    group = 'govt bond fut'

    def __init__(
            self,
            styler_kwargs=None,
            **kwargs
    ):
        self.styler_kwargs = styler_kwargs or {}
        super().__init__(**kwargs)

    def get_widget(self, dc, **kwargs):
        margin = kwargs.pop('margin', {})
        group = self.group
        df = dc['mkt'].data.query(f'group == "{group}"').set_index('display_name')[['live', 'change']].rename_axis(None)
        df['live'] = df.index + '__' + df['live'].astype(str)
        self.data = df
        widget = DFOutput(
            df=df,
            # out=self.out,
            styler_kwargs=dict(
                formatters={'live': custom_format_govt_bond_fut, 'change': f'{{:.{3}f}}'},
                applymap={'func': negative_red, 'subset': 'change'},
                **self.styler_kwargs,
            ),
            margin=margin
        )
        self.widget = widget
        return self.widget.view
