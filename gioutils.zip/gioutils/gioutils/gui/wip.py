from itertools import chain
from io import StringIO

import ipywidgets as w
import numpy as np
import pandas as pd
import requests
from plotly import (
    io as pio,
    express as px,
    graph_objects as go,
    figure_factory as ff
)
from plotly.subplots import make_subplots
from scipy.linalg import block_diag
from scipy.spatial.distance import pdist, squareform
from scipy.cluster.hierarchy import (
    linkage,
    fcluster,
    optimal_leaf_ordering,
    leaves_list,
    dendrogram
)

class DFPlot:
    def __init__(self, df):
        self.df = df
        self.dd = w.Dropdown(options=df.columns)

        def fn(col):
            fig = self.df[col].plot(backend='plotly')
            display(fig)


        self.out = w.interactive_output(fn, dict(col=self.dd))
        self.app = w.VBox([self.dd, self.out])

    def _ipython_display_(self):
        return display(self.app)


def corr_plot(
    corr,
    title=None,
    fmt='.0%',
    width=None,
    height=None,
    colorscale=None,
    showscale=True,
    **kwargs,
):
    if fmt:
        fig = ff.create_annotated_heatmap(
            z=corr.to_numpy(),
            x=[*corr.columns],
            y=[*corr.index],
            annotation_text=corr.applymap(lambda x: f'{x: {fmt}}').to_numpy(),
            colorscale=colorscale or 'viridis',
            showscale=showscale,
            **kwargs
        )
    else:
        fig = go.Figure(
            data=go.Heatmap(
                z=corr.to_numpy(),
                x=[*corr.columns],
                y=[*corr.index],
                colorscale=colorscale or 'viridis',
                showscale=showscale,
                **kwargs
            )
        )


    # fig.update_xaxes(tickangle=45, side='bottom')

    fig.update_layout(
        autosize=False,
        title={
            'text': title,
            'y':0.9,
            'x':0.5,
            'xanchor': 'center',
            'yanchor': 'top'
        } if title else None,
        width=width or 1000,
        height=height or 700
    )\
       .update_xaxes(tickangle=45, side='bottom')

    return fig


def agg_ret(prices, freq='A', compounded=False):
    to_freq = prices.resample(freq).last()

    res = pd.concat([
        pd.Series(prices.iloc[0], index=[prices.index[0] - pd.tseries.frequencies.to_offset(freq)]),
        to_freq
    ])

    if compounded:
        res = res.pct_change().dropna()
    else:
        res = res.diff().dropna()

    if freq=='M':
        res = pd.concat(
            [pd.Series(group.to_numpy(), index=group.index.month, name=group.index[0].year) for index, group in res.groupby(pd.Grouper(freq='A'))],
            axis=1
        )

    return res


@pd.api.extensions.register_dataframe_accessor("zscore")
class RollingZScore:
    def __init__(self, pandas_obj):
        self._obj = pandas_obj

    def __call__(self, n):
        obj = self._obj
        rolling = obj.rolling(n)
        return (obj - rolling.mean()) / rolling.std()


@pd.api.extensions.register_series_accessor("zscore")
class RollingZScoreZScore:
    def __init__(self, pandas_obj):
        self._obj = pandas_obj

    def __call__(self, *args, **kwargs):
        ewm = kwargs.pop('ewm', False)
        accessor = 'rolling' if not ewm else 'ewm'
        accessor = getattr(self._obj, accessor)

        obj = self._obj
        accessor_ = accessor(*args, **kwargs)
        return (obj - accessor_.mean()) / accessor_.std()



def get_feature_names():
    flat_groups = [*chain.from_iterable(pca_groups.values())]

    return [*set([*flat_groups, *diff, *passthrough])]



def distance_correlation(corr):
   return ((1 - corr) / 2) ** 0.5


def seriate(corr):
    dist_corr = distance_correlation(corr)
    flat_dist = squareform(dist_corr)
    # dim = len(dist_corr)
    # tri_a, tri_b = np.triu_indices(dim, k=1)
    # flat_dist = dist_corr[tri_a, tri_b]  # this is same as squareform(dist_corr)

    Z = linkage(flat_dist, method='ward')
    order = leaves_list(Z)
    return corr.iloc[order, order]


from symawofo.strategies.base import BaseStrategy

class MultiStratMixin:

    def get_predictions(self):
        predictions = self.get_all_predictions()
        return self.get_agg(self.pred_agg_fn, signals)

    def get_signals(self):
        signals = self.get_all_signals()
        return self.get_agg(self.agg_fn, signals)

    def get_asset_returns(self):
          return [*self.strategies.values()][0].get_asset_returns()

    def get_asset_prices(self, compound=True, start_value=None, start_index=None):
        return [*self.strategies.values()][0].get_asset_prices(compound=compound, start_value=start_value, start_index=start_index)

    def get_agg(self, fn, df):
        if not fn:
            return df
        if isinstance(fn, str):
            if not (agg_fn := self._agg_map.get(fn, None)):
                return getattr(df, fn)(axis=1).rename('signals')
            else:
                return agg_fn(self, df)
        else:
            res = fn(df)
            return res

    def get_all_signals(self, dropna=True):
        signals = pd.concat([s.get_signals() for s in self.strategies.values()], axis=1).set_axis(self.strategies, axis=1)
        return signals.dropna() if dropna else signals

    def get_all_predictions(self, dropna=True):
        predictions = pd.concat([s.get_predictions() for s in self.strategies.values()], axis=1).set_axis(self.strategies, axis=1)
        return predictions.dropna() if dropna else signals

    def _agg_agree(self, signals):
        return (signals.iloc[:, 0] * (signals.sum(axis=1).abs() == signals.shape[1])).rename('signals')

    def _agg_sign(self, signals):
        return np.sign(signals.mean(axis=1)).rename('signals')

    _agg_map = {
        'agree': _agg_agree,
        'sign': _agg_sign
    }


class MultiStrat(MultiStratMixin, BaseStrategy):

    def __init__(self, strategies, pred_agg_fn=None, signal_agg_fn=None, **kwargs):

        if signal_agg_fn and pred_agg_fn:
            raise ValueError('Cannot aggregate predictions and signals at the same time')

        if isinstance(strategies, list):
            strategies = {f's{i}': s for i, s in enumerate(strategies, 1)}
        s1 = [*strategies.values()][0]

        asset_type = kwargs.pop('asset_type', s1.t_costs)
        t_costs = kwargs.pop('t_costs', s1.t_costs)

        super().__init__(asset_type=asset_type, t_costs=t_costs, **kwargs)

        self.strategies = strategies
        self.pred_agg_fn = pred_agg_fn
        self.signal_agg_fn = agg_fn
