from numbers import Number

import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
import QuantLib as ql
from IPython.display import display
from ipydatagrid import DataGrid, TextRenderer, BarRenderer, Expr
from bqplot import LinearScale, ColorScale, OrdinalColorScale, OrdinalScale
from pandas.tseries.offsets import BDay

from .base import View, Tabs, years_to_maturity_col
from ..data.base import data_path, tables
from ..data.utils import add_pcs, make_rating_categories
from ..utils import parse_offset

from ..data.processing import (
    add_years_to_maturity,
    add_maturity_bucket,
    add_custom_rating,
    add_rating_bucket,
    add_geo_area
)
from .collectors import CollectorL

dt_fmt = '%Y-%m-%d'
bbg_dt_fmt = '%Y%m%d'


def get_issuer_curve_old(
        bond_ref,
        issuer,
        maturities=None,
        currency='EUR',
        thresholds=None,
        unique=True,
):
    maturities = [*sorted(maturities)] if maturities else [2, 3, 5, 7, 10, 30, 50]
    thresholds = thresholds or {}

    if not isinstance(maturities, list):
        maturities = [maturities]

    subset = bond_ref.query(f"ticker == '{issuer}'")
    if currency:
        subset = subset.query(f"currency == '{currency}'")

    if subset.empty:
        return pd.DataFrame()

    res = []
    _mats = []
    for maturity in maturities:
        ss = subset.loc[(subset[years_to_maturity_col] - maturity).abs().idxmin()]
        t = thresholds.get(maturity)
        # print(thresholds, maturity)
        # print(ss['ticker'], ss[years_to_maturity_col], t)
        if isinstance(t, Number):
            if np.abs(ss[years_to_maturity_col] - maturity) < t:
                res.append(ss)
                _mats.append(maturity)
        elif isinstance(t, (tuple, list)):
            if (maturity - t[0]) <= ss[years_to_maturity_col] <= (maturity + t[1]):
                res.append(ss)
                _mats.append(maturity)
        else:
            res.append(ss)
            _mats.append(maturity)
    if res:
        return pd.concat(res, axis=1).T.sort_values(years_to_maturity_col).assign(
            maturity_label=_mats
        ).drop_duplicates(subset='name')
    return pd.DataFrame()


def get_issuer_curve(
        bond_ref,
        issuer,
        maturities=None,
        currency='EUR',
        thresholds=None,
        unique=True,
):
    maturities = [*sorted(maturities)] if maturities else [2, 3, 5, 7, 10, 30, 50]
    thresholds = thresholds or {}

    if not isinstance(maturities, list):
        maturities = [maturities]

    subset = bond_ref.query(f"ticker == '{issuer}'")
    if currency:
        subset = subset.query(f"currency == '{currency}'")

    if subset.empty:
        return pd.DataFrame()

    res = []
    for maturity in maturities:
        t = thresholds.get(maturity)
        # print(thresholds, maturity)
        # print(ss['ticker'], ss[years_to_maturity_col], t)
        if isinstance(t, Number):
            mask = np.abs(subset[years_to_maturity_col] - maturity) <= t
        elif isinstance(t, (tuple, list)):
            mask = subset[years_to_maturity_col].between(maturity - t[0], maturity + t[1])
        else:
            mask = slice(None)
        ss = subset.loc[mask]
        if not ss.empty:
            ss = ss.assign(maturity_label=maturity)
            if unique:
                ss = ss.loc[(ss[years_to_maturity_col] - maturity).abs().idxmin()].to_frame().T
            if not ss.empty:
                res.append(ss)
    if res:
        res = pd.concat(res).sort_values(years_to_maturity_col).drop_duplicates(subset='name')
    else:
        res = pd.DataFrame()
    return res


def get_issuers_curves(bond_ref, maturities=None, currency=None, bmk=False, thresholds=None):
    if not bmk:
        bond_ref = bond_ref.loc[~bond_ref['security'].isin(bond_ref['bmk_bond'])]
    ic = pd.concat([get_issuer_curve(bond_ref, issuer=issuer, maturities=maturities, currency=currency, thresholds=thresholds)
                      for issuer in bond_ref['ticker'].drop_duplicates()])
    return make_rating_categories(ic)


class PanelOut(View):
    def __init__(self, widget, **kwargs):
        self.widget = widget
        super().__init__(**kwargs)

    def make_view(self, **kwargs):
        self.out = w.Output()
        with self.out:
            display(self.widget)
        self.view = self.out


class DatePicker(View):
    dt_fmt = '%Y-%m-%d'

    def __init__(
            self,
            value=None,
            label=None,
            style=None,
            dense=True,
            outlined=None,
            **kwargs
    ):
        if isinstance(value, pd.Timestamp):
            value = f"{value:{self.dt_fmt}}"
        self._value = value
        self._label = label
        self._style = style
        self._dense = dense
        self._outlined = outlined

        super().__init__(**kwargs)

    def make_widgets(self, **kwargs):
        self.dp = v.DatePicker(
            v_model=self._value,
        )
        self.tf = v.TextField(
            v_model=None,
            label=self._label,
            clearable=True,
            dense=self._dense,
            outlined=self._outlined,
            prepend_icon="mdi-calendar",
            # readonly=True,
            v_on='menu.on',
            v_bind='menu.attrs',
            style_=self._style,
            hide_details=True,
        )
        w.jslink((self.dp, 'v_model'), (self.tf, 'v_model'))

        self.menu = v.Menu(
            v_model=None,
            close_on_content_click=False,
            nudge_right=40,
            transition="scale-transition",
            offset_y=True,
            min_width="auto",
            v_slots=[
                {
                    'name': 'activator',
                    'variable': 'menu',
                    'children': self.tf
                }
            ],
            children=[
                self.dp
            ]
        )

    def make_view(self, **kwargs):
        self.view = self.menu

    def link(self, **kwargs):
        def close_menu(*args, **kwargs):
            self.menu.v_model = False

        self.dp.on_event('input', close_menu)

    @property
    def components(self):
        return {
            'dp': self.dp,
            'tf': self.tf,
            'menu': self.menu
        }

    @property
    def date(self):
        return pd.to_datetime(self.tf.v_model)


# class DatePicker(View):
#     dt_fmt = '%Y-%m-%d'
#
#     def __init__(
#             self,
#             value=None,
#             label=None,
#             description=None,
#             style=None,
#             dense=True,
#             outlined=None,
#             margin=None,
#             layout_kwargs=None,
#             **kwargs
#     ):
#         if isinstance(value, pd.Timestamp):
#             value = value.to_pydatetime().date()
#         self._value = value
#         self._label = label
#         self._style = style
#         self._dense = dense
#         self._margin = margin
#         self._description = description
#         self._layout_kwargs = layout_kwargs or {}
#         self._width = kwargs.pop('width', '250px')
#         self._outlined = outlined
#
#         super().__init__(**kwargs)
#
#     def make_widgets(self, **kwargs):
#         layout_kwargs = dict(width=self._width)
#         layout_kwargs.update(self._layout_kwargs)
#         if self._margin:
#             layout_kwargs['margin'] = self._margin
#
#         self.dp = w.DatePicker(
#             value=self._value,
#             layout=w.Layout(**layout_kwargs),
#             placeholder=self._label,
#             description=self._description or ''
#         )
#
#     def make_view(self, **kwargs):
#         self.view = self.dp
#
#     @property
#     def date(self):
#         return pd.to_datetime(self.dp.value)
#
#
# class DatePicker(View):
#     dt_fmt = '%Y-%m-%d'
#
#     def __init__(
#             self,
#             value=None,
#             label=None,
#             description=None,
#             style=None,
#             dense=True,
#             outlined=None,
#             margin=None,
#             pn_kwargs=None,
#             **kwargs
#     ):
#         if isinstance(value, pd.Timestamp):
#             value = value.to_pydatetime().date()
#         self._value = value
#         self._label = label
#         self._style = style
#         self._dense = dense
#         self._margin = margin  # or (0, 0, 0, 0)
#         self._description = description
#         self._pn_kwargs = pn_kwargs or {}
#         self._width = kwargs.pop('width', 200)
#         self._outlined = outlined
#
#         super().__init__(**kwargs)
#
#     def make_widgets(self, **kwargs):
#         from copy import deepcopy
#         pn_kwargs = deepcopy(self._pn_kwargs)
#         pn_kwargs['name'] = self._label
#         pn_kwargs['value'] = self._value
#         pn_kwargs['width'] = self._width
#         pn_kwargs['margin'] = self._margin
#         self.dp = pn.widgets.DatePicker(**pn_kwargs)
#         self.po = PanelOut(self.dp)
#
#     def make_view(self, **kwargs):
#         self.view = self.po.view
#
#     @property
#     def date(self):
#         return pd.to_datetime(self.dp.value)


def get_bond_ref(bond_ref=None, date=None):
    date = date or pd.Timestamp.today().floor('d')
    bond_ref = bond_ref if bond_ref is not None else \
        tables.bonds_reference.query(f"issue_date <= '{date:%Y-%m-%d}' and maturity > '{date:%Y-%m-%d}'")
    bond_ref = add_maturity_bucket(
        add_years_to_maturity(bond_ref, date=date),
        maturity_bins=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20, 25, 30, 35, 40, 45, 50, 60]
    )
    bond_ref = add_rating_bucket(add_custom_rating(bond_ref))
    bond_ref = add_geo_area(bond_ref, more_cols={'name': 'country_name'})
    return bond_ref


def get_bday(date, previous=True):
    return date - BDay() + BDay() if not previous else date + BDay() - BDay()


def get_history_table(df, field, source='BGN'):
    df_ = df.query(f"source =='{source}'")[['date', 'security', field]]
    df_ = df_.pivot(index='date', columns='security', values=field).resample('B').ffill()
    return df_