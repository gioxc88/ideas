import json

import pandas as pd
from ipyaggrid import Grid

from gioutils.utils import update_recursively
from .base import View
from inflection import camelize

LOCALES_DEFAULT = 'en-GB'
NO_CURRENCY = "XXX"


class AGGridHandler(View):
    '''

    :param df:
    :param index:
    :param theme: one of:
        'ag-theme-balham',
        'ag-theme-balham-dark',
        'ag-theme-material',
        'ag-theme-fresh',
        'ag-theme-dark',
        'ag-theme-blue',
        'ag-theme-bootstrap',
        'ag-theme-excel'
    :param column_defs:
    :param grid_options:
    :param grid_kwargs:
    :param kwargs:
    '''
    def __init__(
            self,
            df,
            index=False,
            theme=None,
            column_defs=None,
            column_defs_fn=None,
            grid_options=None,
            grid_kwargs=None,
            title=None,
            autoformat=False,
            **kwargs
    ):

        self.df = self._check_dataframe(df)
        self._column_defs = column_defs
        self._column_defs_fn = column_defs_fn
        self._grid_options = grid_options or {}
        self._index = index
        self._grid_kwargs = grid_kwargs or {}
        self._grid_kwargs.setdefault('theme', theme or 'ag-theme-balham')
        self._title = title
        self._autoformat = autoformat

        super().__init__(df=self.df, index=index, column_defs=column_defs, grid_options=self._grid_options,
                         **self._grid_kwargs)

    def _check_dataframe(self, df):
        df = df.copy() if isinstance(df, pd.DataFrame) else df.to_frame()
        if df.columns.nlevels == 1:
            df.columns = df.columns.astype(str)

        index_names = []
        for i, name in enumerate(df.index.names):
            index_names.append(name or f"index{i}")
        df.index.names = index_names
        return df

    def _get_default_column_def(self, name, dtype=None):
        col_def = {
            'headerName': str(name),
            'field': str(name),
            'filterParams': {
                'buttons': ['reset']
            }
            # 'resizable': True,
            # 'sortable': True,
            # 'filter': 'agSetColumnFilter'
        }

        if dtype == 'object':
            col_def['filter'] = 'agSetColumnFilter'
        return col_def

    def _get_default_index_def(self, name, dtype=None):
        col_def = {
            'headerName': str(name),
            'field': str(name),
            'pinned': 'left',
            'cellStyle': {'font-weight': 'bold'},
            'filterParams': {
                'buttons': ['reset']
            }
            # 'resizable': True,
            # 'sortable': True,
        }
        if dtype == 'object':
            col_def['filter'] = 'agSetColumnFilter'
        return col_def

    def make_widgets(self, **kwargs):
        self._make_default_grid(**kwargs)

    def make_view(self, **kwargs):
        self.view = self.g

    def _make_default_grid(self, df, column_defs=None, grid_options=None, index=None, **kwargs):
        column_defs = column_defs or {}
        default_kwargs = dict(
            columns_fit='auto',
            show_toggle_edit=True
        )
        for key, value in default_kwargs.items():
            kwargs.setdefault(key, value)

        grid_options = grid_options or {}
        column_defs_ = {str(col): self._get_default_column_def(col, dtype=dtype) for col, dtype in df.dtypes.items()}

        if index:
            column_defs_ = {
                **{str(name): self._get_default_index_def(name, dtype=dtype) for name, dtype in df.index.to_frame().dtypes.items()},
                **column_defs_
            }

        if self._autoformat:
            dtypes = df.reset_index().dtypes
            for key, val in column_defs_.items():
                default_col_defs = DEFAULT_COLUMN_DEFS.get(dtypes.get(key).name, {})
                update_recursively(val, default_col_defs)
                # val.update(default_col_defs)

        for key, val in column_defs.items():
            update_recursively(column_defs_[key], val)
            # column_defs_[key].update(val)

        if self._column_defs_fn:
            column_defs_ = self._column_defs_fn(column_defs_)

        self._default_column_defs = column_defs_

        if not self._title:
            column_defs_options = [*column_defs_.values()]
        else:
            column_defs_options = [{'headerName': self._title, 'children': [*column_defs_.values()]}]

        self._default_column_defs_options = column_defs_options
        grid_options_ = {
            'columnDefs': column_defs_options,
            'enableSorting': True,
            'enableFilter': True,
            'enableColResize': True,
            'enableRangeSelection': True,
            'defaultColDef': {
                'sortable': True,
                'resizable': True,

            },
            # 'getRowStyle': format_breach,
        }

        update_recursively(grid_options_, grid_options)
        # grid_options_.update(grid_options)

        self._default_grid_options = grid_options

        g = Grid(
            grid_data=df,
            grid_options=grid_options_,
            index=index,
            **kwargs
        )
        self.g = g

    # def _ipython_display_(self):
    #     if hasattr(self, 'g'):
    #         display(self.g)


def format_number(locales=LOCALES_DEFAULT, null='-', ccy_col=None, default_ccy=None, **kwargs):
    '''

    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/NumberFormat/NumberFormat#options
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/NumberFormat#constructor
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl#locales_argument

    :param compactDisplay
        Only used when notation is "compact". Takes either "short" (default) or "long".
    :param currency
        The currency to use in currency formatting. Possible values are the ISO 4217 currency codes, such as "USD" for the US dollar, "EUR" for the euro, or "CNY" for the Chinese RMB — see the Current currency & funds code list. There is no default value; if the style is "currency", the currency property must be provided.
    :param currencyDisplay
        How to display the currency in currency formatting. The default is "symbol".
            - "symbol": use a localized currency symbol such as €.
            - "narrowSymbol": use a narrow format symbol ("$100" rather than "US$100").
            - "code": use the ISO currency code.
            - "name": use a localized currency name such as "dollar".
    :param currencySign
        In many locales, accounting format means to wrap the number with parentheses instead of appending a minus sign. You can enable this formatting by setting the currencySign option to "accounting". The default value is "standard".
    :param localeMatcher
        The locale matching algorithm to use. Possible values are "lookup" and "best fit"; the default is "best fit". For information about this option, see the Intl page.
    :param notation
        The formatting that should be displayed for the number. The default is "standard".
            - "standard": plain number formatting.
            - "scientific": return the order-of-magnitude for formatted number.
            - "engineering": return the exponent of ten when divisible by three.
            - "compact": string representing exponent; defaults to using the "short" form.
    :param numberingSystem
        Numbering System. Possible values include: "arab", "arabext", "bali", "beng", "deva", "fullwide", "gujr", "guru", "hanidec", "khmr", "knda", "laoo", "latn", "limb", "mlym", "mong", "mymr", "orya", "tamldec", "telu", "thai", "tibt".
    :param signDisplay
        When to display the sign for the number. The default is "auto".
            - "auto": sign display for negative numbers only, including negative zero.
            - "always": always display sign.
            - "exceptZero": sign display for positive and negative numbers, but not zero.
            - "negative": sign display for negative numbers only, excluding negative zero. Experimental
            - "never": never display sign.
    :param style
        The formatting style to use. The default is "decimal".
            - "decimal" for plain number formatting.
            - "currency" for currency formatting.
            - "percent" for percent formatting.
            - "unit" for unit formatting.
    :param unit
        The unit to use in unit formatting, Possible values are core unit identifiers, defined in UTS #35, Part 2, Section 6. A subset of units from the full list was selected for use in ECMAScript. Pairs of simple units can be concatenated with "-per-" to make a compound unit. There is no default value; if the style is "unit", the unit property must be provided.
    :param unitDisplay
        The unit formatting style to use in unit formatting. The default is "short".
            - "long" (e.g., 16 litres).
            - "short" (e.g., 16 l).
            - "narrow" (e.g., 16l).
    :param useGrouping Experimental
        Whether to use grouping separators, such as thousands separators or thousand/lakh/crore separators. The default is auto.
            - "always": display grouping separators even if the locale prefers otherwise.
            - "auto": display grouping separators based on the locale preference, which may also be dependent on the currency.
            - false: do not display grouping separators.
            - "min2": display grouping separators when there are at least 2 digits in a group.
            - true: alias for always.
    :param roundingMode Experimental
        Options for rounding modes. The default is halfExpand.
            - "ceil": round toward +∞. Positive values round up. Negative values round "more positive".
            - "floor" round toward -∞. Positive values round down. Negative values round "more negative".
            - "expand": round away from 0. The magnitude of the value is always increased by rounding. Positive values round up. Negative values round "more negative".
            - "trunc": round toward 0. This magnitude of the value is always reduced by rounding. Positive values round down. Negative values round "less negative".
            - "halfCeil": ties toward +∞. Values above the half-increment round like ceil (towards +∞), and below like floor (towards -∞). On the half-increment, values round like ceil.
            - "halfFloor": ties toward -∞. Values above the half-increment round like ceil (towards +∞), and below like floor (towards -∞). On the half-increment, values round like floor.
            - "halfExpand": ties away from 0. Values above the half-increment round like expand (away from zero), and below like trunc (towards 0). On the half-increment, values round like expand.
            - "halfTrunc": ties toward 0. Values above the half-increment round like expand (away from zero), and below like trunc (towards 0). On the half-increment, values round like trunc.
            - "halfEven": ties towards the nearest even integer. Values above the half-increment round like expand (away from zero), and below like trunc (towards 0). On the half-increment values round towards the nearest even digit.
        These options reflect the ICU user guide, where "expand" and "trunc" map to ICU "UP" and "DOWN", respectively. The rounding modes example below demonstrates how each mode works.
    :param roundingPriority Experimental
        Specify how rounding conflicts will be resolved if both "FractionDigits" (minimumFractionDigits/maximumFractionDigits) and "SignificantDigits" (minimumSignificantDigits/maximumSignificantDigits) are specified:
            - "auto": the result from the significant digits property is used (default).
            - "morePrecision": the result from the property that results in more precision is used.
            - "lessPrecision": the result from the property that results in less precision is used.
        Note that for values other than auto the result with more precision is calculated from the maximumSignificantDigits and maximumFractionDigits (minimum fractional and significant digit settings are ignored).
    :param roundingIncrement Experimental
        Specifies the rounding-increment precision. Must be one of the following integers: 1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000, 2500, 5000.
    :param trailingZeroDisplay Experimental
        A string expressing the strategy for displaying trailing zeros on whole numbers. The default is "auto".
            - "auto": keep trailing zeros according to minimumFractionDigits and minimumSignificantDigits.
            - "stripIfInteger": remove the fraction digits if they are all zero. This is the same as auto if any of the fraction digits is non-zero.
    :param minimumIntegerDigits
        The minimum number of integer digits to use. A value with a smaller number of integer digits than this number will be left-padded with zeros (to the specified length) when formatted. Possible values are from 1 to 21; the default is 1.
    :param minimumFractionDigits
        The minimum number of fraction digits to use. Possible values are from 0 to 20; the default for plain number and percent formatting is 0; the default for currency formatting is the number of minor unit digits provided by the ISO 4217 currency code list (2 if the list doesn't provide that information).
    :param maximumFractionDigits
        The maximum number of fraction digits to use. Possible values are from 0 to 20; the default for plain number formatting is the larger of minimumFractionDigits and 3; the default for currency formatting is the larger of minimumFractionDigits and the number of minor unit digits provided by the ISO 4217 currency code list (2 if the list doesn't provide that information); the default for percent formatting is the larger of minimumFractionDigits and 0.
    :param minimumSignificantDigits
        The minimum number of significant digits to use. Possible values are from 1 to 21; the default is 1.
    :param maximumSignificantDigits
        The maximum number of significant digits to use. Possible values are from 1 to 21; the default is 21.
    :return:
    '''

    if not locales:
        locales = LOCALES_DEFAULT
    default_ccy = default_ccy or NO_CURRENCY
    if ccy_col or kwargs.get('currency'):
        kwargs['style'] = 'currency'
        # kwargs['currency'] = f'params.data.{ccy_col}'
        kwargs.setdefault('currencyDisplay', 'narrowSymbol')
    locales = f"'{locales}'" if locales else 'null'
    options = json.dumps(kwargs)

    if ccy_col:
        options = options.replace(f'"params.data.{ccy_col}"', f'params.data.{ccy_col}')

    fn = f'''function(params){{
        const locales = {locales};
        let options = {options};
        if (params.value === null){{
            return '{null}'
        }}
        
        if ({"true" if ccy_col else "false"}) {{
            let ccy = params.data.{ccy_col};
            if (ccy === null || ccy === '' || typeof ccy === 'undefined') {{
                ccy = '{default_ccy}';
            }}
            options["currency"] = ccy;
        }}
        
        let x = new Intl.NumberFormat(locales, options).format(params.value);
        return x 
    }}'''

    return fn


def format_date(locales=LOCALES_DEFAULT, null='-', **kwargs):

    '''
    :param locales:
    :param null:
    :param kwargs:

    :param localeMatcher: The locale matching algorithm to use. Possible values are "lookup" and "best fit"; the default is "best fit".
    :param weekday: The representation of the weekday. Possible values are "long", "short", "narrow".
    :param era: The representation of the era. Possible values are "long", "short", "narrow".
    :param year: The representation of the year. Possible values are "numeric", "2-digit".
    :param month: The representation of the month. Possible values are "numeric", "2-digit", "long", "short", "narrow".
    :param day: The representation of the day. Possible values are "numeric", "2-digit".
    :param hour: The representation of the hour. Possible values are "numeric", "2-digit".
    :param minute: The representation of the minute. Possible values are "numeric", "2-digit".
    :param second: The representation of the second. Possible values are "numeric", "2-digit".
    :param timeZoneName: The representation of the time zone name. Possible values are "short", "long".
    :param formatMatcher: The format matching algorithm to use. Possible values are "basic" and "best fit"; the default is "best fit".
    :param hour12: Whether to use 12-hour time (as opposed to 24-hour time). Possible values are true and false; the default is locale dependent.
    :param timeZone: The time zone to use. The only value implementations must recognize is "UTC"; the default is the runtime's default time zone. Implementations may also recognize the time zone names of the IANA time zone database, such as "Asia/Shanghai", "Asia/Kolkata", "America/New_York".
    :param dateStyle: The format of output message. Possible values are "full", "long", "medium", "short".
    :param timeStyle: The format of output message. Possible values are "full", "long", "medium", "short".
    :param dayPeriod: The representation of the day period. Possible values are "narrow", "short", "long".
    :param numberingSystem: The numbering system to use. Possible values are "arab", "arabext", "bali", "beng", "deva", "fullwide", "gujr", "guru", "hanidec", "khmr", "knda", "laoo", "latn", "limb", "mlym", "mong", "mymr", "orya", "tamldec", "telu", "thai", "tibt".
    :param calendar: The calendar to use. Possible values are "buddhist", "chinese", "coptic", "ethioaa", "ethiopic", "gregory", "hebrew", "indian", "islamic", "islamicc", "iso8601", "japanese", "persian", "roc".
    :return:
    '''

    null = 'null' if null is None else f"'{null}'" if null != 0 else 0
    if not locales:
        locales = LOCALES_DEFAULT
    locales = f"'{locales}'" if locales else 'null'
    options = json.dumps(kwargs)
    fn = f'''function(params){{
        const locales = {locales};
        let dateObj = new Date(params.value);
        if (isNaN(dateObj) || dateObj === null){{
            if (params.value !== "NaT" && params.value !== null && typeof params.value !== 'undefined' && params.value !== ""){{
                return params.value
            }}
            return {null}
        }};
  
        let x = new Intl.DateTimeFormat(locales, {options}).format(dateObj);
        return x 
    }}'''

    return fn


def format_threshold(threshold=0, positive_style=None, negative_style=None, invert=False):
    positive_style = positive_style or {'color': 'green'}
    negative_style = negative_style or {'color': 'red'}

    if invert:
        positive_style, negative_style = negative_style, positive_style

    fn = f'''function(params){{
        if (params.value >= {threshold}){{
            return {positive_style};
        }} else {{
            return {negative_style};
        }}
        return ""
    }}
    '''

    return fn


def get_date():
    fn = f'''function getDate(date) {{
      let dateObj = new Date(date);
      if (isNaN(dateObj)) {{
        return new Date(-8.64e15)
      }} else {{
        return dateObj
      }}
    }}
    '''
    return fn


def compare_dates():
    fn = f'''function dateComparator(date1, date2) {{
      
      let date1Number = new Date(date1).getTime();
      let date2Number = new Date(date2).getTime();   
      
      if (isNaN(date2Number)) {{ 
        return -1;
      }}
      
      if (date1Number == date2Number){{
        return 0
      }}
 
      if (date1Number < date2Number){{
        return 1;
      }}

      if (date1Number > date2Number){{
        return -1;
      }} 
      

      
    }}
    '''
    return fn


DEFAULT_COLUMN_DEFS = {
    'int32': {
        'valueFormatter': format_number(notation="compact", maximumFractionDigits=4, minimumFractionDigits=0),
    },
    'float64': {
        'valueFormatter': format_number(notation="compact", maximumFractionDigits=4, minimumFractionDigits=0),
    },
    'datetime64[ns]': {
        'valueFormatter': format_date(year="2-digit", month='short', day="numeric", null='-'),
        # 'valueGetter': get_date(),
        'filterParams': {
            'comparator': compare_dates()
        }
    }
}



