import json
import sys
from pathlib import Path

import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
from IPython.display import display
from ipydatagrid import DataGrid
from sklearn.linear_model import LinearRegression
from inflection import underscore

from .datagrid import DataGridGio
from ..store import get_store_mixin


ViewStore = get_store_mixin('view')


class View(ViewStore):
    def __init__(self, *args, **kwargs):
        try:
            super().__init__(*args, **kwargs)
        except TypeError:
            pass

        if kwargs.pop('build', True):
            self.build(**kwargs)

    def build(self, **kwargs):
        self.make_widgets(**kwargs)
        self.make_view(**kwargs)

        _built = True

        if kwargs.pop('link', True):
            self.link(**kwargs)

    def make_widgets(self, **kwargs):
        pass

    def make_view(self, **kwargs):
        pass

    def link(self, **kwargs):
        _linked = True

    def _ipython_display_(self):
        if hasattr(self, 'view'):
            display(self.view)


class WidgetView(View):
    def __init__(self, widget, **kwargs):
        self.view = widget
        super().__init__(**kwargs)


# class Router(View):
#     def __init__(
#             self,
#             components=None,
#             **kwargs
#     ):
#         self.components = components or {}
#         self._value = None
#         super().__init__(**kwargs)
#         self.value = None if not components else [*components][0]
#
#     @property
#     def value(self):
#         return self._value
#
#     def make_view(self, **kwargs):
#         # self.view = v.Container(fluid=True, class_="ma-0 pa-0")
#         self.out = w.Output()
#         self.view = self.out
#
#     # @value.setter
#     # def value(self, value):
#     #     from copy import deepcopy
#     #     if value in self.components:
#     #         self._value = value
#     #         # self. view = v.Container(children=[self.components[value]], fluid=True, class_="ma-0 pa-0")
#     #         self.view.children = [self.components[value]]
#
#     @value.setter
#     def value(self, value):
#         if value in self.components:
#             self._value = value
#             # self. view = v.Container(children=[self.components[value]], fluid=True, class_="ma-0 pa-0")
#             with self.out:
#                 self.out.clear_output(wait=True)
#                 display(self.components[value])
#
#     def register(self, components):
#         update_view = True if not self.components and not self.value else False
#         self.components.update(components)
#         if update_view:
#             self.value = [*components][0]


class Router(View):
    def __init__(
            self,
            components=None,
            **kwargs
    ):
        self.components = components or {}
        self._value = None
        super().__init__(**kwargs)
        self.value = None if not components else [*components][0]

    @property
    def value(self):
        return self._value

    def make_view(self, **kwargs):
        # self.view = v.Container(
        #     children=[c for k, c in self.components.items()],
        #     fluid=True, class_="ma-0 pa-0"
        # )
        self.view = w.VBox(children=[c for k, c in self.components.items()])

    @value.setter
    def value(self, value):
        if value in self.components:
            self._value = value
            for i, (k, c) in enumerate(self.components.items()):
                if k != value:
                    c.layout.display = 'none'
                else:
                    c.layout.display = None

            # self. view = v.Container(children=[self.components[value]], fluid=True, class_="ma-0 pa-0")
            # self.view.children = [self.components[value]]
    def register(self, components):
        update_view = True if not self.components and not self.value else False
        self.components.update(components)
        self.view.children = [*self.view.children, *[c for k, c in components.items()]]
        if update_view:
            self.value = [*components][0]


router = Router()


class Tabs(View):
    def __init__(
            self,
            tabs,
            *args,
            tabs_kwargs=None,
            tabs_items_kwargs=None,
            force_grid_render=False,
            **kwargs
    ):
        tabs = {k: WidgetView(v) if isinstance(v, w.Widget) else v for k, v in tabs.items()}
        self.tabs = tabs
        self.data = {}
        self.tabs_kwargs = tabs_kwargs or {}
        self.tabs_items_kwargs = tabs_items_kwargs or {}
        self.force_grid_render = force_grid_render

        # store.tabs = self
        for key, value in tabs.items():
            value.build(link=False)
        for key, value in tabs.items():
            value.link()
        super().__init__(*args, **kwargs)

    def make_widgets(self, **kwargs):
        self.tabs_bar = v.Tabs(
            # dark=True,
            v_model=None,
            children=[v.Tab(children=[name]) for name in self.tabs],
            **self.tabs_kwargs
        )

        self.tabs_items = v.TabsItems(
            v_model=None,
            # dark=True,
            children=[v.TabItem(children=[tab.view]) for name, tab in self.tabs.items()],
            **self.tabs_items_kwargs
        )

    def make_view(self, **kwargs):
        self.view = v.Container(
            class_="my-0 py-0",
            fluid=True,
            children=[
                v.Row(children=[v.Col(children=[self.tabs_bar])]),
                v.Row(children=[v.Col(children=[self.tabs_items])]),
            ]
        )
        #
        # self.view = v.Card(
        #     children=[
        #         self.tabs_bar,
        #         self.tabs_items
        #     ]
        # )

    def link(self, **kwargs):
        w.jslink((self.tabs_bar, 'v_model'), (self.tabs_items, 'v_model'))

        if self.force_grid_render:
            self.tabs_bar.on_event('change', self.on_change_render_grids)

        super().link(**kwargs)

    def on_change_render_grids(self, widget, event, payload):
        view = self.tabs_items.children[payload].children[0]
        print('rendering', payload)
        force_render(view)

    def __getitem__(self, item):
        return self.tabs[item]


def force_render(widget):
    if isinstance(widget, View):
        for key, value in widget.__dict__.items():
            force_render(value)
    elif hasattr(widget, 'children'):
        for value in widget.children:
            force_render(value)
    elif isinstance(widget, DataGridGio):
        widget.rerender()


def on_change_render_grids(self, widget, event, payload):
    view = self.tabs_items.children[payload].children[0]
    print(type(view))
    print('rendering', payload)
    force_render(view)

