from copy import deepcopy
from functools import partial

import numpy as np
import pandas as pd
import ipywidgets as w
from ipydatagrid import DataGrid
from py2vega.functions.type_checking import isValid

from .base import View


def default_styler(
        df,
        precision=4,
        date_format='%Y-%m-%d',
        na_rep='-',
        hover_color="#ffff99",
        formatters=None,
        multipliers=None,
        apply=None,
        applymap=None,
        format_index=None,
        bar=None,
        finalize=None,
        finalize_kwargs=None,
):
    format_index = format_index or {}
    bar = bar or {}

    th_props = [
        ('font-size', '11px'),
        ('text-align', 'center'),
        ('font-weight', 'bold'),
        # ('color', '#6d6d6d'),
        ('background-color', '#f7f7f9'),
        ('border-bottom', '1px solid  #d7d7d7'),
        ('white-space', 'nowrap !important')
    ]

    tr_props = [
        ("line-height", "11px"),
        # ('border-color', 'white'),
        ('background-color', 'white'),
        ('border-bottom', '1px solid  #d7d7d7'),
        # ('white-space', 'nowrap !important')
    ]
    td_props = [
        ('font-size', '11px'),
        ('white-space', 'nowrap !important')
    ]

    selectors = [
        {"selector": "tr", "props": tr_props},
        {"selector": "td, th", "props": "line-height: inherit; padding-top: 2.5px; padding-bottom: 2.5px;"},
        {'selector': 'th', 'props': th_props},
        {'selector': 'td', 'props': td_props},
        *hover(hover_color)
    ]

    if multipliers:
        if isinstance(multipliers, int):
            df = df * multipliers
        else:
            for mult in multipliers:
                df[mult] = multipliers[mult] * df[mult]

    date_cols = {}
    if date_format:
        date_format = f'{{:{date_format}}}'
        for col in df:
            if np.issubdtype(df[col].dtype, np.datetime64):
                date_cols[col] = partial(format_time_nat, fmt=date_format)

    formatters = {**(formatters or {}), **date_cols}

    styler = df.style. \
        set_table_styles(selectors). \
        format(
        formatter=formatters,
        precision=precision,
        na_rep=na_rep,
    )

    if apply and not isinstance(apply, list):
        apply = [apply]
        for fn in apply:
            if not isinstance(fn, dict):
                fn = {'dict': fn}
            styler = styler.apply(**fn)

    if applymap and not isinstance(applymap, list):
        applymap = [applymap]
        for fn in applymap:
            if not isinstance(fn, dict):
                fn = {'dict': fn}
            styler = styler.applymap(**fn)
    styler = styler.format_index(**format_index)

    styler = styler if not bar else styler.bar(**bar)

    if finalize:
        finalize_kwargs = finalize_kwargs or {}
        styler = finalize(styler, **finalize_kwargs)

    return styler


def negative_red(val):
    """
    Takes a scalar and returns a string with
    the css property `'color: red'` for negative
    strings, black otherwise.
    """
    color = 'red' if val < 0 else 'black'
    return 'color: %s' % color


def format_time_nat(t, fmt='{:%Y-%m-%d}'):
    try:
        return fmt.format(t)  # or strftime
    except ValueError:
        return t


def hover(hover_color="#ffff99"):
    return [
        dict(
            selector="tr:hover",
            props=[("background-color", "%s" % hover_color)]
        ),
        dict(
            selector="th:hover",
            props=[("background-color", "%s" % hover_color)]
        ),
    ]


class DFOutput(View):
    def __init__(self, df, out=None, style_fn=default_styler, styler_kwargs=None, margin=None, **kwargs):
        self._df = df

        layout_kwargs = {
            'layout': dict(
                margin=f'{margin[0]}px {margin[1]}px {margin[2]}px {margin[3]}px')
        } if margin else {}
        self.out = out or w.Output(**layout_kwargs)
        self.style_fn = style_fn or (lambda df: df.style)
        self.styler_kwargs = styler_kwargs or {}
        super().__init__(**kwargs)

    def make_widgets(self, **kwargs):
        self.styler = self.style_fn(self.df, **self.styler_kwargs)
        with self.out:
            self.out.clear_output(wait=True)
            # display(self.style_fn(self._df, **self.styler_kwargs))

            self.out.append_display_data(self.styler)

    def make_view(self, **kwargs):
        self.view = self.out

    @property
    def df(self):
        return self._df if isinstance(self._df, pd.DataFrame) else self._df.to_frame()

    @df.setter
    def df(self, value):
        self._df = value
        self.styler = self.style_fn(value, **self.styler_kwargs)
        with self.out:
            self.out.clear_output(wait=True)
            # display(self.style_fn(self._df, **self.styler_kwargs))
            self.out.append_display_data(self.styler)


def custom_row_line(df, mapping, border=2, color='#ABABAB'):
    dfs = pd.DataFrame().reindex_like(df).fillna('')
    if isinstance(mapping, dict):
        mapping = {key: mapping[key] for key in df.index}
        grouper = [*mapping.values()]
        last_rows = dfs.reset_index().groupby(grouper, as_index=False, sort=False).last().iloc[:, 0]
    else:  # assuming is a list
        last_rows = mapping
    mask = dfs.index.isin(last_rows)
    dfs.loc[mask, :] = f'border-bottom: {border}px solid  {color}'
    return dfs


def custom_index_row_line(ser, mapping, border=2, color='#ABABAB'):
    serf = pd.Series(dtype=object).reindex_like(ser).fillna('')
    if isinstance(mapping, dict):
        mapping = {key: mapping[key] for key in ser}
        grouper = [*mapping.values()]
        last_rows = serf.to_frame().reset_index().groupby(grouper, as_index=False, sort=False).last().iloc[:, 0]
        mask = serf.index.isin(last_rows)
    else:  # assuming is a list
        last_rows = mapping
        mask = ser.isin(last_rows)
    serf.loc[mask] = f'border-bottom: {border}px solid  {color} !important'
    return serf


def custom_styler_row_line(styler, **kwargs):
    styler = styler.apply(custom_row_line, axis=None, **kwargs)
    styler = styler.apply_index(custom_index_row_line, axis=0, **kwargs)
    return styler


def millify(
        cell,
        decimal=2,
        pct=3,
        zero=1e-7,
        na_rep='-',
        k_decimal=2,
        m_decimal=2,
        b_decimal=2,
        t_decimal=2,
        zero_rep='0'
):
    cell = getattr(cell, 'value', cell)
    n = abs(float(cell))

    if n <= zero:
        return zero_rep
    elif n < 1 and pct:
        return format(cell, ".{}%".format(pct)) if pct else format(cell, ".{}f".format(decimal))
    elif n < 1000:
        return format(cell, ".{}f".format(decimal))
    elif n < 1000000:
        return format(cell / 1000, ".{}f".format(k_decimal)) + 'k'
    elif n < 1000000000:
        return format(cell / 1000000, ".{}f".format(m_decimal)) + 'm'
    elif n < 1000000000000:
        return format(cell / 1000000000, ".{}f".format(b_decimal)) + 'b'
    elif n < 1000000000000000:
        return format(cell / 1000000000000, ".{}f".format(t_decimal)) + 't'
    else:  # assume is nan ps it does not work
        return na_rep if na_rep else str(cell)

from numbers import Number


def millifyp(
        cell,
        decimal=2,
        pct=3,
        bp=None,
        zero=1e-7,
        na_rep='-',
        k_decimal=2,
        m_decimal=2,
        b_decimal=2,
        t_decimal=2,
        zero_rep='0'
):
    cell = getattr(cell, 'value', cell)
    # if cell is None:
    #     print(cell)
    #     return na_rep
    if not isinstance(cell, Number):
        return cell
    # if isinstance(cell, str):
    #     return cell

    n = abs(float(cell))
    cell = float(cell)
    if n <= zero:
        return zero_rep
    elif n < 0.1:
        return format(10000 * cell, ".{}%".format(bp)) if bp else format(cell, ".{}f".format(decimal))
    elif n < 1:
        return format(cell, ".{}%".format(pct)) if pct else format(cell, ".{}f".format(decimal))
    elif n < 1000:
        v = cell
        return format(cell, ".{}f".format(decimal if not v.is_integer() else 0))
    elif n < 1000000:
        v = cell / 1000
        return format(v, ".{}f".format(k_decimal if not v.is_integer() else 0)) + 'k'
    elif n < 1000000000:
        v = cell / 1000000
        return format(v, ".{}f".format(m_decimal if not v.is_integer() else 0)) + 'm'
    elif n < 1000000000000:
        v = cell / 1000000000
        return format(v, ".{}f".format(b_decimal if not v.is_integer() else 0)) + 'b'
    elif n < 1000000000000000:
        v = cell / 1000000000000
        return format(v, ".{}f".format(t_decimal if not v.is_integer() else 0)) + 't'
    else:  # assume is nan ps it does not work
        return na_rep if na_rep else str(cell)



def millify1(cell):
    value = cell.value
    n = abs(float(value))

    if not isValid(cell.value):
        return '-'
    elif n < 0.1:
        return format(value, '.2f')
    elif n < 1:
        return format(value, '.2f')
    elif n < 1000:
        return format(value, '.1f')
    elif n < 1000000:
        return format(value / 1000, '.1f') + 'k'
    elif n < 1000000000:
        return format(value / 1000000, '.1f') + 'm'
    elif n < 1000000000000:
        return format(value / 1000000000, '.1f') + 'b'
    else:
        return format(value / 1000000000000, '.1f') + 't'


from inspect import getsource


def if_(test, if_true, if_false):
    pass


from ipydatagrid import VegaExpr

def millify_vega(
        na_rep='-',
        pct1_fmt='.2f',
        pct2_fmt='.2f',
        float_fmt='.1f',
        float_k_fmt='.1f',
        float_m_fmt='.1f',
        float_b_fmt='.1f',
        float_t_fmt='.1f',
):
    expr = f'''
    if(
        Math.isNaN(cell.value), f"'{na_rep}'", if(
            abs(float(cell.value)) < 0.1, format(cell.value, f"'{pct1_fmt}'"), if(
                abs(float(cell.value)) < 1, format(cell.value, f"'{pct2_fmt}'"), if(
                    abs(float(cell.value)) < 1000, format(cell.value, f"'{float_fmt}'"), if(
                        abs(float(cell.value)) < 1000000, format(cell.value / 1000, f"'{float_k_fmt}'") + 'k', if(
                            abs(float(cell.value)) < 1000000000, format(cell.value / 1000000, f"'{float_m_fmt}'") + 'm', if(
                                abs(float(cell.value)) < 1000000000000, format(cell.value / 1000000000, f"'{float_b_fmt}'") + 'b', format(cell.value / 1000000000000, f"'{float_t_fmt}'") + 't'
                            )
                        )
                    )
                )
            )
        )
    )
    '''
    return VegaExpr(expr)

