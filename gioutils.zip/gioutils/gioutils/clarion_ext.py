from inspect import signature, Parameter, Signature
from uuid import uuid4

import pandas as pd
from inflection import underscore

fx = pd.DataFrame(
    [
        {
            'Name': 'CurrencyPair',
            'Type': 'str',
            'Description': 'Currency pair of the trade'
        },
        {
            'Name': 'Expiry',
            'Type': 'str',
            'Description': "Expiry as date (YYYY-MM-DD) or tenor e.g. '3M'"
        },
        {
            'Name': 'Strike',
            'Type': 'num/str',
            'Description': "'atm', 'a', 'spot', 's', 'atms', 'forward', 'f', 'atmf', num"
        },
        {
            'Name': 'OptionType',
            'Type': 'str',
            'Description': "'Call', 'C', 'Put', 'P', 'Straddle', 'S'"},
        {
            'Name': 'Notional', 'Type': 'num/str', 'Description': 'Notional'
        },
        {
            'Name': 'PayCurrency',
            'Type': 'str',
            'Description': 'For options that pay in cash, this is the currency for that payment'
        },
        {
            'Name': 'BarrierDown',
            'Type': 'num/str',
            'Description': 'For options with barriers, this is the level above which a barrier is triggered'
        },
        {
            'Name': 'BarrierUp',
            'Type': 'num/str',
            'Description': 'For options with barriers, this is the level below which a barrier is triggered'
        },
        {
            'Name': 'BarrierStartDate',
            'Type': 'str',
            'Description': 'For options with window barriers, this is the starting date of the window'
        },
        {
            'Name': 'BarrierEndDate',
            'Type': 'str',
            'Description': 'For options with window barriers, this is the ending date of the window'
        }
    ]
)  # .set_index('Name')

rates = pd.DataFrame(
    [
        {

            'Name': 'InstrumentName',
            'Type': 'str',
            'Description': 'Instrument name as specified in line pricer for Rates'

        },
        {

            'Name': 'Notional', 'Type': 'num/str', 'Description': 'Notional'

        },
        {
            'Name': 'Strike', 'Type': 'num/str', 'Description': "'a' or num"
        },
        {
            'Name': 'ClearingHouse',
            'Type': 'str',
            'Description': 'The clearing house (alternatively provide CollateralCurrency)'
        },
        {
            'Name': 'CollateralCurrency',
            'Type': 'str',
            'Description': 'The collateral currency (alternatively provide ClearingHouse)'
        },
        {
            'Name': 'Currency', 'Type': 'str', 'Description': 'The instrument currency'
        },
        {
            'Name': 'StartDate',
            'Type': 'str',
            'Description': 'The starting date as YYYY-MM-DD'
        },
        {
            'Name': 'SwapType', 'Type': 'str', 'Description': "'Pay' or 'Rec'"
        },
        {
            'Name': 'SwaptionType',
            'Type': 'str',
            'Description': "'Pay', 'Rec' or 'Straddle'"
        },
        {
            'Name': 'FraType', 'Type': 'str', 'Description': "'Pay' or 'Rec'"
        },
        {
            'Name': 'Tenor',
            'Type': 'str',
            'Description': 'The maturity date or contract duration as YYYY-MM-DD'
        },
        {
            'Name': 'Expiry',
            'Type': 'str',
            'Description': 'The expiry date as YYYY-MM-DD'
        },
        {
            'Name': 'SettleType',
            'Type': 'str',
            'Description': "The settle type as specified in line pricer for Rates, e.g. 'Cash Price'"
        },
        {
            'Name': 'PaySettle', 'Type': 'str', 'Description': "'Spot' or 'Fwd'"
        },
        {
            'Name': 'Isin', 'Type': 'str', 'Description': 'The ISIN for a bond'
        },
        {
            'Name': 'OptionType',
            'Type': 'str',
            'Description': "'Call' or 'Put' or 'Straddle'"
        },
        {
            'Name': 'CapFloorType',
            'Type': 'str',
            'Description': "'Cap', 'Floor', or 'Straddle'"
        }
    ]
)  # .set_index('Name')

equity = pd.DataFrame(
    [
        {
            'Name': 'InstrumentName',
            'Type': 'str',
            'Description': 'Instrument name as specified in line pricer for Equities'
        },
        {
            'Name': 'Quantity', 'Type': 'num/str', 'Description': 'Quantity'
        },
        {
            'Name': 'Strike',
            'Type': 'num/str',
            'Description': "The option strike. If ContractType is 'OTC' can have eg 100F or 100S for 100% forward moneyness or 100% spot moneyness respectively"
        },
        {
            'Name': 'UnderlyingExpiry',
            'Type': 'str',
            'Description': 'The expiry of the future underlying. Future expiries are in format MMMYY or future code eg U25 or U5'
        },
        {
            'Name': 'ContractType',
            'Type': 'str',
            'Description': "The 3-character venue or 'OTC'"
        },
        {
            'Name': 'Expiry',
            'Type': 'str',
            'Description': 'For options, the expiry of the contract as date (YYYY-MM-DD) or tenor (eg 6m). For futures, expiries are in format MMMYY or future code eg U25 or U5.'
        },
        {
            'Name': 'OptionType',
            'Type': 'str',
            'Description': "'Call' or 'Put' or 'Straddle'"
        },
        {
            'Name': 'ExerciseType',
            'Type': 'str',
            'Description': "'American' or 'European'"
        }
    ]
)  # .set_index('Name')

credit = pd.DataFrame(
    [
        {'Name': 'InstrumentName',
         'Type': 'str',
         'Description': 'Instrument name as specified in line pricer for Credit'},
        {'Name': 'Isin',
         'Type': 'str',
         'Description': 'Bond ISIN. For bonds this replaces InstrumentName'},
        {'Name': 'Notional', 'Type': 'num/str', 'Description': 'Notional'},
        {'Name': 'Currency', 'Type': 'str', 'Description': 'Trade currency'},
        {'Name': 'Tier', 'Type': 'str', 'Description': "eg 'SNRFOR'"},
        {'Name': 'DocClause', 'Type': 'str', 'Description': "eg 'XR', 'MM14'"},
        {'Name': 'CollateralCurrency',
         'Type': 'str',
         'Description': 'Bilateral collateral currency'},
        {'Name': 'PositionType',
         'Type': 'str',
         'Description': "'Buy' or 'Sell' protection"},
        {'Name': 'StartDate',
         'Type': 'str',
         'Description': "Start date of a CDS. Format 'yyyy-MM-dd'"},
        {'Name': 'Strike',
         'Type': 'num/str',
         'Description': 'The strike of an option'},
        {'Name': 'Expiry',
         'Type': 'str',
         'Description': "Expiry of an option. Format 'yyyy-MM-dd' or tenor eg '5y'"},
        {'Name': 'Maturity',
         'Type': 'str',
         'Description': "Maturity of a CDS. Format 'yyyy-MM-dd' or tenor eg '5y'"},
        {'Name': 'OptionType',
         'Type': 'str',
         'Description': "For CDS Index Options, 'Pay' or 'Rec'"},
        {'Name': 'Coupon', 'Type': 'num/str', 'Description': 'Coupon of a CDS'}
    ]
)  # .set_index('Name')

doc_map = {
    'fx': fx,
    'rates': rates,
    'equity': equity,
    'credit': credit,
}


def clarion_instrument(clarion, instrument):
    klass = instrument
    instrument_type_params = clarion.price.instrument_type_params(klass)
    param_map = {underscore(d['field']): d['field'] for d in instrument_type_params}
    required_map = {underscore(d['field']): not d['optional'] for d in instrument_type_params}
    fn_params = [
        Parameter('self', kind=Parameter.POSITIONAL_ONLY),
        *[
            Parameter(
                param,
                kind=Parameter.POSITIONAL_OR_KEYWORD,
                default=None,
                annotation=f"{'required' if required_map[param] else 'optional'}"
            ) for param in param_map
        ],
        Parameter('id', kind=Parameter.POSITIONAL_OR_KEYWORD, default=None),
    ]
    new_signature = Signature(fn_params)

    for type_ in doc_map:
        if instrument.lower().startswith(type_):
            doc = doc_map[type_].copy()
            doc['Name'] = doc['Name'].map(underscore)
            doc['Required'] = doc['Name'].map(required_map)
            doc = doc.query(f"Name in {[*param_map]}")
            doc = doc.set_index('Name').loc[[param for param in param_map if param in [*doc['Name']]], :].reset_index()
            break

    class Wrapper:
        def __init__(self, **kwargs):
            self._id = None
            self._trade_type = klass
            self._trade = None

            self._kwargs = kwargs

            for k in param_map:
                setattr(self, k, None)

            for k, v in kwargs.items():
                if k == 'id':
                    k = '_id'
                setattr(self, k, v)

            self._param_map = {
                **param_map,
            }

        @property
        def id(self):
            if not self._id:
                self._id = self.get_id()
            return self._id

        @id.setter
        def id(self, value):
            self.trade.id = value

        def get_id(self):
            return f"{klass.lower()}_{uuid4().hex}"

        def get_params(self):
            params = {
                'id': self.id,
                '_type': self.__class__.__name__,
                **{f"_{v}": getattr(self, v) for v in self._param_map if v is not None}
            }
            return params




        @property
        def trade(self):
            if not self._trade:
                trade = clarion.create_trade(
                    id=self.id,
                    trade_type=self._trade_type,
                    instrument_data={v: p for k, v in self._param_map.items() if (p := getattr(self, k)) is not None},
                )
                self._trade = trade
            return self._trade

        def __repr__(self):
            return self.trade.__repr__()

    Wrapper.__init__.__signature__ = new_signature
    Wrapper.__name__ = klass
    Wrapper.__qualname__ = klass
    Wrapper.__init__.__doc__ = make_doc(doc)

    return Wrapper


class Runner:
    _max_items = 100

    def __init__(self, clarion=None):
        self.clarion = clarion

    def run(
            self,
            metrics: list,
            data_list,
            start_date: pd.Timestamp | str = None,
            end_date: pd.Timestamp | str = None,
            system_time: pd.Timestamp | str = None,
            settings: dict = None,
            market_mode: str = 'live',
            polling_count: int = 60,
            polling_interval: int = 1,
            backoff: int = 1,
            max_items: int = None,
            attach_params=True,
    ):

        max_items = max_items or self._max_items
        if self.clarion:
            clarion = self.clarion

        if not isinstance(metrics, list):
            metrics = [metrics]

        if not isinstance(data_list, list):
            if isinstance(data_list, dict):
                data_list = [*data_list.values()]
            else:
                data_list = [data_list]

        data_list = [getattr(i, 'trade', i) for i in data_list]
        self._data_list = data_list
        data_lists = [data_list[i:i + max_items] for i in range(0, len(data_list), max_items)]
        reqs = []

        self._data_lists = data_lists
        start_date = f"{pd.to_datetime(start_date):%Y-%m-%d}" if start_date else None
        end_date = f"{pd.to_datetime(end_date):%Y-%m-%d}" if end_date else None
        system_time = system_time or pd.Timestamp.now()
        system_time = f"{pd.to_datetime(system_time):%Y-%m-%dT%H:%M:%S.%fZ}"

        for trades in data_lists:
            trades = [getattr(trade, 'trade', trade) for trade in trades]
            req = clarion.price.request(
                metrics=metrics,
                data_list=trades,
                start_date=start_date,
                end_date=end_date,
                system_time=system_time,
                settings=settings,
                market_mode=market_mode,
                polling_count=polling_count,
                polling_interval=polling_interval,
                backoff=backoff,
            )
            reqs.append(req)
        self._reqs = reqs
        ress = []
        for req in reqs:
            res = clarion.price.retrieve(
                req['KEY'],
                polling_count=polling_count,
                polling_interval=polling_interval,
                backoff=backoff
            )
            ress.append(res)
        self._ress = ress
        df = pd.concat(res['DFRAME'] for res in ress)

        if attach_params:
            params_df = pd.DataFrame([self.get_params(t) for t in data_list])
            self._params_df = params_df
            df = df.merge(params_df, how='left', on='id').set_index('id').loc[params_df['id'], :].reset_index()

        if 'period' in df.columns:
            df['period'] = pd.to_datetime(df['period'])
        self.df = df
        return df

    def get_params(self, trade):
        return {
            'id': trade.id,
            '_type': trade.get_instrument().get_type(),
            **{f"_{underscore(key)}": val for key, val in trade.get_instrument().get_instrument_data().items()}
        }


def super_clarion(clarion, instruments=None, verbose=False):
    instrument_types = instruments or clarion.price.instrument_types()

    class Instruments:
        def __repr__(self):
            return 'Clarion Instruments Accessor'

    for instrument in instrument_types:
        try:
            setattr(Instruments, instrument, clarion_instrument(clarion, instrument))
            log = f'{instrument}: ok'
        except Exception as e:
            log = f'{instrument}: error'
        finally:
            if verbose:
                print(log)

    clarion.instruments = Instruments()
    clarion.runner = Runner(clarion=clarion)


def make_doc(param_df):
    string = 'Parameters\n----------\n'
    for index, row in param_df.iterrows():
        new_string = f"{row['Name']}: {row['Type']}, {'required' if row['Required'] else 'optional'}:{chr(10)}    " \
                     f"{row['Description']}.{chr(10)}"
        string = f"{string}{new_string}"
    return string
