import warnings

import numpy as np
import pandas as pd
from IPython.display import display
from inflection import underscore
from pandas.tseries.offsets import BDay
from plotly import graph_objects as go

from .tools import parse_swap_periods
from .utils import (
    get_bday,
    get_next_n,
    parse_offset,
    today,
    get_generic_future,
    get_bbg_fut_chain_ticker,
    get_root
)

BPV = 1e4

options = [
    'RatesBondFutureOption',
    'RatesShortTermFutureOption',
]

future_exclusions = [
    'FxForward',
    'EquityCashOption',
]

spot_map = {
    'rx': 'GTDEM10Y Govt',
    'oe': 'GTDEM5Y Govt',
    'ty': 'GT10 Govt',
    'fv': 'GTDEM5Y Govt',
    'sfr': 'SOFRRATE Index',
    'ff': 'FEDL01 Index',
    'ed': 'US0003M Index',
    '0e': 'US0003M Index',
    '3m': 'GTDEM10Y Govt',
    'er': 'EUR003M Index'
}

curve_map = {
    'EUR LIFFE 3M': 'EUR.3M',
    'EUR LIFFE MID': 'EUR.3M',
    'GBP SONIA': 'GBP.SONIA',
    'USD CBT 30D': 'USD.OIS',
    'USD SOFR': 'USD.SOFR',
    'EUR ESTER': 'EUR.ESTER',
    'EURIBOR A 3M': 'EUR.3M',
    'EURIBOR A 6M*': 'EUR.6M',
    'USD SOFR CME 3M': 'USD.SOFR',
    'USD CME 3M': 'USD.3M',
    'GBP SONIA ICE 3M': 'GBP.SONIA',
    'JPY DYENCALM': 'JPY.DYENCALM'
}

delta_map = {
    'RatesBondFuture': -1,
    'RatesBondFutureOption': -1,
    'RatesShortTermFuture': -1,
    'RatesShortTermFutureOption': -1
}

field_map = {
    'tu': 'yld_ytm_mid',
    'fv': 'yld_ytm_mid',
    'ty': 'yld_ytm_mid',
    'us': 'yld_ytm_mid',
    'du': 'yld_ytm_mid',
    'oe': 'yld_ytm_mid',
    'rx': 'yld_ytm_mid',
    'ub': 'yld_ytm_mid',
    'ik': 'yld_ytm_mid',
}


def get_future_root(ticker):
    if not pd.isnull(ticker):
        return ticker.split(' ')[0].strip()[:-2].lower()
    return np.nan


def get_aged_futures(uticker, gticker):
    if not pd.isnull(gticker):
        root = uticker.split(' ')[0].strip()[:-2]
        end = gticker.split(' ', 1)[-1].strip()
        n = int(gticker.split(' ')[0].strip()[len(root):])
        if n > 1:
            aged = f"{root}{n - 1} {end}"
        else:
            aged = spot_map[root.lower()]
    else:
        aged = np.nan
    return aged


def get_swap_curve(underlying):
    return curve_map.get(underlying, np.nan)


def get_hpstring(
        instrument,
        curve,
        period,
        ticker,
        root,
        stir_as_swap=True
):
    if instrument in ['RatesBondFuture', 'RatesBondFutureOption']:
        field = 'YLD_YTM_MID'  # field_map.get(root)
        return f'[BBG {ticker} {field}]'
    elif instrument in ['RatesShortTermFuture', 'RatesShortTermFutureOption']:
        if stir_as_swap:
            return f'[s {curve} {period}]'
        return f'(100 - [BBG {ticker}])' if ticker not in spot_map.values() else f'[BBG {ticker}]'
    elif instrument in ['RatesSwap', 'RatesSwaption']:
        return f'[s {curve} {period}]'


def get_as_swap(instrument, stir_as_swap):
    if instrument in ['RatesShortTermFuture', 'RatesShortTermFutureOption']:
        if stir_as_swap:
            return True
    elif instrument in ['RatesSwap', 'RatesSwaption']:
        return True
    return False


def get_clarion_positions(clarion, book='MM-BAL', date=None, metrics=None):
    metrics = metrics or []
    cols = [
        "id",
        # "status",
        "isIntraday",
        # "type",
        # "Portfolio",
        "Category",
        "Strategy",
        "Ticker",
        "Underlying",
        "Description",
        "LocalCurrency",
        # "currency",
        "Notional",
        "TradeType",
        # "Counterparty",
        # "PrimeBroker",
        "TradeDate",
        "ExecutionTime",
        "TradePrice",
        # "Cut",
        # "NotionalLeftCurrency",
        # "NotionalRightCurrency",
        "Strike",
        "ExpiryDate",
        "CallPut",
        # "SettleDate",
        "PayReceive",
        "StartDate",
        "MaturityDate",
        # "delta_USD",
        # "gamma_USD",
        # "StartDateUnbumped",
        # "MaturityDateUnbumped",
        # "Clearer",
        # "delta_EUR",
        # "gamma_EUR",
        "fwd_rate",
        "Delta",
        "Gamma",
        "Vega"
    ]

    date_cols = [
        "TradeDate",
        "ExecutionTime",
        "ExpiryDate",
        "StartDate",
        "MaturityDate"
    ]

    rates_delta = clarion.metric(
        "delta",
        "Delta",
        "Rates",
        {"VolSpotDynamic": "StickyDelta", "RiskSpace": "Par", "RiskBuckets": "Default"},
    )
    rates_gamma = clarion.metric(
        "gamma",
        "Gamma",
        "Rates",
        {"VolSpotDynamic": "StickyDelta", "RiskSpace": "Par", "RiskBuckets": "Default"},
    )

    rates_vega = clarion.metric(
        "vega",
        "Vega",
        "Rates",
        {'Period': 'Daily'},
    )
    fwd_rate = clarion.metric('fwd_rate', 'Forward', 'Rates')

    metrics_ = [
        rates_delta,
        rates_gamma,
        rates_vega,
        fwd_rate,
        *metrics
    ]

    run_kwargs = dict(
        metrics=metrics_,
        portfolios=[book],
        market_mode="live" if not date else "reval",
    )
    if date:
        run_kwargs['asof_date'] = f"{pd.to_datetime(date):%Y-%m-%d}"

    res = clarion.positions.run(**run_kwargs)
    data = res["DFRAME"]
    data = data.query("Notional != 0")
    data = data.assign(
        Category=data["TradeType"].apply(underscore).str.split("_").str[0],
        Delta=data[data.columns[data.columns.str.contains("delta_")]]
              .replace("", None)
              .astype("float")
              .sum(axis=1),
        Gamma=data[data.columns[data.columns.str.contains("gamma_")]]
              .replace("", None)
              .astype("float")
              .sum(axis=1),
        Vega=data[data.columns[data.columns.str.contains("vega_")]]
        .replace("", None)
        .astype("float")
        .sum(axis=1),
    )

    data['id'] = data['id'].replace('', -1).astype(int)
    for col in date_cols:
        data[col] = pd.to_datetime(data[col]).dt.tz_localize(None)
    cols = [*cols, *[m.label for m in metrics]]
    data = data[cols]
    data = data.sort_values(['Category', 'Strategy', 'ExecutionTime', 'TradeDate'])
    return data


def get_history_plotter_book(
        clarion,
        bq,
        delta_tol=100,
        delta_mul=-1,
        age='3m',
        add_ptf=True,
        adj_fut=False,
        stir_as_swap=True,
        aged_bottom=False,
):
    data = get_clarion_positions(clarion)

    options_tickers = data.query(f'TradeType in {options}').drop_duplicates('Underlying')[['Ticker', 'Underlying']]
    # with warnings.catch_warnings():
    #     warnings.filterwarnings(action="ignore")
    if not options_tickers.empty:
        options_underlying_tickers = bq.bdp(
            securities=options_tickers['Ticker'],
            fields={'REAL_UNDERLYING_TICKER': 'uticker'}
        ).rename({'security': 'Ticker'}, axis=1)
        options_underlying_tickers['uticker'] = options_underlying_tickers['uticker'] + ' Comdty'
        options_tickers = options_tickers.merge(options_underlying_tickers, on='Ticker')
        d = data.merge(options_tickers.drop('Ticker', axis=1), on='Underlying', how='left')
    else:
        d = data

    d = d.replace('', np.nan)
    d['uticker'] = d['uticker']
    d['TradeType'] = d['TradeType']
    d.loc[~d['TradeType'].isin(options), 'uticker'] = d.loc[~d['TradeType'].isin(options), 'Ticker']
    future_tickers = d.query(f'TradeType not in {future_exclusions}')['uticker'].drop_duplicates().dropna()
    gen_fut = get_generic_future(future_tickers, bq=bq);
    future_tickers = future_tickers.to_frame().assign(
        gticker=gen_fut,
        cticker=[get_bbg_fut_chain_ticker(fut, days=10, yk=None) for fut in gen_fut] if adj_fut else gen_fut,
    )
    d = d.merge(future_tickers, on='uticker', how='left')

    d['rticker'] = d.apply(lambda row: get_future_root(ticker=row['uticker']), axis=1)
    d['cticker_aged'] = d.apply(lambda row: get_aged_futures(uticker=row['uticker'], gticker=row['cticker']), axis=1)
    d['hpcurve'] = d.apply(lambda row: get_swap_curve(underlying=row['Underlying']), axis=1)
    d['hpperiod'] = d.apply(lambda row: parse_swap_periods(start_date=row['StartDate'], end_date=row['MaturityDate']),
                            axis=1)
    d['hpperiod_aged'] = d.apply(
        lambda row: parse_swap_periods(start_date=row['StartDate'], end_date=row['MaturityDate'], age=age), axis=1)
    # d['delta_rate'] = d.apply(lambda row: row['Delta'] * delta_map.get(row['TradeType'], 1), axis=1)
    d['delta_rate'] = d['Delta']

    d['string'] = d.apply(lambda row: get_hpstring(
        instrument=row['TradeType'],
        curve=row['hpcurve'],
        period=row['hpperiod'],
        ticker=row['cticker'],
        root=row['rticker'],
        stir_as_swap=stir_as_swap
    ), axis=1)

    d['string_aged'] = d.apply(lambda row: get_hpstring(
        instrument=row['TradeType'],
        curve=row['hpcurve'],
        period=row['hpperiod_aged'],
        ticker=row['cticker_aged'],
        root=row['rticker'],
        stir_as_swap=stir_as_swap
    ), axis=1)

    d['as_swap'] = d.apply(lambda row: get_as_swap(
        instrument=row['TradeType'],
        stir_as_swap=stir_as_swap
    ), axis=1)

    d_ = d.query('Category == "rates"').groupby(['Strategy', 'string', 'string_aged'])['delta_rate'].sum().reset_index()
    d_ = d_.loc[~d_['delta_rate'].between(-delta_tol, delta_tol), :]
    d_['Strategy'] = d_['Strategy'].str.split(':', n=1).str[1:].str[0].str.replace(' ', '_').str.lower()
    d_['delta_rate'] = d_['delta_rate'] * delta_mul

    parsed = {}
    round_ = 1
    for index, group in d_.groupby('Strategy'):
        s_base = (group['delta_rate'] / BPV).apply(lambda x: format(x, f'+.{round_}f')) + '*'
        s = f"{' '.join(s_base + group['string'])}"
        sa = f"{' '.join(s_base + group['string_aged'])}"
        parsed[index] = s
        parsed[f"{index}A"] = sa

    parsed = pd.Series(parsed, dtype=object)

    if add_ptf:
        ptf = pd.Series(
            [
                ' + '.join(parsed.index[[*range(0, len(parsed), 2)]]),
                ' + '.join(parsed.index[[*range(1, len(parsed), 2)]])
            ],
            index=['ptf', 'ptfA']
        )
        parsed = pd.concat([parsed, ptf])
    if aged_bottom:
        order = [*parsed.loc[~parsed.index.str.endswith('A')].index, *parsed.loc[parsed.index.str.endswith('A')].index]
        parsed = parsed.loc[order]

    parsed.to_clipboard(header=False)

    return d, parsed.rename('expression').rename_axis('strategy')
