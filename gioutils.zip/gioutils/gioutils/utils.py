import base64
import logging
import pickle
import shelve
import threading
import time
import re
from pathlib import Path
from functools import partial, wraps
from time import sleep
from threading import Thread, Event

import numpy as np
import pandas as pd
import dataframe_image as dfi
from pandas.tseries.offsets import BDay
from inflection import underscore


period_mapping = {
    'd': 'days',
    'b': pd.tseries.offsets.BDay,
    'w': 'weeks',
    'm': 'months',
    'y': 'years',
    'ytd': pd.tseries.offsets.YearBegin(),
    'start of year': pd.tseries.offsets.YearBegin()
}

future_expiry_month_codes = {
    1: 'F',
    2: 'G',
    3: 'H',
    4: 'J',
    5: 'K',
    6: 'M',
    7: 'N',
    8: 'Q',
    9: 'U',
    10: 'V',
    11: 'X',
    12: 'Z',
    'F': 1,
    'G': 2,
    'H': 3,
    'J': 4,
    'K': 5,
    'M': 6,
    'N': 7,
    'Q': 8,
    'U': 9,
    'V': 10,
    'X': 11,
    'Z': 12
}


def add_pcs(securities, source, sep=None):
    sep = sep or '@'
    if isinstance(securities, str):
        securities = [securities]
    new_sec = []
    for sec in securities:
        split = sec.rsplit(' ', 1)
        if len(split) > 1:
            root, yellow_key = sec.rsplit(' ', 1)
            new_sec.append(f"{root}{sep}{source} {yellow_key}")
        else:
            new_sec.append(f"{split[0]}{sep}{source}")

    return new_sec if len(new_sec) > 1 else new_sec[0]


def make_id(securities, type=None):
    if isinstance(securities, str):
        securities = [securities]

    res = [f'/{type}/{sec}' for sec in securities]
    if len(res) == 1:
        res = res[0]
    return res


def parse_tenor(tenor, key='tenor'):
    fn = lambda tenor: f"{tenor:.0f}Y" if tenor > 1 else f"{int(12 * tenor):.0f}M"
    if isinstance(tenor, pd.DataFrame):
        return tenor.assign(tenor=tenor[key].map(fn))
    elif isinstance(tenor, pd.Series):
        return tenor.map(fn)
    elif isinstance(tenor, str):
        return fn(tenor)
    else:
        raise TypeError(f'Only str, DataFrame od Series are allowed, got object of type {type(tenor)} instead')


def apply_function(res, fields=None):
    # assumes the fields have already been renamed
    for field in fields:
        fn = field.get('fn')
        if fn and field['name'] in res:
            res[field['name']] = fn(res[field['name']])

    return res


def get_securities(securities, id_type=None, pcs=None, sep=None):
    id_type = id_type or ''
    if pcs:
        if id_type.lower() == 'isin':
            _sep = '@'
        else:
            _sep = ' '

        sep = sep or _sep
        securities = add_pcs(securities, source=pcs, sep=sep)

    return [f'/{id_type}/{sec}' for sec in securities] if id_type else securities


def unparse_securities(securities, pcs=None, sep=None, id_type=None):
    securities = pd.Series(securities)
    if pcs:
        sep = sep or ' '
        securities = securities.str.replace(f'{sep}{pcs}', '')
    if id_type:
        securities.str.replace(f'/{id_type}/', '')
    return securities.to_list()


def unparse_results_securities(res, pcs, sep, id_type=None):
    return res.assign(security=unparse_securities(res['security'], pcs=pcs, sep=sep, id_type=id_type))


def parse_offset(s, b=False):
    try:
        d = pd.to_datetime(s)
        return d if not b else get_bday(d)
    except:
        pass

    pattern = re.compile(r'(\d+)([A-Za-z]+)')
    match = pattern.match(s)
    try:
        n, period = match.groups()
    except (ValueError, AttributeError):
        period = s

    key = period_mapping[period.lower()]
    if b and key == 'days':
        return pd.tseries.offsets.BDay(int(n))

    if period.lower() in ['b']:
        return key(int(n))

    if isinstance(key, str):
        return pd.tseries.offsets.DateOffset(**{key: int(n)})
    else:
        return key


def get_bday(date, previous=True):
    return date - BDay() + BDay() if not previous else date + BDay() - BDay()


def today():
    return pd.Timestamp.today().floor('d')


def date_from_offset(date=None, offset=None, previous=False, b=False):
    date = date or today()
    return date + ((-1 if previous else 1) * parse_offset(offset, b=b))


def get_counter():
    class Counter:
        _id = 0

        @classmethod
        def get_id(cls):
            cls._id += 1
            return cls._id

    return Counter



def get_previous_monday(date):
    return date if not date.weekday() else date - pd.tseries.offsets.DateOffset(days=date.weekday())


def get_expiry_from_n(n=1, date=None, mult=3, settle=False):
    date = date or pd.Timestamp.today().floor('d')
    month = date.month
    temp = mult * (month // mult + 1) if month % mult else month

    temp_expiry = pd.Timestamp(year=date.year, month=temp, day=19)
    expiry = get_previous_monday(temp_expiry)

    if date >= expiry:
        expiry = get_previous_monday(expiry + pd.tseries.offsets.DateOffset(months=3))
    else:
        expiry = expiry

    if n > 1:
        expiry = get_previous_monday(expiry + pd.tseries.offsets.DateOffset(months=3 * (n - 1)))
    if settle:
        expiry = expiry + pd.tseries.offsets.BDay(2)

    return expiry


def get_expiry_from_code(code, date=None, settle=True):
    '''
    given a code for example H3 it returns the expiry of the future contract
    '''
    date = date or pd.Timestamp.today().floor('d')
    m, y = code[0], code[1]
    year = date.year
    yr_str = str(year)

    if int(yr_str[-1]) <= int(y):
        y_ = f"{yr_str[:-1]}{y}"
    else:
        y_ = f"{yr_str[:2]}{int(yr_str[2] + 1)}{y}"

    y_ = int(y_)
    expiry = get_previous_monday(pd.Timestamp(year=y_, month=future_expiry_month_codes.get(m), day=19))
    if settle:
        expiry = expiry + pd.tseries.offsets.BDay(2)
    return expiry


def get_n_from_code(code, date=None):
    '''
    given a code for example Z3 it returns a number saying which contract is. E.g. 1 means first contract
    '''
    n = 1
    while True:
        res = get_next_n([n], date=date)[0]
        if res.lower() == code.lower():
            return n
        n += 1


def get_next_n(n=None, date=None, bbg=True):
    '''
    given a list of n it returns the specific contract. E.g. 1 returns Z2
    '''
    n = n or 1
    rng = range(1, n + 1) if isinstance(n, int) else n
    exps = [get_expiry_from_n(i, date=date) for i in rng]

    res = [f"{future_expiry_month_codes[exp.month]}{exp:%y}" for exp in exps] if not bbg else \
        [f"{future_expiry_month_codes[exp.month]}{str(exp.year)[-1]}" for exp in exps]
    return res


def parse_dates(start_date=None, end_date=None, history=None):
    if start_date:
        start_date = pd.to_datetime(start_date)
    if end_date:
        end_date = pd.to_datetime(end_date)

    if not any([start_date, end_date, history]):
        end_date = get_bday(today())
        start_date = end_date - parse_offset('1y')
    elif history and start_date:
        end_date = start_date + parse_offset(history)
    elif history and end_date:
        start_date = end_date - parse_offset(history)
    elif history and not any([start_date, end_date]):
        end_date = get_bday(today())
        start_date = end_date - parse_offset(history)
    return start_date, end_date


def parse_swap_period(start_date=None, end_date=None, age=None, date=None):
    date = pd.to_datetime(date) if date else today()

    if isinstance(start_date, str):
        start_date = today() + parse_offset(start_date)
    if isinstance(end_date, str):
        end_date = start_date + parse_offset(end_date)

    end_date = end_date or (date + parse_offset(age) if age else date)
    start = np.abs(int(np.round(((start_date - end_date).days / 30.5))))
    if not start % 12:
        return f'{start // 12}y'
    else:
        return f"{start}m"


def parse_swap_periods(start_date, end_date, sep='x', age=None, date=None):
    start = parse_swap_period(start_date=start_date, age=age, date=date)
    tail = parse_swap_period(start_date=start_date, end_date=end_date, date=date)
    return f"{start}{sep}{tail}" if int(start[0]) else tail


def parse_swap_tenor_expr(expr):
    '''
    :param expr: it can be a string like '2yx3y' or a date
    :return:
    '''
    effofwd = expr.lower().split('x')[0]
    try:
        mtyortenor = expr.lower().split('x')[1]
    except IndexError:
        effofwd, mtyortenor = None, effofwd
    if effofwd and len(effofwd) > 4:
        effofwd = pd.to_datetime(effofwd)
    if len(mtyortenor) > 4:
        mtyortenor = pd.to_datetime(mtyortenor)

    return effofwd, mtyortenor


def age_swap_expr(expr):
    pattern = re.compile(r' (\d+[my])(x\d+[my])*', re.IGNORECASE)
    src = pattern.search(expr)
    forward_start, tenor = src.groups()
    start_aged = parse_swap_period(forward_start, age='3m')
    return expr.replace(forward_start, start_aged)


class RepeatedTimer:
    def __init__(self, function, interval):
        self._timer = None
        self.interval = interval
        self.function = function
        self.is_running = False

    def _run(self, *args, **kwargs):
        self.is_running = False
        self.start()
        self.function(*args, **kwargs)

    def start(self, *args, **kwargs):
        if not self.is_running:
            if hasattr(self, 'next_call'):
                self.next_call += self.interval
            else:
                self.next_call = time.time()
            self._timer = threading.Timer(parse_time(self.next_call - time.time()), partial(self._run, *args, **kwargs))
            self._timer.start()
            self.is_running = True

    def stop(self):
        self._timer.cancel()
        self.is_running = False


unit_mult = {
    's': 1,
    'm': 60
}


def parse_time(value):
    if isinstance(value, str):
        value, unit = float(value[:-1]), value[-1]
        value = value * unit_mult[unit]
    return int(value)


def repeat_in_thread(time, event, verbose=True, raise_error=False):
    def decorator(fn):
        def wrapper(*args, **kwargs):
            i = 0
            res = []
            if verbose:
                logging.warning('STARTING execution in thread')
            while True:
                if event.is_set():
                    if verbose:
                        logging.warning('STOPPING execution in thread')
                    break
                if verbose:
                    logging.warning(f'ITERATION {i}')
                try:
                    res_ = fn(*args, **kwargs)
                    res.append(res_)
                except Exception as e:
                    if raise_error:
                        raise e
                    else:
                        pass
                i += 1
                sleep(parse_time(time))
            return res
        return wrapper
    return decorator


class RepeatedTimerThread:
    def __init__(self, function, interval, verbose=True):
        self.interval = interval
        self.function = function
        self.is_running = False
        self.verbose = verbose

    def start(self, *args, **kwargs):
        self.event = Event()
        self.thread = Thread(
            target=repeat_in_thread(time=self.interval, event=self.event, verbose=self.verbose)(self.function))
        self.thread.start()
        self.is_running = True

    def stop(self):
        self.event.set()
        self.is_running = False


def get_bbg_fut_chain_ticker(
    fut,
    roll='r',
    adj='d',
    days=0,
    months=0,
    yk='comdty'
):
    '''

    :param fut: str
    :param roll: str
        B = Bloomberg Default
        R = Relative to Expiration
        F = Fixed Day of Month
        A = With Active Future
        N = Relative to First Notice
        D = At First Delivery
        O = At option expiration

    :param adj: str
        N = None
        D = Difference
        R = Ratio
        W = Average

    :param days:
    :param months:
    :param yk: str
    :return:
    '''

    if not adj:
        adj = 'n'

    if not yk:
        fut, yk = fut.split(' ', 1)
        fut = fut.strip()
        yk = yk.strip()

    return f"{fut.upper()} {roll.upper()}:{days:02d}_{months:1d}_{adj.upper()} {yk.title()}"


def get_xy(X, y, diff=False, history=None, freq=False):
    if diff:
        X = X.diff().dropna()
        y = y.diff().dropna()
    if history:
        X = X.loc[X.index[-1] - parse_offset(history):, :]
        y = y.loc[y.index[-1] - parse_offset(history):]
    df_reg = pd.concat([X, y], axis=1).ffill()
    if freq:
        df_reg = df_reg.resample(freq).last().ffill()
    return df_reg.iloc[:, :-1], df_reg.iloc[:, -1]


def log_time(logger=None):
    logger = logger or logging
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            start = pd.Timestamp.now()
            res = fn(*args, **kwargs)
            finish = pd.Timestamp.now()
            log = elapsed_time(start, finish)
            log = f"function \"{fn.__name__}\" from module \"{fn.__module__}\" took {log} to execute"
            logging.warning(log)
            return res
        return wrapper
    return decorator


def elapsed_time(start, finish):
    t = (finish - start)
    seconds = t.seconds
    minutes = seconds // 60
    hours = minutes // 60
    string = f'{f"{hours} hours, " if hours else ""}{f"{minutes} minutes, " if minutes else ""}{f"{seconds} seconds" if seconds else ""}'
    return string


def _get_future_tickers(tickers, yk='comdty'):
    if isinstance(tickers, str):
        tickers = [tickers]
    tickers = pd.Series(tickers)
    tickers = tickers.str.lower()
    tickers = tickers.str.replace(yk.lower(), '').str.strip()
    return tickers


def get_root(tickers):
    tickers = _get_future_tickers(tickers)
    return tickers.str[:-2].to_list()


def get_generic_future(tickers, lookup=36, yk='comdty', bq=None):
    field = "FUT_CUR_GEN_TICKER"
    tickers = _get_future_tickers(tickers, yk=yk)
    roots = get_root(tickers)
    chain = bq.bdp([f"{root}{i}".upper() + f' {yk.title()}' for root in roots for i in range(1, lookup + 1)], field)
    chain = chain.set_index(field).squeeze()
    return [*chain.loc[tickers.str.upper()]]


def get_specific_future(tickers, yk='comdty', bq=None):
    field = "FUT_CUR_GEN_TICKER"
    tickers = _get_future_tickers(tickers)
    return (bq.bdp(tickers.str.upper() + f' {yk.title()}', field)[field] + f' {yk.title()}').to_list()


def to_shelve(obj, db_path, key, **kwargs):
    with shelve.open(db_path, **kwargs) as db:
        db[key] = obj


def read_shelve(db_path, key, **kwargs):
    with shelve.open(db_path, **kwargs) as db:
        return db[key]


def read_pickle(filename, **kwargs):
    with open(filename, 'rb') as handle:
        obj = pickle.load(handle, **kwargs)
    return obj


def to_pickle(obj, filename, **kwargs):
    with open(filename, 'wb') as handle:
        pickle.dump(obj, handle, protocol=pickle.HIGHEST_PROTOCOL, **kwargs)


def read_history_plotter_ts(columns=None, resample='B'):

    df = pd.read_clipboard(header=None).dropna(axis=1, how='all')
    res = []

    for j, i in enumerate(range(0, df.shape[1], 2)):
        df_ = df.iloc[:, i:i+2]
        df_ = df_.dropna().set_index(df_.columns[0]).rename_axis('date')
        df_ = df_.set_axis(pd.to_datetime(df_.index))
        res.append(df_)

    res = pd.concat(res, axis=1).ffill()
    if columns:
        res = res.set_axis(columns, axis=1)
    else:
        res = res.set_axis(range(res.shape[1]), axis=1)
    if resample:
        res = res.resample(resample).asfreq()
    return res


def encode_df_as_image_tag(df, file_name=None, delete_after=True, **kwargs):
    max_cols = kwargs.pop('max_cols', -1)
    table_conversion = kwargs.pop('table_conversion', 'chrome')
    if not file_name:
        file_name = f"df_{pd.Timestamp.now():%d%b%Y_%H%M%S}"
    file_name_ = f"{file_name}.png"
    dfi.export(df, file_name_, max_cols=max_cols, table_conversion=table_conversion, **kwargs)
    image_data = open(file_name_, 'rb').read()
    encoded_image = base64.b64encode(image_data).decode("utf-8")
    tag = f'<img src = "data:image/png;base64,{encoded_image}"/>'
    if delete_after:
        Path(file_name_).unlink(True)
        res = tag
    else:
        print(True)
        res = tag, file_name_
    return res


def encode_plotly_fig_as_image_tag(fig, **kwargs):
    image_data = fig.to_image(format='png', **kwargs)
    encoded_image = base64.b64encode(image_data).decode("utf-8")
    tag = f'<img src = "data:image/png;base64,{encoded_image}"/>'
    return tag


def filter_high_corr_with_y(df, threshold=0.8, y_col='y'):
    corr = df.corr()

    melt_corr = corr.drop(y_col, axis=1).drop(y_col).melt(ignore_index=False).reset_index()
    melt_corr = melt_corr.loc[melt_corr['variable'] != melt_corr['index']]

    indices = []
    len_corr = len(corr) - 1  # excluding y
    for i in range(len_corr):
        l = len_corr - 1
        start = i * l + i
        end = i * l + l
        indices.extend([*range(start, end)])
    unique_corr = melt_corr.iloc[indices]

    filtered_corr = unique_corr.loc[unique_corr['value'].abs() > threshold]
    drop = []

    for index, row in filtered_corr.iterrows():
        if abs(corr.loc[y_col, row['index']]) > abs(corr.loc[y_col, row['variable']]):
            drop.append(row['variable'])
        else:
            drop.append(row['index'])

    return df.drop(drop, axis=1)


def filter_high_corr(df, scores, threshold=0.8, return_df=True):
    corr = df.rename_axis(None, axis=1).corr()
    melt_corr = corr.melt(ignore_index=False).reset_index()
    melt_corr = melt_corr.loc[melt_corr['variable'] != melt_corr['index']]
    indices = []
    len_corr = len(corr)

    for i in range(len_corr):
        l = len_corr - 1
        start = i * l + i
        end = i * l + l
        indices.extend([*range(start, end)])

    unique_corr = melt_corr.iloc[indices]
    filtered_corr = unique_corr.loc[unique_corr['value'].abs() > threshold]

    drop = []
    for index, row in filtered_corr.iterrows():
        if scores[row['index']] >= scores[row['variable']]:
            drop.append(row['variable'])
        else:
            drop.append(row['index'])
    return df.drop(drop, axis=1) if return_df else df.drop(drop, axis=1).columns


def bbg_stir_to_clarion(code, date=None):
    date = date or pd.Timestamp.now()
    year = str(date.year)[-2]
    return f"{code[:-1]}{year}{code[-1]}"


from scipy.stats.mstats import winsorize


def get_df_reg(X, y, diff=False, history=None, standardize=False, winsor=None):
    if isinstance(X, pd.Series):
        X = X.to_frame()
    if diff:
        X = X.diff().dropna()
        y = y.diff().dropna()
    if history:
        X = X.loc[X.index[-1] - parse_offset(history):, :]
        y = y.loc[y.index[-1] - parse_offset(history):]
    df_reg = pd.concat([X, y], axis=1).ffill().dropna()

    if winsor:
        df_reg = pd.DataFrame(winsorize(df_reg.to_numpy(), axis=0, limits=winsor), index=df_reg.index,
                              columns=df_reg.columns)

    if standardize:
        df_reg = df_reg.subtract(df_reg.mean(axis=1), axis=0).div(df_reg.std(axis=1), axis=0)

    return df_reg


mid_curve_map = {
    'sfr': [
        # 'sra',
        # 'srr',
        # 'srw',
        '0q',
        '2q',
        '3q',
        '4q',
    ],
    'er': [
        '0r',
        '2r',
        '3r',
        '4r'
    ]
}

fixing_map = {
    'sfr': 'SOFRRATE Index',
    'er': 'EUR003M Index'
}


def get_underlying_ticker(underlying, contract, yk=None):
    yk = yk or 'Comdty'
    return f"{underlying.upper()}{contract.upper() if isinstance(contract, str) else contract} {yk.title()}"


def get_fut_chain(underlying, bq, contracts=None, yk=None):
    contracts = contracts or range(1, 16 + 1)
    yk = yk or 'Comdty'
    securities = [get_underlying_ticker(underlying, contract, yk) for contract in contracts]
    tickers = [*(bq.bdp(securities, {"FUT_CUR_GEN_TICKER": 'ticker'})['ticker'] + ' ' + yk)]
    ticker_map = {contract: ticker for contract, ticker in zip(contracts, tickers)}
    prices = bq.bdp([fixing_map[underlying], *tickers], {"px_last": 'price', "LAST_TRADEABLE_DT": 'expiry'})
    prices.loc[prices['security'] == fixing_map[underlying], 'expiry'] = today()
    prices.loc[prices['security'] == fixing_map[underlying], 'price'] = 100 - prices.loc[prices['security'] == fixing_map[underlying], 'price']
    days = (prices['expiry'] - today()).dt.days
    prices['days'] = days
    return prices


def get_opt_chain_and_info(underlying, bq):
    chain_ = bq.bds(underlying, 'OPT_CHAIN')
    if chain_.empty:
        return
    chain_ = chain_.squeeze().rename('chain')
    chain = chain_.str.replace(r'\s+', ' ', regex=True).str.split(' ')
    chain = pd.DataFrame.from_dict(dict(zip(chain.index, chain.values))).T.set_axis(['code', 'strike', 'yk'], axis=1)
    chain['call_put'] = chain['code'].str[-1]
    chain['code'] = chain['code'].str[:-1]
    chain['strike'] = chain['strike'].astype(float)
    chain['orig'] = chain_

    opt_chain = chain.drop_duplicates('code').set_index('code')['orig']
    opt_expiry = bq.bdp(opt_chain, {'LAST_TRADEABLE_DT': 'expiry'}).rename({'security': 'orig'}, axis=1)

    def get_strike_increment(df):
        return df['strike'].head(2).diff().dropna().squeeze()

    increments = chain.groupby('code', sort=False).apply(get_strike_increment).rename('inc')
    opt_info = opt_expiry.merge(opt_chain.reset_index(), on='orig').merge(increments, on='code')

    return chain, opt_info


def update_recursively(dict1, dict2):
    for key, value in dict2.items():
        if isinstance(value, dict):
            dict1[key] = update_recursively(dict1.get(key, {}), value)
        else:
            dict1[key] = value
    return dict1