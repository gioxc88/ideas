import logging
from functools import cache
from uuid import uuid4

import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay

from . import giobhutils as bh
from .utils import parse_offset, today, get_bday


def date_to_xl(date=None):
    if not date:
        return
    return (pd.to_datetime(date) - pd.Timestamp("1900-01-01")).days + 2


_sa = 'SQLP1-A'
_sb = 'SQLP1-B'
_sc = 'SQLP1-C'
_s2a = 'SQLP2-A'


def get_irbt_server_query(db=None):
    db = db or SQL.FITradePricer.server
    return f"SELECT [value] FROM Config WHERE name='{db}.RemoteServer'"


class Counter:
    _id = 0

    @classmethod
    def get_id(cls):
        cls._id += 1
        return cls._id


class SQL:
    class Snap:
        server = _sb
        db = 'Snap'

    class Quants:
        server = _sa
        db = 'Quants'

    class Curves:
        server = _sa
        db = 'Curves'

    class Products:
        server = _sa
        db = 'Products'

    class TradeReporter:
        server = _sa
        db = 'TradeReporter'

    class Histories:
        server = _sa
        db = 'Histories'

    class MurexData:
        server = _sb
        db = 'MurexData'

    class Ticks:
        server = _sb
        db = 'Ticks'

    class SVM:
        server = _sa
        db = 'SVM'

    class FITradePricer:
        server = _s2a
        db = 'FITradePricer'

    class RiskVar:
        server = _sc
        db = 'RiskVar'

    class IRBTServer:
        port = 5557

        @classmethod
        @property
        def server(cls):
            h = bh.bhDbReadSql(
                uuid4().hex,
                SQL.FITradePricer.server,
                SQL.FITradePricer.db,
                get_irbt_server_query(),
                addspaces=True
            )
            # return bh.bhDbGetValues(h, 0).squeeze()[()]
            return h.py

    class RiskReporterLite:
        server = _sa
        db = 'riskreporterlite'


class BHStatic:
    def __init__(self, name=None):
        bh.bhInit(name or uuid4().hex)
        self.static()

    def static(self):
        mkt_defs = bh.bhDbMktDefs(
            name="LiveCurves",
            dbserver=SQL.Quants.server,
            dbname=SQL.Quants.db
        )

        fx_mkt_defs = bh.bhDbFxMktDefs(
            name="VolWeightedDay",
            dbserver=SQL.Quants.server,
            dbname=SQL.Quants.db,
        )

        ccy_cals = bh.bhDbCalendars(
            name="CURRENCY",
            dbserver=SQL.Quants.server,
            dbname=SQL.Quants.db,
            usenull=True,
        )

        mx_cals = bh.bhDbCalendars(
            name="MUREX",
            dbserver=SQL.Quants.server,
            dbname=SQL.Quants.db,
            usenull=True,
        )

        ccy_cals_prov_db = bh.bhCalendarProviderDb(
            calprov=ccy_cals,
            namecol="Currency",
            calcol="Calendar"
        )

        mx_cals_prov_db = bh.bhCalendarProviderDb(
            calprov=mx_cals,
            namecol="Currency",
            calcol="Calendar"
        )

        mtg_dts = bh.bhFiReadMeetingDates(
            quantsdb=SQL.Quants.db,
            quantsserver=SQL.Quants.server,
        )

        gens = bh.bhFiReadGenerators(
            quantsdb=SQL.Quants.db,
            quantsserver=SQL.Quants.server,
            cals=mx_cals,
            asof=get_bday(today())
        )

        mm_crv_config = bh.bhMMLoadCurveConfig(
            quantsserver=SQL.Quants.server,
            quantsname=SQL.Quants.db,
            rrlserver=SQL.RiskReporterLite.server,
            rrlname=SQL.RiskReporterLite.server
        )

        gens_factory = bh.bhFiCreateTradesGeneratorsFactory(generators=gens)

        self.mkt_defs = mkt_defs
        self.fx_mkt_defs = fx_mkt_defs
        self.ccy_cals = ccy_cals
        self.mx_cals = mx_cals
        self.ccy_cals_prov_db = ccy_cals_prov_db
        self.mx_cals_prov_db = mx_cals_prov_db
        self.mtg_dts = mtg_dts
        self.gens = gens
        self.mm_crv_config = mm_crv_config
        self.gens_factory = gens_factory


bhs = BHStatic()


def get_generators(ccys=None):
    query = 'SELECT NAME FROM uvw_staticSwap'

    if isinstance(ccys, str):
        ccys = [ccys]
    if isinstance(ccys, list):
        ccys = tuple([ccy.upper() for ccy in ccys])
    if ccys and len(ccys) == 1:
        ccys = f"('{ccys[0].upper()}')"
    if ccys:
        query = f"{query}{chr(10)}WHERE Ccy1 IN {ccys}"

    res = bh.bhDbReadSql(
        rsid=get_id(),
        sqlserver=SQL.Quants.server,
        sqldatabase=SQL.Quants.db,
        sqlquery=query,
        fractiondates=None,
        timeout=None,
        addspaces=None,
        setnullstonas=True,
    )
    return res.py


def get_curves(ccys=None):
    query = 'SELECT Name FROM uvw_cfgCurve'

    if isinstance(ccys, str):
        ccys = [ccys]
    if isinstance(ccys, list):
        ccys = tuple([ccy.upper() for ccy in ccys])
    if len(ccys) == 1:
        ccys = f"('{ccys[0].upper()}')"
    if ccys:
        query = f"{query}{chr(10)}WHERE Currency IN {ccys}"

    res = bh.bhDbReadSql(
        rsid=get_id(),
        sqlserver=SQL.Curves.server,
        sqldatabase=SQL.Curves.db,
        sqlquery=query,
        fractiondates=None,
        timeout=None,
        addspaces=None,
        setnullstonas=True,
    )
    return res.py


bh_cash_settle_map = {
    'c': 'Cash',
    'cp': 'CashZC',
    'p': 'Physical',
    'pc': 'PhysicalCleared',
}

bh_metric_map = {
    '31.1': 'PV',
    'fwdpremium': 'Premium',
    'spotpremcent': 'PV',
    'bpvol': 'Vol'
}

bh_metric_scaling = {
    'pv': 0.001,
    'strike': 100,
    'rate': 100,
    'spotpremium': 0.001,
    'fwdpremium': -0.001,
    'vol': 100,
    'bpvol': 10000 * 252 ** -0.5,
    'ann01': 1,
    'spotpremcent': 0.01,
}

bh_remote_db_columns = {
    'TradeId': 'int',
    'ccy': 'string',
    'SVMInstrument': 'string',
    # 'GeneratorInput': 'string',
    'EffExp': 'string',
    # 'MtyTnrIn': 'string',
    'Strike': 'string',
    'StrikeTerm': 'string',
    'PayoutType': 'string',
    'SwaptionSettleTypeIn': 'string',
    'ForwardSettled': 'int',
    'Nominal': 'double',
    'FwdTenor': 'string',
    'ForceCapToImm': 'int',
    'Generator': 'string',
    'MtyTnr': 'string',
    'StrikeDate': 'date',
    'SwaptionSettleType': 'string',
    'PaySettleType': 'string',
    'TradeLabel': 'string',
    'UnderlyingClearingHouse': 'string',
    'CollateralCcy': 'string',
}


def parse_expr(expr):
    expr = expr.replace('[', '').replace(']', '')
    split = expr.split(' ')
    instrument = split[0]
    curve_name = split[1]
    period = split[2]

    return instrument, curve_name, period


def parse_period(period):
    split = period.split('x')
    if len(split) == 1:
        split = (None, split[0])
    return split


def parse_dates(start_date=None, end_date=None, history=None):
    if not any([start_date, end_date, history]):
        end_date = get_bday(today())
        start_date = end_date - parse_offset('1y')
    elif history and start_date:
        end_date = start_date + parse_offset(history)
    elif history and end_date:
        start_date = end_date - parse_offset(history)
    elif history and not any([start_date, end_date]):
        end_date = get_bday(today())
        start_date = end_date - parse_offset(history)
    return start_date, end_date


def bh_get_swap_ts(
        expr=None,
        period=None,
        curve_name=None,
        forward_start=None,
        tenor=None,
        start_date=None,
        end_date=None,
        history=None,
):

    if expr:
        instrument, curve_name, period = parse_expr(expr)
    if period:
        forward_start, tenor = parse_period(period)

    start_date, end_date = parse_dates(start_date=start_date, end_date=end_date, history=history)
    _curvename = f"{curve_name.upper()}.STD" if all(i not in curve_name for i in [
        "sofr",
        "ois",
        'ester',
        'dyencalm',
        'sonia'
    ]) else curve_name.upper()

    dbh = bh.bhReadMergedTsCurves(
        dbhandle='dbtest',
        tscrvhandle='crv1',
        startdate=date_to_xl(start_date - pd.tseries.offsets.Day(504)),
        enddate=date_to_xl(end_date),
        market="COB_COMPLETE",
        curvename=_curvename,
        source="CRV",
        category="O",
        _class="BHCURVE",
        curvesdbname=SQL.Curves.db,
        curvesdbserver=SQL.Curves.server,
        histdbname=SQL.Histories.db,
        histdbserver=SQL.Histories.server,
    )

    calendar = bh.bhDbLookUp(
        bhs.ccy_cals_prov_db,
        curve_name[:3].upper(),
        "Currency",
        "Calendar",
        0
    )

    # crvh = bh.bhDbGetColValues(rsid=dbh, columns="TsCurve")[0][0] it was like this before I don't remember why
    crvh = bh.bhDbGetColValues(rsid=dbh, columns="TsCurve")

    _type = "sw" if (start_date + parse_offset(tenor) - start_date).days > 360 else "dp"
    _ccy = f"{curve_name[:3].upper()}.STD" if all(i not in curve_name for i in [
        "sofr",
        "ois",
        'ester',
        'dyencalm',
        'sonia'
    ]) else curve_name.upper()


    rates_ts = bh.bhTsRate(
        tsid='ts1',
        crvstsid=crvh,
        efforfwd=forward_start.upper() if forward_start else None,
        mtyortenor=tenor.upper(),
        type=_type,
        ccy=_ccy,
        mktdefs=bhs.mkt_defs,
        calprovider=calendar,
        leavemtyflag=1
    )

    try:
        ts = pd.Series(
            bh.bhTsGet(
                tsid=rates_ts,
                outputtype="v",
                start=date_to_xl(start_date),
                end=date_to_xl(end_date)
            ),
            index=bh.bhTsGet(
                tsid=rates_ts,
                outputtype="d",
                start=date_to_xl(start_date),
                end=date_to_xl(end_date)
            ),
            dtype='float'
        )
    except Exception as e:
        print(
            expr,
            period,
            curve_name,
            _curvename,
            _ccy,
            forward_start,
            tenor,
            start_date,
            end_date,
            history,
        )
        
        print(bh.bhTsGet(
            tsid=rates_ts,
            outputtype="v",
            start=date_to_xl(start_date),
            end=date_to_xl(end_date)
        ))
        return None
    return ts.rename(f"s {curve_name.lower()} {f'{forward_start.lower()}x' if forward_start else ''}{tenor.lower()}")


def bh_get_ts(expr, **kwargs):

    instrument = expr.split(' ', 1)[0]
    if instrument.lower().strip() == 's':
        return bh_get_swap_ts(expr=expr, **{key: val for key, val in kwargs.items() if key != 'bq'})
    elif instrument.lower().strip() == 'bbg':
        return bh_get_bbg_ts(expr, **kwargs)


def bh_get_bbg_ts(
        expr,
        bq,
        start_date=None,
        end_date=None,
        history=None
):
    comps = expr.split(' ')[1:]
    comps = [comp.strip() for comp in comps]
    if len(comps) == 2:
        ticker, yk, field = [*comps, 'px_last']
    else:
        ticker, yk, field = comps
    start_date, end_date = parse_dates(start_date=start_date, end_date=end_date, history=history)

    res = bq.bdh(
        securities=f"{ticker} {yk}",
        fields=field,
        start_date=start_date,
        end_date=end_date,
        pivot=True,
    ).squeeze().rename(expr)

    return res


def ensure_series(data):
    if isinstance(data, np.ndarray):
        data = pd.DataFrame(data)
        return data.squeeze(axis=1)
    elif isinstance(data, pd.Series):
        return data
    else:  # assuming is number datetime or string
        return pd.Series(data)


def tsh_to_series(tsh):
    return ensure_series(bh.bhTsGet(tsh, "v"))\
        .set_axis(pd.to_datetime(ensure_series(bh.bhTsGet(tsh, "d"))))\
        .infer_objects()\
        .rename_axis('date')


def get_null():
    return None


def parse_ccy(ccy):
    return ccy.upper()


def parse_instrument(instrument):
    return instrument.lower()


def parse_generator(generator):
    return generator.upper()


def parse_pay_receive(pay_receive):
    return pay_receive.lower()


def parse_eff_ex_mty_or_tenor(value):
    # if not isinstance(value, str):
    #     try:
    #         value = f"{date_to_xl(value)}"  # f"{value:%Y-%m-%d}"  #
    #     except:
    #         pass
    try:
        value = f"{date_to_xl(value)}"  # f"{value:%Y-%m-%d}"  #
    except:
        pass
    return value


def parse_strike(strike=None):
    return strike or "a"


def parse_tenor_mty(tenor_mty):
    from pandas.errors import ParserError
    try:
        return pd.to_datetime(tenor_mty)
    # except ParserError:
    except Exception as e:
        return tenor_mty.lower()


def parse_atm_fixed_date(atm_fixed_date=None, date=None):
    if not atm_fixed_date:
        return
    atm_fixed_date = parse_tenor_mty(atm_fixed_date)

    if isinstance(atm_fixed_date, pd.Timestamp):
        return atm_fixed_date
    else:
        if not date:
            date = get_bday(today())
        return date - parse_offset('1y')


def parse_metric(metric=None, metric_map=None):
    metric_map = metric_map or bh_metric_map
    return metric_map.get(metric, metric)


def parse_pay_settle_type(metric=None):
    if not metric:
        return 's'
    return 'x' if parse_metric(metric).lower() == 'premium' else 's'


def parse_collateral(collateral=None, ccy=None):
    if not collateral:
        return 'USD'

    if collateral.lower() == 'local' and ccy:
        return ccy.upper()
    else:
        return collateral.upper()


def parse_clearing_house(settle):
    if settle[:2] == 'pc':
        try:
            return settle.split('_')[1].upper()
        except IndexError:
            pass
    return get_null()


def parse_swaptions_settle_type(settle, cash_settle_map=None):
    if not settle:
        return 'Physical'
    cash_settle_map = cash_settle_map or bh_cash_settle_map
    key = settle.split('_')[0].lower()
    return cash_settle_map.get(key)


def get_trade_label(
        ccy=None,
        instrument=None,
        generator=None,
        eff_exp=None,
        tenor_mty=None,
        strike=None,
        atm_fixed_date=None,
        pay_receive=None,
        metric=None
):
    from datetime import datetime, date

    if isinstance(eff_exp, (pd.Timestamp, datetime, date)):
        eff_exp = f"{eff_exp:%Y-%m-%d}"
    if isinstance(tenor_mty, (pd.Timestamp, datetime, date)):
        tenor_mty = f"{tenor_mty:%Y-%m-%d}"

    eff_exp = f' {eff_exp}' if eff_exp else ''
    tenor_mty = f'x{tenor_mty}' if tenor_mty else ''
    strike_fmt = 's' if isinstance(strike, str) else '.4f'
    strike = f' @{strike:{strike_fmt}}' if strike else ''
    atm_fixed_date = parse_atm_fixed_date(atm_fixed_date)
    atm_fixed_date = f' ({atm_fixed_date})' if atm_fixed_date else ''
    metric = f' {metric}' if metric else ''

    label = f"{ccy} {instrument} {generator}{eff_exp}{tenor_mty} {pay_receive}{strike}{atm_fixed_date}{metric}".strip()
    return label


def parse_irb_remote_args(
        trade_id=None,
        ccy=None,
        instrument=None,
        generator=None,
        eff_exp=None,
        tenor_mty=None,
        strike=None,
        atm_fixed_date=None,
        pay_receive=None,
        settle=None,
        collateral=None,
        metric=None,
        nominal=1e6
):
    data = {
        'TradeId': trade_id if trade_id is not None else Counter.get_id(),
        'ccy': parse_ccy(ccy) if ccy else get_null(),
        'SVMInstrument': parse_instrument(instrument) if instrument else get_null(),
        # 'GeneratorInput': parse_generator(generator) if generator else get_null(),
        'EffExp': parse_eff_ex_mty_or_tenor(eff_exp) if eff_exp else get_null(),
        # 'MtyTnrIn': parse_eff_ex_mty_or_tenor(tenor_mty) if tenor_mty else get_null(),
        'Strike': parse_strike(strike) if ccy else get_null(),
        'StrikeTerm': atm_fixed_date if atm_fixed_date else get_null(),
        'PayoutType': parse_pay_receive(pay_receive) if pay_receive else get_null(),
        'SwaptionSettleTypeIn': settle if settle else get_null(),
        'ForwardSettled': get_null(),
        'Nominal': nominal,
        'FwdTenor': get_null(),
        'ForceCapToImm': get_null(),
        'Generator': parse_generator(generator) if generator else get_null(),
        'MtyTnr': parse_eff_ex_mty_or_tenor(parse_tenor_mty(tenor_mty)) if tenor_mty else get_null(),
        'StrikeDate': parse_atm_fixed_date(atm_fixed_date),
        'SwaptionSettleType': get_null() if not settle and instrument.lower() != 'oswp' else parse_swaptions_settle_type(settle),
        'PaySettleType': parse_pay_settle_type(metric) if ccy else get_null(),
        'TradeLabel': get_trade_label(
            ccy=ccy,
            instrument=instrument,
            generator=generator,
            eff_exp=eff_exp,
            tenor_mty=tenor_mty,
            strike=strike,
            atm_fixed_date=atm_fixed_date,
            pay_receive=pay_receive,
            metric=metric
        ),
        'UnderlyingClearingHouse': parse_clearing_house(settle) if settle else get_null(),
        'CollateralCcy':   parse_collateral(collateral, ccy),
    }
    return data


def get_irbt_ts(
        ccy=None,
        instrument=None,
        generator=None,
        eff_exp=None,
        tenor_mty=None,
        strike=None,
        atm_fixed_date=None,
        pay_receive=None,
        settle=None,
        collateral=None,
        metric=None,
        nominal=1e6,
        start_date=None,
        end_date=None,
        history=None,
        scale=False,
):
    data = parse_irb_remote_args(
        ccy=ccy,
        instrument=instrument,
        generator=generator,
        eff_exp=eff_exp,
        tenor_mty=tenor_mty,
        strike=strike,
        atm_fixed_date=atm_fixed_date,
        pay_receive=pay_receive,
        settle=settle,
        collateral=collateral,
        metric=metric,
        nominal=nominal,
    )

    db = bh.bhDbCreate(
        id='irbtremote',
        columnnames=[*bh_remote_db_columns],
        columntype=[*bh_remote_db_columns.values()],
        # remember this has to be a list of lists ow it throws an error saying it can't find the column
        data=[[*data.values()]]
    )

    start_date, end_date = parse_dates(start_date=start_date, end_date=end_date, history=history)
    irbt_metric = parse_metric(metric)

    remote_call = bh.bhTsFiRemoteRiskCalc(
        handle=f"{data['TradeId']}",
        tradesdb=db,
        pblevals=irbt_metric,
        startdate=start_date,
        enddate=end_date,
        irbtdbname=SQL.FITradePricer.db,
        irbtdbsrvname=SQL.FITradePricer.server,
        remoteservername=SQL.IRBTServer.server,
        remoteserverport=SQL.IRBTServer.port,
        timeout=120
    )

    status = bh.bhDbGetColValues(remote_call, "Status")
    try:
        status = status.squeeze()[()]
    except:
        pass

    if isinstance(status, str) and status == "OK":
        remote_db = bh.bhDbLookUp(remote_call, irbt_metric, "Metric", "TS")
    else:
        remote_db = remote_call.py.dropna()['TS']
    try:
        ts_filtered = bh.bhTsFilter(newid=uuid4().hex, tsid=remote_db, filtertype="v")
        # ts = tsh_to_series(ts_filtered).rename(data[-3])

        scale = 1 if not scale else bh_metric_scaling.get(irbt_metric.lower(), 1) if scale is True else scale
        ts_scaled = bh.bhTsCalcM(
            _newid=uuid4().hex,
            _tsids=ts_filtered,
            _calctype="mult",
            _calcarg=float(scale)
        )

        ts = tsh_to_series(ts_scaled).rename(data['TradeLabel'])
        return ts
    except:
        print(status)
        print(data)
        raise ValueError


def get_id(root='ez'):
    return f"{root}_{uuid4().hex}"


def get_sheet_mkt(date=None, mkt='LIVE', **kwargs):
    date = date or get_bday(today())
    try:
        sheet_mkt = bh.bhCreateSheetMarket(
            handle=get_id(),
            mkt=mkt,
            asof=date,
            mktdefs=bhs.mkt_defs,
            calprov=bhs.mx_cals,
            mtgdts=bhs.mtg_dts,
            crvdbsvr=SQL.Curves.server,
            crvdbname=SQL.Curves.db,
            mktdatasvr="localhost",
            mktdataport=60000,
            snapdbsvr=SQL.Snap.server,
            snapdbname=SQL.Snap.db,
            **kwargs
        )
    except TypeError:
        sheet_mkt = bh.bhCreateSheetMarket(
            hdl=get_id(),
            mkt=mkt,
            asof=date,
            mktdefs=bhs.mkt_defs,
            calprov=bhs.mx_cals,
            mtgdts=bhs.mtg_dts,
            crvdbsvr=SQL.Curves.server,
            crvdbnm=SQL.Curves.db,
            mdssvr="localhost",
            mdsport=60000,
            snapdbsvr=SQL.Snap.server,
            snapdbnm=SQL.Snap.db,
            **kwargs
        )
    return sheet_mkt


def parse_date_and_offset(date=None, offset=None, live=True):
    date = get_bday(date) if date else (get_bday(today()) if live else get_bday(today()) - BDay())
    if offset:
        date = get_bday(date - parse_offset(offset))

    return date, offset


class LiveCurvesLocal:
    mkt_name = 'LIVE'
    sheet_mkt_kwargs = {}
    _live = True

    def __init__(self, date=None, curves=None, ccys=None, **kwargs):
        self.ccys = ccys
        self.curves = curves if not ccys else [*get_curves(ccys)]
        self._snap_id = get_id()
        self.build(date, kwargs.get('offset'))

    def build(self, date=None, offset=None):
        date, offset = parse_date_and_offset(date, offset, live=self._live)
        self.date = date
        self.offset = offset
        self.mkt = get_sheet_mkt(date, mkt=self.mkt_name, **self.sheet_mkt_kwargs)
        if hasattr(self, '_cached_snap'):
            delattr(self, '_cached_snap')

    @property
    def mkt_snap(self):
        return bh.bhCurveMarketSnap(
            handle=self._snap_id,
            market=self.mkt,
            curves=self.curves
        )

    @property
    def mkt_snap_db(self):
        return bh.bhCurveMarketSnapAsDb(
            handle=f'{self._snap_id}db',
            marketsnap=self.mkt_snap
        )

    @property
    def mkt_snap_db_curves(self):
        return bh.bhDbLookUp(
            rsid=self.mkt_snap_db,
            lookupvalues=self.mkt_name,
            lookupcols="name",
            returncols="curves"
        )

    def get_snap(self, **kwargs):
        mkt_snap_db = self.mkt_snap_db_curves
        self._cached_snap = mkt_snap_db
        return mkt_snap_db

    @property
    def snap(self):
        return self.get_snap()

    @property
    def cached_snap(self):
        if not hasattr(self, '_cached_snap'):
            self._cached_snap = self.snap
        return self._cached_snap


class LiveInflLocal(LiveCurvesLocal):
    mkt_name = 'LIVE_INFLATION'
    sheet_mkt_kwargs = {
        'snapdbdate': 0,
        'gens': bhs.gens
    }


class LiveCurvesRemote:
    def __init__(self, date=None, curves=None, ccys=None):
        self.date, _ = parse_date_and_offset(date)
        self.ccys = ccys
        self.curves = curves if not ccys else [*get_curves(ccys)]
        self._snap_id = get_id()

        self.mkt = bh.bhCreateCurvesDbMarket(
            handle=get_id(),
            mktname="LIVE",
            asofdate=self.date,
            datadate=self.date,
            mktdefs=bhs.mkt_defs,
            cals=bhs.mx_cals,
            curvesserver=SQL.Curves.server,
            curvesdb=SQL.Curves.db,
        )

    @property
    def mkt_snap(self):
        self._mkt_snap = bh.bhMarketSnap(
            handle=self._snap_id,
            market=self.mkt,
            curves=self.curves
        )
        return self._mkt_snap

    def get_snap(self, **kwargs):
        mkt_snap = self.mkt_snap
        self._cached_snap = mkt_snap
        return mkt_snap

    @property
    def snap(self):
        return self.get_snap()

    @property
    def cached_snap(self):
        if not hasattr(self, '_cached_snap'):
            self._cached_snap = self.snap
        return self._cached_snap


class LiveVolsRemote:
    def __init__(self, date=None, ccys=None, curves=None):
        self.date, _ = parse_date_and_offset(date)
        self.ccys = ccys
        self.curves = curves
        self._snap_id = get_id()

        self.mkt = bh.bhCreateVolsDbMarket(
            hndl=get_id(),
            asof=self.date,
            mxcalprov=bhs.mx_cals,
            mktdefs=bhs.mkt_defs,
            quantsdbname=SQL.Quants.db,
            quantsdbserver=SQL.Quants.server,
            curvesdbname=SQL.Curves.db,
            curvesdbserver=SQL.Curves.server,
            mktccys=ccys,
            buildmcs=False
        )

    def get_mkt_snap(self, curve_snap=None):
        curve_snap = curve_snap or self.curves.snap
        return bh.bhSnapVolMarket(
            hndl=self._snap_id,
            volmkt=self.mkt,
            crvdb=curve_snap,
            ccys=self.ccys
        )

    def get_snap(self, curve_snap=None, **kwargs):
        return self.get_mkt_snap(curve_snap=curve_snap)

    @property
    def snap(self):
        vols = self.get_mkt_snap()
        self._cached_snap = vols
        return vols

    @property
    def cached_snap(self):
        if not hasattr(self, '_cached_snap'):
            self._cached_snap = self.snap
        return self._cached_snap


class COBCurvesRemote:
    mkt_name = 'COB'

    def __init__(self, date=None, curves=None, ccys=None, offset=None):
        self.ccys = ccys
        self.curves = curves if not ccys else [*get_curves(ccys)]
        self.build(date, offset)

    def build(self, date=None, offset=None):
        date, offset = parse_date_and_offset(date=date, offset=offset, live=False)
        self.date = date
        self.offset = offset

        self.mkt = bh.bhCreateCurvesDbMarket(
            handle=f'{get_id()}_{date:%Y%m%d}',
            mktname=self.mkt_name,
            asofdate=date,
            datadate=date,
            mktdefs=bhs.mkt_defs,
            cals=bhs.mx_cals,
            curvesserver=SQL.Curves.server,
            curvesdb=SQL.Curves.db,
            minextraptnr='80y'
        )

        self.mkt_snap_cob = bh.bhMarketSnap(
            handle=f'{get_id()}_{date:%Y%m%d}',
            market=self.mkt,
            curves=self.curves
        )

    def get_snap(self, **kwargs):
        return self.mkt_snap_cob

    @property
    def snap(self):
        return self.mkt_snap_cob


# class COBInflRemote(COBCurvesRemote):
#     mkt_name = 'COB_INFLATION'


class COBInflLocal(LiveInflLocal):
    mkt_name = 'COB_INFLATION'
    sheet_mkt_kwargs = {
        'gens': bhs.gens
    }
    _live = False

    @property
    def snap(self):
        if not hasattr(self, '_cached_snap'):
            self._cached_snap = self.mkt_snap_db_curves
        return self._cached_snap


class COBVolsRemote:
    def __init__(self, date=None, ccys=None, curves=None, offset=None):
        self.curves = curves
        self.ccys = ccys
        self._snap_id = get_id()
        self.build(date, offset)

    def build(self, date=None, offset=None):
        date, offset = parse_date_and_offset(date=date, offset=offset, live=False)
        self.date = date
        self.offset = offset

        self.db_mkt = bh.bhCreateSnapVolMarket(
            hndl=f'{get_id()}_{self.date:%Y%m%d}',
            asof=self.date,
            mxcalprov=bhs.mx_cals,
            mktdefs=bhs.mkt_defs,
            paramsdate=self.date,
            pricesasofdate=self.date,
            runlive=False,
            snapdbname=SQL.Snap.db,
            snapdbsvr=SQL.Snap.server,
            quantsdbname=SQL.Quants.db,
            quantsdbsvr=SQL.Quants.server,
            svmdbname=SQL.SVM.db,
            svmdbsvr=SQL.SVM.server,
            livemktsvr=None,
            livemktport=None,
            mktccys=self.ccys,
            useatmvols=True,
            buildmcs=True,
            atmvolsdt=None,
            mccorrdt=None,
            irradjors=None,
            snapcat=None,
        )

        if self.curves:
            self.get_mkt_snap(self.curves.snap)

    def get_mkt_snap(self, curve_snap=None):
        self.mkt_snap_cob = bh.bhSnapVolMarket(
            hndl=f'{self._snap_id}_{self.date:%Y%m%d}',
            volmkt=self.db_mkt,
            crvdb=curve_snap,
            ccys=self.ccys
        )
        return self.mkt_snap_cob

    def get_snap(self, curve_snap=None, **kwargs):
        if hasattr(self, 'mkt_snap_cob'):
            return self.mkt_snap_cob
        return self.get_mkt_snap(curve_snap=curve_snap)

    @property
    def snap(self):
        return self.mkt_snap_cob


class ZCILSHelper:
    def __init__(self):
        self.data = self.get_data()
        self.idx_mkt_defs = self.create()

    _data = [
        {
            'name': 'EUR.CPTFEMU',
            'Indices': 'CPTFEMU',
            'Ccy': 'EUR',
            'FixingDays': 1,
            'Lag': 3,
            'AdjIndexDays': 0,
            'IndxnRateFreqs': 12,
            'InterpTypes': 'flat',
            'Calendars': 'TARGET'
        },
        {
            'name': 'EUR.FRCPXTOB',
            'Indices': 'FRCPXTOB',
            'Ccy': 'EUR',
            'FixingDays': 1,
            'Lag': 3,
            'AdjIndexDays': 0,
            'IndxnRateFreqs': 12,
            'InterpTypes': 'flat',
            'Calendars': 'TARGET'
        },
        {
            'name': 'GBP.UKRPI',
            'Indices': 'UKRPI',
            'Ccy': 'GBP',
            'FixingDays': 1,
            'Lag': 2,
            'AdjIndexDays': 0,
            'IndxnRateFreqs': 12,
            'InterpTypes': 'flat',
            'Calendars': 'GBP'},
        {
            'name': 'USD.CPURNSA',
            'Indices': 'CPURNSA',
            'Ccy': 'USD',
            'FixingDays': 1,
            'Lag': 3,
            'AdjIndexDays': 0,
            'IndxnRateFreqs': 12,
            'InterpTypes': 'flat',
            'Calendars': 'USD'
        },
        {
            'name': 'EUR.ITCPI',
            'Indices': 'ITCPI',
            'Ccy': 'EUR',
            'FixingDays': 1,
            'Lag': 3,
            'AdjIndexDays': 0,
            'IndxnRateFreqs': 12,
            'InterpTypes': 'flat',
            'Calendars': 'TARGET'
        },
        {
            'name': 'EUR.SPIPC',
            'Indices': 'SPIPC',
            'Ccy': 'EUR',
            'FixingDays': 1,
            'Lag': 3,
            'AdjIndexDays': 0,
            'IndxnRateFreqs': 12,
            'InterpTypes': 'flat',
            'Calendars': 'TARGET'
        },
        {
            'name': 'CAD.CACPI',
            'Indices': 'CACPI',
            'Ccy': 'CAD',
            'FixingDays': 1,
            'Lag': 3,
            'AdjIndexDays': 0,
            'IndxnRateFreqs': 12,
            'InterpTypes': 'flat',
            'Calendars': 'CAD'
        },
        {
            'name': 'JPY.JCPNJGBI',
            'Indices': 'JCPNJGBI',
            'Ccy': 'JPY',
            'FixingDays': 10,
            'Lag': 3,
            'AdjIndexDays': 0,
            'IndxnRateFreqs': 12,
            'InterpTypes': 'flat',
            'Calendars': 'JPY'
        }
    ]

    @classmethod
    def get_data(cls):
        return pd.DataFrame(cls._data)

    @classmethod
    def create(cls):
        data = pd.DataFrame(cls._data)

        idx_defs = bh.bhCreateIndexMktDefs(
            defsid=get_id(),
            indices=data['Indices'],
            lags=data['Lag'],
            interptypes=data['InterpTypes'],
            adjindexdays=data['AdjIndexDays'],
            indxnratefreqs=data['IndxnRateFreqs'],
            fixingdays=data['FixingDays'],
            calendars=data['Calendars'],
        )
        return idx_defs

    def get_params_from_index(self, index, snap):
        data = self.data
        idx_defs = self.idx_mkt_defs
        row = data.query(f'Indices == "{index}"').squeeze(axis=0)
        name = row['name']
        ccy = row['Ccy']
        curve = bh.bhDbLookUp(snap, name, "name", "curve", 0)
        cal = bh.bhCalendarFromProvider(handle=get_id(), calprov=bhs.mx_cals, name=row['Calendars'])

        params = dict(
            idxcrvid=curve,
            type='zci',
            cpi=index,
            indexmktdefs=idx_defs,
            ccy=ccy,
            mktdefs=bhs.mkt_defs,
            calendar=cal,
        )
        return params

    def get_rates(
            self,
            index,
            eff,
            mty,
            snap,
            as_matrix=True,
    ):
        eff_ = [eff] if isinstance(eff, str) else eff
        mty_ = [mty] if isinstance(mty, str) else mty
        params = self.get_params_from_index(index, snap)

        res = []
        for e in eff_:
            for m in mty_:
                params_ = {'eff': e, 'mty': m, **params}
                rate = bh.bhInfRate(**params_)
                res.append([e, m, rate])
        res = pd.DataFrame(res, columns=['eff', 'ten', 'rate'])
        if len(res) == 1:
            return res.squeeze()['rate']
        if as_matrix:
            res = res.pivot(index='eff', columns='ten', values='rate')
            return res.loc[eff_, mty_]


def get_fi_mkt(
        curves,
        vols=None,
        infl=None,
        date=None
):
    date = date or get_bday(today())
    fi_db = curves

    if vols:
        fi_db = bh.bhDbJoin(
            # newid=get_id(),
            lhsid=curves,
            rhsid=vols,
            lhsindex="name",
            rhsindex="name",
            rhscols="cube",
            includelhs=True,
            includerhs=True
        )

    if infl:
        infl_ = bh.bhDbCalcCols(
            oldid=bh.bhDbFilter(oldid=infl, filter="valid=1"),
            colnames="cube",
            colcalcs="",
        )
        fi_db = bh.bhDbMerge(oldids=[fi_db.handle, infl_.handle])

    fi_mkt = bh.bhCreateFiMarket2(
        asofdate=date,
        mktdefs=bhs.mkt_defs,
        curvesdb=fi_db,
        generators=bhs.gens,
        ccycalprov=bhs.ccy_cals,
        snapsvr=SQL.Snap.server,
        quantssvr=SQL.Quants.server,
        svmsvr=SQL.SVM.server,
        readcmsvols=True,
        cmsvolsccat=True,
        datadate=date,
    )

    return fi_mkt


def parse_ir_periods(value):
    try:
        value = pd.to_datetime(value)
    except:
        pass
    return value


def parse_ir_strike(value):
    if value != 'a':
        value = float(value)
    return value


ir_map = pd.DataFrame(
    [
        ('TradeId', 'Int', None, None, None),
        ('EffExp', 'String', 'eff_exp', parse_ir_periods, None),
        ('MtyTnr', 'String', 'mty_tnr', parse_ir_periods, None),
        ('PayoutType', 'String', 'payout_type', lambda x: x.lower(), 'pay'),
        ('Nominal', 'Double', 'notional', None, 1e6),
        ('Strike', 'String', 'strike', parse_ir_strike, 'a'),
        ('SwaptionSettleType', 'String', 'swaption_settle_type', lambda x: x.lower(), 'p'),
        ('CollateralCcy', 'String', 'collateral', lambda x: x.upper(), 'LCH'),
        ('ClearingHouse', 'String', 'clearing_house', None),
        ('UnderlyingClearingHouse', 'String', 'underlying_clearing_house', None, None),
        ('IsStrikeNumber', 'String', None, None, None),
        ('Generator', 'String', 'generator', lambda x: x.upper()),
        ('SVMInstrument', 'String', 'instrument', lambda x: x.lower(), 'irs'),
    ],
    columns=['col', 'type', 'arg', 'fn', 'default']
)

# {
#     'SVMInstrument': ['irs', 'cf', 'oswp', 'zcis'],
#     'PayoutType': ['Pay', 'Rec', 'Floor', 'Cap']
#     'SwaptionSettleType': ['c', 'p', 'cp']
# }

from numbers import Number


def get_ir_trades(inputs, null=''):
    if isinstance(inputs, dict):
        inputs = [inputs]

    if not isinstance(inputs, pd.DataFrame):
        inputs = pd.DataFrame(inputs)

    check = ir_map.dropna(subset='arg').set_index('arg')
    rows = []
    for index, row in inputs.iterrows():
        row_ = {}
        for key, spec in check.iterrows():
            value = row.get(key)
            if pd.isnull(value):
                value = spec['default']
                if not value:
                    value = null
            else:
                if fn_ := spec['fn']:
                    value = fn_(value)
            row_[spec['col']] = value
        rows.append(row_)

    inputs_ = pd.DataFrame(rows)
    inputs_ = inputs_.assign(
        TradeId=range(1, len(inputs_) + 1),
        IsStrikeNumber=inputs_['Strike'].map(lambda x: isinstance(x, Number))
    ).loc[:, [*ir_map['col']]]

    inputs_ = bh.bhDbCreate(
        id=get_id(),
        columnnames=ir_map['col'].to_list(),
        columntype=ir_map['type'].to_list(),
        columntyped='F',
        data=inputs_,
    )

    return inputs_


class Test:
    pass


def get_price_info(
        inputs,
        curves,
        vols=None,
        infl=None,
        date=None,
        hist='1y',
        vol_model="Normal"
):
    date = date or get_bday(today())

    fi_mkt = get_fi_mkt(
        curves=curves,
        vols=vols,
        infl=infl
    )

    fixing_fi_loader = bh.bhCreateFiFixingsLoader(
        datadate=date,
        flateextrap=False,
        hasois=True,
        histdbserver=SQL.Histories.server,
        histdbname=SQL.Histories.db,
        extractsdbsrv=None,
        extractsdbname=None,
        histterm=hist.upper(),
        generators=None,
    )

    fi_price_factory = bh.bhCreateFiPriceableFactory(
        volmodels="",
        undrst=fixing_fi_loader,
        eodvl=False,
        gns=bhs.gens,
        date=date,
        svmsvr=SQL.SVM.server,
        snapsvr=SQL.Snap.server,
        prodsvr=SQL.Products.server,
        quantssvr=SQL.Quants.server,
    )

    ir_trades = get_ir_trades(inputs)

    ir_trades_db = bh.bhFiCreateFiTradesDb(
        tradesdb=ir_trades,
        tradegenfac=bhs.gens_factory,
        mkt=fi_mkt,
        pblefac=fi_price_factory,
        addtradesdata=True
    )

    priceable = bh.bhFiCreatePriceables(
        trades=ir_trades_db,
        priceablefactory=fi_price_factory,
        fimarket=fi_mkt,
        volmodel=vol_model
    )

    Test.ir_trades = ir_trades
    Test.ir_tradee_db = ir_trades_db
    Test.priceable = priceable

    price_info = bh.bhFiPriceableInfo(
        dborpriceablehandles=priceable,
        adddiagnostics=True,
    )

    return price_info

