import pandas as pd
from IPython.display import display
from .gui.aggrid import AGGridHandler
from .utils import update_recursively


@pd.api.extensions.register_series_accessor("zscore")
@pd.api.extensions.register_dataframe_accessor("zscore")
class RollingZScoreZScore:
    def __init__(self, pandas_obj):
        self._obj = pandas_obj

    def __call__(self, *args, **kwargs):
        obj = self._obj
        ewm = kwargs.pop('ewm', False)
        rolling = kwargs.pop('rolling', False)
        accessor = 'rolling' if rolling else 'ewm' if ewm else None
        if accessor:
            accessor = getattr(obj, accessor)
            accessor_ = accessor(*args, **kwargs)
        else:
            accessor_ = obj
        return (obj - accessor_.mean()) / accessor_.std()


@pd.api.extensions.register_series_accessor("aggrid")
@pd.api.extensions.register_dataframe_accessor("aggrid")
class AGGrid:
    def __init__(self, pandas_obj):
        self._obj = pandas_obj

        self._gh = AGGridHandler(
            self._obj,
            index=True,
            # grid_options=dict(
            #     domLayout='autoHeight'
            # ),
            grid_kwargs=dict(
                sync_on_edit=True,
                height=500,
                # theme='ag-theme-bootstrap'
            ),
            autoformat=True,
        )

    def __call__(self, height=500, **kwargs):
        grid_options = dict()
        if height == -1:
            grid_options['domLayout'] = 'autoHeight'

        kwargs_grid_options = kwargs.pop('grid_options', {})

        update_recursively(grid_options, kwargs_grid_options)
        # grid_options.update(kwargs_grid_options)

        default_grid_kwargs = dict(
            sync_on_edit=True,
            height=height,
            # theme='ag-theme-bootstrap'
        )
        # default_grid_kwargs.update(kwargs.pop('grid_kwargs', {}))

        update_recursively(default_grid_kwargs, kwargs.pop('grid_kwargs', {}))

        default_kwargs = dict(
            index=True,
            grid_options=grid_options,
            grid_kwargs=default_grid_kwargs,
            autoformat=True,
        )
        default_kwargs.update(**kwargs)

        self._gh = AGGridHandler(
            self._obj,
            **default_kwargs,
        )
        return self

    def _ipython_display_(self):
        display(self._gh.g)

