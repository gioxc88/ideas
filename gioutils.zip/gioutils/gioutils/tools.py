import re

import numpy as np
import pandas as pd

from .utils import parse_offset

bpv = 10000
exchanges = [
    'ICE',
    'CME',
    'CBOT'
]


def today():
    return pd.Timestamp.today().floor('d')


def parse_clipboard(cols=None):
    cols = cols or [
        ('Trade Details', 'Strategy'),
        ('Trade Details', 'Trade Type'),
        ('Trade Details', 'Ccy'),
        ('Trade Details', 'Instrument'),
        ('Trade Details', 'Expiry/ Tenor'),
        ('Trade Details', 'Start Bumped'),
        ('Trade Details', 'Maturity Bumped'),
        ('Trade Details', 'Notional'),
        ('Risk', 'Delta'),
    ]

    date_cols = [
        ('Trade Details', 'Start Bumped'),
        ('Trade Details', 'Maturity Bumped'),
    ]

    num_cols = [
        ('Trade Details', 'Notional'),
        ('Risk', 'Delta')
    ]

    # data = pd.read_clipboard(sep='\t', header=[1], parse_dates=date_cols)

    data = pd.read_clipboard(sep='\t', header=[0, 1])

    idx = data.columns.to_frame().reset_index(drop=True)
    idx.loc[idx[0].str.contains('Unnamed'), 0] = np.nan
    idx[0] = idx[0].ffill()
    data = data.set_axis(pd.MultiIndex.from_frame(idx), axis=1)

    for col in num_cols:
        data[col] = data[col].astype(str).str.replace(',', '').astype(float)

    for col in date_cols:
        data[col] = pd.to_datetime(data[col])

    return data[cols].droplevel(0, axis=1).dropna(subset=['Strategy', 'Instrument'])


def parse_swap_period(start_date=None, end_date=None, age=None, date=None, use_weeks=False):
    date = pd.to_datetime(date) if date else today()

    if isinstance(start_date, str):
        start_date = today() + parse_offset(start_date)
    if isinstance(end_date, str):
        end_date = start_date + parse_offset(end_date)

    date_ = date + parse_offset(age) if age else date
    days = (start_date - date_).days
    if not end_date and days <= 15.25:
        return

    if end_date:
        if days >= 0:
            days = (end_date - start_date).days
        else:
            days = (end_date - date_).days

    if pd.isna(days):
        return days

    months = round(days / 30.5)
    if months < 0:   # change
        return "1m"

    if use_weeks:
        weeks = round(days / 7)
        if not weeks % 52:
            return f'{round(weeks / 52)}y'
        elif not weeks % 4:
            return f'{round(weeks / 4)}m'
        return f"{weeks}w"
    # if the months correspond to an exact number of years or is greater than 5y (for longer maturities)
    if (not months % 12) or (months > 12*5):
        return f'{round(months / 12)}y'
    else:
        return f"{months}m"


def parse_swap_periods(start_date, end_date, sep='x', age=None, date=None, use_weeks=False):
    if pd.isnull(start_date) or pd.isnull(end_date):
        return np.nan
    start = parse_swap_period(start_date=start_date, age=age, date=date, use_weeks=use_weeks)
    tail = parse_swap_period(start_date=start_date, end_date=end_date, date=date, age=age,  use_weeks=use_weeks)
    if start:
        return f"{start}{sep}{tail}"
    else:
        if int(tail[0]) == 0:
            return '1m'
        else:
            return tail


def parse_instrument(instrument):
    for ex in exchanges:
        instrument = instrument.replace(ex, '')
    return instrument.strip()


def age_swap_expr(expr):
    pattern = re.compile(r' (\d+[my])(x\d+[my])*', re.IGNORECASE)
    src = pattern.search(expr)
    forward_start, tenor = src.groups()
    start_aged = parse_swap_period(forward_start, age='3m')
    return expr.replace(forward_start, start_aged)


def parse_curve(instrument, currency, instrument_type=None):
    instrument = parse_instrument(instrument)
    if any(s in instrument for s in ['SOFR', 'ESTR', 'SONIA', 'ESTER']):
        curve = instrument.split(' ')[0].lower()
        if curve.lower() == 'estr':
            curve = 'ESTER'
        curve = f"{currency.lower()}.{curve}"
    elif 'FEDFUNDS' in instrument:
        curve = f"{currency.lower()}.ois"
    elif any(s in instrument for s in ['EURIBOR', 'LIBOR']):
        split = instrument.split(' ')
        if split[-1][-1] in ['M', 'Y']:
            tenor = split[-1]
            if currency == 'USD' and tenor == '3M':
                suffix = ''
            elif currency == 'EUR' and tenor == '6M':
                suffix = ''
            else:
                suffix = f".{tenor.lower()}"
        else:  # maybe this block is never reached
            suffix = ''

        curve = f"{currency.lower()}{suffix}"
    elif 'US' in instrument:
        curve = 'usd.sofr'
    elif 'BUND' in instrument or 'SCHATZ' in instrument:
        curve = 'eur.ester'
    elif 'EUR LIFFE' in instrument:
        curve = 'EUR.ESTER'

    try:
        curve
    except (UnboundLocalError, NameError):
        print(instrument)
    return curve


def get_swap_string(
        instrument,
        currency,
        start_date,
        end_date,
        age=None,
        instrument_type=None,
):
    curve = parse_curve(instrument=instrument, currency=currency, instrument_type=instrument_type)
    swap_periods = parse_swap_periods(start_date=start_date, end_date=end_date, age=age)
    return f"[s {curve} {swap_periods}]"


def get_default_strategy_map(strategies):
    strategies = strategies.drop_duplicates()

    s_map = {}
    for s, sl in zip(strategies, strategies.str.split(':').str[1].str.split(' ')):
        if len(sl) > 2:
            s_map[s] = f"{sl[0][:3]}_{sl[1][:3]}_{sl[2][:2]}".lower()
        elif len(sl) == 2:
            s_map[s] = f"{sl[0][:3]}_{sl[1][:3]}".lower()
        else:
            s_map[s] = sl[0].lower()
    return s_map


def get_history_plotter_strings(
        strategy_map=None,
        delta_tol=100,
        delta_mul=1,
        age='3m',
        add_ptf=True,
):

    d = parse_clipboard()
    d = d.loc[~d['Delta'].between(-delta_tol, delta_tol), :]
    d['Delta'] = d['Delta'] * delta_mul
    strategy_map = strategy_map or get_default_strategy_map(d['Strategy'])

    dg = d.groupby(
        ['Strategy', 'Trade Type', 'Ccy', 'Instrument', 'Expiry/ Tenor', 'Start Bumped', 'Maturity Bumped'],
        as_index=False
    ).sum()

    dg = dg.loc[~dg['Delta'].between(-delta_tol, delta_tol), :]

    dg['curve'] = dg.apply(lambda row: parse_curve(
        instrument=row['Instrument'],
        currency=row['Ccy'],
    ), axis=1)

    dg['period'] = dg.apply(lambda row: parse_swap_periods(
        start_date=row['Start Bumped'],
        end_date=row['Maturity Bumped'],
    ), axis=1)

    dg['period_aged'] = dg.apply(lambda row: parse_swap_periods(
        start_date=row['Start Bumped'],
        end_date=row['Maturity Bumped'],
        age=age
    ), axis=1)

    dg['string'] = dg.apply(lambda row: get_swap_string(
        instrument=row['Instrument'],
        currency=row['Ccy'],
        start_date=row['Start Bumped'],
        end_date=row['Maturity Bumped'],
    ), axis=1)

    dg['string_aged'] = dg.apply(lambda row: get_swap_string(
        instrument=row['Instrument'],
        currency=row['Ccy'],
        start_date=row['Start Bumped'],
        end_date=row['Maturity Bumped'],
        age=age,
    ), axis=1)

    dg_ = dg.groupby(['Strategy', 'string', 'string_aged'], as_index=False).sum()
    dg_ = dg_.loc[~dg_['Delta'].between(-delta_tol, delta_tol), :]

    parsed = {}
    round_ = 1
    for index, group in dg_.groupby('Strategy'):
        s = (group['Delta'] / bpv).apply(lambda x: format(x, f'+.{round_}f')) + '*' + group['string']
        s = f"{' '.join(s)}"
        parsed[strategy_map.get(index, index)] = s

    parsed = pd.Series(parsed, dtype=object)

    parsed_aged = {}
    for index, group in dg_.groupby('Strategy'):
        s = (group['Delta'] / bpv).apply(lambda x: format(x, f'+.{round_}f')) + '*' + group['string_aged']
        s = f"{' '.join(s)}"
        parsed_aged[f"{strategy_map.get(index, index)}A"] = s

    parsed_aged = pd.Series(parsed_aged, dtype=object)
    parsed_all = pd.concat([parsed, parsed_aged])

    if add_ptf:
        ptf = pd.Series(
            [
                ' + '.join(parsed_all.index[:len(parsed_all) // 2]),
                ' + '.join(parsed_all.index[len(parsed_all) // 2:])
            ],
            index=['ptf', 'ptfA']
        )
        parsed_all = pd.concat([parsed_all, ptf])

    parsed_all.to_clipboard(header=False)
    return d, dg, parsed_all
