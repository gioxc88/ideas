from IPython.display import display
from inflection import underscore


class Store:
    def __init__(self, name='', registry=None):
        self.name = name
        self.data = {}
        self.components = {}
        self.registry = registry or NameRegistry()

    def add(self, value):
        self.components[value.name] = value

    def __getitem__(self, item):
        return self.components[item]

    def reset(self):
        self.components = {}

    @property
    def router(self):
        return self.components.get('router')

    def __repr__(self):
        return self.components.__repr__()

    def _ipython_display(self):
        display(self.components)


class NameRegistry:
    def __init__(self):
        self.registry = {}

    def register(self, name):
        reg = self.registry
        count = reg.get(name, 0)
        if not count:
            reg[name] = 1
            return name
        else:
            new_name = f"{name}{count + 1}"
            reg[new_name] = 1
            reg[name] += 1
            return new_name


def get_store_mixin(name):
    store_ = Store(name=name)
    attr_name = f'_{name}_store'

    class HasStore:
        _store = store_

        def __init__(self, *args, **kwargs):
            self.name = kwargs.get('name', getattr(
                self,
                'name',
                store_.registry.register(underscore(self.__class__.__name__))
            ))

            store_.add(self)
            setattr(self, attr_name, store_)

            try:
                super().__init__(*args, **kwargs)
            except TypeError:
                pass

        @property
        def store(self):
            return self._store

        def get_store(self, name):
            return getattr(self, f'_{name}_store')

    return HasStore