import bhutils as bh

bh.bhTsCalcExpression()

inputs = [

    ('a', '[S USD 5yx5y]'),
    ('b', '[S EUR 5yx5y]'),
    ('c', 'a + b')
]

import threading


def hello_world():  # called every minute
    print("Hello, World!")


hello_world()


class Timer:
    def __init__(self, fn, time):
        self.fn = fn
        self.timer = threading.Timer(time, fn)

    def start(self):
        self.timer.start()

    def stop(self):
        self.timer.cancel()


import threading
import time
from functools import partial


class RepeatedTimer:
    def __init__(self, function, interval):
        self._timer = None
        self.interval = interval
        self.function = function
        self.is_running = False

    def _run(self, *args, **kwargs):
        self.is_running = False
        self.start()
        self.function(*args, **kwargs)

    def start(self, *args, **kwargs):
        if not self.is_running:
            if hasattr(self, 'next_call'):
                self.next_call += self.interval
            else:
                self.next_call = time.time()
            self._timer = threading.Timer(self.next_call - time.time(), partial(self._run, *args, **kwargs))
            self._timer.start()
            self.is_running = True

    def stop(self):
        self._timer.cancel()
        self.is_running = False


threading.Timer(2.0, hello_world).start()


[
    'EURHE',
    'BOX',
    'EURFSPRD',
    'USDRCUR',
    'EURHEA',
    'BOXA',
    'EURFSPRDA',
    'USDRCURA',
]
