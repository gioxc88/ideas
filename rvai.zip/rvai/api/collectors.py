import logging
from itertools import chain
from uuid import uuid4

import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay
from inflection import underscore
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.utils.validation import check_is_fitted, NotFittedError
from gioutils.utils import get_xy

from gioutils.ezutils import bh, bhs, ZCILSHelper
from gioutils.utils import parse_offset, today, get_next_n, get_bday
from gioutils.ezutils import LiveCurvesLocal, COBCurvesRemote, LiveCurvesRemote, LiveVolsRemote, COBVolsRemote
from gioutils.store import get_store_mixin

from .gui.params import bbg_params, eco_fields, eco_params, bbg_fields, eco_tickers

pd.options.plotting.backend = "plotly"


def get_rate_from_generator(
        generator,
        efforfwd,
        mtyortenor,
        snap,
        collateral='LCH',

):
    try:
        rate = bh.bhFiRate(
            efforfwd=efforfwd,
            mtyortenor=mtyortenor,
            generatorname=generator,
            curves=snap,
            collateral=collateral,
            generators=bhs.gens
        )
    except Exception as e:
        logging.warning(f"for {generator} {efforfwd} {mtyortenor} got error {e}")
        return np.nan
    return rate


def get_rates_from_generator(
        generator,
        efforfwd,
        mtyortenor,
        snap,
        collateral='LCH',
        drop_duplicates=True,

):
    if drop_duplicates:
        efforfwd = pd.Series(efforfwd).drop_duplicates().to_list()
        mtyortenor = pd.Series(mtyortenor).drop_duplicates().to_list()

    res_db = bh.bhFiRates(
        handle=uuid4().hex,
        fwdterms=efforfwd,
        tenors=mtyortenor,
        generatorname=generator,
        curves=snap,
        collateral=collateral,
        generators=bhs.gens
    )
    df = pd.DataFrame(bh.bhDbGetValues(rsid=res_db, columnheadings=True))
    return df.rename(columns=df.iloc[0]).drop(df.index[0]).reset_index(drop=True).infer_objects()


def get_vol_from_generator(
        generator,
        expiry,
        tenor,
        curve_snap=None,
        vol_snap=None,
        strike=None,
        voltype='n',
        collateral='LCH',
        **kwargs
):
    try:
        if not strike:
            strike = get_rate_from_generator(
                generator=generator,
                efforfwd=expiry,
                mtyortenor=tenor,
                snap=curve_snap,
                collateral=collateral
            )

        vol = bh.bhFiVol(
            expiry=expiry,
            tenor=tenor,
            strike=strike,
            voltype=voltype,
            generatorname=generator,
            volcubes=vol_snap,
            collateral=collateral,
            generators=bhs.gens,
            **kwargs
        )
    except Exception as e:
        logging.warning(f"for {generator} {expiry} {tenor} got error {e}")
        return np.nan
    return vol


CollectorStoreMixin = get_store_mixin(name='collector')


class BaseCollector:
    def get_data(self, snaps=None, **kwargs):
        try:
            return self._get_data(snaps=snaps, **kwargs)
        except Exception as e:
            logging.warning(e)


class SpotForward(BaseCollector, CollectorStoreMixin):
    def __init__(self, spot_params, fwd_params, **kwargs):
        self.spot_params = spot_params
        self.fwd_params = fwd_params

        self.params = {
            'spot': spot_params,
            'fwd': fwd_params
        }

        super().__init__(**kwargs)

    def _get_data(self, snaps=None, **kwargs):
        snaps = {k: snaps[k] for k in ['live', 'cob']}

        if isinstance(snaps, dict):
            res = {}
            for curve_type, curves in snaps.items():
                res[curve_type] = self._get_data_from_snap(snap=curves)
            try:
                res['live']['spot']['change'] = res['live']['spot']['rate'] - res['cob']['spot']['rate']
                res['live']['fwd']['change'] = res['live']['fwd']['rate'] - res['cob']['fwd']['rate']
            except Exception as e:
                raise e
        elif isinstance(snaps, list):
            res = []
            for curves in snaps:
                res.append(self._get_data_from_snap(snap=curves))
        else: # assuming only one snap
            res = self._get_data_from_snap(snap=snaps)
        self.data = res
        return res

    def _get_data_from_snap(self, snap=None, **kwargs):
        rates = {}
        for key, params in self.params.items():
            rates_data = {}
            for params_ in params:
                starts, tenors = [*zip(*params_['tenors'])]
                rates_df = get_rates_from_generator(
                    generator=params_['gen'],
                    efforfwd=starts,
                    mtyortenor=tenors,
                    snap=snap
                )
                rates_data[params_['gen']] = rates_df
            rates_data = pd.concat(rates_data)
            rates[key] = rates_data
        return rates


class Futures(BaseCollector, CollectorStoreMixin):
    _base_tickers = {
        'EUR': 'ER',
        'USD': 'SFR',
        'GBP': 'SFI'
    }
    _base_spot_tickers = {
        'EUR': 'EUR003M Index',
        'USD': 'SOFRRATE Index',
        'GBP': 'SONIO/N Index'
    }

    def __init__(self, base_tickers=None, n=8, **kwargs):
        self.base_tickers = base_tickers or self._base_tickers
        self.n = n
        super().__init__(**kwargs)

    def get_tickers(self, return_dict=False):
        exps = get_next_n(self.n)
        base_tickers = self.base_tickers
        res = {ccy: [self._base_spot_tickers[ccy], *[f"{base_tickers[ccy]}{exp} Comdty" for exp in exps]] for ccy in
               base_tickers}
        return res if return_dict else [*chain.from_iterable(res.values())]

    def _get_data(self, snaps=None, cob_date=None, **kwargs):
        bq = kwargs.get('bq')
        cob_date = cob_date or today() - BDay()
        tickers = self.get_tickers()
        fields = ['px_last', 'security_des']
        live = bq.bdp(
            tickers,
            fields
        ).rename({'px_last': 'live'}, axis=1).set_index('security')

        cob = bq.bdh(
            tickers,
            fields[:1],
            start_date=cob_date,
            end_date=cob_date,
        ).rename({'px_last': 'cob'}, axis=1).set_index('security')
        data = pd.concat([live, cob], axis=1)
        data['change'] = data['live'] - data['cob']
        self.data = data
        return data


class Market(BaseCollector, CollectorStoreMixin):
    _params = pd.DataFrame(bbg_params)
    _fields = bbg_fields

    def __init__(self, params=None, fields=None, **kwargs):
        self.params = params or self._params
        self.fields = fields or self._fields
        super().__init__(**kwargs)

    def get_tickers(self):
        return self.params['ticker']

    def _get_data(self, snaps=None, cob_date=None, **kwargs):
        bq = kwargs.get('bq')
        cob_date = get_bday(cob_date) if cob_date else today() - BDay()
        fields = [*self._fields.keys()]
        tickers = self.get_tickers()
        live = bq.bdp(
            tickers,
            fields
        ).rename({'px_last': 'live', 'last_yld': 'yield live'}, axis=1).set_index('security')

        cob = bq.bdh(
            tickers,
            fields[:1],
            start_date=cob_date,
            end_date=cob_date,
        ).rename({'px_last': 'cob'}, axis=1).set_index('security')
        self.live = live
        self.cob = cob


        data = pd.concat([live, cob], axis=1)
        data['change'] = data['live'] - data['cob']
        data['yield change'] = data['yield live'] - data['cob']

        to_add = self.params.set_index('ticker').rename_axis('security')
        data = pd.concat([data, to_add], axis=1)
        self.data = data
        return data


class ECO(BaseCollector, CollectorStoreMixin):
    _params = pd.DataFrame(eco_params)
    _fields = eco_fields

    def __init__(self, bq=None, **kwargs):

        super().__init__(**kwargs)

    def _get_data(self, snaps=None, cob_date=None, **kwargs):
        bq = kwargs.get('bq')
        fields = self._fields
        tickers = self._params['security']

        if not hasattr(self, 'data'):

            data = bq.bdp(
                tickers,
                fields
            )

            data = self._params.merge(data, on='security', how='left')\
                .sort_values('rank', ascending=False)\
                .reset_index(drop=True)

            hist_data = bq.bdh(
                tickers,
                {'actual_release': 'actual', 'first_revision': 'rev'},
                today() - parse_offset('ytd'),
                options=False
            )

            last_2 = []
            for index, group in hist_data.groupby('security'):
                g = group[-2:].sort_values('date', ascending=False)
                g = g.assign(label=['last', 'prior'])
                g_ = g.drop(['date', 'security'], axis=1).melt(id_vars='label')
                g_ = g_.assign(label=(g_['label'] + '_' + g_['variable']).str.replace('_actual', '')).\
                    set_index('label')['value'].rename(index)
                g_ = g_.to_frame().rename_axis(None).T.rename_axis('security').reset_index()
                last_2.append(g_)

            hist_data_ = pd.concat(last_2)

            data_ = data.merge(hist_data_, on='security', how='left')
            self.data = data_

        else:
            fields = {
                    'eco_release_dt': 'next',
                    'actual_release': 'actual',
                    'bn_survey_median': 'survey',
                }
            new_data = bq.bdp(
                self.data['security'],
                fields
            )
            self.data[[*fields.values()]] = new_data[[*fields.values()]]

        return self.data


def get_mtgs_query(ccys=None, date=None):
    date = date or today()
    if ccys:
        if isinstance(ccys, str):
            ccys = [ccys]
        ccys = tuple(ccys)
        if len(ccys) == 1:
            ccys = f"('{ccys[0]}')"
        query = f"USE Quants SELECT * FROM SEMtgDates " \
            f"WHERE Currency in {ccys} " \
            f"AND MeetingDate > '{date:%Y%m%d}' " \
            f"ORDER BY Currency, MeetingDate ASC"
    else:
        query = f"USE Quants SELECT * FROM SEMtgDates " \
            f"WHERE MeetingDate > '{date:%Y%m%d}' " \
            f"ORDER BY Currency, MeetingDate ASC"
    return query


def get_mtgs_df(ccys=None, date=None, parse=True):
    date = date or today()
    mtgs_db = bh.bhDbReadSql(
        rsid=uuid4().hex,
        sqlserver="SQLP1-A",
        sqldatabase="Quants",
        sqlquery=get_mtgs_query(ccys=ccys, date=date),
        addspaces=True
    )
    df = pd.DataFrame(bh.bhDbGetValues(rsid=mtgs_db, columnheadings=True))
    df = df.set_axis(df.iloc[0], axis=1).drop(df.index[0]).infer_objects()
    if parse:
        return parse_mtgs_df(df, date)
    else:
        return df


def parse_mtgs_df(mtgs_df, date=None):
    date = date or today()
    res = []
    for index, group in mtgs_df.groupby('Currency', sort=False):
        append = pd.DataFrame(
            [[index, date, 'fixing', date + BDay()]],  # date + BDay()
            columns=[*group.columns, "MaturityDate"], index=[0]
        )
        group["MaturityDate"] = group["EffectiveDate"].shift(-1)
        group = pd.concat([append, group])

        res.append(group.dropna())

    res = pd.concat(res)
    return res


class Mtgs(BaseCollector, CollectorStoreMixin):
    gens_curves_map = {
        'USD': 'USD OIS',
        'EUR': 'EUR ESTER',
        'GBP': 'GBP SONIA'
    }

    gens_ticker_map = {
        'USD OIS': 'FEDL01 Index',
        'USD SOFR': 'SOFRRATE Index',
        'EUR ESTER': 'ESTRON Index',
        'GBP SONIA': 'SONIO/N Index'
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def _get_data(self, snaps=None, **kwargs):
        bq = kwargs.get('bq')

        fixings = bq.bdp(
            [*self.gens_ticker_map.values()],
            'px_last'
        ).set_index('security')
        fixings['px_last'] = fixings['px_last'] / 100

        mtgs_df = get_mtgs_df(ccys=[*self.gens_curves_map], parse=False)
        res = []
        for index, group in mtgs_df.groupby('Currency', sort=False):
            group['eff'] = group['MeetingDate']
            group['mty'] = group['eff'].shift(-1)
            gen = self.gens_curves_map[index]
            group['rate'] = [
                get_rate_from_generator(
                    generator=gen,
                    efforfwd=row['eff'],  # row['EffectiveDate'],
                    mtyortenor=row['mty'],
                    snap=snaps['live']
                ) for _, row in group.iterrows()
            ]

            new_row = pd.DataFrame(
                [[index, 'fixing', 'fixing', 'fixing', 'fixing', fixings.loc[self.gens_ticker_map[gen], 'px_last']]],  # date + BDay()
                columns=[*group.columns], index=[0]
            )
            group = pd.concat([new_row, group]).reset_index(drop=True)
            group['hikes'] = group['rate'].diff()
            res.append(group)

        res = pd.concat(res)
        self.data = res
        return res


fwt_mat_ccy_gen_map = {
    'USD': 'USD SOFR',
    'EUR': 'EUR ESTER',
    'GBP': 'GBP SONIA'
}

fwt_mat_index = [
    '3M',
    '6M',
    '1Y',
    '2Y',
    '5Y',
    '10Y',
]

fwt_mat_columns = [
    '1Y',
    '2Y',
    '3Y',
    '5Y',
    '10Y',
    '30Y',
]


class FwdMatrix(BaseCollector, CollectorStoreMixin):
    def __init__(self, ccy_gen_map=None, index=None, columns=None, **kwargs):
        self.ccy_gen_map = ccy_gen_map or fwt_mat_ccy_gen_map
        self.index = index or fwt_mat_index
        self.columns = columns or fwt_mat_columns
        super().__init__(**kwargs)

    def _get_data(self, snaps=None, **kwargs):
        snaps = {k: snaps[k] for k in ['live', 'cob']}
        res = {}
        for key, curve in snaps.items():
            for ccy, gen in self.ccy_gen_map.items():
                res[(key, ccy)] = self.get_fwd_matrix(gen, curve)

        data = pd.concat(res)
        change = data.loc['live'] - data.loc['cob']

        data = pd.concat(
            [
                data,
                pd.concat([change], keys=['change'])
            ]
        )
        self.data = data
        return data

    def get_fwd_matrix(self, gen, snap):
        index = self.index
        columns = self.columns
        mat = pd.DataFrame(index=index, columns=columns)
        for idx in index:
            for col in columns:
                rate = get_rate_from_generator(
                    generator=gen,
                    efforfwd=idx,
                    mtyortenor=col,
                    snap=snap
                )
                mat.loc[idx, col] = rate
        return mat


vol_expiry = [
    '1M',
    '3M',
    '6M',
    '9M',
    '1Y',
    '18M',
    '2Y',
    '3Y',
    '4Y',
    '5Y',
    '10Y',
    '15Y',
    '20Y',
]

vol_tenor = [
    '1Y',
    '2Y',
    '3Y',
    '4Y',
    '5Y',
    '7Y',
    '10Y',
    '15Y',
    '20Y',
    '30Y',
]


class VolMatrix(BaseCollector, CollectorStoreMixin):
    def __init__(self, ccy_gen_map=None, index=None, columns=None, **kwargs):
        self.ccy_gen_map = ccy_gen_map or fwt_mat_ccy_gen_map
        self.index = index or vol_expiry
        self.columns = columns or vol_tenor

        super().__init__(**kwargs)

    def _get_data(self, snaps=None, **kwargs):
        res = {}

        snaps_ = {
            'live': (snaps['live'], snaps['live_vol']),
            'cob': (snaps['cob'], snaps['cob_vol'])}
        for key, (curve, vol) in snaps_.items():
            for ccy, gen in self.ccy_gen_map.items():
                res[(key, ccy)] = self.get_vol_matrix(gen, curve, vol)

        data = pd.concat(res)
        change = data.loc['live'] - data.loc['cob']

        data = pd.concat(
            [
                data,
                pd.concat([change], keys=['change'])
            ]
        )
        self.data = data
        return data

    def get_vol_matrix(self, gen, curve_snap, vol_snap):
        index = self.index
        columns = self.columns
        mat = pd.DataFrame(index=index, columns=columns)
        for idx in index:
            for col in columns:
                rate = get_vol_from_generator(
                    generator=gen,
                    expiry=idx,
                    tenor=col,
                    curve_snap=curve_snap,
                    vol_snap=vol_snap
                )
                mat.loc[idx, col] = rate
        return mat


zcil_indices = {
    'USD': 'CPURNSA',
    'EUR': 'CPTFEMU',
    'GBP': 'UKRPI',
}

zcil_index = [
    '0M',
    '3M',
    '6M',
    '1Y',
    '2Y',
    '5Y',
    '10Y',
]

zcil_columns = [
    '1Y',
    '2Y',
    '3Y',
    '5Y',
    '10Y',
    '30Y',
]


class ZCILMatrix(BaseCollector, CollectorStoreMixin):
    def __init__(self, indices=None, index=None, columns=None, **kwargs):
        self.indices = indices or zcil_indices
        self.index = index or zcil_index
        self.columns = columns or zcil_columns
        self.zcil = ZCILSHelper()
        super().__init__(**kwargs)

    def _get_data(self, snaps=None, **kwargs):
        res = {}

        snaps = {key: snaps.get(key) for key in ['live_infl', 'cob_infl']}
        for key, snap in snaps.items():
            if snap:
                for ccy, index in self.indices.items():
                    data = self.zcil.get_rates(index=index, eff=self.index, mty=self.columns, snap=snap)
                    res[key, ccy] = data

        data = pd.concat(res)
        data = pd.concat([data, pd.concat([data.loc['live_infl'] - data.loc['cob_infl']], keys=['change'])])
        self.data = data
        return self.data

    def get_vol_matrix(self, gen, curve_snap, vol_snap):
        index = self.index
        columns = self.columns
        mat = pd.DataFrame(index=index, columns=columns)
        for idx in index:
            for col in columns:
                rate = get_vol_from_generator(
                    generator=gen,
                    expiry=idx,
                    tenor=col,
                    curve_snap=curve_snap,
                    vol_snap=vol_snap
                )
                mat.loc[idx, col] = rate
        return mat


def get_bbg_data(securities, date, bq, options=None):
    data = bq.bdh(
        securities=securities,
        fields='px_last',
        start_date=date,
        options=options
    )

    data_mat = data.pivot(index='date', columns='security', values='px_last')
    return data_mat


class ECOPred(BaseCollector, CollectorStoreMixin):
    def __init__(self, X_names, y_name, date=None, freq='W-Fri', model=LinearRegression(), **kwargs):
        self.X_names = X_names
        self.y_name = y_name
        self.date = date or pd.Timestamp(2013, 1, 1)
        self.model = model
        self.freq = freq
        self.fit_data = None
        self.last_y_date = None
        self.predict_data = None
        self.display_name = kwargs.pop('display_name', y_name)
        super().__init__(**kwargs)

    def get_bbg_data(self, X_names=None, y_name=None, date=None, bq=None, options=False):
        X_names = X_names if X_names is not None else self.X_names
        y_name = y_name if y_name is not None else self.y_name
        if isinstance(y_name, str):
            y_name = [y_name]
        date = date or self.date
        data = get_bbg_data(securities=[*X_names, *y_name], date=date, bq=bq, options=options)
        return data

    def get_reg_data(self, data_mat):
        X_names = self.X_names
        y_name = self.y_name
        y_ = data_mat[y_name].dropna()
        self.y_ = y_
        data_ = data_mat
        if freq := self.freq:
            data_ = data_mat.resample(self.freq).last()
        data_ = data_.ffill().dropna().loc[:y_.index[-1]]
        X, y = get_xy(data_[X_names], data_[y_name], diff=True)
        return X, y

    def fit(self, bq=None, **kwargs):
        data_mat = self.get_bbg_data(bq=bq)
        self.fit_data = data_mat
        X, y = self.get_reg_data(data_mat)
        self.X_reg = X
        self.y_reg = y
        self.model.fit(X, y)

    def get_predict_data(self, bq):
        if not self.last_y_date:
            y_date = self.fit_data[self.y_name].dropna().index[-1]
        else:
            y_date = self.last_y_date

        y_data = self.get_bbg_data(X_names=[], date=y_date, bq=bq, options=False)
        X_data = self.get_bbg_data(y_name=[], date=y_date, bq=bq, options=None)
        self.last_y_date = y_data.dropna().index[-1]
        self.pred_data = pd.concat([X_data, y_data], axis=1)
        return self.pred_data

    def get_last_yh(self, bq, **kwargs):
        try:
            check_is_fitted(self.model)
        except NotFittedError:
            self.fit(bq=bq)

        pred_data = self.get_predict_data(bq=bq)
        y_reg_hat = self.model.predict((pred_data.iloc[-1] - pred_data.iloc[0])[self.X_names].to_frame().T)[0]
        self.y_reg_hat = y_reg_hat
        self.last_y = pred_data[self.y_name].dropna()[0]
        yh = y_reg_hat + self.last_y
        self.last_yh = yh
        return yh

    def get_y_reg_hat(self):
        return pd.Series(self.model.predict(self.X_reg), index=self.y_reg.index, name='yhat')

    def get_y_hat(self):
        yh = self.get_y_reg_hat()
        return (self.y_.shift() + yh).rename('yhat')

    def _get_data(self, bq=None, cob_date=None, **kwargs):
        yh = self.get_last_yh(bq=bq, **kwargs)

        if cob_date:
            cob = self.fit_data[self.y_name].ffill().loc[get_bday(cob_date)]
        else:
            cob = self.last_y

        data = {
            'live': yh,
            'cob': cob,
            'change': yh - cob
        }

        self.data = pd.Series(data, name=self.display_name)
        return self.data
