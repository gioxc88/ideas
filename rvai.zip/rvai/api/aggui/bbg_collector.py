import datetime
import json
import os
from copy import deepcopy
from uuid import uuid4

import blpapi
import clarion
import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd

from gioutils.gui.base import View, ViewStore, WidgetView, Tabs
from gioutils.gui.aggrid import format_number, format_date, AGGridHandler, format_threshold


pd.options.plotting.backend = "plotly"


DEFAULT_BBG_FIELD_FORMATTERS = dict(
    px_last={
        'valueFormatter': format_number(notation="compact", maximumFractionDigits=4, minimumFractionDigits=0),
        # 'cellStyle': format_threshold()
    },
    px_close_1d={
        'valueFormatter': format_number(notation="compact", maximumFractionDigits=4, minimumFractionDigits=0),
        # 'cellStyle': format_threshold()
    },
    chg_net_1d={
        'valueFormatter': format_number(notation="compact", maximumFractionDigits=2, minimumFractionDigits=0),
        'cellStyle': format_threshold()
    },
    chg_pct_1d={
        'valueFormatter': format_number(notation="compact", maximumFractionDigits=2, minimumFractionDigits=0),
        'cellStyle': format_threshold()
    },
    sw_eff_dt={
        'valueFormatter': format_date(year="2-digit", month='short', day="numeric")
    },
)


class BBGCollectorHandler:
    def __init__(self, bq=None, collectors=None):
        self.bq = bq
        self.collectors = collectors or []

    def get_data(self, **kwargs):
        kwargs = self.parse_kwargs(self.collectors)
        self._data = self.bq.bdp(**kwargs)

    def set_data(self, data=None, **kwargs):
        data = data if data is not None else self._data
        for collector in self.collectors:
            collector._get_data(data)

    def refresh(self, *kwargs):
        self.get_data()
        self.set_data()

    @staticmethod
    def parse_kwargs(collectors):
        all_bdp_kwargs = {}
        for collector in collectors:
            for key, value in collector.get_bdp_kwargs().items():
                if key == 'fields':
                    if isinstance(value, list):
                        value = {val: val for val in value}
                    else:
                        value = {key: key for key, val in value.items()}
                    all_bdp_kwargs.setdefault(key, {})
                    all_bdp_kwargs[key].update(value)
                else:
                    all_bdp_kwargs.setdefault(key, [])
                    all_bdp_kwargs[key].extend(value)

        all_bdp_kwargs['securities'] = pd.Series(all_bdp_kwargs['securities']).str.lower().drop_duplicates().to_list()
        return all_bdp_kwargs


class BaseBBGCollector:
    '''
    Workflow:
        1. Each instance of BaseBBGCollector gets initialized with arguments and fields to pass to bq.bdp
        2. BBGCollectorHandler makes a unique list with securities and fields and makes a call to retireve all the fields
        3. BaseBBGCollector has the logic to extract from the entire dataframe, only the securities and fields that
           has requested.
        4.
    '''
    def __init__(self, bdp_kwargs=None, parse_fn=None, **kwargs):
        self.bdp_kwargs = deepcopy(bdp_kwargs) if bdp_kwargs else {}
        for key, value in self.bdp_kwargs.items():
            self.bdp_kwargs[key] = [val.lower() for val in value] if isinstance(value, (list, tuple)) else {
                k.lower(): val.lower() for k, val in value.items()}
        # self._column_names = self.bdp_kwargs['fields'] if isinstance(self.bdp_kwargs['fields'], dict) else {val: val for val in self.bdp_kwargs['fields']}
        self.parse_fn = parse_fn
        super().__init__(**kwargs)

    @property
    def _column_names(self):
        bdp_kwargs = self.get_bdp_kwargs()
        return bdp_kwargs['fields'] if isinstance(bdp_kwargs['fields'], dict) else {val: val for val in
                                                                                    bdp_kwargs['fields']}

    def get_bdp_kwargs(self, **kwargs):
        return self.bdp_kwargs

    # def get_data(self, data):
    #     return self._get_data(data)

    def _get_data(self, data):
        self._data = data.query(f"security in {self.get_bdp_kwargs()['securities']}").loc[:,
                     ['security', *self.get_bdp_kwargs()['fields']]]
        self._data = self._data.rename(self._column_names, axis=1)
        self._parsed_data = self._parse_data(self._data)
        self._post_get_data()

    def _post_get_data(self):
        pass

    def _parse_data(self, data):
        if self.parse_fn:
            return self.parse_fn(data)
        return data


class BaseBBGGridCollector(BaseBBGCollector, View):

    def __init__(self, title=None, **kwargs):
        super().__init__(**kwargs)
        self._title = title

        self._container = v.Container(
            fluid=True,
            children=[]
        )

    def _get_data(self, data):
        super()._get_data(data)
        grid = self._gh if hasattr(self, '_gh') else self.make_grid()
        self._update_grid_data(grid, self._parsed_data)

    def make_grid(self):
        self._make_grid()
        self._container.children = [self._gh.g]
        return self._gh

    def _make_grid(self):
        column_defs = {value: DEFAULT_BBG_FIELD_FORMATTERS[key] for key, value in self._column_names.items() if
                       key in DEFAULT_BBG_FIELD_FORMATTERS}
        self._gh = AGGridHandler(
            self._parsed_data,
            theme='ag-theme-balham-dark',
            column_defs=column_defs,
            title=self._title,
            grid_options=dict(
                domLayout='autoHeight'
            ),
            grid_kwargs=dict(
                sync_on_edit=True,
                height=-1,
                show_toggle_edit=False,
            )
        )
        return self._gh

    def _update_grid_data(self, grid, data):
        grid.g.update_grid_data(data)
        # if isinstance(grid, AGGridHandler):
        #     grid.g.update_grid_data(data)
        # else:
        #     grid.update_grid_data(data)

    @property
    def view(self):
        return self._container


class MTGGridCollector(BaseBBGGridCollector):
    def _make_grid(self):
        column_defs = {
            'security': {'hide': True},
            'date': {
                'valueFormatter': format_date(year="2-digit", month='short', day="numeric")
            },
            'px_last': {
                'valueFormatter': format_number(notation="compact", maximumFractionDigits=2, minimumFractionDigits=0),
                # 'cellStyle': format_threshold()
            },
            'hikes (bp)': {
                'valueFormatter': format_number(notation="compact", maximumFractionDigits=2, minimumFractionDigits=0),
                # 'cellStyle': format_threshold()
            },
            'chg (bp)': {
                'valueFormatter': format_number(notation="compact", maximumFractionDigits=2, minimumFractionDigits=0),
                'cellStyle': format_threshold()
            }
        }
        self._gh = AGGridHandler(
            self._parsed_data,
            theme='ag-theme-balham-dark',
            column_defs=column_defs,
            title=self._title,
            grid_options=dict(
                domLayout='autoHeight'
            ),
            grid_kwargs=dict(
                sync_on_edit=True,
                height=-1,
                show_toggle_edit=False,
            )
        )


