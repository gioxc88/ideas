import datetime
import json
from copy import deepcopy

import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay, DateOffset

from gioutils.utils import parse_offset, today, get_next_n, get_bday
from gioutils.gui.aggrid import format_number, format_date, AGGridHandler, format_threshold

from .bbg_collector import BaseBBGCollector, MTGGridCollector, BaseBBGGridCollector, BBGCollectorHandler

securities = [
    'CNPRTTLY Index',
    'CNPRETLY Index',
    'CPMICOMP Index',
    'CPMINDX Index',
    'CPMINMAN Index',
    'CHCUCAB Index',
    'MPMICNMA Index',
    'MPMICNCA Index',
    'MPMICNSA Index',
    'CNGFOREX Index',
    'CNMS2YOY Index',
    'CNMS0YOY Index',
    'CNLNNEW Index',
    'CNMS1YOY Index',
    'CNLNASF Index',
    'CNCPIYOY Index',
    'CHEFTYOY Index',
    'CNDIACRY Index',
    'CNTSECNY Index',
    'CNTSTCN Index',
    'CNFREXPY Index',
    'CNTSICNY Index',
    'CNFRIMPY Index',
    'CNFRBAL$ Index',
    'CHHEAVGM Index',
    'CHLLM1YR Index',
    'CHLLM1YV Index',
    'CNGDPYOY Index',
    'CNGDPQOQ Index',
    'CNGDPC$Y Index',
    'CHVAICY Index',
    'CHVAIOY Index',
    'CNRSACMY Index',
    'CNRSCYOY Index',
    'CNFAYOY Index',
    'CHRXCINY Index',
    'CHRXSARY Index',
    'CNUESRU Index',
    'CHLRLPR5 Index',
    'CHLRLPR1 Index',
    'CNFZNCC Index',
    'GRFIFINB Index',
    'GRGDARCL Index',
    'GRWPMOMI Index',
    'GRWPYOYI Index',
    'GRPFIMOM Index',
    'GRPFIYOY Index',
    'GRZEWI Index',
    'GRZECURR Index',
    'MPMIDEMA Index',
    'MPMIDESA Index',
    'MPMIDECA Index',
    'GRIFPBUS Index',
    'GRCP20YY Index',
    'GRCP20MM Index',
    'GRIFPEX Index',
    'GRCP2HYY Index',
    'GRIFPCA Index',
    'GRCP2HMM Index',
    'GRCP2NRM Index',
    'GRCP2NRY Index',
    'GRCP2SAM Index',
    'GRCP2SAY Index',
    'GRCP2BRM Index',
    'GRCP2BVY Index',
    'GRCP2HEM Index',
    'GRCP2BVM Index',
    'GRCP2HEY Index',
    'GRCP2BRY Index',
    'GRCP2BWY Index',
    'GRCP2BWM Index',
    'GRGDPPGQ Index',
    'ECO1GFKC Index',
    'GDPB95YY Index',
    'GRGDPPGY Index',
    'GRIMP95M Index',
    'GRIMP95Y Index',
    'GRGDPCQ Index',
    'GRGDGCIQ Index',
    'GRGDGCQ Index',
    'GRFRIAMM Index',
    'GRFRINYY Index',
    'GRUECHNG Index',
    'GRUEPR Index',
    'GRBTEXMM Index',
    'GRBTIMMM Index',
    'GRBTBALE Index',
    'MPMIDEXA Index',
    'GRIORTMM Index',
    'GEIOYY Index',
    'GRIPIMOM Index',
    'GEINYY Index',
    'GRCAEU Index',
    'SPIPCMOM Index',
    'SPIPCYOY Index',
    'SPCPEUMM Index',
    'SPCPEUYY Index',
    'SPIPCCYY Index',
    'SPIPCCMM Index',
    'SPTBEUBL Index',
    'SPHTHYOY Index',
    'SPMTCYOY Index',
    'SPMTHIYY Index',
    'SPROCHNG Index',
    'SPROYOY Index',
    'SPCAEURO Index',
    'MPMIESMA Index',
    'SPUECHNG Index',
    'MPMIESCA Index',
    'MPMIESSA Index',
    'SPIOYOY Index',
    'SPIOWSAY Index',
    'SPIOWSAM Index',
    'SPNPTHQ Index',
    'SPNPTHY Index',
    'SPRSWDSY Index',
    'SPRSRGIY Index',
    'SPLCTYY Index',
    'SPNAGDPQ Index',
    'SPNAGDPY Index',
    'SPUNEMPR Index',
    'EUGNEMUQ Index',
    'EUGNEMUY Index',
    'EMEMULYY Index',
    'EMEMULQQ Index',
    'EUITEMUM Index',
    'EUIPEMUY Index',
    'XTSBEZ Index',
    'XTTBEZ Index',
    'EUSATOTN Index',
    'EUCCEMU Index',
    'EUCPTSAM Index',
    'EUCPTWDY Index',
    'MPMIEZMA Index',
    'MPMIEZCA Index',
    'MPMIEZSA Index',
    'GRZEEUEX Index',
    'ECCPEMUY Index',
    'ECCPEMUM Index',
    'CPEXEMUY Index',
    'ECMAM3YY Index',
    'EUESEMU Index',
    'EUICEMU Index',
    'EUSCEMU Index',
    'ECCPEST Index',
    'UMRTEMU Index',
    'EUPPEMUY Index',
    'EUPPEMUM Index',
    'RSSAEMUM Index',
    'RSWAEMUY Index',
    'SNTEEUGX Index',
    'EUHNEMUQ Index',
    'NGVTEMUQ Index',
    'FCFNEMUQ Index',
    'EURR002W Index',
    'EUORDEPO Index',
    'EUORMARG Index',
    'LNTNEMUY Index',
    'EUDBEURO Index',
    'FRUEREUO Index',
    'FRUEREU Index',
    'FRCPIYOY Index',
    'FRCPEECY Index',
    'FRCPIMOM Index',
    'FRCPEECM Index',
    'FRCPXTOB Index',
    'BDFRTOTY Index',
    'MPMIFRMA Index',
    'MPMIFRSA Index',
    'MPMIFRCA Index',
    'INSESYNT Index',
    'INSESURV Index',
    'INSEPROD Index',
    'INSECOMP Index',
    'FRCCO Index',
    'FRGEGDPQ Index',
    'FRGEGDPY Index',
    'FRPIYOY Index',
    'FRPIMOM Index',
    'FRSNTTLM Index',
    'FRSNTTLY Index',
    'FRBDEURO Index',
    'FPIPMOM Index',
    'FPIPYOY Index',
    'FRMPMOM Index',
    'FRMPYOY Index',
    'FRPRPAYQ Index',
    'FRPRPRIQ Index',
    'FRTEBAL Index',
    'FFCAB12S Index',
    'FRWAMOQ Index',
    'FRQBMOP3 Index',
    'FRJSTQ Index',
    'UKUEMOM Index',
    'UKUEILOR Index',
    'UKUER Index',
    'UKAWMWHO Index',
    'UKAWXTOM Index',
    'UKLFEMCH Index',
    'UKPRLZVD Index',
    'UKPYPEMC Index',
    'UKRPCJYR Index',
    'UKRPCJMR Index',
    'UKHCA9IQ Index',
    'UKRPMOM Index',
    'UKRPYOY Index',
    'UKRPI Index',
    'UKRPXYOY Index',
    'UKLHUKY Index',
    'UKHCCPIY Index',
    'UKPPB7SY Index',
    'UKPPB7SM Index',
    'UKPPHIPY Index',
    'UKPPHIPM Index',
    'UKRVINFM Index',
    'UKRVINFY Index',
    'UKRVAMOM Index',
    'UKRVAYOY Index',
    'UKRMNAPM Index',
    'UKRMNAPY Index',
    'MPMIGBMA Index',
    'MPMIGBSA Index',
    'MPMIGBCA Index',
    'UKPSJ5II Index',
    'UKPSNB Index',
    'UKPSBR Index',
    'MTEF1C Index',
    'MTEF4C Index',
    'UKPSM98R Index',
    'DTSRR1RB Index',
    'DTSDD1RB Index',
    'UKCCI Index',
    'UKNBAAMM Index',
    'UKNBANYY Index',
    'LTSBBSBX Index',
    'UKMSVTVX Index',
    'UKMSM41Y Index',
    'UKMSM41M Index',
    'UKMSVTVJ Index',
    'BRCPALLY Index',
    'UKMS4QG Index',
    'UKMSB3PS Index',
    'UKMSB4TC Index',
    'UKCR Index',
    'UKBFFTIN Index',
    'MPMIGBXA Index',
    'UKVHRYY Index',
    'KPRSLFLS Index',
    'UKRXPBAL Index',
    'UKIPIMOM Index',
    'UKMPIMOM Index',
    'UKIPIYOY Index',
    'UKTBTTBA Index',
    'UKTBALEE Index',
    'UKMPIYOY Index',
    'UKISCT3M Index',
    'UKISCTMM Index',
    'UKGDM3M Index',
    'UKCNALSY Index',
    'UKCNALSM Index',
    'UKGDM3 Index',
    'UKTBGTEM Index',
    'UKTBTTEM Index',
    'UKBRBASE Index',
    'UKGRABIQ Index',
    'UKGRABIY Index',
    'UKCA Index',
    'UKGEABRQ Index',
    'UKBINPEQ Index',
    'UKGENMYQ Index',
    'UKGEIKKQ Index',
    'UKBINPEY Index',
    'UKGEIKLQ Index',
    'UKGENPTQ Index',
    'ITSR1B Index',
    'ITGGTOTE Index',
    'ITTRALEE Index',
    'ITTRALEX Index',
    'ITCAEUR Index',
    'ITCPEY Index',
    'ITCPI Index',
    'ITBCI Index',
    'ITPSSA Index',
    'ITESECSE Index',
    'ITISTSAM Index',
    'ITISTOTY Index',
    'MPMIITMA Index',
    'ITVHYOY Index',
    'ITBDNETE Index',
    'ITPIRAYY Index',
    'ITDDDEFY Index',
    'ITCPEM Index',
    'ITMUURS Index',
    'ITCPNICM Index',
    'ITCPNICY Index',
    'ITPIRLQS Index',
    'ITPIRLYS Index',
    'MPMIITCA Index',
    'MPMIITSA Index',
    'ITNSSTN Index',
    'ITNSTY Index',
    'ITPNIMOM Index',
    'ITPNIYOY Index',
    'ITPRSANM Index',
    'ITPRWAY Index',
    'ITPRNIY Index',
    'ITEMUNES Index',
    'ITDDGQ Index',
    'ITNHYOY Index',
    'ITNHMOM Index',
    'JNVHSYOY Index',
    'JGDPQGDP Index',
    'JGDPAGDP Index',
    'JGDFDEFY Index',
    'JGDOQOQ Index',
    'JGDPCIQ Index',
    'JGDPPCQ Index',
    'JGDPCPIN Index',
    'JGDPCNEX Index',
    'JNIPMOM Index',
    'JNIPYOY Index',
    'JNCAPMOM Index',
    'JNMOCHNG Index',
    'JNTIAMOM Index',
    'JNTBAL Index',
    'JNMOYOY Index',
    'JSIABOND Index',
    'JSIHSTCK Index',
    'JNTBALA Index',
    'JSIHBOND Index',
    'JNTBEXPY Index',
    'JSIASTCK Index',
    'JNTBIMPY Index',
    'JNC SALE Index',
    'MPMIJPMA Index',
    'MPMIJPCA Index',
    'MPMIJPSA Index',
    'JNMTOY Index',
    'JNPIY Index',
    'JNCPIYOY Index',
    'JNCPIXFF Index',
    'JCPNEFFE Index',
    'JNDSNYOY Index',
    'JNDSTYOY Index',
    'JNNETYOY Index',
    'JNRETMOM Index',
    'JNCICLEI Index',
    'JNRSYOY Index',
    'JNCICCOI Index',
    'JNHSYOY Index',
    'JNHSAN Index',
    'JNVNYOYS Index',
    'JNMBYOY Index',
    'JNVNIYOY Index',
    'JNMBMOBE Index',
    'JNCRPYOY Index',
    'JNSASYOY Index',
    'JNUE Index',
    'JNCPTXFF Index',
    'JBTARATE Index',
    'JNCPT Index',
    'JCOMSHCF Index',
    'JCPTEFFE Index',
    'JNLSUCTL Index',
    'JNLSUCRE Index',
    'JNBPAB Index',
    'JNBPTRD Index',
    'JNBPABA Index',
    'JNBLENDA Index',
    'JNBLBYOY Index',
    'JMNSM2Y Index',
    'JMNSM3Y Index',
    'JWCOOVSA Index',
    'JWEXOVSA Index',
    'JNWSDYOY Index',
    'JNWSDOM Index',
    'JHHSLERY Index',
    'MIKIMT07 Index',
    'BOJDPBAL Index',
    'BOJDPRLT Index',
    'JBSIBCLA Index',
    'JBSIBCLM Index',
    'JNTSMFG Index',
    'JTFIFILA Index',
    'JPTFLMFG Index',
    'JNTSNMFG Index',
    'JPTFLNMF Index',
    'JNTEMFG Index',
    'JPTFSMFG Index',
    'JNTENMFG Index',
    'JPTFSNMF Index',
    'JFYFGDPC Index',
    'JFYFCPI1 Index',
    'JFYFGDP2 Index',
    'JFYFGDP1 Index',
    'JFYFCPI2 Index',
    'JFYFCPIC Index',
    'CPI CHNG Index',
    'CPI YOY Index',
    'CPUPXCHG Index',
    'CPI XYOY Index',
    'SBOITOTL Index',
    'CPUPAXFE Index',
    'CPURNSA Index',
    'REALYRAE Index',
    'REALYRAW Index',
    'RSTAMOM Index',
    'MBAVCHNG Index',
    'IP CHNG Index',
    'EMPRGBCI Index',
    'FRNTTOTL Index',
    'RSTAXMOM Index',
    'FRNTTNET Index',
    'CPTICHNG Index',
    'RSTAXAG% Index',
    'USHBMIDX Index',
    'MTIBCHNG Index',
    'RSTAXAGM Index',
    'IPMGCHNG Index',
    'INJCJC Index',
    'NHSPSTOT Index',
    'FDIDFDMO Index',
    'OUTFGAF Index',
    'INJCSP Index',
    'FDIUFDYO Index',
    'FDIUSGYO Index',
    'FDIDSGMO Index',
    'NHSPATOT Index',
    'NHCHSTCH Index',
    'NHCHATCH Index',
    'FDIDSGUM Index',
    'FDIUSGUY Index',
    'NYBLCNBA Index',
    'LEI CHNG Index',
    'IMP1CHNG Index',
    'IMP1YOY% Index',
    'EXP1CMOM Index',
    'EXP1CYOY Index',
    'IMP1XPM% Index',
    'MPMIUSMA Index',
    'ETSLTOTL Index',
    'MPMIUSSA Index',
    'MPMIUSCA Index',
    'ETSLMOM Index',
    'PNMARADI Index',
    'FEDMMINU Index',
    'GDP CQOQ Index',
    'GDP PIQQ Index',
    'GDPCTOT% Index',
    'GDPCPCEC Index',
    'CFNAI Index',
    'KCLSSACI Index',
    'CONSSENT Index',
    'NHSLTOT Index',
    'PITLCHNG Index',
    'PCE CRCH Index',
    'PCE CMOM Index',
    'PCE CYOY Index',
    'PCE DEFY Index',
    'NHSLCHNG Index',
    'PCE CHNC Index',
    'PCE DEFM Index',
    'CONSPXMD Index',
    'CONSP5MD Index',
    'CONSEXP Index',
    'CONSCURR Index',
    'KCSSMCOM Index',
    'DGNOCHNG Index',
    'USPHTMOM Index',
    'DGNOXTCH Index',
    'DFEDGBA Index',
    'CGNOXAI% Index',
    'CGSHXAI% Index',
    'USPHTYOY Index',
    'CONCCONF Index',
    'CHPMINDX Index',
    'MWINCHNG Index',
    'RCHSINDX Index',
    'HPIMMOM% Index',
    'SPCS20Y% Index',
    'SPCSUSAY Index',
    'HPI PURQ Index',
    'SPCS20SM Index',
    'USTGTTCB Index',
    'RSRSTMOM Index',
    'CONCEXP Index',
    'CONCPSIT Index',
    'DSERGBCC Index',
    'RCSSCLBC Index',
    'NAPMPMI Index',
    'CNSTTMOM Index',
    'NAPMPRIC Index',
    'SAARTOTL Index',
    'NAPMNEWO Index',
    'NAPMEMPL Index',
    'PRODNFR% Index',
    'COSTNFR% Index',
    'NAPMNMI Index',
    'NAPMNPRC Index',
    'NAPMNNO Index',
    'NAPMNEMP Index',
    'TMNOCHNG Index',
    'TMNOXTM% Index',
    'CICRTOT Index',
    'MWSLCHNG Index',
    'ADP CHNG Index',
    'USTBTOT Index',
    'JOLTTOTL Index',
    'CHALYOY% Index',
    'NWORCHNG Index',
    'NFP TCH Index',
    'USURTOT Index',
    'FDDSSD Index',
    'USMMMNCH Index',
    'AHE YOY% Index',
    'AHE MOM% Index',
    'NFP PCH Index',
    'AWH TOTL Index',
    'USUDMAER Index',
    'PRUSTOT Index',
    'ECONGECC Index',
    'FDTR Index',
    'FDTRFTRL Index',
    'IRRBIOER Index',
    'USCABAL Index',
    'ECI SA% Index'
]

fields = {
    'region_or_country': 'country',
    'long_comp_name': 'name',
    'observation_period': 'period',
    'relevance_value': 'relevance',
    'rt_bn_survey_median': 'median',
    'prev_close_val': 'prev',
    'first_revision': 'revision',
    'last_update_dt': 'last_update_dt',
    'eco_release_dt': 'eco_release_dt',
    'eco_release_time': 'eco_release_time',
    # 'previous_trading_date',
    'prev_trading_dt_realtime': 'prev_trading_dt_realtime',
    'prior_observation_date': 'prior_observation_date',
    'cr_observation_date': 'cr_observation_date',
    # 'eco_future_release_date_list',
    'eco_future_release_date': 'eco_future_release_date',
    'bn_survey_median': 'bn_survey_median',
    # 'bn_survey_average',
    # 'rt_bn_survey_average',
    # 'bn_survey_high',
    # 'rt_bn_survey_high',
    # 'bn_survey_low',
    # 'rt_bn_survey_low',
    # 'bn_survey_number_observations',
    'px_last': 'px_last',
    'actual_release': 'actual_release',
    # 'last price',
}


def get_today_formatter(col='release_time', style1=None, style2=None):
    style1 = style1 or {'background-color': '#EAFFF1'}
    style2 = style2 or {'background-color': '#E5EEF7'}
    fn = f'''function(params){{
        let now = new Date();
        let today = new Date();
        let date = new Date(params.data.{col});
        let date1 = new Date(date);
        today.setHours(0, 0, 0, 0);
        date1.setHours(0, 0, 0, 0);
      
        if ((date >= now) && (date1.getTime() === today.getTime())){{
            return {style1};
        }} else if (date1.getTime() === today.getTime()) {{ 
            return {style2}
        }}
        return "" 
    }}'''
    return fn


def get_relevance_formatter(threshold1=60, threshold2=80):
    fn = f'''
    function formatter(params) {{
      const {{ yValue }} = params;
      return {{
        fill: yValue <= {threshold1} ? '#4fa2d9' : yValue < {threshold2} ? '#277cb5' : '#195176',
      }};
    }}
    '''
    return fn


def get_miss_formatter(threshold=0):
    fn = f'''
    function formatter(params) {{
      const {{ yValue }} = params;
      return {{
        fill: yValue <= {threshold} ? 'red' : 'green',
      }};
    }}
    '''
    return fn


def get_main_formatter(
        col1='median',
        col2='actual',
        positive_style=None,
        negative_style=None,
        base_style=None
):
    base_style = base_style or {'font-weight': 'bold', 'font-size': '150%'}
    positive_style = {**base_style, **(positive_style or {'color': 'green'})}
    negative_style = {**base_style, **(negative_style or {'color': 'red'})}
    fn = f'''
    function formatter(params) {{
      let v1 = params.data.{col1};
      let v2 = params.data.{col2};
      
      console.log(v1, v2, typeof(v1), typeof(v2));
      
      if (
       isNaN(v1) || isNaN(v2) || 
       typeof(v1) === 'string' || 
       typeof(v2) === 'string' || 
       typeof(v1) === 'undefined' || 
       typeof(v2) === 'undefined' || 
       v1 === null || 
       v2 === null
       )  {{
        return {base_style}
      }}
      
      if (v1 < v2) {{
        return {negative_style}
      }} else if (v1 > v2) {{
        return {positive_style}
      }} else {{
        return {base_style}
      }}

    }}
    '''
    return fn


class ECOCalendar(BaseBBGGridCollector):
    def __init__(self, date=None, **kwargs):
        self.date = pd.to_datetime(date) if date else today()
        super().__init__(**kwargs)

    def get_bdp_kwargs(self, **kwargs):
        if self.date < today():
            return {}
        kw = deepcopy(self.bdp_kwargs)
        if hasattr(self, '_ref_'):
            kw['securities'] = [
                *self._ref_.query(f"'{today():%Y-%m-%d}' <= release_date <= '{today() + BDay():%Y-%m-%d}'").index]
        kw['fields'] = ['px_last']

        return kw

    def _get_data(self, data):
        if self.date < today():
            return
        super(BaseBBGGridCollector, self)._get_data(data)

        grid = self._gh if hasattr(self, '_gh') else self._make_grid()
        self._update_grid_data(grid, self._ref_.loc[:, :'first_revision'].rename(self.bdp_kwargs['fields'], axis=1))

    def initialize(self, bq=None):
        date = self.date
        tickers = self.bdp_kwargs['securities']
        fields = [*self.bdp_kwargs['fields']]

        miss = bq.bdh(tickers, fields=['actual_release', 'bn_survey_median'], history='13y', end_date=None, options={})
        miss['diff'] = miss['actual_release'] - miss['bn_survey_median']
        des = miss.query(f'date <= "{date:%Y-%m-%d}"').groupby('security', sort=False)['diff'].agg(['mean', 'std']).dropna()

        self.miss = miss
        self.miss_des = des

        ref = bq.bdp(tickers, fields, options={})
        future_release_date = bq.bdp(securities=tickers, fields=['eco_future_release_date'],
                                     overrides=[('start_dt', f"{today():%Y%m%d}")])
        ref['eco_future_release_date_override'] = future_release_date['eco_future_release_date']
        ref['eco_future_release_date'] = pd.to_datetime(ref['eco_future_release_date'], errors='coerce')
        ref['_future_release_date'] = pd.to_datetime(ref['eco_future_release_date_override'], errors='coerce').fillna(
            ref['eco_release_dt'])

        if date < today():
            pass
            date_list = bq.bdp(
                securities=pd.Series(tickers).str.lower().to_list(),
                fields=['eco_future_release_date'],
                overrides=[
                    ('start_dt', f"{date:%Y%m%d}"),
                    # ('end_dt', f"{date + DateOffset(years=1):%Y%m%d}")
                ]
            )
            date_list['eco_future_release_date'] = pd.to_datetime(date_list['eco_future_release_date'])
            date_list['release'] = pd.to_datetime(date_list['eco_future_release_date']).dt.floor('d')
            offset = (ref.set_index('security')['_future_release_date'].dt.floor('d') - ref.set_index('security')[
                'cr_observation_date']).rename('offset').reset_index()

            offset2 = (
                    ref.set_index('security')['_future_release_date'].dt.floor('d') -
                    ref.set_index('security')['cr_observation_date'] - (
                            ref.set_index('security')['cr_observation_date'] -
                            ref.set_index('security')['prior_observation_date']
                    )
            ).rename('offset').reset_index()

            offset.loc[ref['_future_release_date'].dt.floor('d') == ref['eco_future_release_date'].dt.floor('d')] = \
                offset2[ref['_future_release_date'].dt.floor('d') == ref['eco_future_release_date'].dt.floor('d')]

            offset.loc[offset['offset'].dt.days < 0, 'offset'] = offset.loc[offset['offset'].dt.days < 0, 'offset'] * -1

            hist = miss.merge(date_list.merge(offset, on='security'), on='security', how='left')
            hist['period'] = (hist['release'] - hist['offset']) + BDay() - BDay()
            hist['offset'] = hist['offset'].dt.days

            current = hist.query(f'date >= period and release >= "{date:%Y-%m-%d}"').groupby('security', sort=False,
                                                                                             as_index=False).first().set_index(
                'security').loc[:, ['release', 'eco_future_release_date', 'date', 'bn_survey_median', 'actual_release']]
            prior = hist.query(f'date < period and release >= "{date:%Y-%m-%d}"').groupby('security', sort=False,
                                                                                           as_index=False).last().set_index(
                'security').loc[:, 'actual_release', ].rename('prev_close_val')
            final_hist = pd.concat([current, prior], axis=1).rename(
                {
                    'eco_future_release_date': 'release_time',
                    'release': 'release_date',
                    'date': 'observation_period',
                    'bn_survey_median': 'rt_bn_survey_median',
                    'actual_release': 'px_last'

                }, axis=1
            )

            final_hist['observation_period'] = final_hist['observation_period'].dt.strftime('%#d-%b-%y')

            self._hist= hist
            self._date_list = date_list
            self._final_hist = final_hist

        self._ref = ref
        self._post_initialize()
        return self

    def _post_initialize(self):
        ref = self._ref
        des = self.miss_des
        date = self.date
        release_date = pd.to_datetime(
            [
                datetime.datetime.combine(row['_future_release_date'], row['eco_release_time'])
                for index, row in
                pd.concat([ref['_future_release_date'].dt.floor('d'), ref['eco_release_time'].fillna(datetime.time())],
                          axis=1).iterrows()
            ], errors='coerce'
        ).to_series().rename('release_date').reset_index(drop=True)
        release_time = release_date.rename('release_time')

        ref_ = pd.concat([release_date, release_time, ref], axis=1).set_index('security')
        ref_ = pd.merge(ref_, des, left_index=True, right_index=True, how='left').drop('eco_release_time', axis=1)
        ref_['release_date'] = ref_['release_date'].dt.floor('d')

        ref_['_relevance'] = ref_['relevance_value']
        ref_['relevance_value'] = ref_['_relevance'].map(lambda x: [x])
        if date >= today():
            actual = ref_['px_last'].mask((ref_['release_time'] >= pd.Timestamp.now()) | ref_['release_date'].isnull(),
                                          np.nan).rename('actual')
            # print('date today')
        else:
            ref_ = ref_.copy()
            ref_.update(self._final_hist)
            actual = ref_['px_last'].rename('actual')
            # ref_['release_time'] = ref_['eco_future_release_date_list_override']
            # ref_['release_date'] = ref_['release_time'].dt.floor('d')
            # print('date < today')

        self._actual = actual
        miss_ = (actual - ref_['rt_bn_survey_median'] - ref_['mean']) / (ref_['std'])
        ref_['_miss'] = miss_
        ref_ = pd.concat([
            ref_.loc[:, :'relevance_value'],
            miss_.rename('miss').map(lambda x: [x]),
            ref_.loc[:, 'rt_bn_survey_median'],
            actual,
            ref_.loc[:, 'prev_close_val':]

        ], axis=1)

        self._ref_ = ref_.sort_values(['release_date', 'region_or_country', 'release_time'])
        self.make_grid()
        return self

    def _post_get_data(self, **kwargs):
        date = self.date
        if date < today():
            return

        # here I update the price after downloading from bbg
        self._ref_.loc[self._data['security'], self._data.drop('security', axis=1).columns] = self._data.drop(
            'security', axis=1).to_numpy()

        self._ref_['actual'] = self._ref_['px_last'].mask(
            (self._ref_['release_time'] >= pd.Timestamp.now()) | self._ref_['release_date'].isnull(), np.nan)
        self._ref_['_miss'] = ((self._ref_['actual'] - self._ref_['rt_bn_survey_median'] - self._ref_['mean']) / (
            self._ref_['std']))
        self._ref_['miss'] = self._ref_['_miss'].map(lambda x: [x])

    def _make_grid(self, **kwargs):
        self._gh = self._ref_.loc[:, :'first_revision'].rename(self.bdp_kwargs['fields'], axis=1).aggrid(
            height=600,
            index=True,
            grid_kwargs=dict(show_toggle_edit=False),
            grid_options={
                # 'sideBar': 'filters',
                'getRowStyle': get_today_formatter(),
            },
            column_defs={
                'release_time': {
                    'valueFormatter': format_date(hour="2-digit", minute='2-digit')
                },
                'relevance': {
                    'filter': 'agNumberColumnFilter',
                    'cellRenderer': 'agSparklineCellRenderer',
                    'cellRendererParams': {
                        'sparklineOptions': {
                            'type': 'bar',
                            'fill': '#5470c6',
                            'stroke': '#91cc75',
                            'highlightStyle': {
                                'fill': '#fac858',
                            },
                            'valueAxisDomain': [0, 100],
                            'paddingOuter': 0,
                            'padding': {
                                'top': 0,
                                'bottom': 0,
                            },
                            'axis': {
                                'strokeWidth': 0,
                            },
                            'formatter': get_relevance_formatter()
                        },
                    },
                },
                'miss': {
                    'cellRenderer': 'agSparklineCellRenderer',
                    'cellRendererParams': {
                        'sparklineOptions': {
                            'type': 'bar',
                            'fill': '#5470c6',
                            'stroke': '#91cc75',
                            'highlightStyle': {
                                'fill': '#fac858',
                            },
                            'valueAxisDomain': [-4, 4],
                            'paddingOuter': 0,
                            'padding': {
                                'top': 0,
                                'bottom': 0,
                            },
                            'axis': {
                                'strokeWidth': 0,
                            },
                            'formatter': get_miss_formatter()
                        },
                    },
                },
                'median': {'cellStyle': get_main_formatter()},
                'actual': {'cellStyle': get_main_formatter('actual', 'prev')},
                'prev': {'cellStyle': {'font-weight': 'bold', 'font-size': '150%'}},
            }
        )._gh

        return self._gh


from inflection import underscore
def get_speakers_grid():
    speakers = pd.read_excel('M:\BHCM\Trading\TeamMB\speakers.xlsx').iloc[:-1, [0, 1, 4]].rename(
        {'Unnamed: 1': 'Country'}, axis=1).dropna()
    speakers['Date Time'] = pd.to_datetime(speakers['Date Time'])
    speakers = speakers.set_axis([underscore(col) for col in speakers.columns.str.replace(r'\s+', '', regex=True)],
                                 axis=1)

    gh = speakers.aggrid(
        column_defs={
            'date_time': {
                'valueFormatter': format_date(year="2-digit", month='short', day="numeric", hour="2-digit",
                                              minute='2-digit')
            },
        },
        grid_kwargs=dict(show_toggle_edit=False),
        grid_options={
            # 'sideBar': 'filters',
            'getRowStyle': get_today_formatter('date_time'),
        },
        index=False
    )
    return gh

