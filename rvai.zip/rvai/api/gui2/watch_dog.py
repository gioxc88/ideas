

import base64
import json
import logging
import os
import re
import smtplib
import sys
import time
import threading
from functools import partial
from itertools import chain
from importlib import reload
from pathlib import Path
from uuid import uuid4
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart

import bhutils
import blpapi
import ipyvuetify as v
import ipywidgets as w
import numpy as np
import pandas as pd
import clarion
import QuantLib as ql
import dataframe_image as dfi
import win32com.client as win32
from bqplot import ColorScale, LinearScale, OrdinalColorScale, OrdinalScale
from ipydatagrid import BarRenderer, DataGrid, Expr, TextRenderer, VegaExpr
from IPython.display import display, clear_output
from pandas.tseries.offsets import BDay
from plotly import graph_objects as go
from plotly.subplots import make_subplots
from blp.blp import BlpParser

from api.watchdog import specs
from api.watchdog.specs import get_trades, get_targets, get_metrics
from api.watchdog.pricer import Pricer
from api.email import smtp_server, to_email_test, to_email_all, df_to_html, from_email, to_email_ext, get_email
from gioutils.clarion_ext import Runner
from gioutils.gui.pandas import millifyp as millify
from gioutils import ezutils as ez
from gioutils.blpw import BlpParser, BlpQuery
from gioutils.clarion_ext import super_clarion
from gioutils.tools import parse_swap_periods
from gioutils.ezutils import (
    bh,
    bhs,
    get_id,
    get_price_info,
)

from gioutils.utils import (
    get_bday,
    get_next_n,
    parse_offset,
    today,
    get_generic_future,
    get_bbg_fut_chain_ticker,
    get_root,
    encode_df_as_image_tag
)
from gioutils.gui.base import View

pd.options.plotting.backend = "plotly"
pd.options.display.float_format = partial(millify, pct=None, decimal=4)


def highlight_cond(df, props, col):
    d = pd.DataFrame(None, df.index, df.columns)
    d.loc[df[col]] = props
    return d


def highlight_target(df, props=None):
    d = pd.DataFrame(None, df.index, df.columns)
    for index, row in df.iterrows():
        props = 'background-color:red; color: Gold; font-weight: bold;' if row[
            'breach'] else 'color: DarkOrange; font-weight: bold;'
        d.loc[index, ['target', row['var']]] = props
    return d


def send_watch_email(s1, s2, to='test'):
    to_email = get_email(to)

    message = MIMEMultipart("alternative")
    message["Subject"] = f'TRADE WATCH - {pd.Timestamp.now(): %d%b%y %H:%M}'
    message["From"] = from_email
    message["To"] = ','.join(to_email)
    img_tags = [encode_df_as_image_tag(s) for s in [s1, s2]]

    html_body = '<br>' + img_tags[0] + ('<br>' * 5) + img_tags[1]
    html_ = MIMEText(html_body, "html")
    message.attach(html_)
    smtp = smtplib.SMTP(smtp_server)
    # smtp.set_debuglevel(1)
    smtp.sendmail(from_email, to_email, message.as_string())


def send_breach_email(s, to='test'):
    to_email = get_email(to)
    message = MIMEMultipart("alternative")
    message["Subject"] = f'TRADE WATCH BREACH- {pd.Timestamp.now(): %d%b%y %H:%M}'
    message["From"] = from_email
    message["To"] = ','.join(to_email)
    html_body = '<br>' + df_to_html(s) + ('<br>' * 5)
    html_ = MIMEText(html_body, "html")
    message.attach(html_)
    smtp = smtplib.SMTP(smtp_server)
    # smtp.set_debuglevel(1)
    smtp.sendmail(from_email, to_email, message.as_string())


table_styles = {
    'tr, td': [
        ('white-space', 'nowrap'),
    ],
    'th': [
        ('white-space', 'nowrap')
    ],
    'td': [
        ('white-space', 'nowrap')
    ],
}
table_styles = [{"selector": sel, 'props': '; '.join([': '.join(p) for p in props])} for sel, props in
                table_styles.items()]


def style_watch(watch):
    style = watch.style.apply(highlight_cond, props='background-color:red; color: white; font-weight: bold;',
                              col='breach', axis=None) \
        .apply(highlight_target, axis=None) \
        .format(na_rep='') \
        .format(
        partial(millify, decimal=3, pct=None, zero_rep='-'),
        subset=watch.columns[watch.dtypes == 'float64'].drop('target')
    ) \
        .format(
        partial(millify, decimal=3, pct=None, zero_rep='0'),
        subset='target'
    ) \
        .set_table_styles(table_styles) \
        .set_caption('Trades and triggers')
    return style


def style_details(details):
    style = details.style.format(na_rep='').format(
        partial(millify, decimal=3, pct=None, zero_rep='-'),
        subset=details.columns[details.dtypes == 'float64']
    )
    indices = details.groupby('trade', sort=False).apply(lambda df: df.index[-1])
    style = style.hide(subset=details.columns[details.columns.str.startswith('_')], axis=1).set_sticky(axis=1) \
        .set_table_styles(table_styles) \
        .set_table_styles({i: [{'selector': '', 'props': 'border-bottom: 3px solid red;'}] for i in indices}, axis=1,
                          overwrite=False) \
        .set_caption('Details')
    return style


def convert_seconds(s, to='m'):
    mult = {'m': 60, 'h': 3600}
    return s / mult.get(to, 1)


def fn(
        pricer,
        runner,
        out1,
        out2,
        out3,
        event,
        do_one=False
):
    last_update = time.ctime()
    last_email_sent = time.time()
    p = pricer
    while True:
        if event.is_set():
            break
        try:
            reload(specs)
            from api.watchdog.specs import get_trades, get_targets
            trades = get_trades(clarion)
            targets = get_targets()
            p.get_data(runner, trades, targets, metrics=[*get_metrics(clarion).values()])
            clear_output()
            last_update = time.ctime()
            s1 = style_watch(p.watch)
            s2 = style_details(p.res)
            # clear_output()
            # out.clear_output(wait=True)
            out1.outputs = ()
            out1.append_display_data(last_update)
            out1.append_display_data(s1)
            out2.outputs = ()
            out2.append_display_data(last_update)
            out2.append_display_data(s2)

            breach_email_df = []
            for name in targets:
                if targets[name].get('send_email', False) and p.watch.loc[name, 'breach']:
                    breach_email_df.append(p.watch.loc[name, :])

            breach_email_df = pd.DataFrame(breach_email_df)
            if not breach_email_df.empty and (convert_seconds(time.time() - last_email_sent, to='m') >= 15):
                send_breach_email(style_watch(breach_email_df))

            # display(out)
            # break
            if not do_one:
                time.sleep(30)
        except Exception as e:
            # return s1
            # raise e
            # clear_output()
            out1.outputs = ()
            out1.append_display_data(f"BROKEN: {last_update}")
            out1.append_display_data(s1)
            out2.outputs = ()
            out2.append_display_data(f"BROKEN: {last_update}")
            out2.append_display_data(s2)
            out3.outputs = ()
            out3.append_display_data(f"BROKEN: {last_update}")
            out3.append_display_data(e)
            time.sleep(5)
            clarion.server_login()
        if do_one:
            break


class Dog(View):

    def __init__(self, clarion, **kwargs):
        self.clarion = clarion
        self.runner = Runner(clarion)
        self.pricer = Pricer()
        self._started = False
        super().__init__(**kwargs)

        if kwargs.get('start'):
            self.start_stop()
            clear_output()

    def make_widgets(self, **kwargs):
        self.out_summary = w.Output(layout={'overflow-x': 'auto'})
        self.out_details = w.Output(layout={
        'overflow-x': 'auto',
        # 'overflow-y': 'auto',
        # 'height': '700px'
    })
        self.out_error = w.Output(layout={'overflow-x': 'auto'})
        self.btn = w.Button(description='stop', layout={'width': '100px', 'border': '1px solid', 'margin': '0 0 5px 0'})

    def make_view(self, **kwargs):
        children = [self.out_summary, self.out_details, self.out_error]
        self.tabs = w.Tab(children=children, titles=['watchdog', 'details', 'errors'])

        self.view = w.VBox(
            [
                self.btn,
                self.tabs
            ]
        )

    def link(self, **kwargs):
        self.btn.on_click(lambda b: self.start_stop())

    def start_stop(self):
        if not self._started:
            self.event = threading.Event()
            self.thread = threading.Thread(target=fn, kwargs={
                'pricer': self.pricer,
                'runner': self.runner,
                'out1': self.out_summary,
                'out2': self.out_details,
                'out3': self.out_error,
                'event': self.event,
                # 'send_email_now': True,
            })
            self.thread.start()
            self._started = True
            self.btn.description = 'stop'
        else:
            self.event.set()
            self._started = False
            self.btn.description = 'start'



class Dog2(View):

    def __init__(self, clarion, **kwargs):
        self.clarion = clarion
        self.runner = Runner(clarion)
        self.pricer = Pricer()
        self._started = False
        super().__init__(**kwargs)

        if kwargs.get('start'):
            self.start_stop()
            clear_output()

    def make_widgets(self, **kwargs):
        self.out_summary = w.Output(layout={'overflow-x': 'auto'})
        self.out_details = w.Output(layout={
        'overflow-x': 'auto',
        # 'overflow-y': 'auto',
        # 'height': '700px'
    })
        self.out_error = w.Output(layout={'overflow-x': 'auto'})
        self.btn = w.Button(description='stop', layout={'width': '100px', 'border': '1px solid', 'margin': '0 0 5px 0'})

    def make_view(self, **kwargs):
        children = [self.out_summary, self.out_details, self.out_error]
        self.tabs = w.Tab(children=children, titles=['watchdog', 'details', 'errors'])

        self.view = w.VBox(
            [
                self.btn,
                self.tabs
            ]
        )

    def link(self, **kwargs):
        self.btn.on_click(lambda b: self.start_stop())

    def start_stop(self):
        if not self._started:
            self.event = threading.Event()
            self.thread = threading.Thread(target=fn, kwargs={
                'pricer': self.pricer,
                'runner': self.runner,
                'out1': self.out_summary,
                'out2': self.out_details,
                'out3': self.out_error,
                'event': self.event,
                # 'send_email_now': True,
            })
            self.thread.start()
            self._started = True
            self.btn.description = 'stop'
        else:
            self.event.set()
            self._started = False
            self.btn.description = 'start'