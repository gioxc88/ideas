import re
from uuid import uuid4

import pandas as pd

from gioutils.ezutils import bh_get_ts
from gioutils.utils import get_counter


counter = get_counter()


def get_random_name():
    return f'v__{counter.get_id()}'
    return f'v__{uuid4().hex}'


def parse_one_expr(expr, prev_names=None, final_map=None):
    final_map = final_map or {}
    name_map = {}
    sb_pattern = re.compile(r"\[.+?\]+")
    new_e = expr
    for one_expr in sb_pattern.findall(expr):
        one_expr = one_expr.lower()
        name_map.setdefault(
            one_expr.replace('[', '').replace(']', ''),
            final_map.get(one_expr.replace('[', '').replace(']', ''), get_random_name())
        )
        new_e = new_e.replace(one_expr, name_map[one_expr.replace('[', '').replace(']', '')])
    for prev_name in prev_names:
        if f'v__{prev_name}' not in new_e:
            new_e = new_e.replace(prev_name, f'v__{prev_name}')
    return name_map, new_e


def parse_expressions_components(expressions):
    final_map = {}
    new_expressions = {}
    all_names = [*expressions]

    for i, (name, expr) in enumerate(expressions.items()):
        name_map, new_expr = parse_one_expr(expr, prev_names=all_names[:i], final_map=final_map)
        new_expressions.setdefault(f"v__{name}", new_expr)
        for k, v in name_map.items():
            final_map.setdefault(k, v)
    return final_map, new_expressions


def get_components_ts(components, **kwargs):
    components_df = []
    for expr, name in components.items():
        components_df.append(bh_get_ts(expr=expr, **kwargs))
    return pd.concat(components_df, axis=1)


def get_expressions_data(expressions, **kwargs):
    try:
        components, new_expressions = parse_expressions_components(expressions)
        components_ts = get_components_ts(components, **kwargs)
        final_df = components_ts

        for comp, new_name in components.items():
            locals()[new_name] = components_ts[comp]

        for new_name, expr in new_expressions.items():
            new_var = eval(expr).rename(new_name.replace('v__', ''))
            locals()[new_name] = new_var
            final_df = final_df.assign(**{new_var.name: new_var})
    except Exception as e:
        print(e)
        return (components, new_expressions, components_ts, final_df, e)

    return final_df
