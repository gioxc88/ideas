import re
import copy
from uuid import uuid4

import pandas as pd
from IPython.display import display

from gioutils.ezutils import bh_get_ts, get_irbt_ts


def get_random_name():
    return f'v__{uuid4().hex}'


def parse_one_expr(expr, prev_names=None, final_map=None):
    final_map = final_map or {}
    name_map = {}
    sb_pattern = re.compile(r"\[.+?\]+")
    new_e = expr
    for one_expr in sb_pattern.findall(expr):
        one_expr = one_expr.lower()
        name_map.setdefault(
            one_expr.replace('[', '').replace(']', ''),
            final_map.get(one_expr.replace('[', '').replace(']', ''), get_random_name())
        )
        new_e = new_e.lower().replace(one_expr, name_map[one_expr.replace('[', '').replace(']', '')])

    new_e = f' {new_e.strip()} '
    for prev_name in prev_names:
        if f'v__{prev_name}' not in new_e:
            # change this from space to any character that is not a-zA-Z, basically symbols and spaces

            new_e = re.sub(rf'([^\w]+)({prev_name})([^\w]+)', rf'\1v__{prev_name}\3', new_e)
            # new_e = new_e.replace(f" {prev_name} ", f'v__{prev_name}')
    return name_map, new_e


def parse_expressions_components(expressions):
    final_map = {}
    new_expressions = {}
    all_names = [*expressions]

    for i, (name, expr) in enumerate(expressions.items()):
        if isinstance(expr, str):
            name_map, new_expr = parse_one_expr(expr, prev_names=all_names[:i], final_map=final_map)
            new_expressions.setdefault(f"v__{name}", new_expr)
            for k, v in name_map.items():
                final_map.setdefault(k, v)
    return final_map, new_expressions


def get_components_ts(components, **kwargs):
    if not components:
        return pd.DataFrame()
    components_df = []
    for expr, name in components.items():
        components_df.append(bh_get_ts(expr=expr, **kwargs))
    return pd.concat(components_df, axis=1)


def get_irbt_components_ts(expressions, **kwargs):
    if not expressions:
        return pd.DataFrame()
    components_df = []
    for name, expr in expressions.items():
        if isinstance(expr, dict):
            components_df.append(
                get_irbt_ts(
                    **expr,
                    **{key: val for key, val in kwargs.items() if key != 'bq'}).rename(f'{name}')
            )
        elif isinstance(expr, (list, tuple)):
            components_df.append(
                get_irbt_ts(*expr,
                            **{key: val for key, val in kwargs.items() if key != 'bq'}
                            ).rename(f'{name}')
            )
    return pd.concat(components_df, axis=1) if components_df else pd.DataFrame()


def get_expressions_data(expressions, **kwargs):
    components, new_expressions = parse_expressions_components(expressions)
    components_ts = get_components_ts(components, **kwargs)
    components_irbt_ts = get_irbt_components_ts(expressions, **kwargs)
    components_ts = pd.concat([components_ts, components_irbt_ts], axis=1)
    final_df = components_ts.copy()

    for comp, new_name in components.items():
        locals()[new_name] = final_df[comp]

    for name, expr in expressions.items():
        if isinstance(expr, (dict, tuple)):
            locals()[f"v__{name}"] = final_df[name]

    for new_name, expr in new_expressions.items():
        new_var = eval(expr).rename(new_name.replace('v__', ''))
        locals()[new_name] = new_var
        final_df = final_df.assign(**{new_var.name: new_var})
    return components_ts, final_df.drop([*components_ts.columns], axis=1)


class ExpressionHandler:
    def __init__(self, expressions=None, **kwargs):
        self.expressions = expressions or {}
        self.kwargs = kwargs
        self.components_data = pd.DataFrame()

    @property
    def data(self):
        return pd.concat([self.components_data, self.expressions_data], axis=1)

    def get_data(self, expressions=None, **kwargs):

        kwargs_ = copy.deepcopy(self.kwargs)
        kwargs_.update(kwargs)
        kwargs = kwargs_

        expressions = expressions or self.expressions
        if not expressions:
            return
        self.expressions = expressions
        components, new_expressions = parse_expressions_components(expressions)

        self._components, self._new_expressions = components, new_expressions
        new_components = {name: value for name, value in components.items() if name not in self.components_data}

        if new_components:
            components_ts = get_components_ts(new_components, **kwargs)
        else:
            components_ts = self.components_data

        components_irbt_ts = get_irbt_components_ts(expressions, **kwargs)
        components_ts = pd.concat(
            [
                components_ts,
                components_irbt_ts
            ],
            axis=1
        ).T.drop_duplicates().T
        final_df = components_ts.copy()

        for comp, new_name in components.items():
            locals()[new_name] = final_df[comp]

        for name, expr in expressions.items():
            if isinstance(expr, (dict, tuple)):
                locals()[f"v__{name}"] = final_df[name]

        for new_name, expr in new_expressions.items():
            new_var = eval(expr).rename(new_name.replace('v__', ''))
            locals()[new_name] = new_var
            final_df = final_df.assign(**{new_var.name: new_var})

        self.parsed_expressions = (components, new_expressions)
        self.components_data = components_ts
        self.expressions_data = final_df.drop([*components_ts.columns], axis=1)
        return self.expressions_data