from gioutils.blpw import BlpQuery
from blp.blp import BlpParser


class Providers:
    BQ = BlpQuery(timeout=50000, parser=BlpParser(raise_security_errors=False)).start()
