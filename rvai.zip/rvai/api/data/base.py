from pathlib import Path

import numpy as np
import pandas as pd


if Path('/dev/projects/menashe').exists():
    root_path = Path('/dev/projects/menashe')
else:
    root_path = Path('/dev/projects/rvai')
shared_path = Path('//rivagecapital.com/Root/BHCM/Trading/TeamMB')
data_path = shared_path / 'data'
logs_path = root_path / 'data/logs'
radar_path = data_path / 'radar'


