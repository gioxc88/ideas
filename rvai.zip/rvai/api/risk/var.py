import base64
import json
import logging
import os
import re
import sys
import time
import threading
from functools import partial
from itertools import chain
from numbers import Number
from pathlib import Path
from uuid import uuid4

import bhutils
import blpapi
import ipyvuetify as v
import ipywidgets as w
import numpy as np
import pandas as pd
import clarion
from pandas.tseries.offsets import BDay
from IPython.display import display

from gioutils.clarion_ext import Runner
from gioutils.gui.pandas import millifyp as millify
from gioutils import ezutils as ez
from gioutils.blpw import BlpParser, BlpQuery
from gioutils.clarion_ext import super_clarion
from gioutils.tools import parse_swap_periods, parse_swap_period
from gioutils.tools_clarion import get_clarion_positions

from gioutils.ezutils import (
    bh,
    bhs,
    get_id,
    get_price_info,
    SQL
)

from gioutils.utils import (
    get_bday,
    get_next_n,
    parse_offset,
    today,
    get_generic_future,
    get_bbg_fut_chain_ticker,
    get_root
)

pd.options.plotting.backend = "plotly"
pd.options.display.float_format = partial(millify, pct=None, decimal=4)


def get_var_query(asof=None, book="MM", offset="522b", horizon='1d'):
    dt_fmt = "%Y%m%d"
    asof = pd.to_datetime(asof) if asof else today() - BDay()
    query = (
        f"SELECT "
        f"p.fund, "
        f"p.book, "
        f"p.strategy, "
        f"p.minnb, "
        f"p.positionName, "
        f"p.riskCategory, "
        f"p.tradeGroup, "
        f"p.currency, "
        f"p.instrument, "
        f"p.underlying_name, "
        f"p.nominal, "
        f"p.nominal1, "
        f"p.delta, "
        f"p.rateTrade, "
        f"p.bhType, "
        f"p.isAO, "
        f"s.returnDate, "
        f"s.returnValue "
        f"FROM RiskManagement..vw_pos_openPositionMarketData p "
        f"JOIN RiskVaR..vw_SeriesData s ON p.cobDate = s.cobDate and p.minbhid = s.minbhid "
        f"WHERE 1=1 "
        f"AND p.cobDate = '{asof:{dt_fmt}}' "
        f"AND p.fund = 'BAL' "
        f"AND p.book = '{book}' "
        f"AND s.riskType = 'Total' "
        f"AND s.returnHorizon = '{horizon.upper()}' "
        f"AND s.analysisHorizon = '{horizon.upper()}' "
        f"AND s.decayFactor = 1 "
        f"AND s.exclude = 0 "
    )

    if offset:
        offset = asof - parse_offset(offset)
        query = f"{query} AND s.returnDate >= {offset:{dt_fmt}}"
    return query


def get_x_book_var_query(asof=None, offset="522b", horizon='1d'):
    dt_fmt = "%Y%m%d"
    asof = pd.to_datetime(asof) if asof else today() - BDay()
    query = (
        f"SELECT "
        f"p.fund, "
        f"p.book, "
        f"p.strategy, "
        f"p.minnb, "
        f"p.positionName, "
        f"p.riskCategory, "
        f"p.tradeGroup, "
        f"p.currency, "
        f"p.instrument, "
        f"p.underlying_name, "
        f"p.nominal, "
        f"p.nominal1, "
        f"p.delta, "
        f"p.rateTrade, "
        f"p.bhType, "
        f"p.isAO, "
        f"s.returnDate, "
        f"s.returnValue "
        f"FROM vw_SeriesData s "
        f"INNER JOIN RiskManagement..vw_pos_OpenPositionMarketData p on p.positionId = s.positionId and p.cobDate=s.cobDate "
        f"INNER JOIN RiskManagement..vw_pos_Risk r on r.positionId=s.positionId and r.cobDate=s.cobDate "   
        f"WHERE 1=1 "
        f"AND s.cobdate = '{asof:{dt_fmt}}' "
        f"AND s.fund = 'TST' "
        f"AND s.book in ('XV') "
        f"AND s.riskType = 'Total' "
        f"AND s.returnHorizon = '{horizon.upper()}' "
        f"AND s.analysisHorizon = '{horizon.upper()}' "
        f"AND s.decayFactor = 1 "
        f"AND s.exclude = 0 "
    )

    if offset:
        offset = asof - parse_offset(offset)
        query = f"{query} AND s.returnDate >= {offset:{dt_fmt}}"
    return query


class VaRPnl:
    def get_data(
            self,
            asof=None,
            book="MM",
            offset="522b",
            exclude_cash=False,
            exclude_null_notional=True,
            groupby="name",
            horizon='1d'
    ):
        asof = pd.to_datetime(asof) if asof else today() - BDay()
        self.date = asof

        query = get_x_book_var_query(asof=asof, offset=offset, horizon=horizon) if book == 'X' else get_var_query(asof=asof, book=book, offset=offset, horizon=horizon)
        res = bh.bhDbReadSql(
            rsid="1",
            sqlserver=SQL.RiskVar.server,
            sqldatabase=SQL.RiskVar.db,
            sqlquery=query,
        )

        self.res = res
        self.parse_res(res, exclude_cash, exclude_null_notional, groupby)

    def parse_res(
            self,
            res=None,
            exclude_cash=False,
            exclude_null_notional=True,
            groupby="name",
    ):
        res = res if res is not None else self.res
        df = res.py
        df["returnDate"] = pd.to_datetime(df["returnDate"])
        ref_cols = [
            "fund",
            "book",
            "strategy",
            "minnb",
            "positionName",
            "riskCategory",
            "currency",
            "tradeGroup",
            "instrument",
            "underlying_name",
            "rateTrade",
            "nominal",
            "nominal1",
            "delta",
            "isAO",
        ]

        if exclude_cash:
            df = df.loc[~df["positionName"].str.contains("CASH")]

        ref_df = df[ref_cols].drop_duplicates()
        ref_df['positionName2'] = [' '.join([p.split(' ', 2)[0], p.split(' ', 2)[-1]]) for p in ref_df['positionName']]
        # ref_df['positionName2'] = [
        #     p.replace(f" {r}", "") if t == 'IRS' else p
        #     for index, (p, t, r) in ref_df[['positionName', 'tradeGroup', 'rateTrade']].iterrows()
        # ]

        ref_df[["nominal", "nominal1", "delta"]] = ref_df.loc[:, ["nominal", "nominal1", "delta"]].replace("NULL", 0)
        ref_df[["nominal", "nominal1", "delta"]] = ref_df.loc[:, ["nominal", "nominal1", "delta"]].astype("float")
        ref_df.loc[ref_df["nominal"] == 0, 'nominal'] = ref_df.loc[ref_df["nominal"] == 0, 'nominal1']
        ref_df = ref_df.drop("nominal1", axis=1)

        if groupby:
            col = "positionName" if groupby == "name" else groupby
            col = ['strategy', 'positionName']

            ref_df = ref_df.groupby(
                ref_df.columns[
                    ~ref_df.columns.isin(["nominal", "delta", "minnb", "rateTrade"])
                ].to_list(),
                as_index=False,
            ).sum()

            hist_df = (
                df.groupby([*col, "returnDate"], as_index=False, sort=False)[
                    "returnValue"
                ].sum().pivot(index="returnDate", columns=col, values="returnValue")
            )

            if exclude_null_notional:
                ref_df = ref_df.loc[(ref_df["nominal"] != 0), :]
                hist_df = hist_df.loc[:, pd.MultiIndex.from_frame(ref_df[col])]

            # ref_df = ref_df.drop_duplicates(subset='positionName')
        else:
            hist_df = df[["returnDate", "minnb", "returnValue"]].pivot(
                index="returnDate", columns="minnb", values="returnValue"
            )

        self.ref = ref_df
        self.hist = hist_df

    def var(self, df=None, days=522, q=0.05, method='weibull'):
        df = df if df is not None else self.hist
        ptf = df[-days:]
        if isinstance(ptf, pd.DataFrame):
            ptf = ptf.sum(axis=1)
        return ptf.quantile(q, interpolation=method)

    def cvar(self, df=None, days=522, q=0.05, method='weibull'):
        df = df if df is not None else self.hist
        ptf = df[-days:]
        if isinstance(ptf, pd.DataFrame):
            ptf = ptf.sum(axis=1)
        var = self.var(df=df, days=days, q=q, method=method)
        return ptf.loc[ptf <= var].mean()

    def tail(self, df=None, periods=None, tail=1, capital=None, add=False):
        if not add:
            df = df if df is not None else self.hist
        else:
            df = pd.concat([self.hist, df], axis=1)

        ptf = df[-periods if periods else -len(df):]
        if isinstance(ptf, pd.DataFrame):
            ptf = ptf.sum(axis=1)
        return ptf.nsmallest(tail) / (capital / 100 if capital else 1)


### MAPPING

ts_var_clac_param_map = {
    'oswp': [
        'SVMInstrument',
        'Ccy',
        'Generator',
        'EffExp',
        'MtyTnr',
        'FwdTenor',
        'PayoutType',
        'Strike',
        'Nominal',
        'CollateralCcy',
        'SwaptionSettleType',
        'PaySettleType',
        'Premium',
        'UnderlyingClearingHouse',
    ],
    'irs': [
        'SVMInstrument',
        'Ccy',
        'Generator',
        'EffExp',
        'MtyTnr',
        'PayoutType',
        'Strike',
        'Nominal',
        'CollateralCcy',
    ],
    'lfut': [
        'SVMInstrument',
        'Ccy',
        'Generator',
        'MtyTnr',
        'Nominal',
    ],
    'sfut': [
        'SVMInstrument',
        'Ccy',
        'Generator',
        'MtyTnr',
        'Nominal',
    ],
    'lfutopt': [
        'SVMInstrument',
        'Ccy',
        'Generator',
        'EffExp',
        'MtyTnr',
        'PayoutType',
        'Strike',
        'CollateralCcy',
        'OptPx',
        'Nominal',
    ],
    'sfutopt': [
        'SVMInstrument',
        'Ccy',
        'Generator',
        'EffExp',
        'MtyTnr',
        'PayoutType',
        'Strike',
        'CollateralCcy',
        'OptPx',
        'Nominal',
    ]
}

param_map = {
    'id': 'TradeId',
    'instrument': 'SVMInstrument',
    'ccy': 'Ccy',
    'gen': 'Generator',
    'eff_exp': 'EffExp',
    'mty_tnr': 'MtyTnr',
    'fwd_tenor': 'FwdTenor',
    'pay_type': 'PayoutType',
    'strike': 'Strike',
    'notional': 'Nominal',
    'collateral': 'CollateralCcy',
    'swaptions_settle_type': 'SwaptionSettleType',
    'pay_settle_type': 'PaySettleType',
    'premium': 'Premium',
    'clearing_house': 'UnderlyingClearingHouse',
    'opt_px': 'OptPx',
}

param_defaults = {
    'pay_type': 'pay',
    'notional': 1,
    'collateral': 'USD',
    'swaptions_settle_type': 'DeliverCleared',
    'pay_settle_type': 's',
    'premium': 0,
    'clearing_house': 'LCH',
}

params_process = {

}

all_params = pd.Series(
    [
        'TradeId',
        *[param for key, val in ts_var_clac_param_map.items() for param in val]
    ]
).drop_duplicates()

months_fut_map = {
    'jan': 'f',
    'feb': 'g',
    'mar': 'h',
    'apr': 'j',
    'may': 'k',
    'jun': 'm',
    'jul': 'n',
    'aug': 'q',
    'sep': 'u',
    'oct': 'v',
    'nov': 'x',
    'dec': 'z'
}
fut_month_map = {val: key for key, val in months_fut_map.items()}

gen_fut_map = {
    'USD CBT T 2Y': 'tu',
    'USD CBT T 5Y': 'fv',
    'USD CBT T 10Y': 'ty',
    'USD CBT T 30Y': 'us',
    'USD CBT T10 ULT': 'uxy',
    'EUX BUXL 30Y': 'ub',
    'EUX BUND 10Y': 'rx',
    'EUX BOBL 5Y': 'oe',
    'EUX SCHATZ 2Y': 'du',
    'GBP SONIA ICE 3M': 'sfi',
    'USD SOFR CME 3M': 'sfr',
    'EUR LIFFE 3M': 'er',
    'USD CBT 30D': 'ff'
}

gen_ccy_map = {
    'USD CBT T 2Y': 'USD',
    'USD CBT T 5Y': 'USD',
    'USD CBT T 10Y': 'USD',
    'USD CBT T 30Y': 'USD',
    'USD CBT T10 ULT': 'USD',
    'EUX BUXL 30Y': 'EUR',
    'EUX BUND 10Y': 'EUR',
    'EUX BOBL 5Y': 'EUR',
    'EUX SCHATZ 2Y': 'EUR',
    'GBP SONIA ICE 3M': 'GBP',
    'USD SOFR CME 3M': 'USD',
    'EUR LIFFE 3M': 'EUR',
    'USD CBT 30D': 'USD'
}

fut_gen_map = {val: key for key, val in gen_fut_map.items()}

underlying_gen_map = {
    'EURIBOR A 6M': 'EURIBOR A 6M*'
}


def parse_cms_sin(s):
    comps = s['Description'].split(' ')
    return f"{comps[0]} CMS {comps[2]} SIN"


clarion_svm_map = {
    'RatesShortTermFuture': {
        'instrument': 'sfut',
        'ccy': lambda s: s['LocalCurrency'],
        'gen': lambda s: s['Underlying'],
        'mty_tnr': lambda s: get_fut_contract_from_des(s['Description']),
        'notional': lambda s: s['Notional'],
    },
    'RatesBondFuture': {
        'instrument': 'lfut',
        'ccy': lambda s: s['LocalCurrency'],
        'gen': lambda s: s['Underlying'],
        'mty_tnr': lambda s: get_fut_contract_from_des(s['Description']),
        'notional': lambda s: s['Notional'],
    },
    'RatesBondFutureOption': {
        'instrument': 'lfutopt',
        'ccy': lambda s: s['LocalCurrency'],
        'gen': lambda s: s['Underlying'],
        'strike': lambda s: s['Strike'],
        'eff_exp': lambda s: ez.date_to_xl(s['ExpiryDate']),
        'mty_tnr': lambda s: get_fut_opt_contract_from_des(s['Description']),
        'collateral': 'USD',
        'pay_type': lambda s: s['CallPut'],
        'opt_px': 0.1,
        'notional': lambda s: s['Notional'],
    },
    'RatesShortTermFutureOption': {
        'instrument': 'sfutopt',
        'ccy': lambda s: s['LocalCurrency'],
        'gen': lambda s: s['Underlying'],
        'strike': lambda s: s['Strike'],
        'eff_exp': lambda s: ez.date_to_xl(s['ExpiryDate']),
        'mty_tnr': lambda s: get_fut_opt_contract_from_des(s['Description']),
        'collateral': 'USD',
        'pay_type': lambda s: s['CallPut'],
        'opt_px': 0.01,
        'notional': lambda s: s['Notional'],
    },
    'RatesSwaption': {
        'instrument': 'oswp',
        'ccy': lambda s: s['LocalCurrency'],
        'gen': lambda s: underlying_gen_map.get(s['Underlying'], s['Underlying']),
        'strike': lambda s: s['Strike'],
        'eff_exp': lambda s: ez.date_to_xl(s['ExpiryDate']),
        'mty_tnr': lambda s: parse_swap_period(start_date=s['StartDate'], end_date=s['MaturityDate']),
        'fwd_tenor': lambda s: parse_swap_period(start_date=s['ExpiryDate'], end_date=s['StartDate']),
        'collateral': 'USD',
        'pay_type': lambda s: s['PayReceive'][:3].lower(),
        'notional': lambda s: s['Notional'],
        'swaptions_settle_type': 'DeliverCleared',
        'pay_settle_type': 's',
        'premium': np.nan,
        'clearing_house': 'LCH'
    },
    'RatesCmsSpreadSingleLook': {
        'instrument': 'CF',
        'ccy': lambda s: s['LocalCurrency'],
        'gen': parse_cms_sin,
        'strike': lambda s: s['Strike'],
        'eff_exp': lambda s: ez.date_to_xl(s['ExpiryDate']),
        'collateral': 'USD',
        'pay_type': lambda s: s['PayReceive'][0].lower(),
        'notional': lambda s: s['Notional'],
        'pay_settle_type': 's',
        'premium': np.nan,
    },
    'RatesSwap': {
        'instrument': 'irs',
        'ccy': lambda s: s['LocalCurrency'],
        'gen': lambda s: underlying_gen_map.get(s['Underlying'], s['Underlying']),
        'strike': lambda s: s['Strike'],
        'eff_exp': lambda s: parse_swap_period(start_date=s['StartDate']),
        'mty_tnr': lambda s: parse_swap_period(start_date=s['StartDate'], end_date=s['MaturityDate']),
        'collateral': 'USD',
        'pay_type': lambda s: s['PayReceive'][:3].lower(),
        'notional': lambda s: s['Notional'],
        'clearing_house': 'LCH'
    },
}

trade_types_to_parse = [
    'RatesShortTermFuture',
    'RatesBondFuture',
    'RatesBondFutureOption',
    'RatesShortTermFutureOption',
    'RatesSwaption',
    'RatesCmsSpreadSingleLook',
]

lfut_list = [
    'du',
    'oe',
    'rx',
    'ub',
    'tu',
    'fv',
    'ty',
    'us',
    'ik',
    'g '
]

sfut_list = [
    'er',
    'sfr',
    'sfi'
]


def var_ptf(
        current_ptf,
        new_trades=None,
        wgt=None,
        flag=4.5e6,
        q=0.05,

):
    if wgt is None and new_trades is not None:
        wgt = np.ones(shape=new_trades.shape[1])
    if new_trades is not None:
        new_ptf = pd.concat([current_ptf, (wgt * new_trades)], axis=1).sum(axis=1)
    else:
        new_ptf = current_ptf

    return - new_ptf.quantile(q, interpolation='weibull') / flag


def cvar_ptf(
        current_ptf,
        new_trades=None,
        wgt=None,
        flag=4.5e6,
        q=0.05,
        agg=False,
        scale=1
):
    if wgt is None and new_trades is not None:
        wgt = np.ones(shape=new_trades.shape[1])
    if new_trades is not None:
        new_ptf = pd.concat([current_ptf, (wgt * new_trades)], axis=1).sum(axis=1)
    else:
        new_ptf = current_ptf

    var_ = new_ptf.quantile(q, interpolation='weibull')
    cvar_ = - new_ptf.loc[new_ptf <= var_].mean() / flag
    return cvar_


def tail_ptf(
        current_ptf,
        new_trades=None,
        wgt=None,
        capital=300e6,
        n=1,
):
    if wgt is None and new_trades is not None:
        wgt = np.ones(shape=new_trades.shape[1])
    if new_trades is not None:
        new_ptf = pd.concat([current_ptf, (wgt * new_trades)], axis=1).sum(axis=1)
    else:
        new_ptf = current_ptf

    tail = - new_ptf.nsmallest(n) / capital
    return tail.squeeze()


def get_fut_contract_from_des(des):
    contract = des.rsplit(' ', 1)[-1]
    month, year = contract[:3], contract[-2:]
    contract = f"{months_fut_map[month.lower()].upper()}{year}"
    return contract


def get_des_from_fut_contract(fut, exp):
    fut = fut.lower()
    exp = exp.lower()
    month, year = exp[0], exp[1:]

    des_undl = fut_gen_map[fut]
    des_exp = f"{fut_month_map[month].upper()}{year}"
    des = f"{des_undl} {des_exp}"
    return des


def get_positions_in_book(positions, ref, hist, use_real_des=True, raise_error_on_missing=True):
    names = [*positions]
    notionals = [*positions.values()]
    des_map = {get_des_from_fut_contract(name[:-3], name[-3:]): name for name in names}
    if use_real_des:
        des = [*positions]
    else:

        des = [*des_map]
    des_notionals = {des_: notional for des_, notional in zip(des, notionals)}

    positions_ref = ref.query(f"positionName in {des}").drop_duplicates(subset='positionName2').set_index('positionName')
    if not raise_error_on_missing:
        positions_ref = positions_ref.loc[positions_ref.index.intersection(des)]
        notionals = [des_notionals[pos] for pos in positions_ref.index]
        positions_ref = positions_ref.reset_index()
    else:
        positions_ref = positions_ref.loc[des].reset_index()

    scales = (np.asanyarray(notionals) / positions_ref['nominal'].abs()).to_numpy()
    positions_hist = hist.loc[:, pd.MultiIndex.from_frame(positions_ref.loc[:, ['strategy', 'positionName']])] * np.sign(positions_ref['nominal']).to_numpy()
    new_positions = positions_hist * scales
    return new_positions if use_real_des else new_positions.droplevel(0, axis=1).rename(des_map, axis=1)   # positions_ref, positions_hist, scales


def get_fut_opt_contract_from_des(des):
    contract = des.split('x')[1].split(' ')[0]
    month, year = contract[:3], contract[-2:]
    contract = f"{months_fut_map[month.lower()].upper()}{year}"
    return contract


def bbg_stir_to_clarion(code, date=None, as_tuples=False):
    code = code.split(' ')[0]
    date = date or pd.Timestamp.now()
    year = str(date.year)[-2]
    return f"{code[:-1]}{year}{code[-1]}".lower() if not as_tuples else (f"{code[:-2]}".lower(), f"{code[-2]}{year}{code[-1]}".lower())


grouper = [
    'Ticker',
    'Underlying',
    'Description',
    'LocalCurrency',
    'TradeType',
    'Strike',
    'ExpiryDate',
    'CallPut',
    'PayReceive',
    'StartDate',
    'MaturityDate',
]


def get_db_from_clarion_positions(data):
    svm_specs = []
    for index, row in data.groupby(grouper, as_index=False, dropna=False)['Notional'].sum().iterrows():
        trade_type = row['TradeType']

        if trade_type in trade_types_to_parse:
            specs = clarion_svm_map[trade_type]
            svm_spec = {key: val if isinstance(val, (str, Number)) else val(row) for key, val in specs.items()}
            svm_spec['des'] = row['Description']
            svm_specs.append(svm_spec)

    param_df = pd.DataFrame(svm_specs)

    for col in param_df:
        if col in param_defaults:
            param_df[col] = param_df[col].fillna(param_defaults[col])
    param_df = param_df.groupby([*param_df.columns.difference(['notional'])], dropna=False, as_index=False)[
        'notional'].sum()

    param_df = param_df.query('notional != 0')
    param_map_ = {'des': 'Description', **param_map}
    remote_df = param_df.set_axis(param_df.columns.map(param_map_), axis=1).assign(TradeId=range(1, len(param_df) + 1))
    remote_db = bh.bhDbRange(
        id='var',
        range=remote_df.T.reset_index(),  # .iloc[:, -1:]
        headers=True,
        transpose=True,
        namode='o'
    )
    return remote_db


def get_db_from_specs(specs):
    new_specs = []
    for dic in specs:
        if dic['instrument'] in ['lfut', 'sfut']:
            dic.setdefault('des', f"{gen_fut_map.get(dic['gen'], dic['gen'])}{dic['mty_tnr']}")
        else:
            dic.setdefault('des', ' '.join([str(i) for i in dic.values()]))

        new_specs.append(dic)

    param_df = pd.DataFrame(new_specs)
    param_map_ = {'des': 'Description', **param_map}

    remote_df = param_df.set_axis(param_df.columns.map(param_map_), axis=1).assign(TradeId=range(1, len(param_df) + 1))

    db = bh.bhDbRange(
        id='var',
        range=remote_df.T.reset_index(),  # .iloc[:, -1:]
        headers=True,
        transpose=True,
        namode='o'
    )
    return db


def get_var_ts(
        db,
        start_date=today() - BDay() - parse_offset('522b'),
        end_date=today() - BDay(),
):
    res = bh.bhTsFiRemoteVarCalc(
        tradesdb=db,
        startdate=today() - BDay() - parse_offset('2y'),
        enddate=today() - BDay(),
        irbtdbname=ez.SQL.FITradePricer.db,
        irbtdbsrvname='SQLP2-A',
        remoteservername='p2prog09',
        # irbtdbsrvname='SQLP1-A',
        # remoteservername='p1prog09',
        remoteserverport='5557',
        timeout=3000
    )

    db_py = db.py
    if isinstance(db.py, pd.Series):
        db_py = db_py.to_frame().T
    db_py['Ccy'] = db_py['Ccy'].str.upper()
    # print(res.py)
    # return res
    valid_ids = res.py.query('Metric == "VolNCurve" and Status == "OK"')['TradeId']
    fx = db_py[['TradeId', 'Description', 'Ccy']].merge(fx_db, on='Ccy', how='left').query(f'TradeId in {[*valid_ids]}')
    # return res, fx
    tss = []
    for index, row in res.py.query('Metric == "VolNCurve" and Status == "OK"').sort_values('TradeId').iterrows():
        ts = ez.tsh_to_series(row['TS'])
        tss.append(ts.to_frame())

    pnl = pd.concat(tss, axis=1).set_axis(fx['Description'], axis=1)
    usd_pnl = pnl * fx.set_index('Description')['Rate']
    return usd_pnl, res


def get_fut_trade_spec(underlying, contract, notional=1):
    instrument = 'lfut' if underlying.lower() in lfut_list else 'sfut'
    gen = fut_gen_map.get(underlying.lower())

    return {
        'instrument': instrument,
        'ccy': gen_ccy_map.get(gen),
        'gen': gen,
        'mty_tnr': contract,
        'pay_type': 'pay',
        'notional': notional,
    }


def get_clarion_fut_trade_spec(clarion, underlying, contract, notional=1):
    class_ = clarion.instruments.RatesBondFuture if underlying.lower() in lfut_list else clarion.instruments.RatesShortTermFuture
    gen = fut_gen_map.get(underlying.lower())

    return class_(
        currency=gen_ccy_map.get(gen),
        instrument_name=gen,
        tenor=contract,
        notional=notional,
        id=f"{gen_fut_map.get(gen, gen)}{contract}"
    )


fx_db = bh.bhDbReadSql(
    rsid='fx_db',
    sqlserver='SQLP1-A',
    sqldatabase='RiskReporterLite',
    sqlquery="Select LeftCcy [Ccy], Rate From uvw_FXRate_main Where RightCcy='USD'",
).py.drop_duplicates(subset='Ccy')




