import threading
import time
import re
from functools import partial

import numpy as np
import pandas as pd


def add_pcs(securities, source, sep=None):
    sep = sep or '@'
    if isinstance(securities, str):
        securities = [securities]
    new_sec = []
    for sec in securities:
        split = sec.rsplit(' ', 1)
        if len(split) > 1:
            root, yellow_key = sec.rsplit(' ', 1)
            new_sec.append(f"{root}{sep}{source} {yellow_key}")
        else:
            new_sec.append(f"{split[0]}{sep}{source}")

    return new_sec if len(new_sec) > 1 else new_sec[0]


def make_id(securities, type=None):
    if isinstance(securities, str):
        securities = [securities]

    res = [f'/{type}/{sec}' for sec in securities]
    if len(res) == 1:
        res = res[0]
    return res


def parse_tenor(tenor, key='tenor'):
    fn = lambda tenor: f"{tenor:.0f}Y" if tenor > 1 else f"{int(12 * tenor):.0f}M"
    if isinstance(tenor, pd.DataFrame):
        return tenor.assign(tenor=tenor[key].map(fn))
    elif isinstance(tenor, pd.Series):
        return tenor.map(fn)
    elif isinstance(tenor, str):
        return fn(tenor)
    else:
        raise TypeError(f'Only str, DataFrame od Series are allowed, got object of type {type(tenor)} instead')


def apply_function(res, fields=None):
    # assumes the fields have already been renamed
    for field in fields:
        fn = field.get('fn')
        if fn and field['name'] in res:
            res[field['name']] = fn(res[field['name']])

    return res


def get_securities(securities, id_type=None, pcs=None, sep=None):
    id_type = id_type or ''
    if pcs:
        if id_type.lower() == 'isin':
            _sep = '@'
        else:
            _sep = ' '

        sep = sep or _sep
        securities = add_pcs(securities, source=pcs, sep=sep)

    return [f'/{id_type}/{sec}' for sec in securities] if id_type else securities


def unparse_securities(securities, pcs=None, sep=None, id_type=None):
    securities = pd.Series(securities)
    if pcs:
        sep = sep or ' '
        securities = securities.str.replace(f'{sep}{pcs}', '')
    if id_type:
        securities.str.replace(f'/{id_type}/', '')
    return securities.to_list()


def unparse_results_securities(res, pcs, sep, id_type=None):
    return res.assign(security=unparse_securities(res['security'], pcs=pcs, sep=sep, id_type=id_type))


period_mapping = {
    'd': 'days',
    'w': 'weeks',
    'm': 'months',
    'y': 'years',
    'ytd': pd.tseries.offsets.YearBegin()
}


def parse_offset(s):
    pattern = re.compile(r'(\d+)([A-Za-z]+)')
    match = pattern.match(s)
    try:
        n, period = match.groups()
    except (ValueError, AttributeError):
        period = s

    key = period_mapping[period.lower()]

    if isinstance(key, str):
        return pd.tseries.offsets.DateOffset(**{key: int(n)})
    else:
        return key


def today():
    return pd.Timestamp.today().floor('d')


def get_counter():
    class Counter:
        _id = 0

        @classmethod
        def get_id(cls):
            cls._id += 1
            return cls._id

    return Counter


future_expiry_month_codes = {
    1: 'F',
    2: 'G',
    3: 'H',
    4: 'J',
    5: 'K',
    6: 'M',
    7: 'N',
    8: 'Q',
    9: 'U',
    10: 'V',
    11: 'X',
    12: 'Z',
    'F': 1,
    'G': 2,
    'H': 3,
    'J': 4,
    'K': 5,
    'M': 6,
    'N': 7,
    'Q': 8,
    'U': 9,
    'V': 10,
    'X': 11,
    'Z': 12
}


def get_previous_monday(date):
    return date if not date.weekday() else date - pd.tseries.offsets.DateOffset(days=date.weekday())


def get_expiry_from_n(n=1, date=None, mult=3, settle=False):
    date = date or pd.Timestamp.today().floor('d')
    month = date.month
    temp = mult * (month // mult + 1) if month % mult else month

    temp_expiry = pd.Timestamp(year=date.year, month=temp, day=19)
    expiry = get_previous_monday(temp_expiry)

    if date >= expiry:
        expiry = get_previous_monday(expiry + pd.tseries.offsets.DateOffset(months=3))
    else:
        expiry = expiry

    if n > 1:
        expiry = get_previous_monday(expiry + pd.tseries.offsets.DateOffset(months=3 * (n - 1)))
    if settle:
        expiry = expiry + pd.tseries.offsets.BDay(2)

    return expiry


def get_expiry_from_code(code, date=None, settle=True):
    date = date or pd.Timestamp.today().floor('d')
    m, y = code[0], code[1]
    year = date.year
    yr_str = str(year)

    if int(yr_str[-1]) <= int(y):
        y_ = f"{yr_str[:-1]}{y}"
    else:
        y_ = f"{yr_str[:2]}{int(yr_str[2] + 1)}{y}"

    y_ = int(y_)
    expiry = get_previous_monday(pd.Timestamp(year=y_, month=future_expiry_month_codes.get(m), day=19))
    if settle:
        expiry = expiry + pd.tseries.offsets.BDay(2)
    return expiry


def get_next_n(n=1, bbg=True):
    exps = [get_expiry_from_n(i) for i in range(1, n + 1)]
    res = [f"{future_expiry_month_codes[exp.month]}{exp:%y}" for exp in exps] if not bbg else \
        [f"{future_expiry_month_codes[exp.month]}{str(exp.year)[-1]}" for exp in exps]
    return res


def parse_swap_period(start_date=None, end_date=None, age=None, date=None):
    date = pd.to_datetime(date) if date else today()

    if isinstance(start_date, str):
        start_date = today() + parse_offset(start_date)
    if isinstance(end_date, str):
        end_date = start_date + parse_offset(end_date)

    end_date = end_date or (date + parse_offset(age) if age else date)
    start = np.abs(int(np.round(((start_date - end_date).days / 30.5))))
    if not start % 12:
        return f'{start // 12}y'
    else:
        return f"{start}m"


def parse_swap_periods(start_date, end_date, sep='x', age=None, date=None):
    start = parse_swap_period(start_date=start_date, age=age, date=date)
    tail = parse_swap_period(start_date=start_date, end_date=end_date, date=date)
    return f"{start}{sep}{tail}" if int(start[0]) else tail


def age_swap_expr(expr):
    pattern = re.compile(r' (\d+[my])(x\d+[my])*', re.IGNORECASE)
    src = pattern.search(expr)
    forward_start, tenor = src.groups()
    start_aged = parse_swap_period(forward_start, age='3m')
    return expr.replace(forward_start, start_aged)


class RepeatedTimer:
    def __init__(self, function, interval):
        self._timer = None
        self.interval = interval
        self.function = function
        self.is_running = False

    def _run(self, *args, **kwargs):
        self.is_running = False
        self.start()
        self.function(*args, **kwargs)

    def start(self, *args, **kwargs):
        if not self.is_running:
            if hasattr(self, 'next_call'):
                self.next_call += self.interval
            else:
                self.next_call = time.time()
            self._timer = threading.Timer(self.next_call - time.time(), partial(self._run, *args, **kwargs))
            self._timer.start()
            self.is_running = True

    def stop(self):
        self._timer.cancel()
        self.is_running = False