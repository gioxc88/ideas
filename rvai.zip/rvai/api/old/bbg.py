from functools import wraps

import pandas as pd

from .blpw import BlpQuery
from .utils import apply_function, parse_tenor


dt_fmt = '%Y-%m-%d'
bbg_dt_fmt = '%Y%m%d'


def cached(attr):
    def decorator(fn):
        @wraps(fn)
        def wrapper(self, *args, **kwargs):
            if (cached:=kwargs.pop('cached', None)):
                try:
                    return getattr(self, attr)
                except AttributeError:
                    pass
            res = fn(self, *args, **kwargs)
            setattr(self, attr, res)
        return wrapper
    return decorator


class BBGInstrument:
    hist_options = {
        'calendarCodeOverride': '5D',
        "nonTradingDayFillOption": "ALL_CALENDAR_DAYS",
        "nonTradingDayFillMethod": "PREVIOUS_VALUE"
    }

    def get_bq(self):
        if not self.bq:
            try:
                return [v for k, v in globals().items() if isinstance(v, BlpQuery)][0]
            except IndexError:
                raise ValueError('blp connection not found')
        return self.bq

    def __init__(self, bq=None):
        self.bq = bq

    def _get_securities(self):
        pass

    def _parse_ref(self, ref):
        return ref

    def _parse_mkt(self, mkt, ref):
        return mkt

    def _parse_hist(self, hist, ref):
        return hist

    def get_ref(self):
        try:
            return self.ref
        except AttributeError:
            pass

        bq = self.get_bq()
        securities = self._get_securities()
        fields = self.fields_ref

        fields_name = [field['field'] for field in fields]
        res = bq.bdp(
            securities=securities,
            fields=fields_name
        )

        res = res.rename({field['field']: field['name'] for field in fields}, axis=1)
        res = apply_function(res, fields)
        self._ref = res
        self.ref = self._parse_ref(res)
        return self.ref

    def get_mkt(self, cached=True):
        if cached:
            try:
                return self.mkt
            except AttributeError:
                pass

        ref = self.get_ref()
        bq = self.get_bq()
        fields = self.fields_mkt
        fields_name = [field['field'] for field in fields]
        res = bq.bdp(
            securities=[ref['security']] if isinstance(ref, pd.Series) else ref['security'].to_list(),
            fields=fields_name
        )

        res = res.rename({field['field']: field['name'] for field in fields}, axis=1)
        res = apply_function(res, fields)
        self._mkt = res
        self.mkt = self._parse_mkt(res, ref)
        return self.mkt

    def get_hist(self, start_date, end_date=None, cached=True):
        if cached:
            try:
                return self.hist
            except AttributeError:
                pass

        ref = self.get_ref()
        bq = self.get_bq()
        start_date = pd.to_datetime(start_date)
        end_date = start_date if not end_date else pd.Timestamp.today().floor(
            'd') if end_date == -1 else pd.to_datetime(end_date)

        fields = self.fields_hist
        fields_name = [field['field'] for field in fields]
        res = bq.bdh(
            securities=[ref['security']] if isinstance(ref, pd.Series) else ref['security'].to_list(),
            fields=fields_name,
            start_date=start_date.strftime(bbg_dt_fmt),
            end_date=end_date.strftime(bbg_dt_fmt),
            options=self.hist_options
        )

        res = res.rename({field['field']: field['name'] for field in fields}, axis=1)
        res = apply_function(res, fields)
        self._hist = res
        self.hist = self._parse_hist(res, ref)
        return self.hist


class BBGRiskFreeCurve(BBGInstrument):
    fields_ref = [
        {
            'field': 'security_tenor_two',
            'name': 'tenor',
        }
    ]

    fields_mkt = [
        {
            'field': 'px_last',
            'name': 'px_last',
        }
    ]

    fields_hist = [
        {
            'field': 'px_last',
            'name': 'px_last',
        }
    ]

    def __init__(
            self,
            members=None,
            name=None,
            **kwargs
    ):
        super().__init__(
            **kwargs
        )

        if members is None:
            members = pd.read_clipboard(',', header=None).squeeze()
            if members.empty:
                raise (ValueError, 'members must be specified')
        self.members = [*members]
        self.name = name or 'Risk Free Curve'

    def _get_securities(self):
        return [*self.members]

    def _parse_mkt(self, mkt, ref):
        return mkt.merge(ref, on='security').set_index('tenor')['px_last']

    def _parse_hist(self, hist, ref):
        return hist.merge(ref, on='security').pivot(index='date', columns='tenor', values='px_last')


class BBGCDS(BBGInstrument):
    fields_ref = [
        {
            'field': 'security_des',
            'name': 'name',
        },
        {
            'field': 'issuer_bulk',
            'name': 'issuer',
        },
        {
            'field': 'crncy',
            'name': 'currency',
        },
        {
            'field': 'cds_recovery_rt',
            'name': 'recovery',
        },
        {
            'field': 'tenor',
            'name': 'tenor',
            'fn': parse_tenor
        },
        {
            'field': 'sw_spread',
            'name': 'coupon'
        }
    ]

    fields_mkt = [
        {
            'field': 'px_last',
            'name': 'px_last',
        },

        {
            'field': 'upfront_last',
            'name': 'upfront_last',
        },
        {
            'field': 'upfront_format_indicator',
            'name': 'trades_upfront',
            'fn': lambda x: x.astype(bool)
        },
    ]

    fields_hist = [
        {
            'field': 'px_last',
            'name': 'px_last',
        },

        {
            'field': 'upfront_last',
            'name': 'upfront_last',
        },
        {
            'field': 'upfront_format_indicator',
            'name': 'trades_upfront',
            'fn': lambda x: x.astype(bool)
        },
    ]

    hist_options = {
        'calendarCodeOverride': '5D',
        "nonTradingDayFillOption": "ALL_CALENDAR_DAYS",
        "nonTradingDayFillMethod": "PREVIOUS_VALUE"
    }

    def __init__(
            self,
            name,
            **kwargs,

    ):
        # if members is None:
        #     members = pd.read_clipboard(';', header=None).squeeze()
        #     if members.empty:
        #         raise(ValueError, 'members must be specified')
        # self.members = [*members]
        super().__init__(
            **kwargs
        )
        self.name = name

    def _get_securities(self):
        return [self.name]

    def _parse_ref(self, ref):
        return ref.squeeze()

    def _parse_mkt(self, mkt, ref):
        return mkt.squeeze()

    def _parse_hist(self, hist, ref):
        return hist.set_index('date')


class BBGList:
    def __init__(self, elems):
        self.elems = elems


class BBGRequestParams:
    def __init__(
            self,
            securities,
            fields,
            overrides=None,
    ):
        self.securities = securities
        self.fields = fields
        self.overrides = overrides


class BBGSecurity:
    def __init__(
            self,
            id,
            id_type='ticker',
            overrides=None,
            pcs=None,
            sep=' ',
    ):
        self.id = id
        self.id_type = id_type
        self.pcs = pcs
        self.sep = sep
        self.overrides = overrides


class BBGField:
    def __init__(
            self,
            field,
            name=None,
            overrides=None
    ):
        self.field = field
        self.name = name or field
        self.overrides = overrides


class BBGOverrides:
    def __init__(
            self,
            label=None,
            **kwargs
    ):
        self.label = label
        self.kwargs = kwargs