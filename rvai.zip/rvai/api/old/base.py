import json
import sys
from pathlib import Path

import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
from IPython.display import display
from inflection import underscore
from ipydatagrid import DataGrid
from sklearn.linear_model import LinearRegression


class Tab:
    def __init__(self, tab, name=None):
        self.tab = tab
        self.name = name

    def _ipython_display_(self):
        display(self.tab)


class Store:
    def __init__(self):
        self.data = {}
        self.components = {}

    def add(self, value):
        self.components[value.name] = value


class NameRegistry:
    def __init__(self):
        self.registry = {}

    def register(self, name):
        reg = self.registry
        count = reg.get(name, 0)
        if not count:
            reg[name] = 1
            return name
        else:
            new_name = f"{name}{count + 1}"
            reg[new_name] = 1
            reg[name] += 1
            return new_name


store = Store()
name_registry = NameRegistry()


class View:
    def __init__(self, *args, **kwargs):
        self._store = kwargs.pop('store', store)
        self.name = kwargs.get('name', getattr(self, 'name', name_registry.register(underscore(self.__class__.__name__))))
        self._store.add(self)
        if kwargs.pop('build', True):
            self.build(**kwargs)

    @property
    def store(self):
        return self._store

    @store.setter
    def store(self, value):
        self._store = value

    def build(self, **kwargs):
        self.make_widgets(**kwargs)
        self.make_view(**kwargs)

        _built = True

        if kwargs.pop('link', True):
            self.link(**kwargs)

    def make_widgets(self, **kwargs):
        pass

    def make_view(self, **kwargs):
        pass

    def link(self, **kwargs):
        _linked = True

    def _ipython_display_(self):
        if hasattr(self, 'view'):
            display(self.view)


class Tabs(View):
    def __init__(self, tabs, *args, **kwargs):
        self.tabs = tabs
        self.data = {}
        store = kwargs.pop('store', Store())
        store.tabs = self
        for key, value in tabs.items():
            value.set_store(store)
            value.build(link=False)
        for key, value in tabs.items():
            value.link()
        super().__init__(store=store)

    def make_widgets(self):
        self.tabs_bar = v.Tabs(
            # dark=True,
            v_model=None,
            children=[v.Tab(children=[name]) for name in self.tabs]
        )

        self.tabs_items = v.TabsItems(
            v_model=None,
            # dark=True,
            children=[v.TabItem(children=[tab.view]) for name, tab in self.tabs.items()]
        )

    def make_view(self):
        self.view = v.Card(
            children=[
                self.tabs_bar,
                self.tabs_items
            ]
        )

    def link(self):
        w.jslink((self.tabs_bar, 'v_model'), (self.tabs_items, 'v_model'))

    def __getitem__(self, item):
        return self.tabs[item]


class MultiTab:
    def __init__(self, tabs):
        self.tabs = tabs
        self.build()

    def build(self):
        self.tabs_bar = v.Tabs(
            # dark=True,
            v_model=None,
            children=[v.Tab(children=[c.name]) for c in self.tabs]
        )

        self.tabs_items = v.TabsItems(
            v_model=None,
            # dark=True,
            children=[v.TabItem(children=[t.tab]) for t in self.tabs]
        )

        self.box = v.Card(
            children=[
                self.tabs_bar,
                self.tabs_items
            ]
        )

        w.jslink((self.tabs_bar, 'v_model'), (self.tabs_items, 'v_model'))

    def _ipython_display_(self):
        display(self.box)