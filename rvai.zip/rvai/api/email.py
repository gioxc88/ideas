import base64
import json
import logging
import os
import re
import smtplib
import sys
import time
import threading
from functools import partial
from itertools import chain
from importlib import reload
from pathlib import Path
from uuid import uuid4
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart

import pandas as pd
from premailer import Premailer

from_email = 'gioreports@brevanhoward.com'
smtp_server = "smtp.rivagecapital.com"

to_email_all = [
    'giovambattista.perciaccante@brevanhoward.com',
    'menashe.banit@brevanhoward.com'
]

to_email_ext = [
    'giovambattista.perciaccante@brevanhoward.com',
    'menashe.banit@brevanhoward.com',
    'michael.benchitrit@brevanhoward.com',
]

to_email_mic = [
    'giovambattista.perciaccante@brevanhoward.com',
    'michael.benchitrit@brevanhoward.com',
]


to_email_test = [
    'giovambattista.perciaccante@brevanhoward.com',
    'gioxc@hotmail.it'
]


def get_email(key):
    if key is True:
        return to_email_all
    elif key == 'ext':
        return to_email_ext
    elif key == 'mic':
        return to_email_mic
    else:
        return to_email_test


styles = {
    "": [
        ('border', 'none'),
        ('border-collapse', 'collapse'),
        ('border-spacing', '0'),
        ('color', 'black'),
        ('font-size', '13px'),
        ('table-layout', 'fixed'),
        ('font-family', 'Calibri')
    ],
    'thead': [
        ('border-bottom', '1px solid #bdbdbd'),
        ('border-collapse', 'collapse'),
        ('vertical-align', 'bottom'),
        # ('font-family', 'Castellar')
    ],
    'tr, td': [
        ('text-align', 'left'),
        ('vertical-align', 'middle'),
        ('padding', '0.5em 0.5em'),
        ('line-height', 'normal'),
        ('white-space', 'nowrap'),
        ('max-width', 'none'),
        ('border', 'none'),
        # ('border-collapse', 'collapse'),
    ],
    'th': [
        ('font-weight', 'bold'),
        ('text-align', 'right'),
        ('white-space', 'nowrap')
    ],
    'thead th': [
        ('text-align', 'center'),
    ],
    'td': [
        ('white-space', 'nowrap')
    ],
    "tbody tr:nth-child(even)": [
        ('background', "#f5f5f5"),
    ],
    # 'tbody tr:hover': [
    #   ('background', 'rgba(66, 165, 245, 0.2)'),
    # ]
}


def df_to_html(df, table_styles=None):
    if isinstance(df, pd.Series):
        df = df.to_frame()

    if not isinstance(df, pd.io.formats.style.Styler):
        s = df.style
    else:
        s = df

    if not table_styles:
        table_styles = [
            {
                "selector": sel, 'props': '; '.join([': '.join(p) for p in props])
            } for sel, props in styles.items()
        ]
    s.set_table_styles(table_styles)
    pm = Premailer(exclude_pseudoclasses=False)
    to_send = pm.transform(s.to_html(doctype_html=True), pretty_print=True)
    return to_send
