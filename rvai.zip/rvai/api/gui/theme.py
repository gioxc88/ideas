bg_color = '#FFFFFF'

grid_style = {
    'void_color': bg_color,
    'background_color': bg_color
}
