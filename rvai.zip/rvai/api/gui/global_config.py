import logging
from functools import partial

import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd

from gioutils.gui.base import View
from gioutils.utils import RepeatedTimer, RepeatedTimerThread


def on_change_update_cob_curves(widget, event, payload, self):
    self.update_cob_curves()


def on_click_change_timer(widget, event, payload, self):
    self.start_stop_timer()


def on_click_refresh(widget, event, payload, self):
    widget.loading = True
    try:
        logging.warning('updating')
        self.refresh()
        logging.warning('updated')
    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False


class GlobalConfig(View):

    def __init__(self, dc=None, timer=RepeatedTimer, **kwargs):
        self.dc = dc
        self.timer = timer
        super().__init__(**kwargs)

    def make_widgets(self, **kwargs):
        refresh_btn = v.Btn(
            fab=True,
            # dark=True,
            x_small=True,
            plain=True,
            class_='ml-2',
            children=[v.Icon(children=['mdi-sync'])],
            hide_details=True,
        )

        timer_tf = v.TextField(
            v_model=30,
            label='time',
            clearable=True,
            dense=True,
            outlined=True,
            # type="number",
            # class_="mr-0",
            hide_details=True,

        )

        change_tf = v.TextField(
            v_model='1d',
            label='change',
            clearable=True,
            dense=True,
            outlined=True,
            # class_="mr-0",
            hide_details=True,
        )

        timer_btn = v.Btn(
            fab=True,
            # dark=True,
            x_small=True,
            plain=True,
            # class_='mt-2 mb-2 mr-2 ml-0',
            children=[v.Icon(children=['mdi-timer'])],
            hide_details=True,
        )

        self.refresh_btn = refresh_btn
        self.timer_tf = timer_tf
        self.timer_btn = timer_btn
        self.change_tf = change_tf

    def make_view(self):
        self.html = w.HTML(self.get_html_text())
        self.param_box = v.Row(
            children=[
                v.Col(
                    # cols=2,
                    # xl=1.0,
                    children=[self.timer_tf],
                    # class_="my-0 py-0 mr-0 pr-0"
                ),
                v.Col(
                    # cols=2,
                    # xl=1.0,
                    children=[self.change_tf],
                    # class_="my-0 py-0 mr-0 pr-0"
                ),
                v.Col(
                    # cols=2,
                    children=[self.timer_btn, self.refresh_btn,],
                    # class_="my-0 py-0"
                ),
                v.Col(
                    # cols=2,
                    children=[self.html],
                    # class_="my-0 py-0"
                ),
            ],
        )

        self.view = self.param_box

    def link(self, **kwargs):
        self.refresh_btn.on_event(
            'click',
            partial(on_click_refresh, self=self)
        )
        self.timer_btn.on_event(
            'click',
            partial(on_click_change_timer, self=self)
        )

        self.change_tf.on_event(
            'change',
            partial(on_change_update_cob_curves, self=self)
        )
        super().link(**kwargs)

    def update_cob_curves(self):
        self.dc.offset = self.change_tf.v_model

    def refresh(self, dc=None):
        dc = dc or self.dc
        dc.refresh()
        self.html.value = self.get_html_text(True)

    def get_html_text(self, time=None):
        if not time:
            return f'<b>last refresh: -'
        else:
            return f'<b>last refresh: {pd.Timestamp.today(): %H:%M:%S}'

    def start_stop_timer(self):
        sec = int(self.timer_tf.v_model)
        try:
            rt = self.rt
            if not rt.is_running:
                rt.interval = sec
        except AttributeError:
            self.rt = self.timer(self.refresh, sec)
            rt = self.rt

        if rt.is_running:
            self.timer_btn.color = None
            rt.stop()
        else:
            self.timer_btn.color = 'success'
            rt.start()

