from gioutils.store import get_store_mixin

RendererStoreMixin = get_store_mixin(name='renderer')

RendererComponentStoreMixin = get_store_mixin(name='renderer_component')
