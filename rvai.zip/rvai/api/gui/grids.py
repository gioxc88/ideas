import logging

import ipyvuetify as v
import ipywidgets as w
import pandas as pd
import numpy as np
from plotly import graph_objects as go
from plotly.subplots import make_subplots
from ipydatagrid import DataGrid, TextRenderer, BarRenderer, Expr, VegaExpr
from bqplot import ColorScale, LinearScale

from gioutils.gui.base import View
from gioutils.gui.datagrid import DataGridGio
from gioutils.gui.pandas import millify1

from .pandas import DFOutput, negative_red
from .params import fwd_tenors
from .renderers import RendererComponentStoreMixin

POSITIVE_COLOR = 'green'
NEGATIVE_COLOR = 'red'
DEFAULT_COLOR = 'default_value'


def get_color(color):
    return f'"{color}"' if color != 'default_value' else color


def get_color_expr(
        positive_color=POSITIVE_COLOR,
        negative_color=NEGATIVE_COLOR,
        neutral_color=DEFAULT_COLOR,
        reverse_color=False
):
    if reverse_color:
        positive_color, negative_color = negative_color, positive_color
    expr = Expr(f'{get_color(negative_color)} if cell.value < 0 else {get_color(positive_color)} if cell.value > 0 else {get_color(neutral_color)}')
    return expr


def make_html_title(text=None, **kwargs):
    if text:
        tag = kwargs.pop('tag', 'h3')
        title = v.Html(
            tag=tag,
            children=[text],
            **kwargs
        )
        return title


class BaseGrid(View, RendererComponentStoreMixin):
    def __init__(self, *args, **kwargs):
        if 'dc' not in kwargs:
            kwargs['build'] = False

        self.grid_kwargs = kwargs.pop('grid_kwargs', {})
        self.multipliers = kwargs.pop('multipliers', None)
        self.title = kwargs.pop('title', '')
        self.html_title = kwargs.pop('html_title', True)
        self.html_title_kwargs = kwargs.pop('html_title_kwargs', {})
        self.na_rep = kwargs.pop('na_rep', '-')
        self.reverse_change_color = kwargs.pop('reverse_change_color', False)
        if not hasattr(self, 'dc_key'):
            self.dc_key = kwargs.pop('dc_key', None)

        super().__init__(*args, **kwargs)

    def _get_title(self, **kwargs):
        return self.title

    def _make_default_renderer(self, data, **kwargs):
        return

    def _make_renderers(self, data, **kwargs):
        return

    def get_data(self, dc, **kwargs) -> pd.DataFrame:
        data = self._get_data(dc, **kwargs)
        multipliers = self.multipliers
        if multipliers:
            if isinstance(multipliers, int):
                data = data * multipliers
            else:
                for mult in multipliers:
                    data[mult] = multipliers[mult] * data[mult]

        # if self.na_rep:
        #     data = data.fillna(self.na_rep)
        self.data = data
        return data

    def get_widget(self, dc, **kwargs):
        data = self.get_data(dc, **kwargs)
        widget = self._get_widget(data, **kwargs)
        self.widget = widget
        if self.html_title:
            self.title_html = make_html_title(self._get_title(**kwargs), **self.html_title_kwargs)
            view = w.VBox([self.title_html, widget])
        else:
            view = widget
        self._view = view
        return view

    def _get_widget(self, data, **kwargs):
        pass

    def update_widget(self, dc, **kwargs):
        try:
            if not hasattr(self, 'widget'):
                self.get_widget(dc, **kwargs)
            else:
                self.get_data(dc, **kwargs)
                self._update_widget(**kwargs)
        except Exception as e:
            logging.warning(e)

    def _update_widget(self, **kwargs):
        data = self.data
        widget = self.widget

        default_renderer = self._make_default_renderer(data, **kwargs)
        renderers = self._make_renderers(data, **kwargs)

        if default_renderer:
            widget.default_renderer = default_renderer
        if renderers:
            widget.renderers = renderers
        widget.data = data

    def _get_data(self, dc, **kwargs) -> pd.DataFrame:
        pass

    @property
    def view(self):
        if hasattr(self, '_view'):
            if isinstance(self._view, View):
                return self._view.view
            return self._view
        else:
            return w.Output()


class BaseChart(BaseGrid):
    def _update_widget(self, **kwargs):
        pass


class SpotGrid(BaseGrid):
    def __init__(
            self,
            gen,
            dc_key='sf',
            reverse_change_color=True,
            **kwargs
    ):
        self.gen = gen
        self.out = w.Output()
        self.dc_key = dc_key
        kwargs['reverse_change_color'] = reverse_change_color
        super().__init__(**kwargs)

    def _get_title(self, **kwargs):
        return self.title or self.gen

    def _get_data(self, dc, **kwargs):
        gen = self.gen
        key = self.dc_key
        title = self._get_title(**kwargs)
        data = dc[key].data
        data = data['live']['spot'].loc[gen].set_index('in.mty')[['rate', 'change']]\
            .rename_axis(None)\
            .rename({'rate': title if not self.html_title else 'live'}, axis=1)

        data['change'] = data['change'] * 10000
        return data

    def _get_widget(self, data, **kwargs):
        live_col = data.columns[0]
        change_renderer = TextRenderer(
            format='.2f',  # Expr("format(cell.value, '.2f')"),
            text_color=get_color_expr(reverse_color=self.reverse_change_color),
            horizontal_alignment='center',
            missing='-',
        )

        rate_renderer = TextRenderer(
            format='.3%',
            horizontal_alignment='center',
            # text_color=Expr(f'{get_color(NEGATIVE_COLOR)} if cell.value < 0 else {get_color(POSITIVE_COLOR)}'),
            missing='-',
        )

        grid = DataGridGio(
            data,
            index_name='',
            renderers={
                'change': change_renderer,
                live_col: rate_renderer
            },
            column_widths={
                live_col: 16 * len(live_col),
                'change': 70,
                '': 40
            },
            # auto_fit_columns=True,
        )

        self.widget = grid
        return grid


class FutureGrid(BaseGrid):
    def __init__(self, gen, ccy, dc_key='fut', **kwargs):
        self.gen = gen
        self.ccy = ccy
        self.dc_key = dc_key
        self.out = w.Output()
        super().__init__(**kwargs)

    def _get_title(self, **kwargs):
        return f"{self.title} Fut" if self.title else f"{self.gen} Fut"

    def _get_data(self, dc, **kwargs):
        ccy = self.ccy
        title = self._get_title(**kwargs)
        dc_key = self.dc_key
        fut_df = dc[dc_key].data.loc[dc[dc_key].get_tickers(return_dict=True)[ccy], ['live', 'change']]
        if not self.html_title:
            fut_df = fut_df.rename({'live': title}, axis=1)
            live_col = title
        else:
            live_col = 'live'
        fut_df = fut_df.set_index(
            fut_df.index.str.replace(' Comdty', '').str[-2:].str.replace('ex', 'spot')).rename_axis(None)
        fut_df.loc['spot', live_col] = 100 - fut_df.loc['spot', live_col]
        # fut_df.loc['spot', "change"] = None
        return fut_df.fillna("")

    def _get_widget(self, data, **kwargs):
        live_col = data.columns[0]

        change_renderer = TextRenderer(
            format='.2f',
            text_color=get_color_expr(reverse_color=self.reverse_change_color),
            horizontal_alignment='center',
            missing='-',
        )

        val_renderer = TextRenderer(
            format='.3f',
            horizontal_alignment='center',
            # text_color=Expr(f'{get_color(NEGATIVE_COLOR)} if cell.value < 0 else {get_color(POSITIVE_COLOR)}'),
            missing='-',
        )
        grid = DataGridGio(
            data,
            index_name='',
            renderers={
                'change': change_renderer,
                live_col: val_renderer
            },
            column_widths={
                live_col: 16 * len(live_col),
                'change': 70,
                '': 40
            },
            # auto_fit_columns=True,
        )
        self.widget = grid
        return grid


class KeyChart(BaseChart):
    def __init__(self, gen, dc_key='sf', chart_kwargs=None, **kwargs):
        self.gen = gen
        self.dc_key = dc_key
        self.chart_kwargs = chart_kwargs or {}
        kwargs['multipliers'] = kwargs.pop('multipliers', {'live': 100, 'cob': 100, 'change': 10000})
        super().__init__(**kwargs)

    def _get_data(self, dc, **kwargs):
        data = dc[self.dc_key].data
        gen = self.gen
        scale = self.chart_kwargs.pop('scale', 100)

        plot_df = pd.concat(
            [
                data['live']['fwd'].set_index(['in.eff', 'in.mty'], append=True).droplevel(1).rename_axis(3 * [None])[
                    'rate'].rename('live'),
                data['cob']['fwd'].set_index(['in.eff', 'in.mty'], append=True).droplevel(1).rename_axis(3 * [None])[
                    'rate'].rename('cob')
            ],
            axis=1
        )
        plot_df['change'] = plot_df['live'] - plot_df['cob']
        plot_df = plot_df.loc[
            [(gen, elm[0], elm[1]) for gen in plot_df.index.get_level_values(0).unique() for elm in fwd_tenors]]
        plot_df = plot_df.set_index(
            pd.MultiIndex.from_arrays(
                [
                    plot_df.index.get_level_values(0),
                    plot_df.index.get_level_values(1).astype(str) + 'x' + plot_df.index.get_level_values(2).astype(str)
                ],
            )
        )
        plot_df_ = plot_df.loc[gen]
        return plot_df_

    def _get_widget(self, data, **kwargs):
        widget = self.make_plot(data, **self.chart_kwargs)
        self.widget = widget
        return widget

    def make_plot(self, plot_df, **kwargs):
        plot_df_ = plot_df
        value_fmt = kwargs.pop('value_fmt', '.1f')
        change_fmt = kwargs.pop('change_fmt', '.0f')
        fig = make_subplots(specs=[[{"secondary_y": True}]])
        fig2 = plot_df_[['live', 'cob']].plot(markers=True)
        fig2.data[0].line.color = 'red'
        fig2.data[1].line.color = 'orange'
        fig3 = plot_df_['change'].plot.bar()
        # fig3.data[0].width = [2] * len(plot_df_)
        # fig3.data[0].offset = 0
        fig3.data[0].marker.line = dict(width=1, color='white')
        fig.add_traces([*fig2.data, *fig3.data], secondary_ys=[True, True, False]) \
            .update_yaxes(showgrid=False, tickformat=change_fmt, nticks=10) \
            .update_yaxes(tickformat=value_fmt, secondary_y=True) \
            .update_xaxes(tickangle=45) \
            .update_layout(
            template='plotly_white',
            height=kwargs.get('height', 500),
            title=self.gen,
            bargap=0,
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            )
        )
        return go.FigureWidget(fig)

    def _update_widget(self, **kwargs):
        data = self.data
        widget = self.widget
        widget.data[0]['y'] = data['live'].to_numpy()
        widget.data[1]['y'] = data['cob'].to_numpy()
        widget.data[2]['y'] = data['change'].to_numpy()


class GroupMktGrid(BaseGrid):
    def __init__(
            self,
            group,
            pct=True,
            precision=2,
            change_precision=2,
            field=None,
            show_subgroup=False,
            dc_key='mkt',
            styler_kwargs=None,
            **kwargs
    ):
        self.group = group
        self.pct = pct
        self.styler_kwargs = styler_kwargs or {}
        self.precision = precision
        self.change_precision = change_precision
        self.field = field
        self.dc_key = dc_key
        self.show_subgroup = show_subgroup
        self.out = w.Output()
        super().__init__(**kwargs)

    def _get_title(self, **kwargs):
        return self.title or self.group

    def _get_data(self, dc, **kwargs):
        live, cob, change = ['live', 'cob', 'change'] if not self.field \
            else [f'{self.field} live', f'cob', f'{self.field} change']

        data = dc[self.dc_key].data.copy()
        if self.pct:
            data[change] = data[change] / data[cob]

        group = self.group
        title = self._get_title(**kwargs)
        if self.show_subgroup:
            set_index = ['sub_group', 'display_name']
            rename_axis = ['country', title] if not self.html_title else ['', '']
        else:
            set_index = 'display_name'
            rename_axis = title if not self.html_title else ''

        df = data.query(f'group == "{group}"').set_index(set_index)[[live, change]] \
            .rename({live: 'live', change: 'change'}, axis=1)
        df = df.rename_axis(rename_axis)
        return df

    def _get_widget(self, data, **kwargs):
        title = self.data.index.names[0 if self.data.index.ndim == 1 else 1]

        change_renderer = TextRenderer(
            format=f'.{self.change_precision}f' if not self.pct else f'.{self.change_precision}%',  # Expr("format(cell.value, '.2f')"),
            text_color=get_color_expr(reverse_color=self.reverse_change_color),
            horizontal_alignment='center',
            missing='-',
        )

        value_renderer = TextRenderer(
            format=f'.{self.precision}f',
            horizontal_alignment='center',
            # text_color=Expr(f'{get_color(NEGATIVE_COLOR)} if cell.value < 0 else {get_color(POSITIVE_COLOR)}'),
            missing='-',
        )

        from copy import deepcopy
        column_widths = {title: 90, 'country': 40}
        column_widths.update(self.grid_kwargs.get('column_widths', {}))
        grid_kwargs = deepcopy(self.grid_kwargs)
        grid_kwargs.setdefault('base_column_size', 70)
        grid_kwargs.pop('column_widths', None)

        grid = DataGridGio(
            data,
            renderers={
                'change': change_renderer,
                'live': value_renderer
            },
            column_widths=column_widths,
            **grid_kwargs
        )

        self.widget = grid
        return grid


class GovBondMktMat(GroupMktGrid):
    def __init__(
            self,
            display='live',
            **kwargs
    ):

        super().__init__(**kwargs)

    def _get_data(self, dc, **kwargs):
        data = super().get_data(dc, **kwargs)
        title = self._get_title(**kwargs)

        country_pattern = r'[A-Za-z]+'
        maturity_pattern = r'\d+[A-Za-z]{1}'
        data = data.assign(
            country=data.index.str.findall(country_pattern).str[0],
            maturity=data.index.str.findall(maturity_pattern).str[0]
        )
        data['value'] = data['live'].apply(lambda x: f"{x:.3f}") + '   ' + data['change'].apply(lambda x: f"{x:+.1f}")
        return data.pivot(index='country', columns='maturity', values='value').loc[
            data['country'].unique(),
            data['maturity'].unique()
        ].rename(axis=title)

    def _get_widget(self, data, **kwargs):
        renderer = TextRenderer(
            text_color=Expr(f'{get_color(NEGATIVE_COLOR)} if "-" in cell.value else {get_color(POSITIVE_COLOR)}'),
            horizontal_alignment='center',
            missing='-',
        )

        grid = DataGridGio(
            data,
            index_name='' if self.html_title else None,
            base_column_size=90,
            default_renderer=renderer
        )
        self.widget = grid
        return grid


def mixed_formatter(v):
    try:
        return f"{v:%d-%b-%y}"
    except:
        return v


def custom_mixed_format(value, float_format='.2%', date_fmt='%d%b%y'):
    if isinstance(value, (str, int)):
        return value
    elif isinstance(value, pd.Timestamp):
        return f"{value:{date_fmt}}"
    elif isinstance(value, float):
        return f"{value:{float_format}}"


class MtgGrid(BaseGrid):
    def __init__(self, ccy, show=9, **kwargs):
        self.ccy = ccy
        self.show = show
        self.out = w.Output()
        super().__init__(**kwargs)

    def _get_data(self, dc, **kwargs):
        ccy = self.ccy
        show = self.show
        data = dc['mtgs'].data.query(f"Currency == '{ccy.upper()}'")[:show]
        data = data.set_index('MeetingDate')
        data.loc['fixing', 'hikes'] = data.loc['fixing', 'rate']
        data['cum'] = data['hikes'].cumsum()
        data = data[['hikes', 'cum']].rename({'hikes': f"{ccy} hikes"})
        data = data.set_axis(data.index.map(custom_mixed_format)).rename_axis(self._get_title(**kwargs))
        return data

    def _get_widget(self, data, **kwargs):
        renderer = TextRenderer(
            format=".3f",
            format_type="number",
        )

        widget = DataGridGio(
            data,
            base_column_size=57,
            default_renderer=renderer,
            index_name='' if self.html_title else None,
        )
        self.widget = widget
        return widget


class MatGrid(BaseGrid):
    def __init__(
            self,
            ccy,
            curve_type,
            dc_key='mat',
            precision=3,
            red_negative=False,
            bar_renderer=None,
            positive_color=POSITIVE_COLOR,
            **kwargs
    ):
        self.ccy = ccy
        self.curve_type = curve_type
        self.dc_key = dc_key
        self.red_negative = red_negative
        self.precision = precision
        self.out = w.Output()
        self.bar_renderer = bar_renderer or {}
        self.positive_color = positive_color
        super().__init__(**kwargs)

    def _get_title(self, **kwargs):
        return f"{self.ccy} {self.title}"

    def _get_data(self, dc, **kwargs):
        ccy = self.ccy
        curve_type = self.curve_type
        data = dc[self.dc_key].data.loc[curve_type, ccy].rename_axis(self._get_title(**kwargs) if not self.html_title else '')
        return data

    def _make_default_renderer(self, data, **kwargs):
        renderer_kwargs = dict(
            format=f".{self.precision}f",
            format_type="number",
        )
        if self.red_negative:
            renderer_kwargs['text_color'] = get_color_expr(
                reverse_color=self.reverse_change_color
            )

        if br := self.bar_renderer:
            scheme = br.get('scheme', "RdYlBu")
            min_mult = br.get('min_mult', 0.4)
            mid = br.get('mid', None)
            max_mult = br.get('max_mult', 1.2)
            bar_value = br.get('bar_value', 1)
            text_color = br.get('text_color', "black")
            if self.red_negative:
                text_color = get_color_expr(
                    positive_color=self.positive_color,
                    reverse_color=self.reverse_change_color
                )

            def_rend = BarRenderer(
                horizontal_alignment="center",
                bar_color=ColorScale(
                    min=data.min().min() * min_mult,
                    max=data.max().max() * max_mult,
                    mid=mid, scheme=scheme
                ),
                bar_value=bar_value,
                format=f".{self.precision}f",
                text_color=text_color
            )
        else:
            def_rend = TextRenderer(**renderer_kwargs)

        return def_rend

    def _get_widget(self, data, **kwargs):

        widget = DataGridGio(
            data,
            base_column_size=55,
            default_renderer=self._make_default_renderer(data, **kwargs),
            column_widths={data.index.name: 110 if not self.html_title else 40}
        )
        self.widget = widget
        return widget


def custom_format_govt_bond_fut(x, precision=2):
    sec, val = x.split('__')
    val = float(val)
    if sec in ['TUA', 'FVA', 'TYA', 'USA']:
        decimal = val % 1
        integer = int(val)
        decimal = round(32 * decimal, precision)
        return f"{integer}-{decimal}"
    return f"{val:.{precision}f}"


def format32nd(val, precision=2):
    decimal = val % 1
    integer = int(val)
    decimal = round(32 * decimal, precision)
    return f"{integer}-{decimal}"


class CustomGovtBondFutGrid(GroupMktGrid):
    group = 'govt bond fut'

    def __init__(
            self,
            styler_kwargs=None,
            dc_key='mkt',
            show_country=False,
            **kwargs
    ):
        self.dc_key = dc_key
        self.show_country = show_country

        kwargs['pct'] = False
        super().__init__(**kwargs)

    def _get_data(self, dc, **kwargs):
        group = self.group

        data = dc['mkt'].data.query(f'group == "{group}"').set_index(['sub_group', 'display_name'])[['live', 'change']]
        fut_formats = {
            'US': format32nd
        }

        data_ = []
        for index, g in data.groupby(level=0, sort=False):
            if fmt := fut_formats.get(index):
                g['live'] = g['live'].apply(fmt)
            else:
                g['live'] = g['live'].apply(lambda x: f"{x:.{self.precision}f}")
            data_.append(g)
        data_ = pd.concat(data_)
        data_ = data_.rename_axis(['country', self._get_title(**kwargs) if not self.html_title else ''])
        if not self.show_country:
            data_ = data_.droplevel(0)
        return data_

    def _get_widget(self, data, **kwargs):
        title = self.data.index.names[0]

        change_renderer = TextRenderer(
            format=f'.{self.change_precision}f' if not self.pct else f'.{self.change_precision}%',
            text_color=get_color_expr(reverse_color=self.reverse_change_color),
            horizontal_alignment='center',
            missing='-',
        )

        value_renderer = TextRenderer(
            horizontal_alignment='center',
            # text_color=Expr(f'{get_color(NEGATIVE_COLOR)} if cell.value < 0 else {get_color(POSITIVE_COLOR)}'),
            missing='-',
        )

        grid = DataGridGio(
            data,
            renderers={
                'change': change_renderer,
                'live': value_renderer
            },
            column_widths={
                'country': 50,
                title: 90 if not self.html_title else 50,
                'live': 75,
                'change': 70
            },
            **self.grid_kwargs
        )

        self.widget = grid
        return grid


class CustomFCIMkt(GroupMktGrid):
    def __init__(self, more_keys=None, **kwargs):
        self.more_keys = more_keys or []
        super().__init__(**kwargs)

    def _get_data(self, dc, **kwargs) -> pd.DataFrame:
        data = super(CustomFCIMkt, self)._get_data(dc, **kwargs)
        more_data = []
        for key in self.more_keys:
            more_data.append(dc[key].data[['live', 'change']].to_frame().T)

        return pd.concat([data, *more_data]).rename_axis('')


def format_actual(cell):
    value = cell.value
    other = cell.metadata.data['last_actual']
    # if not isValid(value) or not isValid(other):
    #     return 'red'
    if value < other:
        return 'red'
    else:
        return 'green'


def format_survey(cell):
    value = cell.value
    other = cell.metadata.data['last']
    # if not isValid(value) or not isValid(other):
    #     return 'red'
    if value < other:
        return 'red'
    elif value > other:
        return 'green'
    else:
        return 'black'


def format_last(cell):
    value = cell.value
    other = cell.metadata.data['prior']
    # if not isValid(value) or not isValid(other):
    #     return 'red'
    if value < other:
        return 'red'
    elif value > other:
        return 'green'
    else:
        return 'black'


def format_prior(cell):
    value = cell.value
    other = cell.metadata.data['prior_rev']
    # if not isValid(value) or not isValid(other):
    #     return 'red'
    if value < other:
        return 'red'
    elif value > other:
        return 'green'
    else:
        return 'black'


def get_vega_expr_other(other, col1='red', col2='green', col3='black'):
    expr = f"if(" \
    f"cell.value < cell.metadata.data['{other}'], " \
    f"'{col1}', if(cell.value > cell.metadata.data['{other}'], '{col2}', '{col3}')"\
    f")"
    return VegaExpr(expr)


def star_rederer(cell):
    if cell.value > 0:
        return '\u2B50'
    else:
        return ' '


from py2vega.functions.type_coercing import toDate
from py2vega.functions.formatting import timeFormat
from py2vega.functions.type_checking import isValid
from .params import eco_stars


class ECOGrid(BaseGrid):

    def __init__(self, dc_key='eco', stars=None, **kwargs):

        self.stars = stars or eco_stars
        kwargs['dc_key'] = dc_key
        kwargs['title'] = kwargs.pop('title', 'ECO Grid')
        super().__init__(**kwargs)

    def _get_data(self, dc, **kwargs):
        data = dc[self.dc_key].data

        data = data.assign(
            star=data['security'].isin(self.stars)
        )
        return data

    def _get_widget(self, data, **kwargs):
        if hasattr(self, 'widget'):
            widget_data = self.widget_data
            data = data.set_index('security').loc[[*widget_data['security']], :]

        widget = DataGridGio(
            data,
            renderers={
                'next': TextRenderer(
                    # text_value=Expr(format_date),
                    format='%d %b %Y',
                    format_type="time",
                ),
                'time': TextRenderer(
                    # text_value=Expr(format_time),
                    format='%H:%M',
                    format_type="time",
                ),
                'actual': TextRenderer(text_value=Expr(millify1), text_color=get_vega_expr_other('survey')),
                'survey': TextRenderer(text_value=Expr(millify1), text_color=get_vega_expr_other('last')),
                'last': TextRenderer(text_value=Expr(millify1), text_color=get_vega_expr_other('prior')),
                'prior': TextRenderer(text_value=Expr(millify1), text_color=get_vega_expr_other('prior_rev')),
                'last_rev': TextRenderer(text_value=Expr(millify1)),
                'prior_rev': TextRenderer(text_value=Expr(millify1)),
                'rank': BarRenderer(
                    bar_color=ColorScale(min=0, max=120),
                    bar_value=LinearScale(min=0, max=100),
                    text_value=VegaExpr("' '"),
                ),
                'star': TextRenderer(text_value=Expr(star_rederer)),
            },
            column_widths={
                'security': 110,
                'country': 70,
                'name': 220,
                'next': 90,
                'time': 60,
                'survey': 65,
                'last': 65,
                'prior': 65,
                'last_rev': 75,
                'prior_rev': 77,
                'star': 50,
                '': 30
            },
            index_name='',
            selection_mode='cell',
            editable=True,
            max_height=750,
        )

        return widget
