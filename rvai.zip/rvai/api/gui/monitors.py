import ipywidgets as w
import ipyvuetify as v
import pandas as pd

from gioutils.gui.base import View

from .grids import SpotGrid, FutureGrid, MtgGrid, MatGrid, GroupMktGrid, KeyChart, CustomGovtBondFutGrid, CustomFCIMkt, ECOGrid
from .renderers import RendererStoreMixin


class Monitor(View, RendererStoreMixin):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def make_view(self, **kwargs):
        self.container = v.Container(
            class_="ma-0 pa-0",
            # style_=f"background: {bg_color}",
            fluid=True
        )
        self.view = self.container

    def render(self, **kwargs):
        if not self.container.children:
            self.container.children = self.update_view()


class MktMonitor(Monitor):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def make_widgets(self, **kwargs):

        # HIKES and RATES
        self.usd_mtg = MtgGrid(ccy='USD', title='USD Hikes', multipliers=100)
        self.usd_spot = SpotGrid(gen='USD SOFR')
        self.usd_fut = FutureGrid(gen='USD SOFR', ccy='USD')

        self.eur_mtg = MtgGrid(ccy='EUR', title='EUR Hikes', multipliers=100)
        self.eur_spot = SpotGrid(gen='EURIBOR A 6M*', title='EURIBOR')
        self.eur_spot2 = SpotGrid(gen='EUR EONIA')
        self.eur_fut = FutureGrid(gen='EURIBOR A 6M*', title='EURIBOR', ccy='EUR')

        self.gbp_mtg = MtgGrid(ccy='GBP', title='GBP Hikes', multipliers=100)
        self.gbp_spot = SpotGrid(gen='GBP SONIA')
        self.gbp_fut = FutureGrid(gen='GBP SONIA', ccy='GBP')

        # BOND and BOND FUTURES
        self.mkt_govt_bond = GroupMktGrid(
            group='govt bond',
            title='GOVT BOND',
            pct=False,
            precision=3,
            change_precision=2,
            show_subgroup=False,
            multipliers={'change': 100},
            field='yield',
            reverse_change_color=True,
            grid_kwargs=dict(max_height=None, column_widths={'': 50})
        )
        self.mkt_govt_bond_fut = CustomGovtBondFutGrid(group='govt bond fut', title='GOVT BOND Fut')

        # EQUITY, FX, COMDTY, CREDIT
        self.mkt_equity = GroupMktGrid(group='equity', title='EQUITY')
        self.mkt_equity_fut = GroupMktGrid(group='equity_fut', title='EQUITY FUTURES')
        self.mkt_fx = GroupMktGrid(
            group='fx',
            pct=False,
            title='FX',
            grid_kwargs={'column_widths': {'live': 75, 'change': 70}},
            precision=4,
            change_precision=4
        )

        self.mkt_comdty = GroupMktGrid(group='commodity', title='COMDTY')
        self.mkt_fci = CustomFCIMkt(group='fci', title='FCIs', more_keys=['nfci'], precision=4)
        self.mkt_credit = GroupMktGrid(group='credit_index', title='CREDIT', pct=False)

        # CHARTS
        self.usd_chart = KeyChart(gen='USD SOFR', chart_kwargs=dict(height=300), html_title=False)
        self.eur_chart = KeyChart(gen='EURIBOR A 6M*', chart_kwargs=dict(height=300), html_title=False)
        self.gbp_chart = KeyChart(gen='GBP SONIA', chart_kwargs=dict(height=300), html_title=False)

        # SWAP MATRIX
        self.mat_usd_live = MatGrid(ccy='USD', curve_type='live', title='Fwd live', multipliers=100)
        self.mat_eur_live = MatGrid(ccy='EUR', curve_type='live', title='Fwd live', multipliers=100)
        self.mat_gbp_live = MatGrid(ccy='GBP', curve_type='live', title='Fwd live', multipliers=100)

        self.mat_usd_chg = MatGrid(
            ccy='USD',
            curve_type='change',
            title='Fwd change',
            multipliers=10000,
            red_negative=True,
            precision=2,
            reverse_change_color=True,
        )
        self.mat_eur_chg = MatGrid(
            ccy='EUR',
            curve_type='change',
            title='Fwd change',
            multipliers=10000,
            red_negative=True,
            precision=2,
            reverse_change_color=True,
        )
        self.mat_gbp_chg = MatGrid(
            ccy='GBP',
            curve_type='change',
            title='Fwd change',
            multipliers=10000,
            red_negative=True,
            precision=2,
            reverse_change_color=True,
        )

        # INFLATION SWAPS MATRIX
        self.zcil_infl_mat_usd = MatGrid(
            ccy='USD',
            curve_type='live_infl',
            dc_key='zcil_mat',
            title='Fwd Infl',
            multipliers=1,
            precision=2,
        )

        self.zcil_infl_mat_eur = MatGrid(
            ccy='EUR',
            curve_type='live_infl',
            dc_key='zcil_mat',
            title='Fwd Infl',
            multipliers=1,
            precision=2,
        )

        self.zcil_infl_mat_gbp = MatGrid(
            ccy='GBP',
            curve_type='live_infl',
            dc_key='zcil_mat',
            title='Fwd Infl',
            multipliers=1,
            precision=2,
        )

        self.zcil_infl_mat_usd_chg = MatGrid(
            ccy='USD',
            curve_type='change',
            dc_key='zcil_mat',
            title='Fwd Infl change',
            multipliers=100,
            red_negative=True,
            precision=2,
            reverse_change_color=True,
        )

        self.zcil_infl_mat_eur_chg = MatGrid(
            ccy='EUR',
            curve_type='change',
            dc_key='zcil_mat',
            title='Fwd Infl change',
            multipliers=100,
            red_negative=True,
            precision=2,
            reverse_change_color=True,
        )

        self.zcil_infl_mat_gbp_chg = MatGrid(
            ccy='GBP',
            curve_type='change',
            dc_key='zcil_mat',
            title='Fwd Infl change',
            multipliers=100,
            red_negative=True,
            precision=2,
            reverse_change_color=True,
        )

    def update_view(self, **kwargs):
        children = [
            v.Row(
                children=[
                    v.Col(
                        # cols=6,
                        # xl=3,
                        children=[
                            w.VBox([
                                w.HBox([
                                    self.usd_mtg.view,
                                    self.eur_mtg.view,
                                    self.gbp_mtg.view
                                ]),
                                w.HBox([
                                    self.usd_fut.view,
                                    self.eur_fut.view,
                                    self.gbp_fut.view,
                                ]),
                                w.HBox([
                                    self.usd_spot.view,
                                    self.eur_spot.view,
                                    self.gbp_spot.view
                                ])
                            ])
                        ]
                    ),
                    v.Col(
                        # cols=3,
                        # xl=2,
                        children=[
                            w.VBox([
                                self.mkt_govt_bond.view,
                                self.mkt_govt_bond_fut.view
                            ])
                        ]
                    ),
                    v.Col(
                        # cols=3,
                        # xl=2,
                        children=[
                            w.VBox([
                                self.mkt_equity.view,
                                self.mkt_equity_fut.view,
                                self.mkt_fx.view,
                                # self.mkt_comdty.view,
                                # self.mkt_fci.view,
                                # self.mkt_credit.view
                            ])
                        ]
                    ),
                    v.Col(
                        # cols=3,
                        # xl=2,
                        children=[
                            w.VBox([
                                self.mkt_comdty.view,
                                self.mkt_fci.view,
                                self.mkt_credit.view
                            ])
                        ]
                    ),
                ],
            ),
            v.Row(
                children=[
                    v.Col(
                        cols=4,
                        children=[self.usd_chart.view]
                    ),
                    v.Col(
                        cols=4,
                        children=[self.eur_chart.view]
                    ),
                    v.Col(
                        cols=4,
                        children=[self.gbp_chart.view]
                    ),
                ]
            ),
            # v.Row(children=[v.Col(cols=5, children=[fly_grid.expr_dg.view])]),
            v.Row(
                children=[
                    v.Col(
                        # cols=4,
                        children=[self.mat_usd_live.view]
                    ),
                    v.Col(
                        # cols=4,
                        children=[self.mat_eur_live.view]
                    ),
                    v.Col(
                        # cols=4,
                        children=[self.mat_gbp_live.view]
                    ),
                ]
            ),
            v.Row(
                children=[
                    v.Col(
                        # cols=4,
                        children=[self.mat_usd_chg.view]
                    ),
                    v.Col(
                        # cols=4,
                        children=[self.mat_eur_chg.view]
                    ),
                    v.Col(
                        # cols=4,
                        children=[self.mat_gbp_chg.view]
                    ),
                ]
            ),
            v.Row(
                children=[
                    v.Col(
                        # cols=4,
                        children=[self.zcil_infl_mat_usd.view]
                    ),
                    v.Col(
                        # cols=4,
                        children=[self.zcil_infl_mat_eur.view]
                    ),
                    v.Col(
                        # cols=4,
                        children=[self.zcil_infl_mat_gbp.view]
                    ),
                ]
            ),
            v.Row(
                children=[
                    v.Col(
                        # cols=4,
                        children=[self.zcil_infl_mat_usd_chg.view]
                    ),
                    v.Col(
                        # cols=4,
                        children=[self.zcil_infl_mat_eur_chg.view]
                    ),
                    v.Col(
                        # cols=4,
                        children=[self.zcil_infl_mat_gbp_chg.view]
                    ),
                ]
            )
        ]
        return children


class MktMonitorMenashe(Monitor):
    def __init__(self, expression_view=None, **kwargs):
        self.expression_view = expression_view
        super().__init__(**kwargs)

    def make_widgets(self, **kwargs):

        # HIKES and RATES
        self.usd_mtg = MtgGrid(ccy='USD', title='USD Hikes', multipliers=100)
        self.usd_spot = SpotGrid(gen='USD SOFR')
        self.usd_fut = FutureGrid(gen='USD SOFR', ccy='USD')

        self.eur_mtg = MtgGrid(ccy='EUR', title='EUR Hikes', multipliers=100)
        self.eur_spot = SpotGrid(gen='EURIBOR A 6M*', title='EURIBOR')
        self.eur_spot2 = SpotGrid(gen='EUR EONIA')
        self.eur_fut = FutureGrid(gen='EURIBOR A 6M*', title='EURIBOR', ccy='EUR')

        self.gbp_mtg = MtgGrid(ccy='GBP', title='GBP Hikes', multipliers=100)
        self.gbp_spot = SpotGrid(gen='GBP SONIA')
        self.gbp_fut = FutureGrid(gen='GBP SONIA', ccy='GBP')

        # BOND and BOND FUTURES
        self.mkt_govt_bond = GroupMktGrid(
            group='govt bond',
            title='GOVT BOND',
            pct=False,
            precision=3,
            change_precision=2,
            show_subgroup=False,
            multipliers={'change': 100},
            field='yield',
            reverse_change_color=True,
            grid_kwargs=dict(max_height=None, column_widths={'': 50})
        )
        self.mkt_govt_bond_fut = CustomGovtBondFutGrid(group='govt bond fut', title='GOVT BOND Fut')

        # EQUITY, FX, COMDTY, CREDIT
        self.mkt_equity = GroupMktGrid(group='equity', title='EQUITY')
        self.mkt_equity_fut = GroupMktGrid(group='equity_fut', title='EQUITY FUTURES')
        self.mkt_fx = GroupMktGrid(
            group='fx',
            pct=False,
            title='FX',
            grid_kwargs={'column_widths': {'live': 75, 'change': 70}},
            precision=4,
            change_precision=4
        )

        self.mkt_comdty = GroupMktGrid(group='commodity', title='COMDTY')
        self.mkt_fci = CustomFCIMkt(group='fci', title='FCIs', more_keys=['nfci'], precision=4)
        self.mkt_credit = GroupMktGrid(group='credit_index', title='CREDIT', pct=False)

        # CHARTS
        self.usd_chart = KeyChart(gen='USD SOFR', chart_kwargs=dict(height=300), html_title=False)
        self.eur_chart = KeyChart(gen='EURIBOR A 6M*', chart_kwargs=dict(height=300), html_title=False)
        self.gbp_chart = KeyChart(gen='GBP SONIA', chart_kwargs=dict(height=300), html_title=False)

        # SWAP MATRIX
        self.mat_usd_live = MatGrid(ccy='USD', curve_type='live', title='Fwd live', multipliers=100)
        self.mat_eur_live = MatGrid(ccy='EUR', curve_type='live', title='Fwd live', multipliers=100)
        self.mat_gbp_live = MatGrid(ccy='GBP', curve_type='live', title='Fwd live', multipliers=100)

        self.mat_usd_chg = MatGrid(
            ccy='USD',
            curve_type='change',
            title='Fwd change',
            multipliers=10000,
            red_negative=True,
            precision=2,
            reverse_change_color=True,
        )
        self.mat_eur_chg = MatGrid(
            ccy='EUR',
            curve_type='change',
            title='Fwd change',
            multipliers=10000,
            red_negative=True,
            precision=2,
            reverse_change_color=True,
        )
        self.mat_gbp_chg = MatGrid(
            ccy='GBP',
            curve_type='change',
            title='Fwd change',
            multipliers=10000,
            red_negative=True,
            precision=2,
            reverse_change_color=True,
        )

        # INFLATION SWAPS MATRIX
        self.zcil_infl_mat_usd = MatGrid(
            ccy='USD',
            curve_type='live_infl',
            dc_key='zcil_mat',
            title='Fwd Infl',
            multipliers=1,
            precision=2,
        )

        self.zcil_infl_mat_eur = MatGrid(
            ccy='EUR',
            curve_type='live_infl',
            dc_key='zcil_mat',
            title='Fwd Infl',
            multipliers=1,
            precision=2,
        )

        self.zcil_infl_mat_gbp = MatGrid(
            ccy='GBP',
            curve_type='live_infl',
            dc_key='zcil_mat',
            title='Fwd Infl',
            multipliers=1,
            precision=2,
        )

        self.zcil_infl_mat_usd_chg = MatGrid(
            ccy='USD',
            curve_type='change',
            dc_key='zcil_mat',
            title='Fwd Infl change',
            multipliers=100,
            red_negative=True,
            precision=2,
            reverse_change_color=True,
        )

        self.zcil_infl_mat_eur_chg = MatGrid(
            ccy='EUR',
            curve_type='change',
            dc_key='zcil_mat',
            title='Fwd Infl change',
            multipliers=100,
            red_negative=True,
            precision=2,
            reverse_change_color=True,
        )

        self.zcil_infl_mat_gbp_chg = MatGrid(
            ccy='GBP',
            curve_type='change',
            dc_key='zcil_mat',
            title='Fwd Infl change',
            multipliers=100,
            red_negative=True,
            precision=2,
            reverse_change_color=True,
        )

    def update_view(self, **kwargs):
        children = [
            v.Row(
                class_='ma-0 pa-0',
                children=[
                    v.Col(
                        # cols=6,
                        # xl=3,
                        class_='ma-0 pa-0',
                        children=[
                            w.VBox([
                                w.HBox([
                                    self.usd_mtg.view,
                                    self.eur_mtg.view,
                                    self.gbp_mtg.view
                                ]),
                                w.HBox([
                                    self.usd_fut.view,
                                    self.eur_fut.view,
                                    self.gbp_fut.view,
                                ]),
                                w.HBox([
                                    self.usd_spot.view,
                                    self.eur_spot.view,
                                    self.gbp_spot.view
                                ])
                            ])
                        ],

                    ),
                    v.Col(
                        # cols=3,
                        # xl=2,
                        class_='ma-0 pa-0',
                        children=[
                            w.VBox([
                                self.mkt_govt_bond.view,
                                self.mkt_govt_bond_fut.view
                            ])
                        ]
                    ),
                    v.Col(
                        # cols=3,
                        # xl=2,
                        class_='ma-0 pa-0',
                        children=[
                            w.VBox([
                                self.mkt_equity.view,
                                self.mkt_equity_fut.view,
                                self.mkt_fx.view,
                                # self.mkt_comdty.view,
                                # self.mkt_fci.view,
                                # self.mkt_credit.view
                            ])
                        ],
                    ),
                    v.Col(
                        # cols=3,
                        # xl=2,
                        class_='ma-0 pa-0',
                        children=[
                            w.VBox([
                                self.mkt_comdty.view,
                                self.mkt_fci.view,
                                self.mkt_credit.view
                            ])
                        ],

                    ),
                ],
            ),
            v.Row(
                class_='ma-0 pa-0',
                children=[
                    v.Col(
                        cols=4,
                        class_='ma-0 pa-0',
                        children=[self.usd_chart.view],
                    ),
                    v.Col(
                        cols=4,
                        class_='ma-0 pa-0',
                        children=[self.eur_chart.view],

                    ),
                    v.Col(
                        cols=4,
                        class_='ma-0 pa-0',
                        children=[self.gbp_chart.view],
                    ),
                ],
            ),
            # v.Row(children=[v.Col(cols=5, children=[fly_grid.expr_dg.view])]),
            v.Row(
                children=[
                    v.Col(
                        # cols=4,
                        children=[self.mat_usd_live.view]
                    ),
                    v.Col(
                        # cols=4,
                        children=[self.mat_eur_live.view]
                    ),
                    v.Col(
                        # cols=4,
                        children=[self.mat_gbp_live.view]
                    ),
                ]
            ),
            v.Row(
                children=[
                    v.Col(
                        # cols=4,
                        children=[self.mat_usd_chg.view]
                    ),
                    v.Col(
                        # cols=4,
                        children=[self.mat_eur_chg.view]
                    ),
                    v.Col(
                        # cols=4,
                        children=[self.mat_gbp_chg.view]
                    ),
                ]
            ),
            v.Row(
                children=[
                    v.Col(
                        # cols=4,
                        children=[self.zcil_infl_mat_usd.view]
                    ),
                    v.Col(
                        # cols=4,
                        children=[self.zcil_infl_mat_eur.view]
                    ),
                    v.Col(
                        # cols=4,
                        children=[self.zcil_infl_mat_gbp.view]
                    ),
                ]
            ),
            v.Row(
                children=[
                    v.Col(
                        # cols=4,
                        children=[self.zcil_infl_mat_usd_chg.view]
                    ),
                    v.Col(
                        # cols=4,
                        children=[self.zcil_infl_mat_eur_chg.view]
                    ),
                    v.Col(
                        # cols=4,
                        children=[self.zcil_infl_mat_gbp_chg.view]
                    ),
                ]
            )
        ]
        return children


class VolMonitor(Monitor):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def make_widgets(self, **kwargs):
        self.usd_vol = MatGrid(
            ccy='USD',
            dc_key='vol_mat',
            curve_type='live',
            title='Vol live',
            multipliers=10000,
            precision=1,
            bar_renderer={'': ''}
        )

        self.usd_chg = MatGrid(
            ccy='USD',
            dc_key='vol_mat',
            curve_type='change',
            title='Vol Change',
            multipliers=10000,
            precision=3,
            bar_renderer={'mid': 0, 'scheme': 'YlGnBu', 'max_mult': 1.5},
            red_negative=True,
            positive_color='white'
        )

        self.usd_vol = MatGrid(
            ccy='USD',
            dc_key='vol_mat',
            curve_type='live',
            title='Vol live',
            multipliers=10000,
            precision=1,
            bar_renderer={'': ''}
        )

        self.usd_chg = MatGrid(
            ccy='USD',
            dc_key='vol_mat',
            curve_type='change',
            title='Vol Change',
            multipliers=10000,
            precision=3,
            bar_renderer={'mid': 0, 'scheme': 'YlGnBu', 'max_mult': 1.5},
            red_negative=True,
            positive_color='white'
        )

        self.eur_vol = MatGrid(
            ccy='EUR',
            dc_key='vol_mat',
            curve_type='live',
            title='Vol live',
            multipliers=10000,
            precision=1,
            bar_renderer={'': ''}
        )

        self.eur_chg = MatGrid(
            ccy='EUR',
            dc_key='vol_mat',
            curve_type='change',
            title='Vol Change',
            multipliers=10000,
            precision=3,
            bar_renderer={'mid': 0, 'scheme': 'YlGnBu', 'max_mult': 1.5},
            red_negative=True,
            positive_color='white'
        )

        self.gbp_vol = MatGrid(
            ccy='GBP',
            dc_key='vol_mat',
            curve_type='live',
            title='Vol live',
            multipliers=10000,
            precision=1,
            bar_renderer={'': ''}
        )

        self.gbp_chg = MatGrid(
            ccy='GBP',
            dc_key='vol_mat',
            curve_type='change',
            title='Vol Change',
            multipliers=10000,
            precision=3,
            bar_renderer={'mid': 0, 'scheme': 'YlGnBu', 'max_mult': 1.5},
            red_negative=True,
            positive_color='white'
        )

    def update_view(self, **kwargs):
        children = [
            v.Row(
                children=[
                    v.Col(
                        # cols=6,
                        # xl=4,
                        children=[
                            self.usd_vol.view,
                        ]
                    ),
                    v.Col(
                        # cols=6,
                        # xl=4,
                        children=[
                            self.usd_chg.view,
                        ]
                    )
                ]
            ),
            v.Row(
                children=[
                    v.Col(
                        # cols=6,
                        # xl=4,
                        children=[
                            self.eur_vol.view,
                        ]
                    ),
                    v.Col(
                        # cols=6,
                        # xl=4,
                        children=[
                            self.eur_chg.view,
                        ]
                    )
                ]
            ),
            v.Row(
                children=[
                    v.Col(
                        # cols=6,
                        # xl=4,
                        children=[
                            self.gbp_vol.view,
                        ]
                    ),
                    v.Col(
                        # cols=6,
                        # xl=4,
                        children=[
                            self.gbp_chg.view,
                        ]
                    )
                ]
            ),
        ]
        return children


class ECOMonitor(Monitor):

    def make_widgets(self, **kwargs):
        self.eco = ECOGrid()

    def update_view(self, **kwargs):
        return [self.eco.view]
