from functools import partial
import numpy as np
import pandas as pd
import ipywidgets as w
from copy import deepcopy

from api.old.base import View


def default_styler(
        df,
        precision=4,
        date_format='%Y-%m-%d',
        na_rep='-',
        hover_color="#ffff99",
        formatters=None,
        multipliers=None,
        apply=None,
        applymap=None,
        format_index=None,
        bar=None,
        finalize=None,
        finalize_kwargs=None,
):
    format_index = format_index or {}
    bar = bar or {}

    th_props = [
        ('font-size', '11px'),
        ('text-align', 'center'),
        ('font-weight', 'bold'),
        # ('color', '#6d6d6d'),
        ('background-color', '#f7f7f9'),
        ('border-bottom', '1px solid  #d7d7d7'),
        ('white-space', 'nowrap !important')
    ]

    tr_props = [
        ("line-height", "11px"),
        # ('border-color', 'white'),
        ('background-color', 'white'),
        ('border-bottom', '1px solid  #d7d7d7'),
        # ('white-space', 'nowrap !important')
    ]
    td_props = [
        ('font-size', '11px'),
        ('white-space', 'nowrap !important')
    ]

    selectors = [
        {"selector": "tr", "props": tr_props},
        {"selector": "td, th", "props": "line-height: inherit; padding-top: 2.5px; padding-bottom: 2.5px;"},
        {'selector': 'th', 'props': th_props},
        {'selector': 'td', 'props': td_props},
        *hover(hover_color)
    ]

    if multipliers:
        if isinstance(multipliers, int):
            df = df * multipliers
        else:
            for mult in multipliers:
                df[mult] = multipliers[mult] * df[mult]

    date_cols = {}
    if date_format:
        date_format = f'{{:{date_format}}}'
        for col in df:
            if np.issubdtype(df[col].dtype, np.datetime64):
                date_cols[col] = partial(format_time_nat, fmt=date_format)

    formatters = {**(formatters or {}), **date_cols}

    styler = df.style. \
        set_table_styles(selectors). \
        format(
            formatter=formatters,
            precision=precision,
            na_rep=na_rep,
        )

    if apply and not isinstance(apply, list):
        apply = [apply]
        for fn in apply:
            if not isinstance(fn, dict):
                fn = {'dict': fn}
            styler = styler.apply(**fn)

    if applymap and not isinstance(applymap, list):
        applymap = [applymap]
        for fn in applymap:
            if not isinstance(fn, dict):
                fn = {'dict': fn}
            styler = styler.applymap(**fn)
    styler = styler.format_index(**format_index)

    styler = styler if not bar else styler.bar(**bar)

    if finalize:
        finalize_kwargs = finalize_kwargs or {}
        styler = finalize(styler, **finalize_kwargs)

    return styler


def negative_red(val):
    """
    Takes a scalar and returns a string with
    the css property `'color: red'` for negative
    strings, black otherwise.
    """
    color = 'red' if val < 0 else 'black'
    return 'color: %s' % color


def format_time_nat(t, fmt='{:%Y-%m-%d}'):
    try:
        return fmt.format(t) # or strftime
    except ValueError:
        return t


def hover(hover_color="#ffff99"):
    return [
        dict(
            selector="tr:hover",
            props=[("background-color", "%s" % hover_color)]
        ),
        dict(
            selector="th:hover",
            props=[("background-color", "%s" % hover_color)]
        ),
    ]


class DFOutput(View):
    def __init__(self, df, out=None, style_fn=default_styler, styler_kwargs=None, margin=None, **kwargs):
        self._df = df

        layout_kwargs = {
            'layout': dict(
                margin=f'{margin[0]}px {margin[1]}px {margin[2]}px {margin[3]}px')
        } if margin else {}
        self.out = out or w.Output(**layout_kwargs)
        self.style_fn = style_fn or (lambda df: df.style)
        self.styler_kwargs = styler_kwargs or {}
        super().__init__(**kwargs)

    def make_widgets(self, **kwargs):
        self.styler = self.style_fn(self.df, **self.styler_kwargs)
        with self.out:
            self.out.clear_output(wait=True)
            # display(self.style_fn(self._df, **self.styler_kwargs))

            self.out.append_display_data(self.styler)

    def make_view(self, **kwargs):
        self.view = self.out

    @property
    def df(self):
        return self._df if isinstance(self._df, pd.DataFrame) else self._df.to_frame()

    @df.setter
    def df(self, value):
        self._df = value
        self.styler = self.style_fn(value, **self.styler_kwargs)
        with self.out:
            self.out.clear_output(wait=True)
            # display(self.style_fn(self._df, **self.styler_kwargs))
            self.out.append_display_data(self.styler)


def custom_row_line(df, mapping, border=2, color='#ABABAB'):
    dfs = pd.DataFrame().reindex_like(df).fillna('')
    if isinstance(mapping, dict):
        mapping = {key: mapping[key]  for key in df.index}
        grouper = [*mapping.values()]
        last_rows = dfs.reset_index().groupby(grouper, as_index=False, sort=False).last().iloc[:, 0]
    else:  # assuming is a list
        last_rows = mapping
    mask = dfs.index.isin(last_rows)
    dfs.loc[mask, :] = f'border-bottom: {border}px solid  {color}'
    return dfs


def custom_index_row_line(ser, mapping, border=2, color='#ABABAB'):
    serf = pd.Series(dtype=object).reindex_like(ser).fillna('')
    if isinstance(mapping, dict):
        mapping = {key: mapping[key]  for key in ser}
        grouper = [*mapping.values()]
        last_rows = serf.to_frame().reset_index().groupby(grouper, as_index=False, sort=False).last().iloc[:, 0]
        mask = serf.index.isin(last_rows)
    else:  # assuming is a list
        last_rows = mapping
        mask = ser.isin(last_rows)
    serf.loc[mask] = f'border-bottom: {border}px solid  {color} !important'
    return serf


def custom_styler_row_line(styler, **kwargs):
    styler = styler.apply(custom_row_line, axis=None, **kwargs)
    styler = styler.apply_index(custom_index_row_line, axis=0, **kwargs)
    return styler


from ipydatagrid import DataGrid
class DataGridGio(DataGrid):
    _max_width = 576
    _max_height = 600
    _adjustment = 25
    def __init__(self, dataframe, **kwargs):

        if "index_name" in kwargs:
            self._index_name = kwargs["index_name"]
        else:
            self._index_name = None

        self._first_call = True
        self._layout_init = kwargs.get('layout', {})

        self.data = dataframe
        df = self.data
        kwargs = self.auto_resize_grid(df, **kwargs)

        super().__init__(dataframe, **kwargs)

    def auto_resize_grid(self, data, **kwargs):
        df = data
        max_width = kwargs.pop('max_width', self._max_width)
        max_height = kwargs.pop('max_height', self._max_height)
        adjustment = kwargs.pop('adjustment', self._adjustment)

        column_widths = kwargs.get('column_widths', {})
        base_row_size = kwargs.get('base_row_size', 20)
        base_column_size = kwargs.get('base_column_size', 64)
        base_row_header_size = kwargs.get('base_row_header_size', 64)
        base_column_header_size = kwargs.get('base_column_header_size', 20)
        index_names = [*df.index.names]
        index_size = np.sum([column_widths.get(v, base_row_header_size) for v in index_names])
        columns_size = np.sum([column_widths.get(v, base_column_size) for v in df.columns])
        # (column_widths)
        # print([column_widths.get(v, base_column_size) for v in df.columns])

        width = index_size + columns_size + adjustment
        height = len(df) * base_row_size + df.columns.nlevels * base_column_header_size + adjustment
        layout = kwargs.pop('layout', {})
        lo_width = layout.get('width', f"{width if width < max_width else ''}px")
        lo_height = layout.get('height', f"{height if height < max_height else ''}px")
        if lo_width != 'px':
            layout['width'] = lo_width
        if lo_height != 'px':
            layout['height'] = lo_height
        layout["align-content"] = "center"
        kwargs['layout'] = layout
        # print(layout)

        return kwargs

    @DataGrid.data.setter
    def data(self, dataframe):
        # Reference for the original frame column and index names
        # This is used to when returning the view data model
        self.__dataframe_reference_index_names = dataframe.index.names
        self.__dataframe_reference_columns = dataframe.columns
        dataframe = dataframe.copy()

        # Primary key used
        index_key = self.get_dataframe_index(dataframe)

        self._data = self.generate_data_object(
            dataframe, "ipydguuid", index_key
        )

        if not self._first_call:
            kwargs = self.auto_resize_grid(
                self.data,
                column_widths=self.column_widths,
                base_row_size=self.base_row_size,
                base_column_size=self.base_column_size,
                base_row_header_size=self.base_row_header_size,
                base_column_header_size=self.base_column_header_size,
                layout=deepcopy(self._layout_init)
            )

            self.layout = kwargs['layout']
        else:
            self._first_call = False
