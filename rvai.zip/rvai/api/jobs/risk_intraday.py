import base64
import smtplib
from copy import deepcopy
from itertools import combinations, permutations
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from functools import partial


import bhutils
import blpapi
import ipyvuetify as v
import ipywidgets as w
import dataframe_image as dfi
import numpy as np
import pandas as pd
from IPython.display import display, clear_output
from scipy.optimize import minimize, linprog
from scipy.special import comb, perm

from api.risk.var import (
    VaRPnl,
    get_db_from_clarion_positions,
    get_fut_trade_spec,
    get_var_ts,
    get_db_from_specs,
    var_ptf,
    cvar_ptf,
    tail_ptf,
    get_clarion_fut_trade_spec,
    get_positions_in_book
)

from api.email import smtp_server, to_email_test, to_email_all, df_to_html, from_email, to_email_ext, get_email

from gioutils.tools_clarion import get_clarion_positions
from gioutils.clarion_ext import Runner
from gioutils.gui.pandas import millifyp as millify
from gioutils.utils import encode_df_as_image_tag, get_specific_future, filter_high_corr

rng = np.random.default_rng()

# max_size = 10e3
# max_iter = 1
# corr_threshold = 0.97
# n_trades = 5
#
# new_trades_list = [
#     ('er', 'u24'),
#     ('sfr', 'm24'),
#     ('rx', 'm23'),
#     ('ty', 'm23'),
# ]

stirs = [
    'er',
    'sfr',
    'sfi',
    'ff'
]

govts = [
    'tu',
    'fv',
    'ty',
    'us',
    'du',
    'oe',
    'rx',
    'ub',
]


def bbg_stir_to_clarion(code, date=None):
    date = date or pd.Timestamp.now()
    year = str(date.year)[-2]
    return f"{code[:-1]}{year}{code[-1]}"


def min_cvar_linprog(current_ptf, new_trades, q=0.05, min_size=None, max_size=None):
    X = pd.concat([current_ptf, new_trades], axis=1).dropna()
    t, n = X.shape
    c = np.concatenate(
        [
            np.zeros(shape=n),
            np.full(shape=t, fill_value=(q * t) ** -1),
            np.ones(shape=1)
        ]
    )
    A_ub = np.concatenate(
        [
            -X.to_numpy(),
            -np.eye(t),
            -np.ones(shape=(t, 1)),
        ],
        axis=1
    )
    b_ub = np.zeros(t)
    A_eq = np.zeros(shape=(1, A_ub.shape[1]))
    A_eq[0, 0] = 1
    b_eq = 1
    bounds = [
        # None,
        (1.0, 1.0),
        *[(min_size, max_size) for col in X.columns[1:]],
        *[(0, None) for i in range(t)],
        (None, None)
    ]

    r = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq, bounds=bounds)
    wgt = r['x'][1:X.shape[1]]
    return r, wgt


def send_live_var_email(
        var_close,
        var_intraday,
        var_new,
        tails_close,
        tails_intraday,
        tails_new,
        intraday_group,
        trades_show,
        tail_risk_df=None,
        cob_tail_reduction_df=None,
        to=None
):
    to_email = get_email(to)
    font_family = 'Helvetica, Arial, Sans-Serif'

    message = MIMEMultipart("alternative")
    message["Subject"] = f'LIVE VaR REDUCTION - {pd.Timestamp.now(): %d%b%y %H:%M}'
    message["From"] = from_email
    message["To"] = ','.join(to_email)

    # dfs = [encode_df_as_image_tag(s) for s in [intraday_group, trades_show]]

    dfs = [df_to_html(s.style.format(millify)) for s in [intraday_group, trades_show]]
    html_body = f"<h3 style=\"font-family:{font_family};\">Close VaR:{'&nbsp;' * 40}{var_close: .2%}</h3>"
    # html_body = html_body + f"<h4 style=\"font-family:{font_family};\">Tail Close:{'&nbsp;' * 2}{tails_close[0]: .2%} and {tails_close[1]: .2%}</h3>" + '<br>' * 3
    html_body = html_body + f"<h4 style=\"font-family:{font_family};\">Daily Tail Close:{'&nbsp;' * 2}{tails_close[0]: .2%}</h3>" + '<br>' * 3
    html_body = html_body + f"<h3 style=\"font-family:{font_family};\">VaR with Intraday (below): {'&nbsp;' * 13}{var_intraday: .2%}</h3>"
    # html_body = html_body + f"<h4 style=\"font-family:{font_family};\">Tail Intraday:{'&nbsp;' * 2}{tails_intraday[0]: .2%} and {tails_intraday[1]: .2%}</h3>" + '<br>' * 3
    html_body = html_body + f"<h4 style=\"font-family:{font_family};\">Daily Tail Intraday:{'&nbsp;' * 2}{tails_intraday[0]: .2%}</h3>" + '<br>' * 3
    html_body = html_body + dfs[0] + '<br>' * 3
    html_body = html_body + f"<h3 style=\"font-family:{font_family};\">VaR after the below trades:{'&nbsp;' * 11}{var_new: .2%}</h3>"
    # html_body = html_body + f"<h4 style=\"font-family:{font_family};\">Daily and Weekly Tail after the below trades:{'&nbsp;' * 2}{tails_new[0]: .2%} and {tails_new[1]: .2%}</h3>"
    html_body = html_body + f"<h4 style=\"font-family:{font_family};\">Daily Tail after the below trades:{'&nbsp;' * 2}{tails_new[0]: .2%}</h3>"
    html_body = html_body + dfs[1]

    if tail_risk_df is not None:
        html_body = html_body + f"<h3 style=\"font-family:{font_family};\">Tail Risk Reduction</h3>"
        html_body = html_body + df_to_html(tail_risk_df.drop(['weekly_tail', 'average_tail', 'current_weekly_tail'], axis=1).style.format(partial(millify, pct=False)))

    if cob_tail_reduction_df is not None:
        html_body = html_body + f"<h3 style=\"font-family:{font_family};\">Tail Risk Reduction Relative to COB Portfolio (NO INTRADAY TRADES CONSIDERED)</h3>"
        html_body = html_body + df_to_html(cob_tail_reduction_df.style.format(partial(millify, pct=False)))


    html_ = MIMEText(html_body, "html")
    message.attach(html_)
    smtp = smtplib.SMTP(smtp_server)
    # smtp.set_debuglevel(1)
    smtp.sendmail(from_email, to_email, message.as_string())


def var_reduction_email2(
        clarion,
        bq,
        book='MM',
        n_trades=5,
        corr_threshold=0.97,
        max_size=10e3,
        use_best_var=False,
        mod_var_fn=None,
        new_trades_list=None,
        stirs_first_contract=1,
        send_email=False,
        tail_risk=True,
        tail_risk_futures_to_use=None,
        tail_risk_number_of_assets=2,
        tail_risk_wgt_grid=None,
        tail_risk_grid_max=2000,
        tail_risk_grid_size=9,
):
    bq.start()
    capital = 300e6 if book.lower() == 'mm' else 200e6
    flag = 1.5 / 100 * capital
    runner = Runner(clarion)
    clarion_delta = clarion.metric(
        'delta',
        'Delta',
        'Rates',
        {'VolSpotDynamic': 'StickyDelta', 'RiskSpace': 'Par', 'RiskBuckets': 'Default'}
    )

    dv = VaRPnl()
    wv = VaRPnl()

    dv.get_data(book=book)
    wv.get_data(
        offset='5y',
        horizon='5d',
        book=book
    )

    dv_positions = deepcopy(dv)
    wv_positions = deepcopy(wv)

    if mod_var_fn:
        dv = mod_var_fn(dv)
        wv = mod_var_fn(wv)

    cob_ptf = dv.hist.sum(axis=1).rename('ptf')
    cob_ptf_w = wv.hist.sum(axis=1).rename('ptf')

    # if mod_cob_fn:
    #     dv, cob_ptf = mod_cob_fn(dv).sum(axis=1).rename('ptf')

    ### INTRADAY POSITIONS
    df = get_clarion_positions(clarion, book=f"{book}-BAL")
    # df.loc[df.query("Description == 'USD SOFR CME 3M MAR23JUN24 C 95.500'").index[0], 'Notional'] = - 2000
    intraday = df.query('isIntraday == True')
    intraday_group = intraday.groupby('Description')['Notional'].sum().replace(0, np.nan).dropna().to_frame()
    rates_mask = intraday.loc[intraday['Category'] == 'rates', 'Description'].drop_duplicates().to_list()
    intraday_rates = intraday_group.loc[intraday_group.index.isin(rates_mask)]
    if not intraday_rates.empty:
        db = get_db_from_clarion_positions(intraday)
        intraday_trades, res = get_var_ts(db)
        current_ptf = pd.concat([cob_ptf, intraday_trades], axis=1).sum(axis=1)
        current_ptf_w = pd.concat([cob_ptf_w, intraday_trades.resample('W-FRI').sum()], axis=1).dropna().sum(axis=1)
    else:
        current_ptf = cob_ptf
        current_ptf_w = cob_ptf_w

    ### ALL STIRS AND GOVT FUTURES

    gen_futs = [
        *[f"{code}{i}" for code in stirs for i in range(stirs_first_contract, 16 + 1)],
        *[f"{code}{i}" for code in govts for i in range(1, 1 + 1)]
    ]
    spec_futs = get_specific_future(gen_futs, bq=bq)
    spec_fut_clarion = [fut.split(' ')[0] for fut in spec_futs]
    spec_fut_clarion = [bbg_stir_to_clarion(fut) for fut in spec_fut_clarion]
    all_fut_list = [(fut[:-3].lower(), fut[-3:].lower()) for fut in spec_fut_clarion]
    all_fut_specs = [get_fut_trade_spec(underlying, contract) for underlying, contract in all_fut_list]

    all_fut_db = get_db_from_specs(all_fut_specs)
    all_fut_ts, res = get_var_ts(all_fut_db)
    if not new_trades_list:
        new_trades = filter_high_corr(all_fut_ts, all_fut_ts.corrwith(current_ptf).abs(), threshold=corr_threshold)
    else:
        new_trades_specs = [get_fut_trade_spec(underlying, contract) for underlying, contract in new_trades_list]
        new_trades_db = get_db_from_specs(new_trades_specs)
        new_trades, res = get_var_ts(new_trades_db)

    ### MINIMISE
    # n_trades_ = n_trades  # if not new_trades_list else len(new_trades_list)
    n_trades_ = len(new_trades_list) if new_trades_list and not n_trades else n_trades
    min_ = 1e9
    total = comb(new_trades.shape[1], n_trades_, exact=True)
    for i, comb_ in enumerate(
            combinations(
                new_trades.columns,
                min(n_trades_, new_trades.shape[1]) if n_trades_ > 0 else new_trades.shape[1]
            )
    ):
        new_trades_ = new_trades.loc[:, comb_]
        r, wgt = min_cvar_linprog(
            current_ptf=current_ptf,
            new_trades=new_trades_,
            min_size=-max_size,
            max_size=max_size
        )
        cvar_ = cvar_ptf(current_ptf=current_ptf, new_trades=new_trades_, wgt=wgt, flag=flag)
        var_ = var_ptf(current_ptf=current_ptf, new_trades=new_trades_, wgt=wgt, flag=flag)
        best = var_ if use_best_var else cvar_

        if best < min_:
            min_ = best
            wgt_ = wgt
            ress = new_trades_, r, wgt, cvar_, var_

        print(f"{i + 1}/{total} // {new_trades.shape[1]}_choose_{n_trades_} - {wgt_.round()} {round(ress[-2], 4)} {round(ress[-1], 4)}", end='\r')

    new_trades_ = ress[0]
    new_trades_clarion = [get_clarion_fut_trade_spec(clarion, underlying, contract) for underlying, contract in
                          [(fut[:-3], fut[-3:]) for fut in new_trades_]]
    deltas = runner.run(metrics=[clarion_delta], data_list=new_trades_clarion).loc[:, ['id', 'delta']]
    clear_output()

    var_close = - cob_ptf.quantile(0.05, interpolation='weibull') / flag
    tail_close = - dv.tail(capital=capital).squeeze() / 100
    tail_close_w = - wv.tail(capital=capital).squeeze() / 100
    tails_close = [tail_close, tail_close_w]
    var_intraday = - current_ptf.quantile(0.05, interpolation='weibull') / flag
    tail_intraday = - dv.tail(current_ptf, capital=capital).squeeze() / 100
    tail_intraday_w = - wv.tail(current_ptf_w, capital=capital).squeeze() / 100
    tails_intraday = [tail_intraday, tail_intraday_w]

    trades = pd.Series(wgt_.round(0), index=new_trades_.columns.str.upper(), name='quantity')
    var_new = var_ptf(current_ptf=current_ptf, new_trades=new_trades_, wgt=wgt_, flag=flag)
    tail_new = tail_ptf(current_ptf=current_ptf, new_trades=new_trades_, wgt=wgt_, capital=capital)
    tail_new_w = tail_ptf(current_ptf=current_ptf_w, new_trades=new_trades_.resample('W-FRI').sum(), wgt=wgt_, capital=capital)
    tails_new = [tail_new, tail_new_w]
    deltas_opt = pd.Series(deltas['delta'].to_numpy(), index=deltas['id'].str.upper())
    delta_usd = (trades * deltas_opt).rename('delta$')

    trades_show = pd.concat([trades, delta_usd], axis=1)
    sum_ = trades_show.sum().rename('TOTAL')
    sum_.iloc[0] = np.nan
    sum_ = sum_.to_frame().T
    trades_show = pd.concat([trades_show, sum_])

    display(w.HTML(f"<h3>Close VaR:{'&nbsp;' * 40}{var_close: .2%}</h3>"))
    display(w.HTML(f"<h3>VaR with Intraday (below): {'&nbsp;' * 11}{var_intraday: .2%}</h3>"))
    display(intraday_rates)
    display(w.HTML(f"<h3>VaR after the below trades:{'&nbsp;' * 11}{var_new: .2%}</h3>"))
    display(trades_show)

    if tail_risk:
        i = 0
        min_d_tail = np.inf
        min_w_tail = np.inf
        mins = []
        max_save = 1000

        try_trades = all_fut_ts if tail_risk_futures_to_use is None else all_fut_ts.loc[:, tail_risk_futures_to_use]
        k = tail_risk_number_of_assets
        if tail_risk_wgt_grid is None:
            wgt_grid = np.linspace(-tail_risk_grid_max, tail_risk_grid_max, tail_risk_grid_size).astype(int)
        else:
            wgt_grid = tail_risk_wgt_grid

        tot = int(comb(try_trades.shape[1], k) * perm(len(wgt_grid), k))
        for comb_ in combinations(try_trades.columns, k):
            for perm_ in permutations(wgt_grid, k):
                i += 1
                # print(f"{i} / {tot}", end='\r')
                new_trades = try_trades.loc[:, comb_] * perm_
                new_trades_w = new_trades.resample('W-FRI').sum()
                d_tail = - dv.tail(df=pd.concat([current_ptf, new_trades], axis=1).dropna(), capital=capital,
                                   add=False).squeeze()
                w_tail = - wv.tail(df=pd.concat([current_ptf_w, new_trades_w], axis=1).dropna(), capital=capital,
                                   add=False).squeeze()

                var_tail = var_ptf(current_ptf, new_trades)

                if len(mins) < max_save:
                    mins.append((comb_, perm_, d_tail, w_tail, var_tail))
                    mins.sort(key=lambda lst: lst[2], reverse=True)

                elif d_tail < min_d_tail:
                    mins.append((comb_, perm_, d_tail, w_tail, var_tail))
                    mins.pop(0)
                min_d_tail = min(min_d_tail, d_tail)
                min_w_tail = min(min_w_tail, w_tail)
                print(
                    f"{i} / {tot}, d_tail:  {mins[-1][0]} {mins[-1][1]} d_tail:{round(mins[-1][2], 2)} w_tail:{round(mins[-1][3], 2)}",
                    end='\r')
                # break
            # break
        res = pd.DataFrame(mins, columns=['contracts', 'quantities', 'daily_tail', 'weekly_tail', 'var'])
        res = res.assign(average_tail=res.loc[:, ['daily_tail', 'weekly_tail']].mean(axis=1)).sort_values('daily_tail')
        tail_risk_df = res.head(10)
        tail_risk_df = tail_risk_df.assign(
            current_daily_tail=-dv.tail(current_ptf, capital=capital).squeeze(),
            current_weekly_tail=-wv.tail(current_ptf_w, capital=capital).squeeze()
        )
        cob_tail_reduction = []

        for index, row in res.iterrows():
            add_trades = dict(zip(row['contracts'], row['quantities']))
            additions = all_fut_ts.loc[:, [*add_trades]] * [*add_trades.values()]
            try:
                additions_d = get_positions_in_book(add_trades, dv_positions.ref, dv_positions.hist, False)
                additions_w = get_positions_in_book(add_trades, wv_positions.ref, wv_positions.hist, False)
            except KeyError as e:
                # print(e)
                continue

            var_cob = var_ptf(cob_ptf, additions)
            cob_daily_tail = -dv.tail(additions_d, capital=capital, add=True)
            cob_weekly_tail = -wv.tail(additions_w, capital=capital, add=True)
            cob_tail_reduction.append(
                {
                    'contracts': row['contracts'],
                    'quantities': row['quantities'],
                    'daily_tail': cob_daily_tail.squeeze(),
                    'weekly_tail': cob_weekly_tail.squeeze(),
                    'daily_tail_date': cob_daily_tail.index.strftime("%d%b%y")[0],
                    'weekly_tail_date': cob_weekly_tail.index.strftime("%d%b%y")[0],
                    'var': var_cob
                }
            )
        # return dv_positions, wv_positions
        cob_tail_reduction = pd.DataFrame(cob_tail_reduction)
        cob_tail_reduction = cob_tail_reduction.assign(
            average_tail=cob_tail_reduction.loc[:, ['daily_tail', 'weekly_tail']].mean(axis=1)).sort_values(
            'average_tail')
        cob_tail_reduction_df = cob_tail_reduction.head(10)
        cob_tail_reduction_df = cob_tail_reduction_df.assign(
            cob_daily_tail=-dv.tail(cob_ptf, capital=capital).squeeze(),
            cob_weekly_tail=-wv.tail(cob_ptf_w, capital=capital).squeeze(),
            cob_daily_tail_date=dv.tail(capital=capital).index.strftime("%d%b%y")[0],
            cob_weekly_tail_date=wv.tail(capital=capital).index.strftime("%d%b%y")[0],
            cob_var=var_close
        )

    else:
        tail_risk_df = None
        cob_tail_reduction_df = None

    if send_email:
        send_live_var_email(
            var_close,
            var_intraday,
            var_new,
            tails_close,
            tails_intraday,
            tails_new,
            intraday_rates,
            trades_show,
            tail_risk_df,
            cob_tail_reduction_df,
            to=send_email
        )


