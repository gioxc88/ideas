from threading import Thread

import pandas as pd

from gioutils.ezutils import LiveCurvesLocal, COBCurvesRemote, LiveCurvesRemote, LiveVolsRemote, COBVolsRemote
from gioutils.blpw import BlpQuery
from gioutils.utils import log_time
from .collectors import CollectorStoreMixin
from .gui.renderers import RendererStoreMixin, RendererComponentStoreMixin

pd.options.plotting.backend = "plotly"


class DataCollector:
    def __init__(
            self,
            live_curves=None,
            cob_curves=None,
            live_vols=None,
            cob_vols=None,
            live_infl=None,
            cob_infl=None,
            bq=None,
            curves=None,
            ccys=None,
            collectors=None,
            renderers=None,
            use_store=True,
            use_threads=False
    ):

        # self.live_curves = live_curves or LiveCurvesRemote(curves=curves, ccys=ccys)
        self.live_curves = live_curves or LiveCurvesRemote(curves=curves, ccys=ccys)
        self.cob_curves = cob_curves or COBCurvesRemote(curves=curves, ccys=ccys)
        self.live_vols = live_vols or LiveVolsRemote()
        self.cob_vols = cob_vols or COBVolsRemote()
        self.live_infl = live_infl
        self.cob_infl = cob_infl
        self._collectors = collectors or {}
        self._renderers = renderers or {}
        self._bq = bq or self.start_bq()
        self._curves = curves
        self._ccys = ccys
        self._offset = None
        self.use_store = use_store
        self.use_threads = use_threads

    @property
    def bq(self):
        return self._bq

    def start_bq(self):
        self._bq = BlpQuery(timeout=50000).start()
        return self._bq

    @property
    def collectors(self):
        if not self._collectors and self.use_store:
            collectors = CollectorStoreMixin._store.components
        else:
            collectors = self._collectors
        return collectors

    @property
    def renderers(self):
        if not self._renderers and self.use_store:
            renderers = RendererStoreMixin._store.components
        else:
            renderers = self._renderers
        return renderers

    @property
    def renderer_components(self):
        if not hasattr(self, '_renderer_components') and self.use_store:
            renderer_components = RendererComponentStoreMixin._store.components
        else:
            renderer_components = self._renderer_components
        return renderer_components

    @property
    def offset(self):
        return self._offset

    @offset.setter
    def offset(self, value):
        self._offset = value
        self.cob_curves.build(offset=value)
        self.cob_vols.build(offset=value)
        if self.cob_infl:
            self.cob_infl.build(offset=value)

    def refresh(self, update=True, **kwargs):
        self.get_data(update=update, **kwargs)
        self.update_renderer_components()
        self.update_renderers()

    @log_time()
    def _get_data(self, update=True, **kwargs):
        if not hasattr(self, 'snaps') or update:
            snaps = self.get_snaps()
            self.snaps = snaps

        bq = self.bq.start()
        snaps = self.snaps
        for name, collector in self.collectors.items():
            # kwargs = collector.get_collector_kwargs()

            collector.get_data(
                snaps=snaps,
                cob_date=self.cob_curves.date,
                bq=bq
            )

    @log_time()
    def _get_data_threading(self, update=True, **kwargs):
        if not hasattr(self, 'snaps') or update:
            snaps = self.get_snaps()
            self.snaps = snaps

        bq = self.bq.start()
        snaps = self.snaps
        threads = []
        for name, collector in self.collectors.items():
            # kwargs = collector.get_collector_kwargs()
            thread = Thread(
                target=collector.get_data,
                kwargs=dict(
                    snaps=snaps,
                    cob_date=self.cob_curves.date,
                    bq=bq
                ),
                daemon=True
            )
            thread.start()
            threads.append(thread)
        [thread.join() for thread in threads]

    def get_data(self, update=True, **kwargs):
        if not self.use_threads:
            self._get_data(update=update, **kwargs)
        else:
            self._get_data_threading(update=update, **kwargs)

    def update_renderer_components(self):
        for name, renderer_component in self.renderer_components.items():
            renderer_component.update_widget(dc=self)

    def update_renderers(self):
        for name, renderer in self.renderers.items():
            renderer.render(dc=self)

    def get_snaps(self):
        live = self.live_curves.snap
        cob = self.cob_curves.snap
        live_vol = self.live_vols.get_snap(live)
        cob_vol = self.cob_vols.get_snap(cob)

        snaps = {
            'live': live,
            'cob': cob,
            'live_vol': live_vol,
            'cob_vol': cob_vol
        }

        if self.live_infl:
            snaps['live_infl'] = self.live_infl.snap
        if self.cob_infl:
            snaps['cob_infl'] = self.cob_infl.snap
        return snaps

    def __getitem__(self, item):
        return self.collectors[item]