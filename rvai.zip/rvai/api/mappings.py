strategy_map = {
    'MM:EUR FLY SPRD': 'eurfly',
    'MM:EUR OPEN OPT': 'europt',
    'MM:EUR SHORT CU': 'eursht',
    'MM:EURUSD BOX': 'eurbox',
    'MM:USD OPEN OPT': 'usdopt',
    'MM:USD SHORT CU': 'usdsht'
}