import re
from functools import partial, cache, cached_property

import numpy as np
import pandas as pd

from gioutils.blpw import BlpQuery
from gioutils.utils import (
    today,
    get_bbg_fut_chain_ticker
)
from .utils import parse_dates, parse_number
from ..data.providers import bq
from . import config as c
from .cache import save_data
from .base import TCost, BQ


class Spot(TCost, BQ):
    def __init__(
            self,
            ticker,
            notional=1,
            start_hist=None,
            end_hist=None,
            yk=None,
            **kwargs
    ):
        self.ticker = ticker
        self._notional = notional
        self._yk = yk
        self._start_hist = start_hist or '1y'
        self._end_hist = end_hist or today()

        super().__init__(**kwargs)

    @property
    def name(self):
        return self.ticker.upper()

    @property
    def trade(self):
        return self

    @property
    def yk(self):
        return self._yk

    @property
    def t_cost_key(self):
        return self.ticker

    @property
    def start_hist(self):
        return parse_dates(self._start_hist, self._end_hist, b=False)[0]

    @start_hist.setter
    def start_hist(self, value):
        self._start_hist = value

    @property
    def end_hist(self):
        return parse_dates(self._start_hist, self._end_hist, b=False)[1]

    @end_hist.setter
    def end_hist(self, value):
        self._end_hist = value

    @property
    def notional(self):
        notional = self._notional
        return notional

    # # @property
    # # @cache
    # @property
    # @save_data(keys=['start_hist', 'end_hist'])
    # def yld(self):
    #     return self.get_hist_data('yld_cnv_last', 'quote').dropna()

    # @property
    # @cache
    @property
    @save_data(keys=['start_hist', 'end_hist'])
    def quote(self):
        return self.get_hist_data('px_last', 'quote').dropna()

    # @property
    # @cache
    @property
    @save_data(keys=['start_hist', 'end_hist'])
    def quote_high(self):
        return self.get_hist_data('px_high', 'quote_high').dropna()

    # @property
    # @cache
    @property
    @save_data(keys=['start_hist', 'end_hist'])
    def quote_low(self):
        return self.get_hist_data('px_low', 'quote_low').dropna()

    # @property
    # @cache
    @property
    @save_data(keys=['start_hist', 'end_hist'])
    def quote_open(self):
        return self.get_hist_data('px_open', 'quote_open').dropna()

    # @property
    # @cache
    @property
    @save_data(keys=['start_hist', 'end_hist'])
    def quote_vw(self):
        return self.get_hist_data('eqy_weighted_avg_px', 'quote_vw').dropna()

    @property
    def bars(self):
        df = pd.concat(
            [
                self.quote_open,
                self.quote_high,
                self.quote_low,
                self.quote,
            ],
            axis=1
        )
        df.columns = ['open', 'high', 'low', 'close']
        return df

    @property
    def symbol(self):
        s = f'{self.ticker} {self.yk}'
        return s

    def get_ref_data(self, fields):
        bq = self.bq
        bq.start()
        p = bq.bdp(
            self.symbol,
            fields
        )
        try:
            return float(p[fields].squeeze())
        except:
            return p[fields].squeeze()

    def get_hist_data(self, fields=None, rename=None):
        bq = self.bq.start()
        return bq.bdh(
            self.symbol,
            fields,
            self.start_hist,
            self.end_hist
        ).set_index('date')[fields].rename(f'{self.ticker.upper()}{"" if not rename else f" {rename}"}')

    @property
    def pv(self):
        quote = self.quote
        pv = (quote - quote.iloc[0]) * self.notional
        return pv.rename(pv.name.replace('quote', 'pv'))
        # return (self.quote.diff() * self.point_value).cumsum()

    def get_pnl(self, pnl):
        return self.notional * pnl

    def slippage(self, value):
        return value

    def __repr__(self):
        return f'{self.ticker.upper()} {self.yk.title()} Notional {self.notional}'


class FX(Spot):
    def __init__(self, *args, **kwargs):
        kwargs['yk'] = 'Curncy'
        super().__init__(*args, **kwargs)

    @property
    def last(self):
        if self.end_hist == today():
            last = self.get_ref_data(['last_price'])
            self.quote.iloc[-1] = last
        else:
            self.end_hist = today()
            self.quote
        return self

