import numpy as np
import pandas as pd

from inspect import signature
from techi import api as ti
import gioutils as gu


def get_crossover_signal(line, ffill=True):
    line = (-np.sign(line * line.shift()).replace(1, np.nan) * np.sign(line))
    return line.ffill() if ffill else line


def wait_for_confirmation(signal, wait=3):
    s = signal
    groups = []
    grouper = s.diff().abs().cumsum().fillna(0)
    for index, group in s.groupby(grouper, sort=False):
        group_abs = group.abs()
        if group_abs.sum() < wait:
            group.loc[~group.isna()] = 0
        else:
            idx = (group_abs.cumsum() == wait).idxmax()
            group.loc[(group_abs.index < idx) & (~group.isna())] = np.nan
        groups.append(group)

    ns = pd.concat(groups)
    return ns


class BaseSignal:
    def __init__(self, instrument=None, **kwargs):
        self.instrument = instrument
        self.wait = kwargs.pop('wait', False)
        self._t_cost = kwargs.pop('t_cost', 0)

    def set_instrument(self, value):
        self.instrument = value
        return self

    @property
    def t_cost(self):
        return self._t_cost

    @property
    def signal(self):
        s = self._get_signal()
        return self.post(s).rename('signal')

    @property
    def trades(self):
        return self.signal.fillna(0).diff().fillna(0).rename('trades')

    @property
    def trade_grouper(self):
        return self.trades.astype(bool).cumsum().rename('trade_grouper')

    def post(self, signal):
        if w := self.wait:
            signal = wait_for_confirmation(signal, w)
        # if self.trade_eop:
        #     signal = signal.shift()
        return signal


class TISingal(BaseSignal):
    # _fn = None
    # _line = None

    def __init__(
            self,
            ti_kwargs=None,
            **kwargs
    ):
        self.ti_kwargs = ti_kwargs or {}
        if fn := kwargs.pop('fn', None):
            self._fn = fn
        super().__init__(**kwargs)

    @property
    def line(self):
        return self.ti[self._line]

    @property
    def ti(self):
        fn = getattr(ti, self._fn)
        instr = self.instrument
        return fn(instr.quote, **self.ti_kwargs)


class MACDHistCrossover(TISingal):
    _fn = 'MACD'
    _line = 'macdhist'

    def _get_signal(self):
        line = self.line
        s = get_crossover_signal(line)
        return s


class PandasSignal(BaseSignal):
    def __init__(
            self,
            fn=None,
            accessor=None,
            args=None,
            **kwargs
    ):

        '''
        :param fn:
        :param accessor:
        :param args: either a tuple or list or dictionary, if accessor is passed to accessor, not to
        :param kwargs:
        '''
        self.fn = fn
        self.accessor = accessor
        self.args = args
        super().__init__(**kwargs)


class ZScoreThreshold(BaseSignal):
    def __init__(
            self,
            threshold=2,
            transform=None,
            **kwargs
    ):
        '''
        if specify window or alpha parameter it's automatically rolling or ewm
        default window = 60
        :param threshold:
        :param kwargs:
        '''
        self.threshold = threshold
        self.transform = transform
        rolling_param = signature(pd.DataFrame.rolling).parameters
        ewm_param = signature(pd.DataFrame.ewm).parameters
        is_rolling = any(k in rolling_param for k in kwargs)
        is_ewm = any(k in ewm_param for k in kwargs)

        if is_ewm:
            params = signature(pd.DataFrame.ewm).parameters
            key = 'ewm'
        else:
            key = 'rolling'
            params = signature(pd.DataFrame.rolling).parameters
        if not is_rolling:
            kwargs['window'] = 60

        fn_kwargs = {}
        for p, v in params.items():
            if p != 'self':
                fn_kwargs[p] = kwargs.pop(p, v.default)

        fn_kwargs[key] = True
        self.fn_kwargs = fn_kwargs
        super().__init__(**kwargs)

    def _get_signal(self):
        quote = self.instrument.quote
        if self.transform:
            quote = getattr(quote, self.transform)()
        line = quote.zscore(**self.fn_kwargs).abs()
        s = (line > self.threshold).astype(int)
        s = replace_with_na(s, line)
        return s


def replace_with_na(s1, s2=None, index=None, inplace=False):
    index = index if index else s2.first_valid_index()
    if not inplace:
        s1 = s1.copy()
    s1.iloc[:s1.index.get_loc(index)] = np.nan
    return s1


def sum_(signals, n=1):
    ss = signals.sum(axis=1)
    s = ss >= n
    return s.astype(int)


def pct_(signals, n=50):
    ss = signals.sum(axis=1) / signals.shape[1]
    s = ss >= (n / 100)
    return s.astype(int)


method_lookup = {
    'sum': sum_,
    'pct': pct_
}


class EnsambleSignal:
    '''
    It has to be the same instrument
    methods:
        all
        any{n}
        mean
        average
    '''

    def __init__(self, signals, instrument=None, method=None):
        if instrument:
            for signal in signals:
                if not signal.instrument:
                    signal.set_instrument(instrument)
        self._signals = signals
        self.method = method or 'any'

    @property
    def signal(self):
        method = self.method
        signals = self.signals
        if isinstance(method, str):
            if method[:3] in ['sum', 'pct']:
                method_ = method[:3]
                n = int(method[3:])
                res = method_lookup[method_](signals, n)
            else:
                res = getattr(signals, method)(axis=1)
                if method in ['any', 'all']:
                    res = res.astype(int)
                res = replace_with_na(res, signals)
        else:  # assume it is callable
            res = method(signals)
        return replace_with_na(res, signals)

    @property
    def signals(self):
        return pd.concat([signal.signal for signal in self._signals], axis=1)

