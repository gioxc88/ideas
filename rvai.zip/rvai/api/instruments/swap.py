import json
import sys
import re
import logging
import os
from pathlib import Path
from functools import partial
from itertools import chain
from uuid import uuid4

import blpapi
import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
import QuantLib as ql


from .utils import parse_number, parse_dates, ez_bump, get_notional_from_weights
from .base import TCost
from gioutils.utils import (
    parse_offset, today,
    get_next_n,
    date_from_offset,
    get_bday,
    parse_swap_tenor_expr
)
from gioutils.blpw import BlpQuery
from gioutils.ezutils import bh, bhs
from gioutils import ezutils as ez
from gioutils.gui.pandas import millify


pd.options.plotting.backend = "plotly"



class BaseSwap:
    invalidate_cache = [
    ]

    _instr = 'irs'

    def __init__(
            self,
            ccy,
            generator,
            eff_exp=None,
            tenor_mty=None,
            pay_receive='pay',
            start_hist=None,
            end_hist=None,
            collateral=None,
            strike='a',
            notional=1,
            scale=False,
            **kwargs
    ):
        self.ccy = ccy
        self.generator = generator
        self.eff_exp = eff_exp
        self.tenor_mty = tenor_mty
        self.pay_receive = pay_receive
        self._start_hist = start_hist or '1y'
        self._end_hist = end_hist or today()
        self.collateral = collateral
        self.strike = strike
        self._notional = notional
        self.scale = scale
        super().__init__(**kwargs)

    @property
    def start_hist(self):
        return parse_dates(self._start_hist, self._end_hist, b=False)[0]

    @property
    def end_hist(self):
        return parse_dates(self._start_hist, self._end_hist, b=False)[1]

    @property
    def notional(self):
        notional = self._notional
        if isinstance(notional, str):
            if notional[0].lower() == 'd':
                delta = parse_number(notional[1:])
                # dv01 = ez.get_irbt_ts(
                #     ccy=ccy,
                #     instrument=self._instr,
                #     generator=self.generator,
                #     eff_exp=self.eff_exp,
                #     tenor_mty=self.tenor_mty,
                #     strike=self.strike,
                #     pay_receive=self.pay_receive,
                #     metric='ann01',
                #     start_date=self.start_hist,
                #     end_date=self.start_hist,
                #     collateral=self.collateral,
                # )
                dv01 = self.get_ts(metric='ann01', end_date=self.start_hist, notional=1)
                n = delta / dv01 * 10000
                return n.squeeze()
            else:
                return parse_number(notional)
        return notional

    def get_ts(
            self,
            metric,
            strike=None,
            eff_exp=None,
            tenor_mty=None,
            notional=None,
            end_date=None,
            scale=None,
    ):
        strike = strike or self.strike
        notional = notional or self.notional
        end_date = end_date or self.end_hist
        eff_exp = eff_exp or self.eff_exp
        tenor_mty = tenor_mty or self.tenor_mty

        ts = ez.get_irbt_ts(
            ccy=self.ccy,
            instrument=self._instr,
            generator=self.generator,
            eff_exp=eff_exp,
            tenor_mty=tenor_mty,
            strike=strike,
            pay_receive=self.pay_receive,
            metric=metric,
            nominal=notional,
            start_date=self.start_hist,
            end_date=end_date,
            collateral=self.collateral,
            scale=scale
        )
        return ts

    @property
    def pv(self):
        return self.get_ts(metric='pv')

    @property
    def quote(self):
        return self.get_ts(metric='rate')

    @property
    def dv01(self):
        return self.get_ts(metric='ann01')

    @property
    def delta(self):
        return self.dv01 * self.notional / 10000

    @property
    def trade(self):
        return self

    def slippage(self, value):
        return value

    @property
    def t_cost_key(self):
        return 'swap'


class RealSwap(BaseSwap, TCost):
    _settle = 2

    @property
    def start_date(self):
        if not self.eff_exp:  # meaning it is a spot starting swap (no forward starting date)
            return ez_bump(self.start_hist, f"{self._settle}b", ccy=self.ccy)
        try:  # case when eff_exp is a date
            return ez_bump(pd.to_datetime(self.eff_exp), ccy=self.ccy, ensure_bday=True)
        except:  # case when eff_exp is an offset
            return ez_bump(
                date=
                ez_bump(
                    date=self.start_hist,
                    term=f"{self._settle}b",
                    ccy=self.ccy
                ),
                term=self.eff_exp,
                ccy=self.ccy
            )

    @property
    def end_date(self):
        try:  # try if tenor_mty is a date
            return ez_bump(pd.to_datetime(self.tenor_mty), ccy=self.ccy, ensure_bday=True)
        except:  # it's not a date
            return ez_bump(
                date=self.start_date,
                term=self.tenor_mty,
                ccy=self.ccy,
                ensure_bday=True
            )

    @property
    def end_date_irbt(self):
        try:
            pd.to_datetime(self.tenor_mty)
        except:  # it's not a date
            return self.tenor_mty
        else:
            return self.end_date

    @property
    def atm_rate(self):
        return super().get_ts(
            strike='a',
            metric='rate',
            eff_exp=self.start_date,
            tenor_mty=self.end_date_irbt,
            end_date=self.start_hist,
            notional=1
        )

    def get_ts(
            self,
            metric,
            strike=None,
            eff_exp=None,
            tenor_mty=None,
            notional=None,
            end_date=None,
            scale=None,
    ):
        strike = strike or self.atm_rate.squeeze() * 100
        eff_exp = eff_exp or self.start_date
        tenor_mty = tenor_mty or self.end_date_irbt
        ts = super().get_ts(
            metric=metric,
            strike=strike,
            eff_exp=eff_exp,
            tenor_mty=tenor_mty,
            notional=notional,
            end_date=end_date
        )
        return ts

    @property
    def pv(self):
        return self.get_ts(metric='pv', end_date=self.end_date)

    @property
    def quote(self):
        return self.get_ts(metric='rate', end_date=self.end_date)

    @property
    def dv01(self):
        return self.get_ts(metric='ann01', end_date=self.end_date)

    @property
    def delta(self):
        return self.dv01 * self.notional / 10000

    def __repr__(self):
        notional = millify(self._notional) if not isinstance(self._notional, str) else self._notional
        dates = f"{self.start_date:%Y-%m-%d}x{self.end_date:%Y-%m-%d}"
        return f'{self.pay_receive} irs: {notional}{self.ccy} vs {self.generator} {self.eff_exp}x{self.tenor_mty} ({dates})'


class RollingSwap(BaseSwap, TCost):
    def get_trade(self, date=None):
        date = date or self._start_hist
        real_swap = RealSwap(
            ccy=self.ccy,
            generator=self.generator,
            eff_exp=self.eff_exp,
            tenor_mty=self.tenor_mty,
            pay_receive=self.pay_receive,
            start_hist=date,
            end_hist=self._end_hist,
            collateral=self.collateral,
            strike=self.strike,
            notional=self._notional,
            scale=self.scale,
        )
        self._trade = real_swap
        return self._trade

    @property
    def trade(self):
        if not hasattr(self, '_trade'):
            return self.get_trade()
        return self._trade

    def get_pnl(self, x):
        return x

    def __repr__(self):
        notional = millify(self._notional) if not isinstance(self._notional, str) else self._notional
        return f'{self.pay_receive} irs: {notional}{self.ccy} vs {self.generator} {self.eff_exp}x{self.tenor_mty}'


def get_signed_wtgs(wgts=None, pay_receive='pay'):
    wgts = np.asarray(wgts)
    signs = [-1, 1, -1] if pay_receive.lower() == 'pay' else [1, -1, 1]
    signs = np.asarray(signs)
    return wgts * signs


pay_rec_map = {
    1: 'pay',
    -1: 'rec'
}


class SwapBasket:
    # wgts = (1,)
    # pay_sign = (1,)
    # rec_sign = (1,)

    def __init__(
            self,
            components,
            wgts=None,
            pay_receive='pay',
            pay_sign=None,
            rec_sign=None
    ):
        self.components = components
        self.wgts = wgts or self.wgts
        self.pay_receive = pay_receive
        self.pay_sign = pay_sign if pay_sign is not None else self.pay_sign
        self.rec_sign = rec_sign if rec_sign is not None else self.rec_sign

    @classmethod
    def get_instance_signed_wtgs(cls, wgts=None, pay_receive='pay', pay_sign=None, rec_sign=None):
        wgts = np.asarray(cls.wgts if not wgts else wgts)
        pay_sign = pay_sign if pay_sign is not None else cls.pay_sign
        rec_sign = rec_sign if rec_sign is not None else cls.rec_sign
        signs = pay_sign if pay_receive.lower() == 'pay' else rec_sign
        signs = np.asarray(signs)
        return wgts * signs

    @property
    def signed_weights(self):
        return self.get_instance_signed_wtgs(self.wgts, self.pay_receive, self.pay_sign, self.rec_sign)

    @classmethod
    def from_legs(
            cls,
            ccy,
            generator,
            legs,
            start_hist=None,
            end_hist=None,
            notional=1,
            collateral='local',
            pay_receive='pay',
            scale=False
    ):

        '''
        '''
        components = []
        instance_wgts = [leg.get('wgt', cls.wgts[i]) for i, leg in enumerate(legs)]
        signed_wgts = cls.get_instance_signed_wtgs(wgts=instance_wgts, pay_receive=pay_receive)
        pay_recs = cls.pay_sign if pay_receive == 'pay' else cls.rec_sign
        for i, leg in enumerate(legs):
            eff_exp, tenor_mty = parse_swap_tenor_expr(leg['expr'])
            notional_ = get_notional_from_weights(notional=notional, weight=instance_wgts[i])
            swap = RollingSwap(
                ccy=ccy,
                generator=generator,
                eff_exp=eff_exp,
                tenor_mty=tenor_mty,
                pay_receive=pay_rec_map.get(pay_recs[i]),
                start_hist=start_hist,
                end_hist=end_hist,
                collateral=collateral,
                notional=notional_,
                scale=scale,
            )
            components.append(swap)
        return cls(components, instance_wgts)

    @property
    def quotes(self):
        return pd.concat([comp.trade.quote for comp in self.components], axis=1)

    @property
    def quote(self):
        return self.quotes @ self.signed_weights

    @property
    def pvs(self):
        return pd.concat([comp.trade.pv for comp in self.components], axis=1)

    @property
    def pv(self):
        return self.pvs.sum(axis=1)

    @property
    def trade(self):
        if not hasattr(self, '_trade'):
            self._trade = RealSwapBasket(
                components=self.components,
                wgts=self.wgts,
                pay_receive=self.pay_receive,
                pay_sign=self.pay_sign,
                rec_sign=self.rec_sign
            )
        return self._trade

    def __repr__(self):
        s = f'{self.pay_receive}{chr(10)}'
        for i, (comp, wgt) in enumerate(zip(self.components, self.wgts)):
            s = f"{s}wgt:{wgt} {comp.trade.__repr__()}{chr(10) if i + 1 < len(self.components) else ''}"
        return s

    def __getitem__(self, item):
        return self.components[item].trade


class RealSwapBasket(SwapBasket):
    @property
    def trade(self):
        return self


class Fly(SwapBasket):
    wgts = (1, 2, 1)
    pay_sign = (-1, 1, -1)
    rec_sign = (1, -1, 1)


class Spread(SwapBasket):
    wgts = (1, 1)
    pay_sign = (-1, 1)
    rec_sign = (1, -1)
