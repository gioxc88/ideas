# def dynamic_property(self, name):
#     return getattr(self, name)
#
#
# def check_cache(react_to='*'):
#     def decorator(fn):
#         def wrapper(self):
#             if not (calc := getattr(self, calc_name := f"_{fn.__name__}_calc", None)) or self._needs_recalc:
#                 res = fn(self)
#             setattr(self, calc_name, res)
#             return res
#
#         return wrapper
#
#     return decorator
#
#
# def check_cache(fn):
#     def wrapper(self):
#         if not (calc := getattr(self, calc_name := f"_{fn.__name__}_calc", None)) or self._needs_recalc:
#             res = fn(self)
#         setattr(self, calc_name, res)
#         return res
#
#     return wrapper
#
#
# # def clear_cache(self, name):
# #     def decorator(fn):
# #         def wrapper(self, value):
# #             if value != getattr(self, name):
# #                 self._needs_recalc = True
# #             setattr(self, name, value)
# #         return wrapper
# #     return decorator
#
#
# def clear_cache(self, value, name):
#     if value != getattr(self, name):
#         self._needs_recalc = True
#     setattr(self, name, value)
#
#
# def cache_manager(klass):
#     class Wrapper(klass):
#         _needs_recalc = {val: True for val in klass._watch}
#
#         @property
#         def needs_recalc(self):
#             return self._needs_recalc
#
#         @needs_recalc.setter
#         def needs_recalc(self, value):
#             self._needs_recalc[value] = not self._needs_recalc[value]
#
#     for prop in Wrapper._watch:
#         prop_ = prop[1:]
#         setattr(Wrapper, prop_, property(partial(dynamic_property, name=prop)))
#         setattr(Wrapper, prop_, getattr(Wrapper, prop_).setter(partial(clear_cache, name=prop)))
#
#     Wrapper.__name__ = klass.__name__
#     Wrapper.__qualname__ = klass.__qualname__
#     Wrapper.__module__ = klass.__module__
#
#     return Wrapper
#
#
# # @cache_manager
# # class BaseSwap:
# #     _watch = [
# #         '_ccy',
# #         '_generator',
# #         '_eff_exp',
# #     ]
# #
# #     def __init__(
# #             self,
# #             ccy='USD',
# #             generator='USD SOFR',
# #             eff_exp=None,
# #             mat=2,
# #     ):
# #         self._ccy = ccy
# #         self._generator = generator
# #         self._eff_exp = eff_exp
# #         self._mat = mat
# #
# #     @property
# #     @check_cache
# #     def mat(self):
# #         return self._mat * 10
from functools import wraps


data_cache = {}


def save_data(keys=None, sep='__'):
    keys = keys or []

    def decorator(fn):
        @wraps(fn)
        def wrapper(self):
            key_ = get_key(self, fn.__name__, keys, sep)
            res = data_cache.get(key_, None)
            if res is not None:
                return res
            res = fn(self)
            data_cache.setdefault(key_, res)
            return res
        return wrapper
    return decorator


def get_key(self, attr, keys=None, sep='__'):
    keys = keys or []
    key_ = f"{self.symbol}{sep}{attr}"
    for key in keys:
        k = getattr(self, key)
        key_ = f"{key_}{sep}{k}"
    return key_
