from functools import partial, cache, cached_property

from . import config as c
from ..data.providers import Providers


class TCost:
    def __init__(self, **kwargs):
        t_cost = kwargs.pop('t_cost', c.USE_T_COST)
        self._t_cost = t_cost
        super().__init__(**kwargs)

    @property
    def t_cost(self):
        t_cost = self._t_cost
        if t_cost is True:
            t_cost = c.t_cost_default.get(self.t_cost_key, 0)
        return t_cost


class BQ:
    def __init__(self, **kwargs):
        self._bq = kwargs.pop('bq', None)
        super().__init__(**kwargs)

    @property
    def bq(self):
        if not self._bq:
            return Providers.BQ
        return self._bq
