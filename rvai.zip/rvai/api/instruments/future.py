import re
from copy import deepcopy
from functools import partial, cache, cached_property

import numpy as np
import pandas as pd
from pandas.tseries.offsets import Day

from gioutils.blpw import BlpQuery
from gioutils.utils import (
    today,
    get_bbg_fut_chain_ticker,
    get_specific_future,
)
from .utils import parse_dates, parse_number
from . import config as c
from .cache import save_data
from .base import TCost, BQ


yk_map = {
    'es': 'Index'
}


age_map = {
    'ff': 3
}


def parse_components(components):
    '''
    1.  [
            {'wgt': 1, 'comp': FutureChain()},
            ...
        ]
    2.  [
            (FutureChain(), 1),
            (FutureChain(), -2)
        ]

    3.  [
            FutureChain(),
            FutureChain()
        ]
        if just a list of instruments the weight is inferred from notional
    '''

    is_tuple = all(isinstance(v, tuple) for v in components)
    is_dict = all(isinstance(v, dict) for v in components)

    if is_tuple:
        components = [{'wgt': t[-1], 'comp': t[0]} for t in components]
    elif not is_dict:  # assuming is list of components
        wgts = np.asarray([c.notional for c in components])
        wgts = wgts // np.abs(wgts).min()
        components = [{'wgt': w, 'comp': c} for c, w in zip(components, wgts)]

    return components


class Future(BQ, TCost):
    def __init__(
            self,
            ticker,
            notional=1,
            start_hist=None,
            end_hist=None,
            yk=None,
            **kwargs
    ):
        self.ticker = ticker
        self._notional = notional
        self._yk = yk
        self._start_hist = start_hist or '1y'
        self._end_hist = end_hist or today()
        super().__init__(**kwargs)

    @property
    def name(self):
        return self.ticker.upper()

    @property
    def trade(self):
        return self

    @property
    def yk(self):
        if not self._yk:
            return yk_map.get(self.root.lower(), 'Comdty')
        return self._yk

    @property
    def root(self):
        pattern = re.compile(r'\d+')
        n = pattern.findall(self.ticker)[0]
        return self.ticker[:-len(n) + 1]

    @property
    def contract(self):
        return int(self.ticker.replace(self.root, ''))


class FutureChain(BQ, TCost):
    def __init__(
            self,
            ticker,
            notional=1,
            roll='r',
            adj='d',
            days=5,
            months=0,
            start_hist=None,
            end_hist=None,
            yk=None,
            **kwargs
    ):
        self.ticker = ticker
        self._notional = notional
        self.roll = roll
        self.adj = adj
        self.days = days
        self.months = months
        self._yk = yk
        self._start_hist = start_hist or '1y'
        self._end_hist = end_hist or today()

        super().__init__(**kwargs)

    @property
    def name(self):
        return self.ticker.upper()

    @property
    def trade(self):
        return self

    @property
    def yk(self):
        if not self._yk:
            return yk_map.get(self.root.lower(), 'Comdty')
        return self._yk

    @property
    def root(self):
        pattern = re.compile('[A-Za-z]+')
        return pattern.findall(self.ticker)[0]

    @property
    def contract(self):
        return int(self.ticker.replace(self.root, ''))

    @property
    @save_data()
    def real_future_ticker(self):
        ticker = f"{self.root}{self.contract  + 1}" if ((self.roll_date - Day(self.days)) <= today() <= self.roll_date) else self.ticker
        # print(ticker)
        return get_specific_future(ticker, self.yk, self.bq)[0].split(' ')[0].lower()

    @property
    @save_data()
    def roll_date(self):
        bq = self.bq
        bq.start()
        p = bq.bdp(
            f"{self.root}1 {self.yk}",
            'last_tradeable_dt'
        )
        return p['last_tradeable_dt'].squeeze()

    @property
    def real_future_tickers(self):
        return [self.real_future_ticker]

    def age(self, months=3):
        new = deepcopy(self)
        new.ticker = f"{self.root}{self.contract - (age_map.get(self.root.lower(), 1) * months // 3)}"
        return new

    @property
    def t_cost_key(self):
        return self.root

    @property
    def start_hist(self):
        return parse_dates(self._start_hist, self._end_hist, b=False)[0]

    @property
    def end_hist(self):
        return parse_dates(self._start_hist, self._end_hist, b=False)[1]

    @start_hist.setter
    def start_hist(self, value):
        self._start_hist = value

    @end_hist.setter
    def end_hist(self, value):
        self._end_hist = value

    @property
    def notional(self):
        notional = self._notional
        if isinstance(notional, str):
            if notional[0].lower() == 'd':
                delta = parse_number(notional[1:])
                return delta / self.delta
            else:
                return parse_number(notional)
        if isinstance(notional, float):
            return int(notional) if notional.is_integer() else notional
        return notional

    @property
    def delta(self):
        return self.point_value / 100

    # @property
    # @cache
    @property
    @save_data()
    def point_value(self):
        return self.get_ref_data('fut_val_pt')

    # @property
    # @cache
    @property
    @save_data()
    def tick_value(self):
        return self.get_ref_data('fut_tick_val')

    # @property
    # @cache
    @property
    @save_data()
    def tick_size(self):
        return self.get_ref_data('fut_tick_size')

    # @property
    # @cache
    @property
    @save_data(keys=['start_hist', 'end_hist'])
    def yld(self):
        return self.get_hist_data('yld_cnv_last', 'quote').dropna()

    @property
    def price_yld(self):
        return 100 - self.yld

    # @property
    # @cache
    @property
    @save_data(keys=['start_hist', 'end_hist'])
    def quote(self):
        return self.get_hist_data('px_last', 'quote').dropna()

    @property
    def last(self):
        if self.end_hist == today():
            last = self.get_ref_data(['last_price', 'yld_ytm_mid'])
            self.quote.iloc[-1] = last['last_price']
            self.yld.iloc[-1] = last['yld_ytm_mid']
        else:
            self.end_hist = today()
            self.quote
            self.yld
        return self

    def get_last(self, ):
        pass

    # @property
    # @cache
    @property
    @save_data(keys=['start_hist', 'end_hist'])
    def quote_high(self):
        return self.get_hist_data('px_high', 'quote_high').dropna()

    # @property
    # @cache
    @property
    @save_data(keys=['start_hist', 'end_hist'])
    def quote_low(self):
        return self.get_hist_data('px_low', 'quote_low').dropna()

    # @property
    # @cache
    @property
    @save_data(keys=['start_hist', 'end_hist'])
    def quote_open(self):
        return self.get_hist_data('px_open', 'quote_open').dropna()

    # @property
    # @cache
    @property
    @save_data(keys=['start_hist', 'end_hist'])
    def quote_vw(self):
        return self.get_hist_data('eqy_weighted_avg_px', 'quote_vw').dropna()

    @property
    def bars(self):

        df = pd.concat(
            [
                self.quote_open,
                self.quote_high,
                self.quote_low,
                self.quote,
            ],
            axis=1
        )
        df.columns = ['open', 'high', 'low', 'close']
        return df

    @property
    def symbol(self):
        s = get_bbg_fut_chain_ticker(
            f'{self.ticker}',
            self.roll, self.adj,
            self.days, self.months,
            self.yk
        )
        return s

    def get_ref_data(self, fields):
        bq = self.bq
        bq.start()
        p = bq.bdp(
            self.symbol,
            fields
        )
        try:
            return float(p[fields].squeeze())
        except:
            return p[fields].squeeze()

    def get_hist_data(self, fields=None, rename=None):
        bq = self.bq.start()
        series = bq.bdh(
            self.symbol,
            fields,
            self.start_hist,
            self.end_hist
        ).set_index('date')[fields]
        return self._rename_attr(series, rename)

    def _rename_attr(self, series, rename):
        return series.rename(f'{self.ticker.upper()}{"" if not rename else f" {rename}"}')

    @property
    def pv(self):
        quote = self.quote
        pv = (quote - quote.iloc[0]) * self.point_value * self.notional
        return pv.rename(pv.name.replace('quote', 'pv'))
        # return (self.quote.diff() * self.point_value).cumsum()

    def get_pnl(self, pnl):
        return self.point_value * self.notional * pnl

    def contract_tick_value(self, ticks=None, points=None):
        if not ticks and not points:
            ticks = 1
        elif points:
            ticks = self.points_to_ticks(points)
        return self.tick_value * self.notional * ticks

    def get_ticks(self, value):
        if isinstance(value, str):
            n = parse_number(value[1:])
            if value[0] == '$':
                ticks = n / self.contract_tick_value()
            elif value[0] == 'p':
                ticks = self.points_to_ticks(n)
            elif value[0] == 't':
                ticks = n
            else:
                raise ValueError('only $, t and p can be parsed')
        else:
            ticks = value
        return ticks

    def get_points(self, value):
        if not isinstance(value, str):
            value = f'p{value}'
        return self.ticks_to_points(self.get_ticks(value))

    def points_to_ticks(self, points):
        return points / self.tick_size

    def ticks_to_points(self, ticks):
        return ticks * self.tick_size

    def slippage(self, value, typ='ticks'):
        if typ == 'ticks':
            return self.ticks_to_points(value)
        else:
            return value

    def __repr__(self):
        return f'{self.ticker.upper()} Future Chain {self.notional} contracts'


class FutureBasket:
    def __init__(
            self,
            instruments,
            weights=None,
            **kwargs
    ):
        instruments = parse_components(instruments)
        self._instruments = instruments
        self.instruments = [inst['comp'] for inst in instruments]
        if weights is not None:
            wgts = weights
        elif all(wgts_ := [inst.get('wgt') for inst in instruments]):
            wgts = wgts_
        elif hasattr(self.__class__, '_wgts'):
            wgts = self.__class__._wgts
        else:
            wgts = [1] * len(instruments)
        self._weights = np.asarray(wgts)
        super().__init__(**kwargs)

    @classmethod
    def from_legs(
            cls,
            ticker,
            legs,
            notional=1,
            start_hist=None,
            end_hist=None,
            wgts=None,
            **kwargs,
    ):

        comps = []
        wgts = wgts or (cls._wgts if hasattr(cls, '_wgts') else [1] * len(legs))

        for leg, wgt in zip(legs, wgts):
            f = FutureChain(
                ticker=f"{ticker}{leg}",
                notional=notional * wgt,
                start_hist=start_hist,
                end_hist=end_hist,
                **kwargs
            )
            comps.append(f)
        return cls(comps, weights=wgts)

    def age(self, months=3):
        news = [i.age(months=months) for i in self.instruments]
        return self.__class__(instruments=news, weights=self._weights)

    @property
    def weights(self):
        return self._weights

    @property
    def real_future_tickers(self):
        return [comp.real_future_ticker for comp in self.instruments]

    @property
    def quotes(self):
        return pd.concat([comp.trade.quote for comp in self.instruments], axis=1)

    @property
    def quote(self):
        return (self.quotes @ self.weights).rename('quote')

    @property
    def pvs(self):
        return pd.concat([comp.trade.pv for comp in self.instruments], axis=1)

    @property
    def pv(self):
        return self.pvs.sum(axis=1).rename('pv')

    @property
    def trade(self):
        return self

    def get_pnl(self, x):
        return x

    def __repr__(self):
        s = ''
        for i, (comp, wgt) in enumerate(zip(self.instruments, self.weights)):
            s = f"{s}{wgt} x {comp.trade.__repr__()}{chr(10) if i + 1 < len(self.instruments) else ''}"
        return s

    def __getitem__(self, item):
        return self.instruments[item].trade


class FutureStructure(FutureBasket, TCost):
    strat = 'strat'

    @property
    def name(self):
        name = ' '.join([inst.name for inst in self.instruments])
        return f"{self.strat} {name}"

    @property
    def notional(self):
        return self[0].notional

    def contract_tick_value(self, ticks=None, points=None):
        return self[0].contract_tick_value(ticks=ticks, points=points)

    @property
    def point_value(self):
        return self[0].point_value

    def get_pnl(self, pnl):
        return self.point_value * self.notional * pnl

    def get_ticks(self, value):
        return self[0].get_ticks(value)

    def get_points(self, value):
        return self[0].get_points(value)

    def points_to_ticks(self, points):
        return self[0].points_to_ticks(points=points)

    def ticks_to_points(self, ticks):
        return self[0].ticks_to_points(ticks)

    def slippage(self, value, typ='ticks'):
        return self[0].slippage(value=value, typ=typ)

    @property
    def root(self):
        return self[0].root

    @property
    def t_cost_key(self):
        return f"{self.root}_{self.strat}"

    @property
    def t_cost(self):
        t_cost = self._t_cost
        if t_cost is True:
            t_cost = c.t_cost_default.get(self.t_cost_key, 0)
        return t_cost


class FutureSpread(FutureStructure):
    strat = 'spread'
    _wgts = (1, -1)


class FutureFly(FutureStructure):
    strat = 'fly'

    @property
    def t_cost_key(self):
        return f"{self.root}_{self.strat}"

    _wgts = (1, -2, 1)
