source ../venv/Scripts/activate
python positions.py
bash