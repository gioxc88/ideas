
from functools import partial

import numpy as np
import pandas as pd
import ipyvuetify as v
import win32com.client as win32
from pandas.tseries.offsets import BDay
from scipy import stats

try:
    import config
except ImportError:
    pass

from gioutils import giobhutils as gio
from gioutils.ezutils import SQL
from gioutils.utils import parse_offset, today
from gioutils.gui.pandas import millify
from gioutils.pretty_html_table import build_table


def get_var_query(asof=None, book="MM", offset="522b", horizon='1d'):
    dt_fmt = "%Y%m%d"
    asof = pd.to_datetime(asof) if asof else today() - BDay()
    query = (
        f"SELECT "
        f"p.fund, "
        f"p.book, "
        f"p.strategy, "
        f"p.minnb, "
        f"p.positionName, "
        f"p.riskCategory, "
        f"p.tradeGroup, "
        f"p.currency, "
        f"p.instrument, "
        f"p.underlying_name, "
        f"p.nominal, "
        f"p.nominal1, "
        f"p.delta, "
        f"p.rateTrade, "
        f"p.bhType, "
        f"p.isAO, "
        f"s.returnDate, "
        f"s.returnValue "
        f"FROM RiskManagement..vw_pos_openPositionMarketData p "
        f"JOIN RiskVaR..vw_SeriesData s ON p.cobDate = s.cobDate and p.minbhid = s.minbhid "
        f"WHERE 1=1 "
        f"AND p.cobDate = '{asof:{dt_fmt}}' "
        f"AND p.fund = 'BAL' "
        f"AND p.book = '{book}' "
        f"AND s.riskType = 'Total' "
        f"AND s.returnHorizon = '{horizon.upper()}' "
        f"AND s.analysisHorizon = '{horizon.upper()}' "
        f"AND s.decayFactor = 1 "
        f"AND s.exclude = 0 "
    )

    if offset:
        offset = asof - parse_offset(offset)
        query = f"{query} AND s.returnDate >= {offset:{dt_fmt}}"
    return query


class VaRPnl:
    def get_data(
            self,
            asof=None,
            book="MM",
            offset="522b",
            exclude_cash=False,
            exclude_null_notional=True,
            groupby="name",
            horizon='1d'
    ):
        asof = pd.to_datetime(asof) if asof else today() - BDay()
        self.date = asof
        res = gio.bhDbReadSql(
            "1",
            sqlserver=SQL.RiskVar.server,
            sqldatabase=SQL.RiskVar.db,
            sqlquery=get_var_query(asof=asof, book=book, offset=offset, horizon=horizon),
        )

        self.res = res
        self.parse_res(res, exclude_cash, exclude_null_notional, groupby)

    def parse_res(
            self,
            res=None,
            exclude_cash=False,
            exclude_null_notional=True,
            groupby="name",
    ):
        res = res if res is not None else self.res
        df = res.py
        df["returnDate"] = pd.to_datetime(df["returnDate"])
        ref_cols = [
            "fund",
            "book",
            "strategy",
            "minnb",
            "positionName",
            "riskCategory",
            "currency",
            "tradeGroup",
            "instrument",
            "underlying_name",
            "rateTrade",
            "nominal",
            "nominal1",
            "delta",
            "isAO",
        ]

        if exclude_cash:
            df = df.loc[~df["positionName"].str.contains("CASH")]

        ref_df = df[ref_cols].drop_duplicates()
        ref_df['positionName2'] = [' '.join([p.split(' ', 2)[0], p.split(' ', 2)[-1]]) for p in ref_df['positionName']]
        # ref_df['positionName2'] = [
        #     p.replace(f" {r}", "") if t == 'IRS' else p
        #     for index, (p, t, r) in ref_df[['positionName', 'tradeGroup', 'rateTrade']].iterrows()
        # ]

        ref_df[["nominal", "nominal1", "delta"]] = ref_df.loc[:, ["nominal", "nominal1", "delta"]].replace("NULL", 0)
        ref_df[["nominal", "nominal1", "delta"]] = ref_df.loc[:, ["nominal", "nominal1", "delta"]].astype("float")
        ref_df.loc[ref_df["nominal"] == 0, 'nominal'] = ref_df.loc[ref_df["nominal"] == 0, 'nominal1']
        ref_df = ref_df.drop("nominal1", axis=1)

        if groupby:
            col = "positionName" if groupby == "name" else groupby
            col = ['strategy', 'positionName']

            ref_df = ref_df.groupby(
                ref_df.columns[
                    ~ref_df.columns.isin(["nominal", "delta", "minnb", "rateTrade"])
                ].to_list(),
                as_index=False,
            ).sum()

            hist_df = (
                df.groupby([*col, "returnDate"], as_index=False, sort=False)[
                    "returnValue"
                ].sum().pivot(index="returnDate", columns=col, values="returnValue")
            )

            if exclude_null_notional:
                ref_df = ref_df.loc[(ref_df["nominal"] != 0), :]
                hist_df = hist_df.loc[:, pd.MultiIndex.from_frame(ref_df[col])]

            # ref_df = ref_df.drop_duplicates(subset='positionName')
        else:
            hist_df = df[["returnDate", "minnb", "returnValue"]].pivot(
                index="returnDate", columns="minnb", values="returnValue"
            )

        self.ref = ref_df
        self.hist = hist_df

    def var(self, df=None, days=522, q=0.05, method='weibull'):
        df = df if df is not None else self.hist
        return df[-days:].sum(axis=1).quantile(q, interpolation=method)


def fill_limit(df, col1, col2):
    c1 = 'background-color: red'
    c2 = 'background-color: lime'
    df_new = pd.DataFrame('', index=df.index, columns=df.columns)
    df_new.loc[df[col1] > df[col2], col1] = c1
    df_new.loc[df[col1] <= df[col2], col1] = c2

    return df_new


### Limits

capital = 300e6
var_flag = 1.5 / 100
var_standalone_limit = 25 / 100
var_limit = capital * var_flag
daily_tail_risk_limit = 2 / 100
weekly_tail_risk_limit = 4 / 100
correlation_limit = 66 / 100
position_counts_limit = 10
category_exclusion = [
    "SCF"
]
strategy_exclusion = [
    'CASH_USAGE'
]

strategy_counts_limit = {
    "RATES": 8,
    "FX": 3,
    'EQD': 1,
}
exclude_cash = True
daily_period = "2y"
weekly_period = "5y"

### VaR

dv = VaRPnl()
dv.get_data(
    offset=daily_period,
    exclude_cash=False,
    exclude_null_notional=True
)

wv = VaRPnl()
wv.get_data(
    offset=weekly_period,
    exclude_cash=False,
    horizon='5d'
)

var_dollar = dv.var()
var_check = pd.DataFrame(
    [
        [- var_dollar, var_limit],
        [- var_dollar / capital * 100, var_flag * 100],
        [- var_dollar / var_limit * 100, 100]

    ],
    index=['var_dollar', 'var_pct', 'var_utilization'],
    columns=['value', 'limit'],
).rename_axis('measure')
# var_check.style.apply(partial(fill_limit, col1='value', col2='limit'), axis=None).format('{:.2f}')

ref = dv.ref.loc[~dv.ref["positionName"].str.contains("CASH")] if exclude_cash else dv.ref
ref = ref
hist = dv.hist.loc[:, pd.MultiIndex.from_frame(ref[['strategy', 'positionName']].drop_duplicates())]
position_counts = (
    ref.query(f"riskCategory != {category_exclusion}").groupby(["strategy", "riskCategory", "positionName2"])
    .count()
    .groupby(level=[0, 1])["positionName"]
    .count()
    .rename("count")
)
strategy_counts = (
    position_counts.reset_index()
    .groupby("riskCategory")["strategy"]
    .count()
    .rename("count")
)

### Number of strategies in each category

strategy_check = pd.concat(
    [
        strategy_counts,
        pd.Series(strategy_counts_limit, name="limit").rename_axis(
            strategy_counts.index.name
        ),
    ],
    axis=1,
).fillna(0)
# strategy_check.style.apply(partial(fill_limit, col1='count', col2='limit'), axis=None).format('{:.2f}')

### Number of positions in each Strategy

position_check = position_counts.to_frame().assign(limit=position_counts_limit)
# position_check.style.apply(partial(fill_limit, col1='count', col2='limit'), axis=None).format('{:.2f}')

### Standalone VaR

standalone_var_check = (
            - hist.groupby(axis=1, level=0, sort=False).sum().iloc[-522:].quantile(0.05, interpolation='weibull') / var_limit * 100) \
    .rename('value').to_frame().rename_axis('strategy').assign(limit=var_standalone_limit * 100)
# standalone_var_check.style.apply(partial(fill_limit, col1='value', col2='limit'), axis=None).format('{:.2f}')

### Tail Risk

daily_tail_risk_check = (- dv.hist.sum(axis=1).nsmallest(1) / capital * 100).rename('value').to_frame().assign(
    limit=daily_tail_risk_limit * 100).rename_axis('daily')

weekly_tail_risk_check = (- wv.hist.sum(axis=1).nsmallest(1) / capital * 100).rename('value').to_frame().assign(
    limit=weekly_tail_risk_limit * 100).rename_axis('weekly')

daily_tail_risk_by_strategy = - dv.hist.groupby(level=0, axis=1).sum()\
    .apply(lambda x, n: pd.Series.nsmallest(x, n=n).squeeze(), axis=0, n=1).rename('daily')

weekly_tail_risk_by_strategy = - wv.hist.groupby(level=0, axis=1).sum()\
    .apply(lambda x, n: pd.Series.nsmallest(x, n=n).squeeze(), axis=0, n=1).rename('weekly')

tail_risk_by_strategy = pd.concat([daily_tail_risk_by_strategy, weekly_tail_risk_by_strategy], axis=1).dropna() / capital * 100

### Correlation

corr = {}
g = hist.groupby(level=0, axis=1)
if len(g) > 1:
    for index, group in g:
        strategy = group.sum(axis=1)
        ptf = hist.drop(group.columns, axis=1).sum(axis=1)
        corr[index] = abs(stats.pearsonr(strategy, ptf).statistic)
corr_check = pd.Series(corr, dtype="float").rename('value').to_frame().rename_axis('strategy').assign(
    limit=correlation_limit) * 100

var_check = var_check.assign(passed=var_check['value'] <= var_check['limit'])
standalone_var_check = standalone_var_check.assign(
    passed=standalone_var_check['value'] <= standalone_var_check['limit'])
daily_tail_risk_check = daily_tail_risk_check.assign(
    passed=daily_tail_risk_check['value'] <= daily_tail_risk_check['limit'])
weekly_tail_risk_check = weekly_tail_risk_check.assign(
    passed=weekly_tail_risk_check['value'] <= weekly_tail_risk_check['limit'])
corr_check = corr_check.assign(passed=corr_check['value'] <= corr_check['limit'])
strategy_check = strategy_check.assign(passed=strategy_check['count'] <= strategy_check['limit'])
position_check = position_check.assign(passed=position_check['count'] <= position_check['limit'])

var_check_fmt = var_check.assign(
    value=var_check['value'].map(partial(millify, pct=None)),
    limit=var_check['limit'].map(partial(millify, pct=None)),
    passed=var_check['passed'].astype(int),
)

standalone_var_check_fmt = standalone_var_check.assign(
    value=standalone_var_check['value'].map(partial(millify, pct=None)),
    limit=standalone_var_check['limit'].map(partial(millify, pct=None)),
    passed=standalone_var_check['passed'].astype(int),
)

daily_tail_risk_check_fmt = daily_tail_risk_check.assign(
    value=daily_tail_risk_check['value'].map(partial(millify, pct=None)),
    limit=daily_tail_risk_check['limit'].map(partial(millify, pct=None)),
    passed=daily_tail_risk_check['passed'].astype(int),
)

weekly_tail_risk_check_fmt = weekly_tail_risk_check.assign(
    value=weekly_tail_risk_check['value'].map(partial(millify, pct=None)),
    limit=weekly_tail_risk_check['limit'].map(partial(millify, pct=None)),
    passed=weekly_tail_risk_check['passed'].astype(int),
)

tail_risk_by_strategy_fmt = tail_risk_by_strategy.round(2)

corr_check_fmt = corr_check.assign(
    value=corr_check['value'].map(partial(millify, pct=None)),
    limit=corr_check['limit'].map(partial(millify, pct=None)),
    passed=corr_check['passed'].astype(int),
)

strategy_check_fmt = strategy_check.assign(
    count=strategy_check['count'].astype(int),
    limit=strategy_check['limit'].astype(int),
    passed=strategy_check['passed'].astype(int),
)

position_check_fmt = position_check.assign(
    count=position_check['count'].astype(int),
    limit=position_check['limit'].astype(int),
    passed=position_check['passed'].astype(int),
)

html = '<h2 style="font-family: Century Gothic, sans-serif;">VaR</h2>'
html = html + build_table(
    var_check_fmt.reset_index(),
    'blue_light',
    conditions={'passed': {'min': 1, 'max': 0, 'min_color': 'red', 'max_color': 'lime'}}
)

html = html + '<h2 style="font-family: Century Gothic, sans-serif;">Standalone VaR</h2>'
html = html + build_table(
    standalone_var_check_fmt.reset_index(),
    'blue_light',
    conditions={'passed': {'min': 1, 'max': 0, 'min_color': 'red', 'max_color': 'lime'}},
    widths='200px',
)

html = html + '<h2 style="font-family: Century Gothic, sans-serif;">Tail Risk</h2>'
html = html + build_table(
    daily_tail_risk_check_fmt.reset_index(),
    'blue_light',
    conditions={'passed': {'min': 1, 'max': 0, 'min_color': 'red', 'max_color': 'lime'}},
    widths='120px',
)

html = html + build_table(
    weekly_tail_risk_check_fmt.reset_index(),
    'blue_light',
    conditions={'passed': {'min': 1, 'max': 0, 'min_color': 'red', 'max_color': 'lime'}},
    widths='120px',
)

html = html + build_table(
    tail_risk_by_strategy_fmt.reset_index(),
    'blue_light',
    widths='200px',
)

if corr_check.empty:
    pass
else:
    html = html + '<h2 style="font-family: Century Gothic, sans-serif;">Correlation</h2>'
    html = html + build_table(
        corr_check_fmt.reset_index(),
        'blue_light',
        conditions={'passed': {'min': 1, 'max': 0, 'min_color': 'red', 'max_color': 'lime'}},
        widths='200px',
    )

html = html + '<h2 style="font-family: Century Gothic, sans-serif;">Strategies per Category</h2>'
html = html + build_table(
    strategy_check_fmt.reset_index(),
    'blue_light',
    conditions={'passed': {'min': 1, 'max': 0, 'min_color': 'red', 'max_color': 'lime'}}
)

html = html + '<h2 style="font-family: Century Gothic, sans-serif;">Positions per Strategy</h2>'
html = html + build_table(
    position_check_fmt.reset_index(),
    'blue_light',
    conditions={'passed': {'min': 1, 'max': 0, 'min_color': 'red', 'max_color': 'lime'}},
    widths='200px',
)


# Send Email
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


from_email = 'gioreports@brevanhoward.com'
smtp_server = "smtp.rivagecapital.com"
to_email = [
    'giovambattista.perciaccante@brevanhoward.com',
    # 'menashe.banit@brevanhoward.com',
]

message = MIMEMultipart("alternative")
message["Subject"] = f'Internal Risk Report as of {dv.date: %d%b%y}'
message["From"] = from_email
message["To"] = ','.join(to_email)
html_ = MIMEText(html, "html")
message.attach(html_)

smtp = smtplib.SMTP(smtp_server)
smtp.sendmail(from_email, to_email, message.as_string())

print('SUCCESS 2')
