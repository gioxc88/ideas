import json
import sys
import re
import logging
import os
import re
from pathlib import Path
from functools import partial, cache, cached_property
from itertools import chain
from inspect import signature
from uuid import uuid4

import blpapi
import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
import QuantLib as ql
import talib as ta
from IPython.display import display
from ipydatagrid import DataGrid, TextRenderer, BarRenderer, Expr, VegaExpr
from bqplot import LinearScale, ColorScale, OrdinalColorScale, OrdinalScale
from pandas.tseries.offsets import BDay
from plotly import graph_objects as go
from plotly.subplots import make_subplots
from sklearn.model_selection import ParameterGrid
from termcolor import colored
from joblib import Parallel, delayed
# from bhsysapi import BHSysApi

from techi import api as ti

from gioutils import ezutils as ez
from gioutils.ezutils import bh, bhs
from gioutils.blpw import BlpQuery
from gioutils.gui.pandas import millify
from gioutils.utils import (
    RepeatedTimer,
    parse_swap_tenor_expr,
    parse_offset,
    today,
    get_next_n,
    get_n_from_code,
    date_from_offset,
    get_bday,
    get_bbg_fut_chain_ticker
)

from api.data.base import data_path, radar_path
from api.gui.params import bbg_params, spot_params, fwd_params
from api.instruments.swap import RealSwap, RollingSwap, Fly, Spread
from api.instruments.utils import parse_dates, parse_number, ez_bump
from api.instruments.strategies import FutureStrategy
from api.instruments.signals import MACDHistCrossover, ZScoreThreshold, EnsambleSignal
from api.instruments.cache import data_cache
from api.instruments.future import FutureChain, FutureSpread, FutureFly
from api.gui.theme import bg_color, grid_style
from api.gui.pandas import DFOutput, negative_red, custom_styler_row_line, DataGridGio
from api.instruments import config as c
from api.instruments.signals2 import BaseSignal, MACDCustomSignal, get_crossover_signal
from api.instruments.strategies2 import MACDCustomStrategy

pd.options.plotting.backend = "plotly"
pd.options.display.float_format = millify
c.USE_T_COST = True

bq = BlpQuery(timeout=50000).start()
# ba = BHSysApi(password="A&3jg5Aj")

notional = 1000
hist = '10y'
strategy_hist = '1y'
start_hist = '10y'



self = RealSwap(
    ccy='usd',
    generator='usd sofr',
    eff_exp='1y',
    tenor_mty='2y',
    pay_receive='pay',
    start_hist=pd.Timestamp(2013, 6, 7),
    end_hist=None,
    collateral='LCH',
    strike='a',

)

self.quote


self = FutureChain(
    ticker='sfr6',
    notional=notional,
    start_hist=start_hist,
    end_hist=pd.Timestamp.today() - BDay(10)
)



