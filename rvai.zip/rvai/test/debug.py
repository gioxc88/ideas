import pandas as pd

remote_db_columns = {
    'TradeId': 'int',
    'ccy': 'string',
    'SVMInstrument': 'string',
    'GeneratorInput': 'string',
    'EffExp': 'string',
    'MtyTnrIn': 'string',
    'Strike': 'string',
    'StrikeTerm': 'string',
    'PayoutType': 'string',
    'SwaptionSettleTypeIn': 'string',
    'ForwardSettled': 'int',
    'Nominal': 'double',
    'FwdTenor': 'string',
    'ForceCapToImm': 'int',
    'Generator': 'string',
    'MtyTnr': 'string',
    'StrikeDate': 'date',
    'SwaptionSettleType': 'string',
    'PaySettleType': 'string',
    'TradeLabel': 'string',
    'UnderlyingClearingHouse': 'string',
    'CollateralCcy': 'string',
}

cash_settle_map = {
    'C': 'Cash',
    'CP': 'CashZC',
    'P': 'Physical',
    'pc': 'PhysicalCleared',
}


class Server:
    FITradePricer = 'SQLP2-A'
    SVM = 'SQLP1-A'
    Curves = 'SQLP1-A'
    Histories = 'SQLP1-A'
    Products = 'SQLP1-A'
    TradeReporter = 'SQLP1-A'
    Snap = 'SQLP1-B'
    Quants = 'SQLP1-A'


class Database:
    snap = 'snap'
    FITradePricer = 'FITradePricer'
    Curves = 'Curves'
    Histories = 'Histories'
    Quants = 'Quants'


ccy = None, 'EUR'
instrument = None, 'oswp'
curve = None, 'usd sofr'
eff_exp = None, '3m'
tenor_mty = None, '5yx5y'
strike = None, 2.15
atm_fixed_date = None, None
pr = None, 'pay'
settle = None, 'pc_lch'
collateral = None, None
metric = None, 'spotpremium'

{
    'PV': 0.001,
    'Strike': 100,
    'Rate': 100,
    'SpotPremium': 0.001,
    'FwdPremium': -0.001,
    'Vol': 100,
    'BPVol': 10000 * 252 ** -0.5,
    'Ann01': 1,
    'SpotPremCent': 0.01,
}

import bhutilscommon as bhc

[
    ('ccy', 'std', 'disc',)
    ('AUD', 'AUD.6M.STD', 'AUD.D.AUDC'),
    ('CAD', 'CAD.3M.STD', 'CAD.D.CADC'),
    ('CHF', 'CHF.6M.STD', 'CHF.D.CHFC'),
    ('EUR', 'EUR.6M.STD', 'EUR.D.EURC'),
    ('GBP', 'GBP.6M.STD', 'GBP.D.GBPC'),
    ('NOK', 'NOK.6M.STD', 'NOK.D.NOKC'),
    ('NZD', 'NZD.3M.STD', 'NZD.D.NZDC'),
    ('SEK', 'SEK.6M.STD', 'SEK.D.SEKC'),
    ('USD', 'USD.SOFR', 'USD.D'),
    ('JPY', 'JPY.6M.STD', 'JPY.D.JPYC'),
],

{
    'ccy': 'EUR', 'tenor': '5yx1y',
    'ccy': 'EUR', 'tenor': '10yx2y',
    'ccy': 'USD', 'tenor': '18mx1y',
    'ccy': 'USD', 'tenor': '5yx1y',
    'ccy': 'AUD', 'tenor': '2yx2y',
    'ccy': 'USD', 'tenor': '2yx2y',
    'ccy': 'AUD', 'tenor': '6mx1y',
    'ccy': 'USD', 'tenor': '6mx1y',
    'ccy': 'EUR', 'tenor': '11mx9y',
    'ccy': 'USD', 'tenor': '11mx9y',
    'ccy': 'USD', 'tenor': '7mx1y',
    'ccy': 'USD', 'tenor': '4yx1y',
    'ccy': 'USD', 'tenor': '3yx2y',
    'ccy': 'USD', 'tenor': '7mx1y',
    'ccy': 'AUD', 'tenor': '7mx1y',
}

query = f'USE Quants SELECT * FROM SEMtgDates ' \
        f'WHERE Currency in {ccys} ' \
        f'AND MeetingDate > "{today():%Y%m%d}"' \
        f' ORDER BY Currency, MeetingDate ASC'

from functools import wraps

pd.DataFrame._ipython_display_

query = f"SELECT" \
        f"'-- Columns from RiskManagement..vw_pos_openPositionMarketData" \
        f"p.fund," \
        f"p.book," \
        f"p.strategy," \
        f"p.minnb," \
        f"p.riskCategory," \
        f"p.currency," \
        f"p.instrument," \
        f"p.underlying_name," \
        f"p.bhType," \
        f"p.isAO," \
        f"'-- Columns from RiskVaR..vw_SeriesData" \
        f"s.returnDate," \
        f"s.returnValue" \
        f"FROM RiskManagement..vw_pos_openPositionMarketData p" \
        f"JOIN RiskVaR..vw_SeriesData s ON p.cobDate = s.cobDate and p.minbhid = s.minbhid" \
        f"WHERE 1=1" \
        f"AND p.cobDate = '20221003'" \
        f"AND p.fund = 'BAL'" \
        f"AND p.book = 'MM'" \
        f"AND s.riskType = 'Total'" \
        f"AND s.returnHorizon = '1D'" \
        f"AND s.analysisHorizon = '1D'" \
        f"AND s.decayFactor = 1" \
        f"AND s.exclude = 0'"

from ipydatagrid import DataGrid


def get_bbg_fut_chain_ticker(
        fut,
        roll='r',
        adj='d',
        days=0,
        months=0,
        yk='comdty'
):
    '''

    :param fut: str
    :param roll: str
        B = Bloomberg Default
        R = Relative to Expiration
        F = Fixed Day of Month
        A = With Active Future
        N = Relative to First Notice
        D = At First Delivery
        O = At option expiration

    :param adj: str
        N = None
        D = Difference
        R = Ratio
        W = Average

    :param days:
    :param months:
    :param yk: str
    :return:
    '''

    if not adj:
        adj = 'n'

    return f"{fut} {roll.upper()}:{days:02d}_{months:1d}_{adj.upper()} {yk}"


from functools import cache, cached_property


class FutureChain:
    def __init__(
            self,
            ticker,
            notional=1,
            bq=None,
            yk='Comdty'
    ):
        self.ticker = ticker
        self.notional = notional
        self.yk = yk
        self.bq = bq

    @property
    @cache
    def point_value(self):
        p = self.bq.bdp(
            f'{self.ticker}1 {self.yk}',
            'fut_val_pt'
        )
        return float(p['fut_val_pt'].squeeze())

    def get_data(self):
        pass

    def

        @property
        def quote(self):
            return

    @property
    def pv(self):
        return

    @property
    def trade(self):
        return self


from gioutils.blpw import BlpQuery

bq = BlpQuery(timeout=50000).start()

range(1, 2)
spread_legs = [
    (2, 4),
    (2, 5),
    (2, 6),
    (2, 7),
    (2, 8),
    (2, 9),
    (3, 5),
    (3, 6),
    (3, 7),
    (3, 8),
    (3, 9),
    (3, 10),
    (3, 11),
    (3, 12),
    (4, 7),
    (4, 8),
    (4, 9),
    (4, 10),
    (4, 11),
    (4, 12),
    (5, 8),
    (5, 9),
    (5, 10),
    (5, 11),
    (5, 12),
    (6, 10),
    (6, 11),
    (6, 12),
    (7, 11),
    (7, 12),
    (8, 12),
    (2, 3),
    (2, 4),
    (2, 5),
    (2, 6),
    (3, 5),
    (3, 6),
    (3, 7),
    (3, 8),
    (4, 6),
    (4, 7),
    (4, 8),
    (4, 9),
    (4, 10),
    (5, 8),
    (5, 9),
    (5, 10),
    (5, 12),
    (6, 8),
    (6, 9),
    (6, 10),
    (6, 11),
    (6, 12),
    (7, 10),
    (7, 11),
    (7, 12),
    (8, 12),
]

fly_legs = [
    (2, 3, 4),
    (2, 4, 6),
    (2, 5, 8),
    (3, 5, 7),
    (3, 6, 9),
    (3, 7, 11),
    (4, 7, 11),
    (4, 8, 12),
    (5, 8, 11),
    (2, 3, 4),
    (2, 4, 6),
    (2, 5, 8),
    (2, 6, 10),
    (2, 7, 12),
    (3, 4, 5),
    (3, 5, 7),
    (3, 6, 9),
    (3, 7, 11),
    (3, 8, 13),
    (4, 6, 8),
    (4, 7, 9),
    (4, 8, 12),
    (5, 8, 11),
    (5, 9, 13),
    (6, 9, 12),
]

FLYS(Euribor and SOFR)
Transaction
tax: 1.5
tic in or out

fly_legs = [
    (2, 3, 4),
    (2, 4, 6),
    (2, 5, 8),
    (2, 6, 10),
    (2, 7, 12),
    (3, 4, 5),
    (3, 5, 7),
    (3, 6, 9),
    (3, 7, 11),
    (3, 8, 13),
    (4, 6, 8),
    (4, 7, 9),
    (4, 7, 11),
    (4, 8, 12),
    (5, 8, 11),
    (5, 9, 13),
    (6, 9, 12),
]

spread_legs = [
    (2, 3),
    (2, 4),
    (2, 5),
    (2, 6),
    (2, 7),
    (2, 8),
    (2, 9),
    (3, 5),
    (3, 6),
    (3, 7),
    (3, 8),
    (3, 9),
    (3, 10),
    (3, 11),
    (3, 12),
    (4, 6),
    (4, 7),
    (4, 8),
    (4, 9),
    (4, 10),
    (4, 11),
    (4, 12),
    (5, 8),
    (5, 9),
    (5, 10),
    (5, 11),
    (5, 12),
    (6, 8),
    (6, 9),
    (6, 10),
    (6, 11),
    (6, 12),
    (7, 10),
    (7, 11),
    (7, 12),
    (8, 12),
]

from bqplot import ColorScale, LinearScale
from ipydatagrid import BarRenderer

{
    'TradeId': 'Int',
    'EffExp': 'String',
    'MtyTnr': 'String',
    'PayoutType': 'String',
    'Nominal': 'Double',
    'Strike': 'String',
    'SwaptionSettleType': 'String',
    'CollateralCcy': 'String',
    'ClearingHouse': 'String',
    'UnderlyingClearingHouse': 'String',
    'IsStrikeNumber': 'String',
    'Generator': 'String',
    'SVMInstrument': 'String',
}

TradeId
EffExp
MtyTnr
PayoutType
Nominal
Strike
SwaptionSettleType
CollateralCcy
ClearingHouse
UnderlyingClearingHouse
IsStrikeNumber
Generator
SVMInstrument

ir_map = pd.DataFrame(
    [
        ('TradeId', 'Int', None, None),
        ('EffExp', 'String', 'eff_exp', None),
        ('MtyTnr', 'String', 'mty_tnr', None),
        ('PayoutType', 'String', 'payout_type', None),
        ('Nominal', 'Double', 'notional', None),
        ('Strike', 'String', 'strike', None),
        ('SwaptionSettleType', 'String', 'swaption_settle_type', None),
        ('CollateralCcy', 'String', 'collateral_ccy', None),
        ('ClearingHouse', 'String', 'clearing_house'), None,
        ('UnderlyingClearingHouse', 'String', 'underlying_clearing_house', None),
        ('IsStrikeNumber', 'String', None, None),
        ('Generator', 'String', 'generator', None),
        ('SVMInstrument', 'String', 'instrument', None),
    ],
    columns=['col', 'type', 'arg', 'fn']
)

from gioutils.blpw import BlpQuery

macro = [
    {'area': 'US', 'topic': 'Inflation', 'name': 'US CPI', 'ticker': 'CPI YOY Index'},
    {'area': 'US', 'topic': 'Inflation', 'name': 'US Core CPI', 'ticker': 'CPI XYOY Index'},
    {'area': 'US', 'topic': 'Inflation', 'name': 'US PPI', 'ticker': 'FDIUFDYO Index'},
    {'area': 'US', 'topic': 'Inflation', 'name': 'US Core PPI', 'ticker': 'FDIUSGUY Index'},
    {'area': 'US', 'topic': 'Inflation', 'name': 'US Inflation Expectations 1y', 'ticker': 'CONSPXMD Index'},
    {'area': 'US', 'topic': 'Inflation', 'name': 'US Inflation Expectations 5-10y', 'ticker': 'CONSP5MD Index'},
    {'area': 'US', 'topic': 'Inflation', 'name': 'PCE', 'ticker': 'PCE DEFY Index'},
    {'area': 'US', 'topic': 'Inflation', 'name': 'Core PCE', 'ticker': 'PCE CYOY Index'},
    {'area': 'US', 'topic': 'Wages', 'name': 'ECI', 'ticker': 'ECI SA% Index'},
    {'area': 'US', 'topic': 'Wages', 'name': 'AHE', 'ticker': 'AHE YOY% Index'},
    {'area': 'US', 'topic': 'Activity', 'name': 'Retail Sales', 'ticker': 'RSTAXMOM Index'},
    {'area': 'US', 'topic': 'Activity', 'name': 'Industrial Production', 'ticker': 'IP CHNG Index'},
    {'area': 'US', 'topic': 'Activity', 'name': 'ISM Manufacturing', 'ticker': 'NAPMPMI Index'},
    {'area': 'US', 'topic': 'Activity', 'name': 'ISM Services', 'ticker': 'NAPMNMI Index'},
    {'area': 'US', 'topic': 'Activity', 'name': 'PMI', 'ticker': 'MPMIUSCA Index'},
    {'area': 'US', 'topic': 'Activity', 'name': 'GDP', 'ticker': 'GDP CQOQ Index'},
    {'area': 'US', 'topic': 'Activity', 'name': 'Durable Goods Orders', 'ticker': 'DGNOCHNG Index'},
    {'area': 'US', 'topic': 'Labour', 'name': 'Initial Jobless Claims', 'ticker': 'INJCJC Index'},
    {'area': 'US', 'topic': 'Labour', 'name': 'Continuing Claims', 'ticker': 'INJCSP Index'},
    {'area': 'US', 'topic': 'Labour', 'name': 'NFP', 'ticker': 'NFP TCH Index'},
    {'area': 'US', 'topic': 'Labour', 'name': 'Urate', 'ticker': 'USURTOT Index'},
    {'area': 'US', 'topic': 'CB', 'name': 'FOMC', 'ticker': 'FDTR Index'},
    {'area': 'US', 'topic': 'CB', 'name': 'Minutes', 'ticker': 'FEDMMINU Index'},
    {'area': 'EU', 'topic': 'Inflation', 'name': 'CPI', 'ticker': 'ECCPEST Index'},
    {'area': 'EU', 'topic': 'Inflation', 'name': 'Core CPI', 'ticker': 'CPEXEMUY Index'},
    {'area': 'EU', 'topic': 'Inflation', 'name': 'PPI', 'ticker': 'EUPPEMUY Index'},
    {'area': 'EU', 'topic': 'Inflation', 'name': 'Germany CPI', 'ticker': 'GRCP2HYY Index'},
    {'area': 'EU', 'topic': 'Inflation', 'name': 'France CPI', 'ticker': 'FRCPEECY Index'},
    {'area': 'EU', 'topic': 'Inflation', 'name': 'Italy CPI', 'ticker': 'ITCPEY Index'},
    {'area': 'EU', 'topic': 'Activity', 'name': 'PMI', 'ticker': 'MPMIEZCA Index'},
    {'area': 'EU', 'topic': 'Activity', 'name': 'Economic Confidence', 'ticker': 'EUESEMU Index'},
    {'area': 'EU', 'topic': 'Activity', 'name': 'GDP', 'ticker': 'EUGNEMUQ Index'},
    {'area': 'EU', 'topic': 'Activity', 'name': 'Retail Sales', 'ticker': 'RSSAEMUM Index'},
    {'area': 'EU', 'topic': 'Activity', 'name': 'Sentix Survey', 'ticker': 'SNTEEUGX Index'},
    {'area': 'EU', 'topic': 'Activity', 'name': 'IP', 'ticker': 'EUITEMUM Index'},
    {'area': 'EU', 'topic': 'Activity', 'name': 'ZEW', 'ticker': 'GRZEEUEX Index'},
    {'area': 'EU', 'topic': 'Activity', 'name': 'Germany IFO', 'ticker': 'GRIFPBUS Index'},
    {'area': 'EU', 'topic': 'CB', 'name': 'ECB', 'ticker': 'EURR002W Index'}
]

bq = BlpQuery().start()
bq.bdsm()
bq.bds
fields = {
    'country': 'country',
    'security_des': 'name',
    'eco_release_dt': 'next',
    'bn_survey_median': 'survey',
    'px_last': 'last',
    'prev_close_val': 'prev',
    'relevance_value': 'rank'
}

res = bq.bdp([d['ticker'] for d in macro], fields)
res = res.sort_values('rank', ascending=False)

'o/n',
'1m',
'3m',
'6m',
'1y',
'2y',
'3y',
'4y',
'5y',
'6y',
'7y',
'8y',
'9y',
'10y',
'12y',
'15y',
'20y',
'25y',
'30y',
'40y',
'50y',