from dotenv import load_dotenv
load_dotenv();

import base64
import json
import logging
import os
import re
import smtplib
import sys
import time
import threading
import traceback
from copy import deepcopy
from functools import partial, wraps
from itertools import chain
from importlib import reload
from pathlib import Path
from uuid import uuid4
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart

import bhutils
import blpapi
import ipyvuetify as v
import ipywidgets as w
import numpy as np
import pandas as pd
import clarion
import QuantLib as ql
import dataframe_image as dfi
import schedule
import win32com.client as win32
from bqplot import ColorScale, LinearScale, OrdinalColorScale, OrdinalScale
from ipydatagrid import BarRenderer, DataGrid, Expr, TextRenderer, VegaExpr
from IPython.display import display, clear_output
from pandas.tseries.offsets import BDay
from plotly import graph_objects as go
from plotly.subplots import make_subplots
from blp.blp import BlpParser

from api.watchdog import specs
from api.watchdog.specs import get_trades, get_targets
from api.watchdog.pricer import Pricer
from api.instruments.future import FutureChain, FutureBasket
from api.instruments.strategies2 import get_base_stop
from api.jobs.risk import daily_var_email
from api.jobs.risk_intraday import var_reduction_email, var_reduction_email2
from api.jobs.macd_watcher import macd_signals_email, make_plotly_fig
from api.jobs.positions import history_plotter_email

from gioutils.clarion_ext import Runner
from gioutils.gui.pandas import millifyp as millify
from gioutils import ezutils as ez
from gioutils.blpw import BlpParser, BlpQuery
from gioutils.clarion_ext import super_clarion
from gioutils.tools_clarion import get_clarion_positions
from gioutils.tools import parse_swap_periods
from gioutils.ezutils import (
    bh,
    bhs,
    get_id,
    get_price_info,
)

from gioutils.utils import (
    get_bday,
    get_next_n,
    parse_offset,
    today,
    get_generic_future,
    get_bbg_fut_chain_ticker,
    get_specific_future,
    get_root
)
from gioutils.tools_clarion import get_history_plotter_book

pd.options.plotting.backend = "plotly"
pd.options.display.float_format = partial(millify, pct=None, decimal=4)

clarion.server_login()
bq = BlpQuery(timeout=50000, parser=BlpParser(raise_security_errors=False)).start()
# ba = BHSysApi(password="A&3jg5Aj")
clear_output()

super_clarion(clarion)
runner = Runner(clarion)
daily_var_email()
var_reduction_email2(clarion, bq, use_best_var=True, send_email=True)


from sklearn.decomposition import PCA

from plotly import express as px

px.imshow()



from traitlets import


