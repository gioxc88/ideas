import numpy as np
import pandas as pd
from plotly import graph_objects as go

from gioutils.utils import today
from gioutils.ezutils import bh, bhs, LiveCurvesLocal

pd.options.plotting.backend = "plotly"

lcl = LiveCurvesLocal()
bh.bhFiRate('2y', '2y', 'USD OIS', lcl.db_curves_cached, collateral='LCH', generators=bhs.gens)


id_ = 'CT5 Govt'
isin = bh.bhGetMktData(id_, "B", "ID_ISIN")
bond_hdl = bh.bhBondRead(isin=isin, calendar=bhs.ccy_cals)
date = today()
settle_dt = bh.bhBondSettlementDate(bond_hdl, date)
