import pandas as pd
ts_var_clac_param_map = {
    'oswp':  [
        'SVMInstrument',
        'Ccy',
        'Generator',
        'EffExp',
        'MtyTnr',
        'FwdTenor',
        'PayoutType',
        'Strike',
        'Nominal',
        'CollateralCcy',
        'SwaptionSettleType',
        'PaySettleType',
        'Premium',
        'UnderlyingClearingHouse',
    ],
    'irs': [
        'SVMInstrument',
        'Ccy',
        'Generator',
        'EffExp',
        'MtyTnr',
        'PayoutType',
        'Strike',
        'Nominal',
        'CollateralCcy',
    ],

    'lfut': [
        'SVMInstrument',
        'Ccy',
        'Generator',
        'MtyTnr',
        'Nominal',
    ],
    'sfut': [
        'SVMInstrument',
        'Ccy',
        'Generator',
        'MtyTnr',
        'Nominal',
    ]


}


