import json
import sys
import re
import logging
import os
from pathlib import Path
from functools import partial
from itertools import chain
from uuid import uuid4

import blpapi
import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
import QuantLib as ql
from IPython.display import display
from ipydatagrid import DataGrid, TextRenderer, BarRenderer, Expr, VegaExpr
from bqplot import LinearScale, ColorScale, OrdinalColorScale, OrdinalScale
from pandas.tseries.offsets import BDay
from plotly import graph_objects as go
from plotly.subplots import make_subplots

# from api.ezutils import bh, mkt_defs, ccy_cals, mx_cals, mtg_dts, gens

from gioutils.utils import parse_offset, today, get_next_n, date_from_offset, get_bday
from api.data.base import data_path, radar_path
from gioutils.gui.base import View, store, WidgetView, Tabs
from api.gui.params import curves, bbg_params, spot_params, fwd_params
from gioutils.blpw import BlpQuery
from gioutils.utils import RepeatedTimer, parse_swap_tenor_expr
from gioutils.ezutils import bh, bhs
from api.gui.theme import bg_color, grid_style
from api.gui.pandas import DFOutput, negative_red, custom_styler_row_line, DataGridGio

pd.options.plotting.backend = "plotly"

from gioutils import ezutils as ez
from api.instruments.swap import RealSwap, RollingSwap, ez_bump, mult_map

ccy = 'USD'
instrument = 'irs'
generator = 'USD LIBOR S 3M*'
exp = '2y'
mat = '3y'
pr = 'pay'
metric = 'rate'
start_date = pd.to_datetime('2022-01-04')
end_date = today()
collateral = 'local'
notional = 1000000
swap = {}
scale = False

for metric in ['rate', 'pv', 'ann01']:
    res = ez.get_irbt_ts(
        ccy=ccy,
        instrument=instrument,
        generator=generator,
        eff_exp=exp,
        tenor_mty=mat,
        pay_receive=pr,
        metric=metric,
        start_date=start_date,
        end_date=end_date,
        collateral=collateral,
        strike=None if metric == 'rate' else swap['rate'][start_date] * (100 if not scale else 1),
        nominal=notional,
        scale=scale
    )

    swap[metric] = res
swap = pd.DataFrame(swap)
swap['pv'] = swap['pv'] * 1000
swap['pnl~'] = (swap['rate'].diff() * 100 * swap['ann01'].shift() * notional / 10000).fillna(0).cumsum()

s1 = RealSwap(
    ccy=ccy,
    generator=generator,
    eff_exp='2y',
    tenor_mty='3y',
    start_hist='1y',
    notional=notional
)

s2 = RollingSwap(
    ccy=ccy,
    generator=generator,
    eff_exp='2y',
    tenor_mty='3y',
    start_hist='1y',
    notional='d0.258k'
)


ss = s2.get_real_swap()