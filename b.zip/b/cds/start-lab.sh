source venv/Scripts/activate && jupyter-lab --VoilaConfiguration.enable_nbextensions=True
