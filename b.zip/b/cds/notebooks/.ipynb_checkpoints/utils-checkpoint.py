from plotly import (
    io as pio,
    express as px,
    graph_objects as go,
    figure_factory as ff
)
from plotly.subplots import make_subplots


def heatmap(
    df,
    title=None,
    fmt='.0%',
    width=None,
    height=None,
    colorscale=None,
    showscale=True,
    **kwargs,
):
    if fmt:
        fig = ff.create_annotated_heatmap(
            z=df.to_numpy(),
            x=[*df.columns],
            y=[*df.index],
            annotation_text=df.applymap(lambda x: f'{x: {fmt}}').to_numpy(),
            colorscale=colorscale or 'viridis',
            showscale=showscale,
            **kwargs
        )
    else:
        fig = go.Figure(
            data=go.Heatmap(
                z=df.to_numpy(),
                x=[*df.columns],
                y=[*df.index],
                colorscale=colorscale or 'viridis',
                showscale=showscale,
                **kwargs
            )
        )


    # fig.update_xaxes(tickangle=45, side='bottom')

    fig.update_layout(
        autosize=False,
        title={
            'text': title,
            'y':0.9,
            'x':0.5,
            'xanchor': 'center',
            'yanchor': 'top'
        } if title else None,
        width=width or 1000,
        height=height or 700
    )\
       .update_xaxes(tickangle=45, side='bottom')

    return fig


def add_vlines(fig, mask, line_color='green', **kwargs):
    temp = mask.rename('mask').to_frame()
    temp['cumsum'] = (~mask).cumsum()
    for index, group in temp.groupby(['mask', 'cumsum'], sort=False):
        if index[0]:
            if len(group) == 1:
                fig.add_vline(x=f"{group.index[0]:%Y-%m-%d}", line_color=line_color, opacity=0.25)
            else:
                fig.add_vrect(x0=f"{group.index[0]:%Y-%m-%d}", x1=f"{group.index[-1]:%Y-%m-%d}", fillcolor=line_color,
                              opacity=0.25, line_width=0)
    return fig