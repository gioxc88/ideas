########################### DQ API CONNECTION - OAUTH

# below is a sample code for making a oauth-based invokation to DQ APIs using your Client ID and Secret
# you can use this as reference to write your own code and include in a .py of yours to import 
# in your API client software. In the example below, there is one method which is meant for import
# which is "get_dq_api_result". If for instance you save this code in a "api_utils.py" module, 
# you would then import it with:
#     from api_utils import get_dq_api_result
# note: the only dependency for below code is 'requests', for the https calls, which can be installed using "pip".

import requests
import datetime

_stored_token = None  # singleton-like variable


def _get_token(cfg):
    global _stored_token # reference to module ariable
    # if first time or prev stored token is elapsed (based on "expires_in" seconds from IDP resonse)
    if _stored_token is None or ((datetime.datetime.now() - _stored_token['created_at']).total_seconds() / 60) >= (_stored_token['expires_in'] - 1):
        # invokes the post agains IDP to get a token
        json = requests.post(
            url=cfg['token_provider_url'],
            proxies={"https": cfg['https_proxy']} if 'https_proxy' in cfg else {},
            data={'grant_type': 'client_credentials', 'client_id': cfg['client_id'], 'client_secret': cfg['client_secret'], 'aud':cfg['dq_api_resource_id']}
        ).json()
        # stores the token in the singleton-like variable together with "created_at" (=system date-time) and "expires_in" (=expiration time in seconds, from the response)
        if 'access_token' in json:
            _stored_token = {'created_at': datetime.datetime.now(), 'access_token': json['access_token'], 'expires_in': json['expires_in']}
        else:
            raise Exception('unexpected result trying to obtain a oauth token: {0}'.format(json))
    return _stored_token['access_token']


def get_dq_api_result(cfg, path, params):
    # concatenates path to base path from config, and issues a GET call using the params and including the token from method above
    return requests.get(
        url=cfg['dq_api_url'] + '/' + path,
        params=params,
        headers={'Authorization': 'Bearer ' + _get_token(cfg)},
        proxies={"https": cfg['https_proxy']} if 'https_proxy' in cfg else {}
    # returns the service response in json (if successful) or raises an exception
    ).json()

########################### USAGE EXAMPLE

# usage example - a few notes:
# 1. cfg is a dictionary with the properties needed for the connection, here hardcoded, but could be loaded from a json or a yaml file
# 2. if you want to try this examplar code, you need to put real client_id and client_password in the dictionary
# 3. the http_proxy value can be omitted/commented if not needed
# 4. the arguments to get_dq_api_result are:
#    - the cfg (configuration) dictionary, either hardcoded as below or loaded from file
#    - the path to be appended to the base URL (corresponding to the service being invoked)
#    - the params dictionary, which contains all the arguments to be sent to the service in query string

cfg = {
    'dq_api_url': 'https://api-developer.jpmorgan.com/research/dataquery-authe/api/v2/',
    'token_provider_url': 'https://authe.jpmchase.com/as/token.oauth2',
    'client_id': '<PUT YOUR CLIENT ID HERE>',
    'client_secret': '<PUT YOUR CLIENT SECRET HERE>',
    #'https_proxy': '<PUT YOUR PROXY HERE, IF YOU NEED ONE, OTHERWISE COMMENT THIS LINE/THIS PROPERTY>',
    'dq_api_resource_id': 'JPMC:URI:RS-06785-DataQueryExternalApi-PROD'
}

#example GET request for simple expression query

print(get_dq_api_result(
        cfg, #configuration dictionary
        'expressions/time-series', # specific service being invoked
        {'expressions': 'DB(FHR,N10,MIDPRC)'} # params to be sent to the service
    ))

