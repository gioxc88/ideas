source venv/Scripts/activate && voila --enable_nbextensions=True ./notebooks/market_monitor_final.ipynb
