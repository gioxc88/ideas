import argparse
import logging
import json
from loggers import get_logger, get_default_logger

import config
from api.data.base import logs_path


def test(logger=get_default_logger(), **kwargs):

    logger.info('this is a test')
    logger.info(kwargs)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--kwargs', type=json.loads)

    logger = get_logger(
        __name__,
        file=logs_path / 'test.log'
    )

    args = parser.parse_args()
    test(logger=logger, **args.kwargs)



