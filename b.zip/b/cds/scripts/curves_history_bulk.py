import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd

try:
    import config
except ModuleNotFoundError:
    pass

from api.blpw import BlpQuery
from api.data.fields import bond_reference_fields
from api.data.processing import post_process, apply_function
from api.data.base import tables, root_path, data_path

from api.data.curves import curves
from api.data.utils import add_pcs

pcs = 'BGN'
sep = ' '

options = {
    'calendarCodeOverride': '5D',
    "nonTradingDayFillOption": "ALL_CALENDAR_DAYS",
    "nonTradingDayFillMethod": "PREVIOUS_VALUE"
}

timestamp = f"{pd.Timestamp.today():%Y%m%d_%H%M%S}"
dt_fmt = '%Y%m%d'
bq = BlpQuery(timeout=50000).start()

try:
    pd.read_csv(data_path / 'curve_history.csv').to_csv(data_path / 'curve_history_backup.csv', index=False)
except FileNotFoundError:
    pass

start_date = pd.Timestamp(2006, 1, 1)
end_date = pd.Timestamp.today()

res = []
for i, curve in enumerate(curves):
    securities = pd.DataFrame(curve['members']).set_index('tenor').squeeze().rename('security')
    # securities = securities.set_axis(pd.CategoricalIndex(securities.index, categories=securities.index, ordered=True))
    fields = [field["field"] for field in curve["fields"]]
    pcs_ = curve.get('pcs', pcs)
    sep_ = curve.get('sep', sep)
    if pcs:
        securities_ = add_pcs(securities, pcs_, sep=sep_)
    else:
        securities_ = securities.to_list()

    res_ = bq.bdh(
        securities=securities_,
        fields=fields,
        start_date=start_date.strftime(dt_fmt),
        end_date=end_date.strftime(dt_fmt),
        options=options
    )
    res_ = res_.dropna(subset=fields, how='all')
    res_ = res_.rename({field["field"]: field["name"] for field in curve["fields"]}, axis=1)
    if pcs_:
        res_['security'] = res_['security'].str.replace(f'{sep_}{pcs_}', '')

    res_ = res_.merge(securities.reset_index(), on='security')
    res_['curve_name'] = curve['name']

    res.append(res_)

res = pd.concat(res)
res.to_csv(data_path / 'curve_history.csv', index=False)




from itertools import chain
from io import StringIO

import ipywidgets as w
import numpy as np
import pandas as pd
import requests
from plotly import (
    io as pio,
    express as px,
    graph_objects as go,
    figure_factory as ff
)
from plotly.subplots import make_subplots
from scipy.linalg import block_diag
from scipy.spatial.distance import pdist, squareform
from scipy.cluster.hierarchy import (
    linkage,
    fcluster,
    optimal_leaf_ordering,
    leaves_list,
    dendrogram
)

class DFPlot:
    def __init__(self, df):
        self.df = df
        self.dd = w.Dropdown(options=df.columns)

        def fn(col):
            fig = self.df[col].plot(backend='plotly')
            display(fig)


        self.out = w.interactive_output(fn, dict(col=self.dd))
        self.app = w.VBox([self.dd, self.out])

    def _ipython_display_(self):
        return display(self.app)


def corr_plot(
    corr,
    title=None,
    fmt='.0%',
    width=None,
    height=None,
    colorscale=None,
    showscale=True,
    **kwargs,
):
    if fmt:
        fig = ff.create_annotated_heatmap(
            z=corr.to_numpy(),
            x=[*corr.columns],
            y=[*corr.index],
            annotation_text=corr.applymap(lambda x: f'{x: {fmt}}').to_numpy(),
            colorscale=colorscale or 'viridis',
            showscale=showscale,
            **kwargs
        )
    else:
        fig = go.Figure(
            data=go.Heatmap(
                z=corr.to_numpy(),
                x=[*corr.columns],
                y=[*corr.index],
                colorscale=colorscale or 'viridis',
                showscale=showscale,
                **kwargs
            )
        )


    # fig.update_xaxes(tickangle=45, side='bottom')

    fig.update_layout(
        autosize=False,
        title={
            'text': title,
            'y':0.9,
            'x':0.5,
            'xanchor': 'center',
            'yanchor': 'top'
        } if title else None,
        width=width or 1000,
        height=height or 700
    )\
       .update_xaxes(tickangle=45, side='bottom')

    return fig


def agg_ret(prices, freq='A', compounded=False):
    to_freq = prices.resample(freq).last()

    res = pd.concat([
        pd.Series(prices.iloc[0], index=[prices.index[0] - pd.tseries.frequencies.to_offset(freq)]),
        to_freq
    ])

    if compounded:
        res = res.pct_change().dropna()
    else:
        res = res.diff().dropna()

    if freq=='M':
        res = pd.concat(
            [pd.Series(group.to_numpy(), index=group.index.month, name=group.index[0].year) for index, group in res.groupby(pd.Grouper(freq='A'))],
            axis=1
        )

    return res


@pd.api.extensions.register_dataframe_accessor("zscore")
class ZScore:
    def __init__(self, pandas_obj):
        self._obj = pandas_obj

    def __call__(self, n):
        obj = self._obj
        rolling = obj.rolling(n)
        return (obj - rolling.mean()) / rolling.std()


@pd.api.extensions.register_series_accessor("zscore")
class ZScore:
    def __init__(self, pandas_obj):
        self._obj = pandas_obj

    def __call__(self, n):
        obj = self._obj
        rolling = obj.rolling(n)
        return (obj - rolling.mean()) / rolling.std()


def distance_correlation(corr):
   return ((1 - corr) / 2) ** 0.5


def seriate(corr):
    dist_corr = distance_correlation(corr)
    flat_dist = squareform(dist_corr)
    # dim = len(dist_corr)
    # tri_a, tri_b = np.triu_indices(dim, k=1)
    # flat_dist = dist_corr[tri_a, tri_b]  # this is same as squareform(dist_corr)

    Z = linkage(flat_dist, method='ward')
    order = leaves_list(Z)
    return corr.iloc[order, order]


