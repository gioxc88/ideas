import json
import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay

try:
    import config
except ModuleNotFoundError:
    pass

from api.blpw import BlpQuery
from api.data.base import tables, data_path
from api.data.fields import bond_history_fields
from api.data.utils import add_pcs, unparse_results_securities

sources_ = ['BGN', 'BVAL', 'CBBT']
sep_ = '@'

options = {
    'calendarCodeOverride': '5D',
    "nonTradingDayFillOption": "ALL_CALENDAR_DAYS",
    "nonTradingDayFillMethod": "PREVIOUS_VALUE",
    "pricingOption": "PRICING_OPTION_PRICE"
}

start_date_ = pd.Timestamp(2006, 1, 1)
end_date_ = pd.Timestamp.today().floor('d') - BDay()
bbg_dt_fmt = '%Y%m%d'


def get_bonds_history(
        securities=None,
        fields=None,
        start_date=None,
        end_date=None,
        sources=None,
        sep=None,

):

    timestamp = f"{pd.Timestamp.today():%Y%m%d_%H%M%S}"
    bq = BlpQuery(timeout=50000).start()

    start_date = start_date or start_date_
    end_date = end_date or end_date_
    sources = sources or sources_
    sep = sep or sep_

    bonds_ref = pd.read_csv(data_path / 'bonds_reference.csv')

    securities = securities or bonds_ref['security'].drop_duplicates().to_list()
    fields = fields or bond_history_fields
    bbg_fields = [field['field'] for field in fields]

    res = []
    for source in sources:
        res_ = bq.bdh(
            securities=securities,
            fields=bbg_fields,
            start_date=start_date.strftime(bbg_dt_fmt),
            end_date=end_date.strftime(bbg_dt_fmt),
            options=options,
            pcs=source,
            sep=sep
        )
        res_ = res_.assign(source=source)
        res.append(res_.dropna(subset=bbg_fields[:-1], how='all'))

    res_all_sources = pd.concat(res)
    res_all_sources = res_all_sources.rename({field['field']: field['name'] for field in fields}, axis=1)

    with open(data_path / 'bonds_history_meta.json', 'w') as f:
        json.dump({'last_date': end_date.strftime('%Y-%m-%d')}, f)

    res_all_sources.to_csv(data_path / f"bonds_history_all.csv", index=False)
    return res_all_sources

