import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd

try:
    import config
except ModuleNotFoundError:
    pass

from api.blpw import BlpQuery
from api.data.fields import bond_reference_fields
from api.data.processing import post_process, apply_function
from api.data.base import tables, root_path, data_path
from api.data.universe import securities

timestamp = f"{pd.Timestamp.today():%Y%m%d_%H%M%S}"

### Bloomberg Connection
bq = BlpQuery(timeout=50000).start()


res_ = bq.bdp(
    securities=securities,
    fields=[field['field'] for field in bond_reference_fields],
)

res_.to_csv(data_path / 'temp' / f"bonds_reference_{timestamp}.csv", index=False)
res = post_process(res_)
res.to_csv(data_path / 'bonds_reference.csv', index=False)


def get_bmk_bonds(bond_ref):
    from api.data.fields import bond_reference_fields
    from api.data.processing import post_process
    all_securities = bond_ref['security']
    securities = bond_ref['bmk_bond'].drop_duplicates().dropna()

    res = []
    while True:

        securities = securities.loc[~securities.isin(all_securities)]
        if securities.empty:
            break

        res_ = bq.bdp(
            securities=securities.to_list(),
            fields=[field['field'] for field in bond_reference_fields],
        )

        res_ = post_process(res_)

        all_securities = pd.concat([all_securities, res_['security']]).drop_duplicates().dropna()
        securities = res_['bmk_bond'].drop_duplicates().dropna()

        res.append(res_)

    return pd.concat(res) if res else None



### Bugfix

#### 1. Add new fields

# res = pd.read_csv(data_path / 'temp' / 'bonds_reference_20220525_193116.csv')
# tickers = pd.read_csv(data_path / 'temp' / 'searches_20220525_193116.csv', index_col=0).squeeze()
bond_ref = pd.read_csv(data_path / 'bonds_reference.csv')
# bonds_ref.loc[(bonds_ref['workout_date'] > pd.Timestamp.today()), :]

fields = [    {
        'field': 'COUPON_FREQUENCY_DESCRIPTION',
        'name': 'coupon_freq',
    },
    {
        'field': 'DAY_CNT_DES',
        'name': 'day_count',
    },]

res_ = bq.bdp(
    securities=bond_ref['security'].to_list(),
    fields=[ field['field'] for field in fields],
).rename({field['field']: field['name'] for field in fields}, axis=1)

res_ = apply_function(res_)

res = bond_ref.merge(res_, on='security', how='left')[['security', *[field['name'] for field in bond_reference_fields]]]
res.to_csv(data_path / 'bonds_reference.csv', index=False)

#### 2. Add new Instruments

securities = None

res_ = bq.bdp(
    securities=securities,
    fields=[field['field'] for field in bond_reference_fields],
).rename({field['field']: field['name'] for field in bond_reference_fields}, axis=1)

res_ = post_process(res_)
res = pd.concat([res, res_])
res.to_csv(data_path / 'bonds_reference.csv', index=False)

