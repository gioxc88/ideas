import json
import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay

try:
    import config
except ModuleNotFoundError:
    pass

from api.blpw import BlpQuery
from api.data.base import tables, data_path
from api.data.fields import bond_history_fields
from api.data.utils import add_pcs, unparse_results_securities

pcs_ = 'BGN'
sep_ = '@'

options = {
    'calendarCodeOverride': '5D',
    "nonTradingDayFillOption": "ALL_CALENDAR_DAYS",
    "nonTradingDayFillMethod": "PREVIOUS_VALUE"
}

start_date_ = pd.Timestamp(2006, 1, 1)
end_date_ = pd.Timestamp.today().floor('d')


def get_bonds_history(
        securities=None,
        fields=None,
        start_date=None,
        end_date=None,
        pcs=None,
        sep=None,

):

    timestamp = f"{pd.Timestamp.today():%Y%m%d_%H%M%S}"
    dt_fmt = '%Y%m%d'
    bq = BlpQuery(timeout=50000).start()

    start_date = start_date or start_date_
    end_date = end_date or end_date_
    pcs = pcs or pcs_
    sep = sep or sep_

    bonds_ref = pd.read_csv(data_path / 'bonds_reference.csv')

    securities = securities or bonds_ref['security'].drop_duplicates().to_list()
    fields = fields or bond_history_fields
    bbg_fields = [field['field'] for field in fields]

    if pcs:
        securities = add_pcs(securities, pcs, sep=sep)

    res_ = bq.bdh(
        securities=securities,
        fields=bbg_fields,
        start_date=start_date.strftime(dt_fmt),
        end_date=end_date.strftime(dt_fmt),
        options=options
    )
    res_ = res_.dropna(subset=bbg_fields, how='all')
    res_.to_csv(data_path / 'temp' / f"bonds_history_{timestamp}.csv", index=False)
    res = res_.rename({field['field']: field['name'] for field in fields}, axis=1)
    res = unparse_results_securities(res, pcs=pcs, sep=sep)

    with open(data_path / 'bonds_history_meta.json', 'w') as f:
        json.dump({'last_date': end_date.strftime('%Y-%m-%d')}, f)

    res.to_csv(data_path / f"bonds_history.csv", index=False)
    return res