import logging


def get_default_logger():
    logger = logging.getLogger('default')
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)
    return logger


def get_logger(
        name=None,
        level=None,
        file=None,
        mode=None,
        fmt=None,
        datefmt=None,
):

    level = level or logging.DEBUG
    mode = mode or 'a'
    fmt = fmt or '%(asctime)s - %(module)s - %(funcName)s - %(levelname)s - %(message)s'
    datefmt = datefmt or '%Y/%m/%d %H:%M:%S'

    logger = logging.getLogger(name)
    logger.setLevel(level)
    formatter = logging.Formatter(
        fmt,
        datefmt=datefmt
    )
    ch = logging.StreamHandler()

    ch.setFormatter(formatter)

    logger.addHandler(ch)

    if file:
        fh = logging.FileHandler(file, mode=mode)
        fh.setFormatter(formatter)
        logger.addHandler(fh)
    return logger


class CustomFormatter(logging.Formatter):
    """Custom formatter, overrides funcName with value of name_override if it exists"""
    def format(self, record):
        if hasattr(record, 'name_override'):
            record.funcName = record.name_override
        return super(CustomFormatter, self).format(record)
