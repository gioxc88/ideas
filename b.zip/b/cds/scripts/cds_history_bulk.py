import sys
from pathlib import Path

import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay

from api.blpw import BlpQuery

from api.data.base import root_path, data_path, tables
from api.data.fields import cds_history_fields
from api.data.utils import add_pcs


timestamp = f"{pd.Timestamp.today():%Y%m%d_%H%M%S}"

### Bloomberg Connection
bq = BlpQuery(timeout=20000).start()
bond_ref = tables.bonds_reference.reset_index()
cds_ref = pd.read_csv(data_path / 'cds_reference.csv')

dt_fmt = '%Y%m%d'

start_date = pd.Timestamp(2007, 1, 1)
end_date = pd.Timestamp.today() - BDay(2)
pcs = 'MSG1'
sep = ' '

# bulk_cds = cds_ref.loc[cds_ref['exists'].fillna(False), 'security'].drop_duplicates().to_list()
securities = cds_ref['security'].drop_duplicates().to_list()

if securities:
    if pcs:
        securities = add_pcs(securities, pcs, sep=sep)
    hist = bq.bdh(
        securities=securities,
        fields=[field['field'] for field in cds_history_fields],
        # overrides=[('PRICING_SOURCE', 'CMAN')]
        start_date=start_date.strftime(dt_fmt),
        end_date=end_date.strftime(dt_fmt)
    )
    hist.to_csv(data_path / 'temp' / f"cds_history_{timestamp}.csv", index=False)
    cds_prices = hist.rename({field['field']: field['name'] for field in cds_history_fields}, axis=1)

    if pcs:
        cds_prices['security'] = cds_prices['security'].str.replace(f'{sep}{pcs}', '')
    cds_prices = cds_prices.merge(cds_ref[['security', 'name']], on='security', how='left')
    # cds_prices = cds_prices.groupby('security', as_index=False, sort=False, dropna=False)\
    #     .apply(lambda df: df.set_index('date').resample('B').ffill().reset_index())

    cds_prices.to_csv(data_path / 'cds_history.csv', index=False)

