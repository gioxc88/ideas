import sys
from pathlib import Path

import numpy as np
import pandas as pd

from api.blpw import BlpQuery
from api.data.base import tables
from api.data.fields import fields_reference
from api.data.processing import post_process
from api.data.base import root_path, data_path, tables

timestamp = f"{pd.Timestamp.today():%Y%m%d_%H%M%S}"

### Bloomberg Connection

bq = BlpQuery().start()

bonds_ref = pd.read_csv(data_path / 'bonds_reference.csv')

searches = [
    'at1',
    'lt2',
    'sp',
    'snp'
]

tickers = []
for search in searches:
    tickers.append(bq.bsrch(f"FI:{search}_daily"))

tickers = pd.concat(tickers, keys=searches, sort=False).droplevel(1).rename('security')
tickers.to_csv(data_path / 'temp' / f"searches_{timestamp}.csv")

new_tickers = tickers.loc[~tickers.isin(bonds_ref['security'])]


if not new_tickers.empty:
    res = bq.bdp(
        securities=new_tickers.to_list(),
        fields=[field['field'] for field in fields_reference],
    )
    res.to_csv(data_path / 'temp' / f"bonds_reference_{timestamp}.csv", index=False)
    res = post_process(res)
    res = pd.concat([bonds_ref, res])
    res.to_csv(data_path / 'bonds_reference.csv', index=False)
