import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd


from api.blpw import BlpQuery
from api.data.fields import fields_reference
from api.data.processing import post_process
from api.data.base import tables
from api.data.base import root_path, data_path, tables
from api.data.utils import get_cds_tickers

timestamp = f"{pd.Timestamp.today():%Y%m%d_%H%M%S}"


### Bloomberg Connection
bq = BlpQuery().start()
bond_ref = tables.bonds_reference.reset_index()
cds_ref = pd.read_csv(data_path / 'cds_reference.csv')

current_cds_5y = cds_ref['cds_ticker_5y'].drop_duplicates().dropna()
all_cds_5y = bond_ref['cds_ticker_5y'].drop_duplicates().dropna()

new_cds_5y = all_cds_5y.loc[~all_cds_5y.isin(current_cds_5y)]


if not new_cds_5y.empty:
    cds_5y = new_cds_5y
    field = 'SECURITY_DES'
    res = bq.bdp(
        securities=cds_5y,
        fields=[field]
    )

    new_cds_ref = []
    for index, row in res.iterrows():
        cds_ticker_5y, cds_generic_name = row['security'], row[field]
        cds_tickers = get_cds_tickers(cds_generic_name=cds_generic_name, bq=bq)
        cds_tickers['cds_ticker_5y'] = cds_ticker_5y
        new_cds_ref.append(cds_tickers)
    new_cds_ref = pd.concat(new_cds_ref)

    to_merge = bond_ref[['ticker', 'issuer_equity_ticker', 'cds_ticker_5y']].dropna().drop_duplicates(
        subset='cds_ticker_5y').set_index('cds_ticker_5y')

    new_cds_ref = new_cds_ref.merge(to_merge, how='left', left_on='cds_ticker_5y', right_index=True)
    cds_ref = pd.concat([cds_ref, new_cds_ref])
    cds_ref.to_csv(data_path / 'cds_reference.csv', index=False)
