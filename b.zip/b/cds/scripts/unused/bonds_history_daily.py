import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay

from api.blpw import BlpQuery
from api.data.base import tables, data_path
from api.data.fields import fields_history
from api.data.utils import add_pcs

dt_fmt = '%Y%m%d'
bq = BlpQuery(timeout=20000).start()

bonds_ref = tables.bonds_reference.reset_index()
bonds_hist = tables.bonds_history
new_bonds = bonds_ref.loc[bonds_ref['has_time_series'].isna()]
existing_bonds = bonds_ref.loc[bonds_ref['has_time_series']]
bonds_merge = bonds_hist.merge(bonds_ref[['security', 'workout_date']], on='security', how='left')
bonds_merge['workout_years'] = (bonds_merge['workout_date'] - bonds_merge['date']).dt.days / 365.2425

all_dates = pd.bdate_range()

securities = bonds_ref['security'].drop_duplicates().to_list()
fields = [field['field'] for field in fields_history]

start_date = pd.Timestamp(2007, 1, 1)
end_date = pd.Timestamp.today()

res_cbbt = bq.bdh(
    securities=add_pcs(securities, 'CBBT'),
    fields=fields,
    overrides=[('PRICING_SOURCE', 'CBBT')],
    start_date=start_date.strftime(dt_fmt),
    end_date=end_date.strftime(dt_fmt)
)
res_cbbt = res_cbbt.rename({field['field']: field['name'] for field in fields_history}, axis=1)
res_cbbt['security'] = res_cbbt['security'].str.replace('@CBBT', '')
res_cbbt['pricing_source'] = 'CBBT'

res_cbbt.to_csv(data_path / 'bonds_history_cbbt.csv', index=False)


