import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd

try:
    import config
except ModuleNotFoundError:
    pass

from api.blpw import BlpQuery
from api.data.base import root_path, data_path, tables
from api.data.utils import get_cds_tickers
from api.data.fields import cds_reference_fields
from api.data.processing import apply_function

timestamp = f"{pd.Timestamp.today():%Y%m%d_%H%M%S}"

### Bloomberg Connection
bq = BlpQuery().start()
bond_ref = tables.bonds_reference
cds_5y = bond_ref['cds_ticker_5y'].dropna().drop_duplicates().to_list()

field = 'SECURITY_DES'
res = bq.bdp(
    securities=cds_5y,
    fields=[field]
)

tenors = [
    '6M',
    '1Y',
    '2Y',
    '3Y',
    '4Y',
    '5Y',
    '7Y',
    '10Y'
]
capital_stack = ['SR']

cds_ref = []
for index, row in res.iterrows():
    cds_ticker_5y, cds_generic_name = row['security'], row[field]
    cds_tickers = get_cds_tickers(
        cds_generic_name=cds_generic_name,
        bq=bq,
        tenors=tenors,
        capital_stack=capital_stack
    )
    cds_tickers['cds_ticker_5y'] = cds_ticker_5y
    cds_ref.append(cds_tickers)
cds_ref = pd.concat(cds_ref).drop_duplicates(subset='cds_name')

na_cds = []
a_cds = []
for sec in cds_ref['cds_name'].drop_duplicates().to_list():
    if 'BNDES' in sec:
        sec_ = sec.replace('Curncy', 'Corp')
        cds_ref.loc[cds_ref['cds_name'] == sec, 'cds_name'] = sec_
    else:
        sec_ = sec
    try:
        t = bq.bdp(
            securities=[sec],
            fields=['TICKER']
        )
        a_cds.append(t)
    except TypeError as e:
        na_cds.append(sec)

cds_real_ref = pd.concat(a_cds).rename({'security': 'cds_name', 'TICKER': 'security'}, axis=1)
cds_real_ref['security'] = cds_real_ref['security'] + ' Curncy'

final_ref = bq.bdp(
    securities=cds_real_ref['security'].to_list(),
    fields=[field['field'] for field in cds_reference_fields]
)
final_ref.to_csv(data_path / f'temp/cds_reference_{timestamp:}.csv', index=False)
final_ref = final_ref.rename({field['field']: field['name'] for field in cds_reference_fields}, axis=1)
final_ref = apply_function(final_ref, cds_reference_fields)

final_ref.to_csv(data_path / 'cds_reference.csv', index=False)
cds_merge = final_ref.merge(
    cds_ref[['cds_name', 'cds_ticker_5y']].rename({'cds_name': 'name'}, axis=1),
    on='name',
    how='left'
)

to_merge = bond_ref[['ticker', 'issuer_equity_ticker', 'issuer_name', 'cds_ticker_5y']].dropna()
cds_final_ref = cds_merge.merge(to_merge, how='left', on='cds_ticker_5y')\
    .drop_duplicates(subset='security')

cds_final_ref.to_csv(data_path / 'cds_reference.csv', index=False)
