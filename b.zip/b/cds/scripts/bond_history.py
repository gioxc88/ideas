try:
    import config
except ModuleNotFoundError:
    pass

from api.data.updates import bonds_daily_history_update

res = bonds_daily_history_update()
