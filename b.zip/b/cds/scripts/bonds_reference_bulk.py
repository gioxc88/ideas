import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd

try:
    import config
except ModuleNotFoundError:
    pass

from api.blpw import BlpQuery
from api.data.fields import bond_reference_fields
from api.data.processing import post_process, apply_function
from api.data.base import tables, root_path, data_path
from api.data.universe import bonds

timestamp = f"{pd.Timestamp.today():%Y%m%d_%H%M%S}"

### Bloomberg Connection
bq = BlpQuery(timeout=50000).start()


def update_bonds_ref():
    try:
        bond_ref = pd.read_csv(data_path / 'bonds_reference.csv')
        securities = pd.Series(bonds).loc[~pd.Series(bonds).isin(bond_ref['security'])]
    except FileNotFoundError:
        bond_ref = pd.DataFrame()
        securities = pd.Series(bonds)

    if not securities.empty:
        res_ = bq.bdp(
            securities=securities.to_list(),
            fields=[field['field'] for field in bond_reference_fields],
        )
        res_.to_csv(data_path / 'temp' / f"add_bonds_reference_{timestamp}.csv", index=False)
        res = post_process(res_)

        new_bond_ref = pd.concat([bond_ref, res])
        new_bond_ref.to_csv(data_path / 'bonds_reference.csv', index=False)

        bmk_bonds = get_bmk_bonds(new_bond_ref)
        if not bmk_bonds.empty:
            new_bond_ref = pd.concat([new_bond_ref, bmk_bonds])
            new_bond_ref.to_csv(data_path / 'bonds_reference.csv', index=False)


def get_bmk_bonds(bond_ref):
    all_securities = bond_ref['security']
    securities = bond_ref['bmk_bond'].drop_duplicates().dropna()

    res = []
    while True:

        securities = securities.loc[~securities.isin(all_securities)]
        if securities.empty:
            break

        res_ = bq.bdp(
            securities=securities.to_list(),
            fields=[field['field'] for field in bond_reference_fields],
        )

        res_ = post_process(res_)

        all_securities = pd.concat([all_securities, res_['security']]).drop_duplicates().dropna()
        securities = res_['bmk_bond'].drop_duplicates().dropna()

        res.append(res_)

    return pd.concat(res) if res else pd.DataFrame()



if __name__ == '__main__':
    update_bonds_ref()

