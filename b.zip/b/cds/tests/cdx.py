import pandas as pd

wgt = pd.read_clipboard()

for i in [1, 2]:
    wgt.iloc[:, i] = wgt.iloc[:, i].str.replace('%', '').astype(float) / 100






