from api.data.updates import bonds_daily_history_update
bonds_daily_history_update()
print('done')
