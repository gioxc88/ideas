[
    'XS1968706876 Corp',
    'XS2109813142 Corp',
    'US195325CX13 Corp',
    'US195325DX04 Corp',
    'XS1558078736 Corp',
    'XS2391398174 Corp',
    'XS1843443356 Corp',
    'US900123CM05 Corp',
    'CMEX1U5 Corp',
    'XS2289588167 Corp',
    'CCHIL1U5 Corp',
    'US168863DU93 Corp',
    'US718286CB15 Corp',
    'US718286CJ41 Corp',
    'US715638BM30 Corp',
    'US715638DQ26 Corp',
    'XS2050933626 Corp',
    'XS1263139856 Corp',
    'XS1245432742 Corp',
    'XS2330514899 Corp',
    'XS2178857285 Corp',
    'XS1694217495 Corp',
    'XS1936302949 Corp',
    'XS1807174393 Corp',
    'XS1959337749 Corp',
    'US195325DP79 Corp',
    'USM88269US88 Corp',
    'XS2445169985 Corp',
    'US836205BA15 Corp',
    'US836205AV60 Corp',
    'US900123AL40 Corp',
    'XS2455985569 Corp',
    '91282CEC1 Corp',
    'XS2455984679 Corp',
    '91282CDY4 Corp',
    'US715638DP43 Corp',
    'US718286CQ83 Corp',
    'US718286CR66 Corp',
    'USY6972HLP91 Corp',
    'US760942BA98 Corp',
    'US760942BB71 Corp',
    'US455780DJ24 Corp',
    'XS1120709826 Corp',
    'CTURK1U3 Corp',
    'US105756CB40 Corp',
    'CBRZ1U5 Corp',
    'US445545AF36 Corp',
    'XS2388586583 Corp',
    'XS1775617464 Corp',
    'US455780CS32 Corp',
    'US455780CT15 Corp',
    'XS2364200514 Corp',
    'XS1313004928 Corp',
    'US715638DF60 Corp',
    'CEGY1U5 Corp',
    'US91087BAL45 Corp',
    'CCOL1U5 Corp',
    'US040114HT09 Corp',
    'US040114HV54 Corp',
    'XS2468421248 Corp',
    'US900123CL22 Corp',
    'US91087BAN01 Corp',
    'US91087BAS97 Corp',
    'XS2159975700 Corp',
    'XS2159975882 Corp',
    'XS2225210330 Corp',
    'XS1696899035 Corp',
    'XS2446175577 Corp',
    'USY7141BAA18 Corp',
    'USY7141BAB90 Corp',
    'XS2259191430 Corp',
    'CPERU1U5 Corp',
    'CSOAF1U5 Corp',
    'US836205BC70 Corp',
    'US836205BE37 Corp',
    'BV8695652 Corp',
    'US195325EA91 Corp',
    'CTURK1U5 Corp',
    'US836205BB97 Corp',
    'XS1892141620 Corp',
    'US698299BL70 Corp',
    'US698299AW45 Corp',
    'XS2109766472 Corp',
    'US455780CW44 Corp',
    'US455780DG84 Corp',
    'XS2270577344 Corp',
    'XS2270576619 Corp',
    'XS2434895806 Corp',
    'XS1028952403 Corp',
    'XS1781710626 Corp',
    'XS1843435840 Corp',
    'USP3579ECB13 Corp',
    'USP3579ECG00 Corp',
    'USP3699PGH49 Corp',
    'XS1108847531 Corp',
    'XS2325747637 Corp',
    'XS1236685613 Corp',
    'XS2388562139 Corp',
    'USP75744AK10 Corp',
    'USP75744AB11 Corp',
    'XS2472852610 Corp',
    'XS1382696398 Corp',
    'XS2079846635 Corp',
    'US718286BG11 Corp',
    'US718286CL96 Corp',
    'XS1968714623 Corp',
    'US836205AY00 Corp',
    'CTUR1U10 Corp',
    'CY002690 Corp',
    'XS2434896010 Corp',
    'XS2447602793 Corp',
    'XS2485248806 Corp',
    'XS2291692890 Corp',
    'XS2388586401 Corp',
    'US71567RAV87 Corp',
    'XS2487342649 Corp',
    'US900123CB40 Corp',
    'XS1057340009 Corp',
    'US900123CA66 Corp',
    'US41809JAA34 Corp',
    'XS2010026305 Corp',
    'XS2010026487 Corp',
    'XS2485249523 Corp',
    'US105756BX78 Corp',
    'CTURK1U1 Corp',
    'US195325BQ70 Corp',
    'XS2280637039 Corp',
    'US900123BJ84 Corp',
    'XS1717013095 Corp',
    'XS1312891549 Corp',
    'US900123CF53 Corp',
    'XS1821416234 Corp',
    'XS2258400162 Corp',
    'USP7S08VCA70 Corp',
    'US71654QBX97 Corp',
    'XS2210006339 Corp',
    'XS2386638733 Corp',
    'XS2391394348 Corp',
    'XS1837994794 Corp',
    'XS1369323149 Corp',
    'US31424EAD40 Corp',
    'US836205AX27 Corp',
    'XS1843435766 Corp',
    'XS2176899701 Corp',
    'XS0505478684 Corp',
    'XS1106137687 Corp',
    'XS2391395154 Corp',
    'XS2451768720 Corp',
    'XS2297221405 Corp',
]



import clarion
clarion.positions

from ipydatagrid import TextRenderer, BarRenderer

fields = [
    {
        "field": "BLP_Z_SPRD_MID",
        "name": "z_spread_mid",
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "z_spread_change_12m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "BLP_Z_SPRD_MID"),
            ("CALC_INTERVAL", "12m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "z_spread_change_ytd",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "BLP_Z_SPRD_MID"),
            ("CALC_INTERVAL", "YTD")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "z_spread_change_6m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "BLP_Z_SPRD_MID"),
            ("CALC_INTERVAL", "6m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "z_spread_change_3m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "BLP_Z_SPRD_MID"),
            ("CALC_INTERVAL", "3m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "z_spread_change_1m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "BLP_Z_SPRD_MID"),
            ("CALC_INTERVAL", "1m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "z_spread_change_1w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "BLP_Z_SPRD_MID"),
            ("CALC_INTERVAL", "1w")
        ]
    },

    {
        "field": "yld_ytm_mid",
        "name": "yield_to_maturity_mid",
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "yield_to_maturity_change_12m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "12m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "yield_to_maturity_change_ytd",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "YTD")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "yield_to_maturity_change_6m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "6m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "yield_to_maturity_change_3m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "3m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "yield_to_maturity_change_1m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "1m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "yield_to_maturity_change_1w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "1w")
        ]
    },

    {
        "field": "px_last",
        "name": "price",
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "price_change_12m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "px_last"),
            ("CALC_INTERVAL", "12m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "price_change_ytd",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "px_last"),
            ("CALC_INTERVAL", "YTD")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "price_change_6m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "px_last"),
            ("CALC_INTERVAL", "6m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "price_change_3m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "px_last"),
            ("CALC_INTERVAL", "3m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "price_change_1m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "px_last"),
            ("CALC_INTERVAL", "1m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "price_change_1w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "px_last"),
            ("CALC_INTERVAL", "1w")
        ]
    },

]


from plotly import graph_objects as go

go.Box

curr_sel = self.curr_sel
maturity_tf = self.maturity_tf
threshold_tf = self.threshold_tf
pcs_tf = self.pcs_tf
sep_tf = self.sep_tf
field_ac = self.field_ac
dl_btn = self.dl_btn
table_btn = self.table_btn
out = self.out

from api.gui.market_monitor_h import CurvesViewer, Pivot, get_issuers_curves, get_bond_ref, get_bday, get_history_table, DatePicker
import json
import sys
import copy
import re
import os
from pathlib import Path
from itertools import chain
from functools import partial

import blpapi
# import clarion
import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
import QuantLib as ql
from IPython.display import display
from ipydatagrid import DataGrid, TextRenderer, BarRenderer, Expr
from bqplot import LinearScale, ColorScale, OrdinalColorScale, OrdinalScale
from pandas.tseries.offsets import DateOffset, BDay
from pandas.tseries.frequencies import to_offset
# from clarion import positions

from api.gui.base import View, Tabs, Store
from api.utils import parse_offset
from api.gui.market_monitor_h import CurvesViewer, Pivot, get_issuers_curves, get_bond_ref, get_bday, get_history_table
from api.gui.max_diff_h import LowestFieldCurve
from api.gui.visual_h import Visual
from api.blpw import BlpQuery
from api.bbg import BBGField, BBGOverrides
from api.data.base import data_path, tables
from api.data.curves import curves
from api.data.utils import add_pcs, parse_tenor
from api.pricing.cds import get_isda_cds
from api.data.processing import (
    apply_function,
    add_years_to_maturity,
    add_maturity_bucket,
    add_custom_rating,
    add_rating_bucket,
    add_geo_area
)


dt_fmt = '%Y-%m-%d'
bbg_dt_fmt = '%Y%m%d'

bq = BlpQuery(timeout=50000).start()

br = pd.read_csv(data_path / 'bonds_reference.csv')
bh = pd.read_csv(data_path / 'bonds_history_all.csv', parse_dates=['date'], dayfirst=True)

store = Store()
store.data['bond_ref'] = get_bond_ref()
store.data['bond_hist'] = copy.deepcopy(bh)
# store.data['issuers_curves'] = copy.deepcopy(issuers_curves)

app = Tabs(
    {
        'curves': CurvesViewer(build=False),
        'pivot': Pivot(build=False),
        'max diff': LowestFieldCurve(build=False),
        'visual': Visual(build=False)
    },
    store=store
)
app


class PivotForward(View):
    _default_maturities = [2, 5, 10]

    def __init__(self, bond_ref=None, issuers_curves=None, **kwargs):
        super().__init__(**kwargs)
        self._bond_ref = bond_ref
        self._issuers_curves = issuers_curves

    def build(self, **kwargs):
        self.get_curves()
        super().build(**kwargs)

    def get_curves(self):
        bond_ref = self.bond_ref

        maturities = [int(i) for i in self.maturity_cb.v_model] if hasattr(self,
                                                                           'maturity_cb') else self._default_maturities
        curves = {
            cur: get_issuers_curves(
                bond_ref,
                maturities=maturities,
                currency=cur,
                thresholds=maturity_thresholds
            )
            for cur in bond_ref['currency'].drop_duplicates()
        }
        curves = {cur: df for cur, df in curves.items() if not df.empty}

    @property
    def bond_ref(self):
        if hasattr(self, 'date_pk'):
            date = self.date_pk.date
        else:
            date = pd.Timestamp.today().floor('d') - pd.tseries.offsets.YearBegin()
        bond_ref = get_bond_ref(date=date)
        bond_ref = bond_ref.loc[~bond_ref['security'].isin(bond_ref['bmk_bond'])]

    @property
    def bond_hist(self):
        return self.store.data['bond_hist'] if self._bond_hist is None else self._bond_hist

    @property
    def issuers_curves(self):
        return self.get_curves()

    def parse_ta(self):
        return pd.read_csv(StringIO(self.sub_ta.v_model), header=None, skipinitialspace=True).set_axis(
            ['currency', 'ticker', 'maturity_label', 'security'], axis=1)

    def make_widgets(self):
        curr_sel = v.Autocomplete(
            v_model='USD',
            items=
            ,
            label='currency',
            dense=True,
            outlined=True
        )

        maturity_cb = v.Combobox(
            v_model=self._default_maturities,
            items=None,
            multiple=True,
            small_chips=True,
            deletable_chips=True,
            outlined=True,
            dense=True,
            clearable=True,
            label="maturities"
        )

        build_curve_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-vector-curve'])]
        )

        date_pk = DatePicker(
            value=pd.Timestamp.today(),
            label='date',
            outlined=True
        )

        self.curr_sel = curr_sel
        self.maturity_cb = maturity_cb
        self.build_curve_btn = build_curve_btn
        self.date_pk = date_pk

        self.out = w.Output()

    def make_view(self):
        curr_sel = self.curr_sel
        maturity_cb = self.maturity_cb
        build_curve_btn = self.build_curve_btn
        date_pk = self.date_pk

        self.param_box = v.Container(
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=2,
                            children=[date_pk.view],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[curr_sel],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=5,
                            children=[maturity_cb],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1.0,
                            children=[build_curve_btn],
                            class_="my-0 py-0"
                        ),
                    ]
                ),
            ]
        )

        self.view = w.VBox(
            [
                self.param_box,
                self.out
            ]
        )

    def link(self):
        curr_sel = self.curr_sel
        build_curve_btn = self.build_curve_btn
        out = self.out

        build_curve_btn.on_event(
            'click',
            partial(
                onclick_rebuild_curves,
                self=self
            )
        )
        super().link()