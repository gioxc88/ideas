import json
import sys
import copy
import re
import os
from pathlib import Path
from itertools import chain
from functools import partial

import blpapi
# import clarion
import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
import QuantLib as ql
from IPython.display import display
from ipydatagrid import DataGrid, TextRenderer, BarRenderer, Expr
from bqplot import LinearScale, ColorScale, OrdinalColorScale, OrdinalScale
from pandas.tseries.offsets import DateOffset, BDay
from pandas.tseries.frequencies import to_offset
# from clarion import positions

from api.gui.base import View, Tabs, Store
from api.utils import parse_offset
from api.gui.market_monitor_h import CurvesViewer, Pivot, get_issuers_curves, get_bond_ref, get_bday, get_history_table
from api.gui.max_diff_h import LowestFieldCurve
from api.gui.visual_h import Visual
from api.gui.fwd_pair_h import Forward
from api.gui.fwd_pivot_h import PivotForward
from api.blpw import BlpQuery
from api.bbg import BBGField, BBGOverrides
from api.data.base import data_path, tables
from api.data.curves import curves
from api.data.utils import add_pcs, parse_tenor
from api.pricing.cds import get_isda_cds
from api.data.processing import (
    apply_function,
    add_years_to_maturity,
    add_maturity_bucket,
    add_custom_rating,
    add_rating_bucket,
    add_geo_area
)


dt_fmt = '%Y-%m-%d'
bbg_dt_fmt = '%Y%m%d'
bq = BlpQuery(timeout=50000).start()

br = pd.read_csv(data_path / 'bonds_reference.csv')
bh = pd.read_csv(data_path / 'bonds_history_all.csv', parse_dates=['date'], dayfirst=True)

store = Store()
store.data['bond_ref'] = get_bond_ref()
store.data['bond_hist'] = copy.deepcopy(bh)
# store.data['issuers_curves'] = copy.deepcopy(issuers_curves)

app = Tabs(
    {
        'curves': CurvesViewer(build=False),
        'pivot': Pivot(build=False),
        'max diff': LowestFieldCurve(build=False),
        'visual': Visual(build=False),
        'fwd pair': Forward(build=False),
        'fwd pivot': PivotForward(build=False)
    },
    store=store
)


self = app['fwd pair']
self.start_date_pk.tf.v_model = '2018-01-01'
self.end_date_pk.tf.v_model = '2022-09-19'
self.name1_ac.v_model = 'COLOM 3 7/8 04/25/27'
self.name2_ac.v_model = 'COLOM 5 06/15/45'
self.rr_tf.v_model = 0.25
self.window_tf.v_model = 20

self.table_btn.fire_event('click', None)
data = self.fwd_df