import json
import sys
import copy
import re
import os
from pathlib import Path
from itertools import chain
from functools import partial

import blpapi
# import clarion
import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
import QuantLib as ql
from IPython.display import display
from ipydatagrid import DataGrid, TextRenderer, BarRenderer, Expr
from bqplot import LinearScale, ColorScale, OrdinalColorScale, OrdinalScale
from pandas.tseries.offsets import DateOffset, BDay
from pandas.tseries.frequencies import to_offset
# from clarion import positions

from api.gui.base import View, Tabs, Store
from api.utils import parse_offset
from api.gui.market_monitor_h import CurvesViewer, Pivot, get_issuers_curves, get_bond_ref, get_bday, get_history_table
from api.gui.max_diff_h import LowestFieldCurve
from api.gui.visual_h import Visual
from api.gui.fwd_pair_h import Forward
from api.gui.fwd_pivot_h import PivotForward
from api.blpw import BlpQuery
from api.bbg import BBGField, BBGOverrides
from api.data.base import data_path, tables
from api.data.curves import curves
from api.data.utils import add_pcs, parse_tenor
from api.pricing.cds import get_isda_cds
from api.data.processing import (
    apply_function,
    add_years_to_maturity,
    add_maturity_bucket,
    add_custom_rating,
    add_rating_bucket,
    add_geo_area
)


dt_fmt = '%Y-%m-%d'
bbg_dt_fmt = '%Y%m%d'

bq = BlpQuery(timeout=50000).start()

br = tables.bonds_reference
bh = pd.read_csv(data_path / 'bonds_history_all.csv', parse_dates=['date'], dayfirst=True)

regs = bq.bdp(
    [*br['security']],
    ['IS_REG_S'],
)

br = br.merge(regs, on='security', how='left')
brn = br.loc[~br['security'].isin(br['bmk_bond'].drop_duplicates())]


gov_securities = bq.bsrch('FI:akash')
non_gov_securities = bq.bsrch('FI:akash2')
all_securities = [*gov_securities, *non_gov_securities]
all_data = bq.bdp(
    [*all_securities],
    ['PARSEKYABLE_DES', 'SECURITY_DES', 'IS_REG_S'],
).sort_values('SECURITY_DES')


all_data['PARSEKYABLE_DES'] = all_data['PARSEKYABLE_DES'].str.replace('[\s]+', ' ', regex=True)
(all_data['PARSEKYABLE_DES'] == all_data['security']).value_counts()
to_add = all_data.loc[~all_data['SECURITY_DES'].isin(br['name'])]
to_add = to_add.loc[~to_add['security'].isin(br['security'])]






all_data.sort_values('SECURITY_DES').to_clipboard()

all_securities.loc[~all_securities.isin(br['security'])]

to_add = all_data.loc[~all_data['SECURITY_DES'].isin(br['name'])]


to_add = all_data.loc[~all_data['security'].isin(br['security'])]


all_securities.loc[~all_securities.isin(br['security'])]
brn.query('bics_sector == "Government"').loc[~brn['name'].isin(all_data['SECURITY_DES'])].to_clipboard()