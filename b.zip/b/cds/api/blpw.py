import datetime
import json
from numbers import Number
from typing import Optional, Generator, Dict, Any, Union, Iterable, Sequence, List

import blpapi
import numpy as np
import pandas as pd
from IPython.display import display
from blp.blp import (
    BlpQuery as BQ,
    BlpParser,
    create_query,
    _EVENT_DICT,
    # message_to_dict,
    _get_time_received,
    datetime_converter,
    logger,
    create_reference_query
)


from .utils import get_securities, unparse_results_securities

_RESPONSE_TYPES = [blpapi.Event.RESPONSE, blpapi.Event.PARTIAL_RESPONSE]


def message_to_dict(msg: blpapi.Message) -> Dict:
    """Convert a blpapi.Message to a dictionary representation.

    Args:
        msg: A blpapi.Message

    Returns: A dictionary with relevant message metadata and data

    """
    return {
        "fragmentType": msg.fragmentType() if hasattr(msg, "fragmentType") else None,
        "correlationIds": [cid.value() for cid in msg.correlationIds()],
        "messageType": f"{msg.messageType()}",
        "timeReceived": _get_time_received(msg),
        "element": element_to_dict(msg.asElement()),
    }


def element_to_value(elem: blpapi.Element) -> Union[pd.Timestamp, str, Number, None]:
    """Convert a blpapi.Element to its value defined in its datatype with some possible coercisions.

    datetime.datetime -> pandas.Timestamp
    datetime.date -> pandas.Timestamp
    blp.name.Name -> str
    null value -> None
    ValueError Exception -> None

    Args:
        elem: Element to convert

    Returns: A value

    """
    if elem.isNull():
        return None
    else:
        try:
            value = elem.getValue()
            if isinstance(value, blpapi.name.Name):
                return str(value)
            if isinstance(value, datetime.datetime) or isinstance(value, datetime.date):
                return datetime_converter(value)

            return value
        except ValueError:
            return None


def _element_to_dict(elem: Union[str, blpapi.Element]) -> Any:
    if isinstance(elem, str):
        return elem
    dtype = elem.datatype()
    if elem.isArray():
        return [_element_to_dict(v) for v in elem.values()]
    elif dtype == blpapi.DataType.CHOICE:
        return {f"{elem.name()}": _element_to_dict(elem.getChoice())}
    elif dtype == blpapi.DataType.SEQUENCE:
        return {f"{elem.name()}": {f"{e.name()}": _element_to_dict(e) for e in elem.elements()}}
    else:
        return element_to_value(elem)


def element_to_dict(elem: blpapi.Element) -> Dict:
    """Convert a blpapi.Element to an equivalent dictionary representation.

    Args:
        elem: A blpapi.Element

    Returns: A dictionary representation of blpapi.Element

    """
    return _element_to_dict(elem)


# class BlpParser2(BlpParser):
#     @staticmethod
#     def _validate_response_type(response, _):
#         rtype = list(response["message"]["element"].keys())[0]
#         known_responses = (
#             "ReferenceDataResponse",
#             "HistoricalDataResponse",
#             "IntradayBarResponse",
#             "IntradayTickResponse",
#             "fieldResponse",
#             "InstrumentListResponse",
#             "GetFillsResponse",
#             "GridResponse"
#         )
#         if rtype not in known_responses:
#             raise TypeError(f"Unknown {rtype!r}, must be in {known_responses}")
#         return response
#
#     @staticmethod
#     def _process_field_exception(response, _):
#         rtype = list(response["message"]["element"].keys())[0]
#         response_data = response["message"]["element"][rtype]
#         if rtype in (
#                 "IntradayBarResponse",
#                 "IntradayTickResponse",
#                 "fieldResponse",
#                 "InstrumentListResponse",
#                 "GetFillsResponse",
#                 "GridResponse"
#         ):
#             return response
#         if rtype == "HistoricalDataResponse":
#             response_data = [response_data]
#         for sec_data in response_data:
#             field_exceptions = sec_data["securityData"]["fieldExceptions"]
#             for fe in field_exceptions:
#                 fe = fe["fieldExceptions"]
#                 einfo = fe["errorInfo"]["errorInfo"]
#                 if einfo["category"] == "BAD_FLD" and einfo["subcategory"] == "NOT_APPLICABLE_TO_REF_DATA":
#                     field = fe["fieldId"]
#                     sec_data["securityData"]["fieldData"]["fieldData"][field] = None
#                 else:
#                     raise TypeError(f"Response for {sec_data['securityData']['security']} contains fieldException {fe}")
#         return response
#
#     @staticmethod
#     def _validate_security_error(response, _):
#         rtype = list(response["message"]["element"].keys())[0]
#         response_data = response["message"]["element"][rtype]
#         if rtype in (
#                 "IntradayBarResponse",
#                 "IntradayTickResponse",
#                 "fieldResponse",
#                 "InstrumentListResponse",
#                 "GetFillsResponse",
#                 "GridResponse",
#         ):
#             return response
#         if rtype == "HistoricalDataResponse":
#             response_data = [response_data]
#         for sec_data in response_data:
#             data = sec_data["securityData"]
#             if "securityError" in data:
#                 raise TypeError(f"Response for {data['security']!r} contains securityError {data['securityError']}")
#         return response
#
#     def __call__(self, response, request_data):
#         """A default parser to parse dictionary representation of response.
#
#         Parses data response to a generator of dictionaries or raises a TypeError if the response type is unknown.
#         There is support for ReferenceDataResponse, HistoricalDataResponse, IntradayBarResponse, IntradayTickResponse,
#         fieldResponse, InstrumentListResponse and GetFillsResponse. Parsed dictionaries have the following forms:
#
#         .. code-block:: text
#
#             1. ReferenceDataResponse
#                 Schema: {'security': <str>, 'fields': <list of str>, 'data': <dict of field:value>}
#                 Examples:
#                     {'security': 'SPY US Equity', 'fields': ['NAME'], 'data': {'NAME': 'SPDR S&P 500 ETF TRUST'}}
#                     {
#                         'security': 'C 1 Comdty',
#                         'fields': ['FUT_CHAIN'],
#                         'data': {'FUT_CHAIN': [
#                             {'Security Description': 'C H10 Comdty'},
#                             {'Security Description': 'C K10 Comdty'}
#                         ]}
#                     }
#
#             2. HistoricalDataResponse
#               Schema: {'security': <str>, 'fields': <list of str>, 'data': <list of dict of field:value>}
#               Examples:
#                   {
#                     'security': 'SPY US Equity',
#                     'fields': ['PX_LAST'],
#                     'data': [
#                       {'date': pandas.Timestamp(2018, 1, 2), 'PX_LAST': 268.77},
#                       {'date': pandas.Timestamp(2018, 1, 3), 'PX_LAST': 270.47}
#                     ]
#                   }
#
#             3. IntradayBarResponse
#               Schema: {'security': <str>, 'events': [<str>],
#                        'data': <list of {'time': <pandas.Timestamp>, 'open': <float>, 'high': <float>, 'low': <float>,
#                                          'close': <float>, 'volume': <int>, 'numEvents': <int>, 'value': <float>}}
#                       }
#               Examples:
#                   {
#                     'security': 'CL1 Comdty',
#                     'data': [{'time': pandas.Timestamp('2019-04-24 08:00:00'), 'open': 65.85, 'high': 65.89,
#                               'low': 65.85, 'close': 65.86, 'volume': 565, 'numEvents': 209, 'value': 37215.16}],
#                     'events': ['TRADE']
#                   }
#
#             4. IntradayTickResponse
#               Schema: {'security': <str>, 'events': <list of str>,
#                        'data': <list of  {'time': <pandas.Timestamp>, 'type': <str>, 'value': <float>, 'size': <int>}>}
#               Examples:
#                   {
#                      'security': 'CL1 Comdty',
#                      'data': [
#                        {'time': pandas.Timestamp('2019-04-24 08:00:00'), 'type': 'BID', 'value': 65.85, 'size': 4},
#                        {'time': pandas.Timestamp('2019-04-24 08:00:00'), 'type': 'BID', 'value': 65.85, 'size': 41},
#                        {'time': pandas.Timestamp('2019-04-24 08:00:00'), 'type': 'ASK', 'value': 65.86, 'size': 50},
#                      ],
#                      'events': ['BID', 'ASK']
#                   }
#
#             5. fieldResponse
#               Schema: {'id': <list of str>, data: {<str>: {field: value}}}
#               Examples:
#                   {
#                     'id': ['PX_LAST', 'NAME'],
#                     'data': {
#                       'DS002': {
#                         'mnemonic': 'NAME',
#                         'description': 'Name',
#                         'datatype': 'String',
#                         'categoryName': [],
#                         'property': [],
#                         'overrides': [],
#                         'ftype': 'Character'
#                       },
#                      'PR005': {
#                        'mnemonic': 'PX_LAST',
#                        'description': 'Last Price',
#                        'datatype': 'Double',
#                        'categoryName': [],
#                        'property': [],
#                        'overrides': ['PX628', 'DY628',...]
#                        'ftype': 'Price'
#                       }
#                     }
#                   }
#
#             6. InstrumentListResponse
#             Schema: {'security': <str>, 'description': <str>}
#             Examples:
#                 {
#                    'security': 'T<govt>,
#                    'description': 'United States Treasury Note/Bond (Multiple Matches)'
#                 }
#
#             7. GetFillsResponse
#             Schema: {'Fills': <dict>}
#             Examples:
#                 {
#                     'fills': [
#                         {'Ticker': 'GCZ9', 'Exchange': 'CMX', 'Type': 'MKT', ...},
#                         {'Ticker': 'SIZ9', 'Exchange': 'CMX', 'Type': 'LMT', ...}
#                     ]
#                 }
#
#         Args:
#             response (dict): Representation of a blpapi.Message
#             request_data (dict): A dictionary representing a blpapi.Request
#
#         Returns: A generator of responses parsed to dictionaries
#
#         """
#         for processor in self._processor_steps:
#             response = processor(response, request_data)
#
#         rtype = list(response["message"]["element"].keys())[0]
#         if rtype == "ReferenceDataResponse":
#             sec_data_parser = self._parse_reference_security_data
#         elif rtype == "HistoricalDataResponse":
#             sec_data_parser = self._parse_historical_security_data
#         elif rtype == "IntradayBarResponse":
#             sec_data_parser = self._parse_bar_security_data
#         elif rtype == "IntradayTickResponse":
#             sec_data_parser = self._parse_tick_security_data
#         elif rtype == "fieldResponse":
#             sec_data_parser = self._parse_field_info_data
#         elif rtype == "InstrumentListResponse":
#             sec_data_parser = self._parse_instrument_info_data
#         elif rtype == "GetFillsResponse":
#             sec_data_parser = self._parse_fills_data
#         elif rtype == "GridResponse":
#             sec_data_parser = self._test
#         else:
#             known_responses = (
#                 "ReferenceDataResponse",
#                 "HistoricalDataResponse",
#                 "IntradayBarResponse",
#                 "IntradayTickResponse",
#                 "fieldResponse",
#                 "InstrumentListResponse",
#                 "GetFillsResponse",
#                 "GridResponse"
#             )
#             raise TypeError(f"Unknown {rtype!r}, must be in {known_responses}")
#
#         return sec_data_parser(response, request_data)
#
#     def _test(self, response, request_data):
#         return response


def get_bbg_time(date):
    return f"{date:%Y-%m-%d}T{date:%H:%M:%S}"


dt_fmt = '%Y-%m-%d'
bbg_dt_fmt = '%Y%m%d'
bbg_options = {
    'calendarCodeOverride': '5D',
    "nonTradingDayFillOption": "ALL_CALENDAR_DAYS",
    "nonTradingDayFillMethod": "PREVIOUS_VALUE"
}


class BlpQuery(BQ):
    _SERVICES = {
        **BQ._SERVICES,
        'ExcelGetGridRequest': '//blp/exrsvc'
    }

    # def __init__(self, *args, **kwargs):
    #     try:
    #         args = [*args]
    #         parser = args.pop(3)
    #     except IndexError:
    #         parser = BlpParser2()
    #     except Exception as e:
    #         print(e)
    #
    #     kwargs.setdefault('parser', parser)
    #     super().__init__(*args, **kwargs)

    def bdp(
            self,
            securities: Sequence[str],
            fields: List[str],
            overrides: Optional[Sequence] = None,
            options: Optional[Dict] = None,
            security_type: str = None,
            pcs=None,
            sep=None,
    ) -> pd.DataFrame:

        securities = get_securities(securities, pcs=pcs, sep=sep, id_type=security_type)
        if isinstance(fields, list):
            flds = fields
            maps = None
        elif isinstance(fields, dict):
            flds = [*fields]
            maps = fields
        else:
            raise ValueError(f'fields can only be list or dict but received {type(fields)}')

        df = super().bdp(
            securities=securities,
            fields=flds,
            overrides=overrides,
            options=options,
        )

        df = df.set_index('security').loc[securities, :].reset_index().drop_duplicates()
        df = unparse_results_securities(df, pcs=pcs, sep=sep, id_type=security_type)
        return df.rename(maps, axis=1) if maps else df

    def bdh(
        self,
        securities: Sequence[str],
        fields: List[str],
        start_date: str,
        end_date: str,
        overrides: Optional[Sequence] = None,
        options: Optional[Dict] = None,
        pcs=None,
        sep=None
    ) -> pd.DataFrame:

        securities = get_securities(securities, pcs=pcs, sep=sep)

        if isinstance(fields, list):
            flds = fields
            maps = None
        elif isinstance(fields, dict):
            flds = [*fields]
            maps = fields
        else:
            raise ValueError(f'fields can only be list or dict but received {type(fields)}')

        if options is None:
            options = bbg_options

        start_date = f"{pd.to_datetime(start_date):{bbg_dt_fmt}}"
        end_date = f"{pd.to_datetime(end_date):{bbg_dt_fmt}}"

        df = super().bdh(
            securities=securities,
            fields=flds,
            start_date=start_date,
            end_date=end_date,
            overrides=overrides,
            options=options
        )

        # usec = df['security'].unique()
        # df = df.set_index(['date', 'security']).loc[
        #      (slice(None), [sec for sec in securities if sec in usec]),
        #      :
        #      ].reset_index()
        # df = df.set_index('security').loc[securities, :].reset_index()
        df = unparse_results_securities(df, pcs=pcs, sep=sep)
        return df.rename(maps, axis=1) if maps else df

    def get_response(self, data_queue: blpapi.EventQueue, timeout: Optional[int] = None) -> Generator:
        """Yield dictionary representation of blpapi.Messages from a blpapi.EventQueue.

        Args:
            data_queue: Queue which contains response
            timeout: Milliseconds to wait for service before the blpapi.EventQueue returns a blpapi.Event.TIMEOUT

        Returns: A generator of messages translated into a dictionary representation

        """
        if timeout is None:
            timeout = self.timeout
        while True:
            event = data_queue.nextEvent(timeout=timeout)
            event_type = event.eventType()
            event_type_name = _EVENT_DICT[event_type]
            if event_type == blpapi.Event.TIMEOUT:
                raise ConnectionError(f"Unexpected blpapi.Event.TIMEOUT received by {self!r}")
            for n, msg in enumerate(event):
                logger.debug(f"Message {n} in {event_type_name}:{msg}")
                response = {
                    "eventType": event_type,
                    "eventTypeName": event_type_name,
                    "messageNumber": n,
                    "message": message_to_dict(msg),
                }
                yield response
            if event_type == blpapi.Event.RESPONSE:
                return

    def bsrch(self, domain: str) -> pd.Series:
        query = create_query('ExcelGetGridRequest', {'Domain': domain})
        def parse(data, request_data):
            return [
                e['DataRecords']['DataFields'][0]['DataFields']
                for e in data['message']['element']['GridResponse']['DataRecords']
            ]

        return pd.Series(self.query(query, parse=parse, collector=list))

    def bdsm(
        self,
            securities: Sequence[str],
            field: str,
            overrides: Optional[Sequence] = None,
            options: Optional[Dict] = None
    ) -> pd.DataFrame:
        query = create_reference_query(securities, field, overrides, options)
        return self.query(query, self.parser, self.collect_many_to_bds)

    def collect_to_bds(self, responses: Iterable) -> pd.DataFrame:
        """Collector for bds()."""
        rows = []
        field = None
        for response in responses:
            keys = list(response["data"].keys())
            if len(keys) > 1:
                raise ValueError(f"responses must have only one field, received {keys}")
            if field is not None and field != keys[0]:
                raise ValueError(f"responses contain different fields, {field} and {keys[0]}")
            field = keys[0]
            data = response["data"][field]
            if data is None:
                data = []
            try:
                rows.extend(data)
            except TypeError:
                raise TypeError(f"response data must be bulk reference data, received {response['data']}")
        df = pd.DataFrame(rows)
        return self.cast_columns(df, df.columns)

    def collect_many_to_bds(self, responses) -> pd.DataFrame:
        """Collector to nested dictionary of DataFrames.

        Top level keys are securities, next level keys are fields and values are DataFrame in bds() form

        """
        res: Dict = {}
        for response in responses:
            security = response["security"]
            sec_dict = res.get(security, {})
            for field in response["data"]:
                data = response["data"][field]
                if data is None:
                    data = []
                rows = sec_dict.get(field, [])
                rows.extend(data)
                sec_dict[field] = rows
            res[security] = sec_dict
        for s in res:
            for f in res[s]:
                # what does res[s][f] look like? can it be passed to to_series directly?
                df = pd.DataFrame(res[s][f])
                res[s][f] = self.cast_columns(df, df.columns)

        try:
            d = {(security, field): df for security, fields in res.items() for field, df in fields.items()}

            res = pd.concat(d) \
                    .reset_index(level=1) \
                    .pivot(columns='level_1') \
                    .swaplevel(0, axis=1) \
                    .rename_axis(('security', None)) \
                    .rename_axis(('field', None), axis=1)
        except ValueError:
            return pd.DataFrame()
        return res

    def bdph(
            self,
            securities,
            fields,
            id_override,
            id_override_field,
            overrides=None,
            id_date=False,
            **kwargs
    ):
        """
        Make iterative calls to ref() and create a long DataFrame with columns
        [date, ticker, field, value] where each date corresponds to overriding
        a historical data override field.

        Parameters
        ----------
        securities: list
            String or list of strings corresponding to tickers
        fields: list
            list of strings corresponding to FLDS
        dates: list
            list of date strings in the format YYYYmmdd
        date_field: str
            Field to iteratively override for requesting historical data,
            e.g. REFERENCE_DATE, CURVE_DATE, etc.
        ovoverridesrds: list of tuples
            List of tuples where each tuple corresponds to the override
            field and value. This should not include the date_field which will
            be iteratively overridden


        Example
        -------
        >>> import pdblp
        >>> con = pdblp.BCon()
        >>> con.start()
        >>> dates = ["20160625", "20160626"]
        >>> con.ref_hist("AUD1M CMPN Curncy", "SETTLE_DT", dates)

        """
        overrides = [] if not overrides else overrides

        self._send_hist(
            securities,
            fields,
            id_override,
            id_override_field,
            overrides,
            **kwargs
        )

        data = self._parse_ref(fields, keep_corrId=True, sent_events=len(id_override))
        data = pd.DataFrame(data, columns=['security', 'field', 'value', id_override_field])
        # data = data.set_index(id_override_field).reset_index()
        data = data.loc[:, [id_override_field, 'security', 'field', 'value']]
        data = data.pivot(index=[id_override_field, 'security'], columns='field', values='value') \
            .loc[id_override, :]\
            .reset_index()\
            .rename_axis(None, axis=1)
        if id_date:
            data[id_override_field] = pd.to_datetime(data[id_override_field])
        return data

    def _send_hist(
            self,
            securities,
            fields,
            id_override,
            id_override_field,
            overrides,
            **kwargs
    ):
        setvals = []
        request = self._create_req(
            'ReferenceDataRequest',
            securities,
            fields,
            overrides,
            setvals
        )

        overrides = request.getElement('overrides')
        if len(id_override) == 0:
            raise ValueError('dates must by non empty')
        kwargs.setdefault(id_override_field, id_override)
        ovrds_ = [overrides.appendElement() for k in kwargs]

        for values in zip(*kwargs.values()):
            for k, v, ovrd in zip(kwargs, values, ovrds_):
                ovrd.setElement('fieldId', k)
                ovrd.setElement('value', v)
                if k == id_override_field:
                    cid_ = v
            # CorrelationID used to keep track of which response coincides with
            # which request
            cid = blpapi.CorrelationId(cid_)
            logger.info('Sending Request:\n{}'.format(request))
            self.session.sendRequest(request, identity=self.identity, correlationId=cid)

    def _parse_ref(self, fields, keep_corrId=False, sent_events=1):
        data = []
        # Process received events
        for msg in self._receive_events(sent_events):
            if keep_corrId:
                corrId = msg['correlationIds']
            else:
                corrId = []
            d = msg['element']['ReferenceDataResponse']
            for security_data_dict in d:
                secData = security_data_dict['securityData']
                ticker = secData['security']
                if 'securityError' in secData:
                    raise ValueError('Unknow security {!r}'.format(ticker))
                self._check_fieldExceptions(secData['fieldExceptions'])
                fieldData = secData['fieldData']['fieldData']
                for fld in fields:
                    # avoid returning nested bbg objects, fail instead
                    # since user should use bulkref()
                    if (fld in fieldData) and isinstance(fieldData[fld], list):
                        raise ValueError('Field {!r} returns bulk reference '
                                         'data which is not supported'
                                         .format(fld))
                    # this is a slight hack but if a fieldData response
                    # does not have the element fld and this is not a bad
                    # field (which is checked above) then the assumption is
                    # that this is a not applicable field, thus set NaN
                    # see https://github.com/matthewgilbert/pdblp/issues/13
                    if fld not in fieldData:
                        datum = [ticker, fld, np.NaN]
                        datum.extend(corrId)
                        data.append(datum)
                    else:
                        val = fieldData[fld]
                        datum = [ticker, fld, val]
                        datum.extend(corrId)
                        data.append(datum)
        return data

    def _create_req(self, operation, securities, fields, overrides, setvals):
        # flush event queue in case previous call errored out
        while self.session.tryNextEvent():
            pass

        service = self._services[self._SERVICES[operation]]
        request = service.createRequest(operation)
        for sec in securities:
            request.getElement('securities').appendValue(sec)
        for f in fields:
            request.getElement('fields').appendValue(f)
        for name, val in setvals:
            request.set(name, val)

        overrides_ = request.getElement('overrides')
        for ovrd_fld, ovrd_val in overrides:
            ovrd = overrides_.appendElement()
            ovrd.setElement('fieldId', ovrd_fld)
            ovrd.setElement('value', ovrd_val)

        return request

    def _receive_events(self, sent_events=1, to_dict=True):
        while True:
            ev = self.session.nextEvent(self.timeout)
            ev_name = _EVENT_DICT[ev.eventType()]
            logger.info('Event Type: {!r}'.format(ev_name))
            if ev.eventType() in _RESPONSE_TYPES:
                for msg in ev:
                    logger.info('Message Received:\n{}'.format(msg))
                    if to_dict:
                        yield message_to_dict(msg)
                    else:
                        yield msg

            # deals with multi sends using CorrelationIds
            if ev.eventType() == blpapi.Event.RESPONSE:
                sent_events -= 1
                if sent_events == 0:
                    break
            # guard against unknown returned events
            elif ev.eventType() not in _RESPONSE_TYPES:
                logger.warning('Unexpected Event Type: {!r}'.format(ev_name))
                for msg in ev:
                    logger.warning('Message Received:\n{}'.format(msg))
                if ev.eventType() == blpapi.Event.TIMEOUT:
                    raise RuntimeError('Timeout, increase BCon.timeout attribute')
                else:
                    raise RuntimeError('Unexpected Event Type: {!r}'.format(ev_name))

    @staticmethod
    def _check_fieldExceptions(field_exceptions):
        # iterate over an array of field_exceptions and check for a
        # INVALID_FIELD error
        for fe_dict in field_exceptions:
            fe = fe_dict['fieldExceptions']
            if fe['errorInfo']['errorInfo']['subcategory'] == 'INVALID_FIELD':
                raise ValueError('{}: INVALID_FIELD'.format(fe['fieldId']))

    def bdpm(self, args, common_overrides=None):
        '''

        Args:
            args: it is a list of dictionaries like
            [
                {
                    'security':
                    'fields'
                    'overrides'
                }
            ]

        Returns:

        '''

        while self.session.tryNextEvent():
            pass
        operation = 'ReferenceDataRequest'

        sent_events = 0
        service = self._services[self._SERVICES[operation]]

        secs = []
        for j, arg in enumerate(args):
            security = arg['security']
            secs.append(security)
            fields = arg['fields']

            request = service.createRequest(operation)
            request.getElement('securities').appendValue(security)
            for f in fields:
                request.getElement('fields').appendValue(f)

            kwargs = arg['overrides']
            overrides = request.getElement('overrides')
            ovrds_ = [overrides.appendElement() for k in kwargs]
            corr_id_key = arg.get('correlation_id_key', [*kwargs][0])

            if common_overrides:
                for _key, _value in common_overrides.items():
                    ovrd = overrides.appendElement()
                    ovrd.setElement('fieldId', _key)
                    ovrd.setElement('value', _value)

            for j, values in enumerate(zip(*kwargs.values())):
                for h, (k, v, ovrd) in enumerate(zip(kwargs, values, ovrds_)):
                    label = None
                    if isinstance(v, dict):
                        label = [*v.keys()][0]
                        v = [*v.values()][0]

                    ovrd.setElement('fieldId', k)
                    ovrd.setElement('value', v)
                    if k == corr_id_key:
                        cid_ = f"{k}__{v}"
                    if label:
                        cid_ = f"{cid_}__{label}"
                # CorrelationID used to keep track of which response coincides with
                # which request
                cid = blpapi.CorrelationId(cid_)
                logger.info('Sending Request:\n{}'.format(request))
                self.session.sendRequest(request, identity=self.identity, correlationId=cid)
                sent_events += 1

        msgs = [msg for msg in self._receive_events(sent_events)]
        data = []
        for msg in msgs:
            id_elems = msg['correlationIds'][0].split('__')
            sec_data = msg['element']['ReferenceDataResponse'][0]['securityData']

            labels = {'label': id_elems[2]} if len(id_elems) == 3 else {}
            d = {
                'security': sec_data['security'],
                **labels,
                id_elems[0]: id_elems[1],
                **sec_data['fieldData']['fieldData']
            }
            data.append(d)

        data = pd.DataFrame(data).set_index('security').loc[secs, :].reset_index()
        return data

    def bdpc(self, request_params):
        '''
        both securities and override per field changes
        Args:
            request_params:
        Returns:

        '''
        while self.session.tryNextEvent():
            pass
        operation = 'ReferenceDataRequest'

        sent_events = 0
        service = self._services[self._SERVICES[operation]]

        bbg_securities = request_params.securities
        bbg_fields = request_params.fields
        secs = []
        use_cid = False
        for j, sec in enumerate(bbg_securities):
            security = sec.id
            secs.append(security)
            for field in bbg_fields:
                if sec.overrides:
                    use_cid = True
                    for sec_overrides in sec.overrides:
                        request = service.createRequest(operation)
                        request.getElement('securities').appendValue(security)
                        bbg_overrides = request.getElement('overrides')
                        request.getElement('fields').appendValue(field.field)

                        for k, v in sec_overrides.kwargs.items():
                            ovrd = bbg_overrides.appendElement()
                            ovrd.setElement('fieldId', k)
                            ovrd.setElement('value', v)

                        cid_kwargs = {**sec_overrides.kwargs}
                        if sec_overrides.label:
                            cid_kwargs['security_label'] = sec_overrides.label

                        if field.overrides:

                            for k, v in field.overrides.kwargs.items():
                                ovrd = bbg_overrides.appendElement()
                                ovrd.setElement('fieldId', k)
                                ovrd.setElement('value', v)

                            cid_kwargs.update(field.overrides.kwargs)
                            if field.overrides.label:
                                cid_kwargs['field_label'] = field.overrides.label

                        cid = blpapi.CorrelationId(json.dumps(cid_kwargs))
                        # logger.info('Sending Request:\n{}'.format(request))
                        self.session.sendRequest(request, identity=self.identity, correlationId=cid)
                        sent_events += 1
                else:
                    request = service.createRequest(operation)
                    request.getElement('securities').appendValue(security)
                    bbg_overrides = request.getElement('overrides')
                    request.getElement('fields').appendValue(field.field)

                    if field.overrides:
                        use_cid = True
                        for k, v in field.overrides.kwargs.items():
                            ovrd = bbg_overrides.appendElement()
                            ovrd.setElement('fieldId', k)
                            ovrd.setElement('value', v)

                        cid_kwargs = {**field.overrides.kwargs}
                        if field.overrides.label:
                            cid_kwargs['field_label'] = field.overrides.label

                        cid = blpapi.CorrelationId(cid_kwargs)
                    else:
                        cid = blpapi.CorrelationId()
                    # logger.info('Sending Request:\n{}'.format(request))
                    self.session.sendRequest(request, identity=self.identity, correlationId=cid)
                    sent_events += 1

        data = []
        msgs = [msg for msg in self._receive_events(sent_events)]
        for msg in msgs:
            sec_data = msg['element']['ReferenceDataResponse'][0]['securityData']
            d = {
                'security': sec_data['security'],
                **sec_data['fieldData']['fieldData']
            }

            drop_duplicates = False
            if use_cid:
                grouper = json.loads(msg['correlationIds'][0])
                d.update(grouper)
                drop_duplicates = True

            data.append(d)

        data = pd.DataFrame(data).set_index('security').loc[secs, :].reset_index()

        if drop_duplicates:
            data = data.groupby([*grouper.keys()], sort=False, as_index=False).apply(
                lambda g: g.ffill().bfill().drop_duplicates()).reset_index(drop=True)
        return data

    def bdpx(self, request_params):
        '''
        fields are the same (no overrides) and each security has a different override
        Args:
            request_params:

        Returns:

        '''
        while self.session.tryNextEvent():
            pass
        operation = 'ReferenceDataRequest'

        sent_events = 0
        service = self._services[self._SERVICES[operation]]

        bbg_securities = request_params.securities
        bbg_fields = request_params.fields
        secs = []
        for j, sec in enumerate(bbg_securities):
            security = sec.id
            secs.append(security)
            for sec_overrides in sec.overrides:
                request = service.createRequest(operation)
                request.getElement('securities').appendValue(security)
                bbg_overrides = request.getElement('overrides')
                for field in bbg_fields:
                    request.getElement('fields').appendValue(field.field)

                for k, v in sec_overrides.kwargs.items():
                    ovrd = bbg_overrides.appendElement()
                    ovrd.setElement('fieldId', k)
                    ovrd.setElement('value', v)

                cid_kwargs = {**sec_overrides.kwargs}
                if sec_overrides.label:
                    cid_kwargs['security_label'] = sec_overrides.label

                cid = blpapi.CorrelationId(json.dumps(cid_kwargs))
                # logger.info('Sending Request:\n{}'.format(request))
                self.session.sendRequest(request, identity=self.identity, correlationId=cid)
                sent_events += 1

        data = []
        msgs = [msg for msg in self._receive_events(sent_events)]
        for msg in msgs:
            sec_data = msg['element']['ReferenceDataResponse'][0]['securityData']
            d = {
                'security': sec_data['security'],
                **sec_data['fieldData']['fieldData']
            }

            grouper = json.loads(msg['correlationIds'][0])
            d.update(grouper)

            data.append(d)

        data = pd.DataFrame(data).set_index('security').loc[secs, :].drop_duplicates().reset_index()
        return data

    def bdpy(self, securities: list, bbg_fields):
        '''
        Same securities for all fields, different overrides for same field
        Args:
            securities:
            fields:

        Returns:
        '''

        '''
        same securities, 
        Args:
            request_params:
        Returns:

        '''
        while self.session.tryNextEvent():
            pass
        operation = 'ReferenceDataRequest'

        service = self._services[self._SERVICES[operation]]

        name_mapping = {}
        for field in bbg_fields:
            request = service.createRequest(operation)
            for sec in securities:
                request.getElement('securities').appendValue(sec)
            request.getElement('fields').appendValue(field.field)
            if field.overrides:
                for k, v in field.overrides.kwargs.items():
                    bbg_overrides = request.getElement('overrides')
                    ovrd = bbg_overrides.appendElement()
                    ovrd.setElement('fieldId', k)
                    ovrd.setElement('value', v)
                cid_kwargs = {**field.overrides.kwargs}
                if field.overrides.label:
                    cid_kwargs['field_label'] = field.overrides.label
                _cid = json.dumps(cid_kwargs)
                cid = blpapi.CorrelationId(_cid)
                name_mapping[_cid] = field.name
            # logger.info('Sending Request:\n{}'.format(request))
            else:
                name_mapping[field.name] = field.name
                cid = blpapi.CorrelationId(field.name)
                # logger.info('Sending Request:\n{}'.format(request))
            self.session.sendRequest(request, identity=self.identity, correlationId=cid)

        data = []
        msgs = [msg for msg in self._receive_events(len(bbg_fields))]
        for msg in msgs:

            sec_data = [resp['securityData'] for resp in msg['element']['ReferenceDataResponse']]
            fields_data = []
            for resp in sec_data:
                if resp['fieldData']['fieldData']:
                    fd = {name_mapping[msg['correlationIds'][0]]: [*resp['fieldData']['fieldData'].values()][0]}
                    fields_data.append({'security': resp['security'], **fd})

            data.extend(fields_data)

        res = pd.DataFrame(data) \
            .melt(id_vars='security') \
            .dropna() \
            .pivot(index='security', columns='variable') \
            .droplevel(0, axis=1) \
            .reset_index() \
            .rename_axis(None, axis=1)

        res = res.set_index('security').loc[
            pd.Series(securities).isin(res['security']).replace(False, np.nan).dropna().to_list(),
            [field.name for field in bbg_fields]
        ]

        return res.reset_index()
