import re

import pandas as pd
from pandas.tseries.offsets import BDay

def today():
    return pd.Timestamp.today().floor('d')


def add_pcs(securities, source, sep=None, ensure_list=True):
    sep = sep or '@'
    if isinstance(securities, str):
        securities = [securities]
    new_sec = []
    for sec in securities:
        split = sec.rsplit(' ', 1)
        if len(split) > 1:
            root, yellow_key = sec.rsplit(' ', 1)
            new_sec.append(f"{root}{sep}{source} {yellow_key}")
        else:
            new_sec.append(f"{split[0]}{sep}{source}")

    return new_sec if (len(new_sec) > 1 or ensure_list) else new_sec[0]


def make_id(securities, type=None):
    if isinstance(securities, str):
        securities = [securities]

    res = [f'/{type}/{sec}' for sec in securities]
    if len(res) == 1:
        res = res[0]
    return res


def parse_tenor(tenor, key='tenor'):
    fn = lambda tenor: f"{tenor:.0f}Y" if tenor > 1 else f"{int(12 * tenor):.0f}M"
    if isinstance(tenor, pd.DataFrame):
        return tenor.assign(tenor=tenor[key].map(fn))
    elif isinstance(tenor, pd.Series):
        return tenor.map(fn)
    elif isinstance(tenor, str):
        return fn(tenor)
    else:
        raise TypeError(f'Only str, DataFrame od Series are allowed, got object of type {type(tenor)} instead')


def get_securities(securities, id_type=None, pcs=None, sep=None, ensure_list=True):
    id_type = id_type or ''
    if pcs:
        if id_type.lower() == 'isin':
            _sep = '@'
        else:
            _sep = ' '

        sep = sep or _sep
        securities = add_pcs(securities, source=pcs, sep=sep)

    secs = [f'/{id_type}/{sec}' for sec in securities] if id_type else securities
    if isinstance(secs, str) and ensure_list:
            secs = [secs]
    elif isinstance(secs, list) and len(secs) == 1 and not ensure_list:
        secs = secs[0]
    return secs


def unparse_securities(securities, pcs=None, sep=None, id_type=None):
    securities = pd.Series(securities)
    if pcs:
        sep = sep or ' '
        securities = securities.str.replace(f'{sep}{pcs}', '')
    if id_type:
        securities = securities.str.replace(f'/{id_type}/', '')
    return securities.to_list()


def unparse_results_securities(res, pcs=None, sep=None, id_type=None):
    if pcs or id_type:
        return res.assign(security=unparse_securities(res['security'], pcs=pcs, sep=sep, id_type=id_type))
    return res


period_mapping = {
    'd': 'days',
    'w': 'weeks',
    'm': 'months',
    'y': 'years',
    'ytd': pd.tseries.offsets.YearBegin(),
    'start of year': pd.tseries.offsets.YearBegin()
}


def parse_offset(s, b=False):
    try:
        rv = pd.to_datetime(s)
        if b:
            rv = get_bday(rv)
        return rv
    except:
        pass

    pattern = re.compile(r'(\d+)([A-Za-z]+)')
    match = pattern.match(s)
    try:
        n, period = match.groups()
    except (ValueError, AttributeError):
        period = s

    key = period_mapping[period.lower()]
    if b and key == 'days':
        return pd.tseries.offsets.BDay(int(n))

    if isinstance(key, str):
        return pd.tseries.offsets.DateOffset(**{key: int(n)})
    else:
        return key


def date_or_previous_bdate(date):
    return + BDay() - BDay()


def get_bday(date, previous=True):
    return date - BDay() + BDay() if not previous else date + BDay() - BDay()