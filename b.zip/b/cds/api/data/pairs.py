pairs = {
    "eur": {
        "AT1 vs LT2": {
            "tickers": [
                "I30904EU Index",
                "I08153EU Index"
            ],
            "op": "/"
        },
        "AT1 vs SNP": {
            "tickers": [
                "I30904EU Index",
                "IBXXEBS4 Index"
            ],
            "op": "/"
        },
        "BBB vs A": {
            "tickers": [
                "I02202EU Index",
                "I02201EU Index"
            ],
            "op": "/"
        },
        "BB vs BBB": {
            "tickers": [
                "I05446EU Index",
                "I02202EU Index"
            ],
            "op": "/"
        },
        "AT1 vs BB Corp": {
            "tickers": [
                "I30904EU Index",
                "I05446EU Index"
            ],
            "op": "/"
        },
        "Banks Sen vs Non-Fin Sen": {
            "tickers": [
                "I08154EU Index",
                "H30585EU Index"
            ],
            "op": "/"
        },
        "LT2 vs Non-Fin Sen": {
            "tickers": [
                "I08153EU Index",
                "H30585EU Index"
            ],
            "op": "/"
        },
        "SNP vs SP": {
            "tickers": [
                "IBXXEBS4 Index",
                "IBXXEBS8 Index"
            ],
            "op": "/"
        },
        "LT2 vs SNP": {
            "tickers": [
                "I08153EU Index",
                "IBXXEBS4 Index"
            ],
            "op": "/"
        },
        "IG Cash vs iTrax Main": {
            "tickers": [
                "LECPTREU Index",
                "ITRX EUR CDSI GEN 5Y Corp"
            ],
            "op": "-",
            "mult": 100
        },
        "HY Cash vs iTrax Crossover": {
            "tickers": [
                "BEHLTREU Index",
                "ITRX XOVER CDSI GEN 5Y Corp"
            ],
            "op": "-",
            "mult": 100
        },
        "Sr Fin Cash vs iTrax Sr Fin": {
            "tickers": [
                "I08154EU Index",
                "SNRFIN CDSI GEN 5Y Corp"
            ],
            "op": "-",
            "mult": 100
        },
        "Sub Fin Cash vs iTrax Sub Fin": {
            "tickers": [
                "I26793EU Index",
                "SUBFIN CDSI GEN 5Y Corp"
            ],
            "op": "-",
            "mult": 100
        },
        "iTrax Crossover vs iTrax Main": {
            "tickers": [
                "ITRX XOVER CDSI GEN 5Y Corp",
                "ITRX EUR CDSI GEN 5Y Corp"
            ],
            "op": "/"
        },
        "iTrax Sub Fin vs iTrax Sr Fin": {
            "tickers": [
                "SUBFIN CDSI GEN 5Y Corp",
                "SNRFIN CDSI GEN 5Y Corp"
            ],
            "op": "/"
        }
    },
    "usd": {
        "AT1 vs LT2": {
            "tickers": [
                "I30903US Index",
                "I26814US Index"
            ],
            "op": "/"
        },
        "BBB vs A": {
            "tickers": [
                "LCB1TRUU Index",
                "I08220US Index"
            ],
            "op": "/"
        },
        "BB vs BBB": {
            "tickers": [
                "I00182US Index",
                "LCB1TRUU Index"
            ],
            "op": "/"
        },
        "AT1 vs BB Corp": {
            "tickers": [
                "I30903US Index",
                "I00182US Index"
            ],
            "op": "/"
        },
        "IG Cash vs CDX IG": {
            "tickers": [
                "BLQCTRUU Index",
                "CDX IG CDSI GEN 5Y Corp"
            ],
            "op": "-",
            "mult": 100
        },
        "HY Cash vs CDX HY": {
            "tickers": [
                "BHYOTRUU Index",
                "CDX HY CDSI GEN 5Y SPRD Corp"
            ],
            "op": "-",
            "mult": 100
        },
        "CDX HY vs CDX IG": {
            "tickers": [
                "CDX HY CDSI GEN 5Y SPRD Corp",
                "CDX IG CDSI GEN 5Y Corp"
            ],
            "op": "-"
        }
    }
}
