from itertools import product

import pandas as pd
from ..blpw import BlpQuery
from .base import tables


def get_cds_index_members(tickers):
    rename = {
        'Member Ticker and Exchange Code': 'NAME',
        'column   1': 'wtg',
        'column   2': 'Crncy',
        'column   3': 'Rank',
        'column   4': 'ticker',
        # 'column 5',
    }

    q = BlpQuery().start()
    memb = q.bdsm(tickers, 'INDX_MEMBERS').droplevel(0, axis=1).rename(rename, axis=1).drop('column   5', axis=1)
    tks = (memb['ticker'] + ' Curncy').to_list()  # figure out if it's alway Curncy
    parent_info = q.bdp(tks, ['CDS_CORP_TKR', 'PRIMARY_EQUITY_TICKER']).set_axis(memb.index)
    return pd.concat([parent_info, memb], axis=1)


_years = [2, 5, 7, 10]
_capital_stack = ['SR', 'SUB', 'SLA']


def get_cds_generic_name(security, bq, root=True):
    '''
    This is the general function that gets the cds generic name for a given equity or bond ticker.
    E.g. for ISP IM Equity it first gets the ticker of CDS_SPREAD_TICKER_5Y that is CBCI1E5 Curncy.
    Based on this ticker it gets the SECURITY_DES that is ISPIM SPA CDS EUR SR 5Y D14. The generic name is then
    ISPIM SPA CDS.
    '''
    field = 'CDS_SPREAD_TICKER_5Y'
    cds_generic_ticker = bq.bdp(
        securities=[security],
        fields=[field]
    )
    cds_generic_ticker = cds_generic_ticker[field].squeeze() + ' Curncy'

    field = 'SECURITY_DES'
    cds_generic_name = bq.bdp(
        securities=[cds_generic_ticker],
        fields=[field]
    )
    cds_generic_name = cds_generic_name[field].squeeze()
    if root:
        return cds_generic_name.rsplit(' ', 3)[0]
    else:
        return cds_generic_name


def get_cds_tickers(
        security: str = None,
        cds_generic_name=None,
        bq=None,
        tenors=None,
        capital_stack=None,

):
    years = tenors or _years
    capital_stack = capital_stack or _capital_stack

    if security and not cds_generic_name:
        cds_generic_name = get_cds_generic_name(security, bq=bq, root=False)
    cds_generic_name = cds_generic_name.rsplit(' ', 3)[0]
    tickers = []
    for yrs, cs in product(years, capital_stack):
        cds_ticker = f"{cds_generic_name} {cs} {yrs} D14 Curncy"
        tickers.append({
            'cds_name': cds_ticker,
            'currency': cds_generic_name.split(' ')[-1],
            'years': yrs,
            'capital_stack': cs})
    return pd.DataFrame(tickers)


def add_pcs(securities, source, sep=None):
    sep = sep or '@'
    if isinstance(securities, str):
        securities = [securities]
    new_sec = []
    for sec in securities:
        split = sec.rsplit(' ', 1)
        if len(split) > 1:
            root, yellow_key = sec.rsplit(' ', 1)
            new_sec.append(f"{root}{sep}{source} {yellow_key}")
        else:
            new_sec.append(f"{split[0]}{sep}{source}")

    return new_sec if len(new_sec) > 1 else new_sec[0]


def make_id(securities, type=None):
    if isinstance(securities, str):
        securities = [securities]

    res = [f'/{type}/{sec}' for sec in securities]
    if len(res) == 1:
        res = res[0]
    return res


def parse_tenor(tenor, key='tenor'):
    fn = lambda tenor: f"{tenor:.0f}Y" if tenor > 1 else f"{int(12 * tenor):.0f}M"
    if isinstance(tenor, pd.DataFrame):
        return tenor.assign(tenor=tenor[key].map(fn))
    elif isinstance(tenor, pd.Series):
        return tenor.map(fn)
    elif isinstance(tenor, str):
        return fn(tenor)
    else:
        raise TypeError(f'Only str, DataFrame od Series are allowed, got object of type {type(tenor)} instead')


def get_securities(securities, id_type=None, pcs=None, sep=None):
    id_type = id_type or ''
    if pcs:
        if id_type.lower() == 'isin':
            _sep = '@'
        else:
            _sep = ' '

        sep = sep or _sep
        securities = add_pcs(securities, source=pcs, sep=sep)

    return [f'/{id_type}/{sec}' for sec in securities] if id_type else securities


def unparse_securities(securities, pcs, sep):
    securities = pd.Series(securities)
    if pcs:
        securities = securities.str.replace(f'{sep}{pcs}', '')
    return securities.to_list()


def unparse_results_securities(res, pcs, sep):
    return res.assign(security=unparse_securities(res['security'], pcs=pcs, sep=sep))


def make_rating_categories(df, cols=None):
    cols = ['custom_rating', 'rating_bucket']
    if 'custom_rating' in df.columns:
        df = df.assign(
            custom_rating=pd.Categorical(df['custom_rating'], ordered=True, categories=tables.rating['rating']),
        )
    if 'rating_bucket' in df.columns:
        df = df.assign(
            rating_bucket=pd.Categorical(df['rating_bucket'], ordered=True, categories=tables.rating['group'].drop_duplicates())
        )
    return df