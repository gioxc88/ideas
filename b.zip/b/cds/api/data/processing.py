import numpy as np
import pandas as pd

from .base import tables, data_path
from .fields import bond_reference_fields
from .base import years_to_maturity_col

# def add_capital_stack(res, tickers):
#     res = res.set_index('security')
#     res = pd.concat(
#         [
#             res,
#             tickers.reset_index().set_index('security').squeeze(axis=1).rename('capital_stack')
#         ],
#         axis=1,
#         sort=False
#     ).reset_index()
#     return res


def add_custom_rating(res, mode='floor'):
    watches = [
        "\*\+",
        "\*-",
        "\*S",
        "\*",
        'u',
        ' ',
        '\(EXP\)',
    ]

    not_rated = [
        'WD',
        'NR'
    ]

    rating_columns = [
        'rating_sp',
        'rating_moody',
        'rating_fitch',
        'rating_bbg',
    ]

    # replace watches
    for col in rating_columns:
        res[col] = res[col].str.replace('|'.join(watches), '', regex=True)

    # replace not rated with na
    for col in rating_columns:
        res.loc[res[col].isin(not_rated), col] = np.nan

    cat_ratings = {}
    cat_codes = {}

    for col in rating_columns[:-1]:
        cat_rtg = pd.Categorical(res[col], ordered=True, categories=tables.rating[col.rsplit('_')[1]])
        cat_ratings[col] = cat_rtg
        cat_codes[col] = cat_rtg.codes

    cat_ratings = pd.DataFrame(cat_ratings)
    cat_codes = pd.DataFrame(cat_codes).replace(-1, np.nan) + 1
    custom_codes = getattr(np, mode)(cat_codes.mean(axis=1))
    custom_rating = custom_codes.replace(tables.rating.set_index('rank')['rating'])
    res = res.assign(
        custom_rating=pd.Categorical(custom_rating, ordered=True, categories=tables.rating['rating'])
    )
    return res


def add_rating_bucket(res):
    rating_bucket = pd.merge(
        res['custom_rating'],
        tables.rating[['rating', 'group']],
        right_on='rating',
        left_on='custom_rating',
        how='left',
    )['group']

    rating_bucket = pd.Categorical(rating_bucket, ordered=True, categories=tables.rating['group'].drop_duplicates())

    return res.assign(rating_bucket=rating_bucket)


def add_geo_area(res, cols=None, more_cols=None):
    cols = cols or ['macroarea', 'area', 'region', 'subregion']
    if more_cols:
        cols = [*cols, *more_cols]

    areas = res['country'].to_frame().merge(
        tables.country[['iso', *cols]].rename(more_cols, axis=1),
        right_on='iso',
        left_on='country',
        how='left',
    ).drop(['iso', 'country'], axis=1).set_index(res.index)

    return res.assign(**areas.to_dict('series'))


def apply_function(res, fields=None):
    fields = fields or bond_reference_fields
    # assumes the fields have already been renamed
    for field in fields:
        fn = field.get('fn')
        if fn and field['name'] in res:
            res[field['name']] = fn(res[field['name']])

    return res


def get_capital_stack(payment_rank, basel_iii_designation, bail_in_bond_designation):
    short_name = None
    if basel_iii_designation == 'Additional Tier 1':
        short_name = 'at1'
    elif basel_iii_designation == 'Tier 2':
        short_name = 'lt2'
    elif payment_rank in ['Sr Non Preferred', 'Sr Preferred', 'Sr Unsecured']:
        if bail_in_bond_designation == 'Y':
            short_name = 'snp'
        else:
            short_name = 'sp'
    return short_name


def add_capital_stack(res):
    capital_stack = pd.Series(
        [get_capital_stack(pr, b3d, bbd) for index, (pr, b3d, bbd) in
         res[['payment_rank', 'basel_iii_designation', 'bail_in_bond_designation']].iterrows()],
        index=res.index
    )
    return res.assign(capital_stack=capital_stack)


def misc(res):
    return res.assign(workout_date=res['workout_date'].fillna(res['maturity']))


def post_process(res, fields=None):
    fields = fields or bond_reference_fields
    res = res.copy(deep=True)
    res = res.rename({field['field']: field['name'] for field in fields}, axis=1)
    res = apply_function(res)
    # res = add_capital_stack(res)
    res = add_custom_rating(res)
    res = add_rating_bucket(res)
    res = misc(res)
    # res = add_geo_area(res)
    res = res.dropna(subset=['ticker', 'name', 'isin'])
    return res


def add_years_to_maturity(df, date=None):
    date = date or pd.Timestamp.today()
    df = df.assign(
        years_to_workout=(df['workout_date'] - date).dt.days / 365.2425,
        years_to_maturity=(df['maturity'] - date).dt.days / 365.2425
    )
    return df


def add_maturity_bucket(df, maturity_bins=None):
    if maturity_bins:
        bins = [*maturity_bins, np.inf]
        labels = pd.Series([f"{bins[i]}{f'-{bins[i+1]}yr' if bins[i+1] != np.inf else '+yr'}" for i in range(len(bins) - 2 + 1)])
    else:
        bins = [*tables.maturity['lower_bound'], np.inf]
        labels = tables.maturity['label']
    idx = np.digitize(df[years_to_maturity_col].fillna(0), bins) - 1
    maturity_bucket = labels.iloc[idx].set_axis(df.index)
    maturity_bucket[df[years_to_maturity_col].isna()] = np.nan
    return pd.concat([df, maturity_bucket.rename('maturity_bucket')], axis=1)


def get_current_data(
        ref_data=None,
        mkt_data=None,
        active=True,
        maturity_bins=None
):

    ref_data = tables.bonds_reference if ref_data is None else ref_data
    mkt_data = tables.bonds_market if mkt_data is None else mkt_data

    data = pd.concat([ref_data, mkt_data], axis=1, join='inner')
    if active:
        data = data.loc[(data['workout_date'] > pd.Timestamp.today()), :]

    data = add_years_to_maturity(data)
    data = add_maturity_bucket(data, maturity_bins=maturity_bins)
    return data


def get_current_cds_data():
    cds_ref = pd.read_csv(data_path / 'cds_reference.csv').drop_duplicates(subset='security')
    cds_mkt = pd.read_csv(data_path / 'cds_market.csv').drop_duplicates(subset='security')

    name_mapping = {
        'security': 'cds_name',
        'last_price': 'cds_spread',
        'years': 'cds_years',
        'capital_stack': 'cds_capital_stack'
    }

    cds_data = cds_mkt.merge(cds_ref.set_index('security'), left_on='security', right_index=True, how='left') \
        .rename(name_mapping, axis=1) \
        .drop(['exists', 'ticker', 'cds_ticker_5y'], axis=1) \
        .dropna(subset='cds_spread')

    return cds_data