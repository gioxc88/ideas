from .utils import parse_tenor


bond_reference_fields = [
    {
        'field': 'TICKER',
        'name': 'ticker',
    },
    {
        'field': 'SECURITY_NAME',
        'name': 'name',
    },
    {
        'field': 'ID_ISIN',
        'name': 'isin',
    },
    {
        'field': 'CRNCY',
        'name': 'currency',
    },
    {
        'field': 'CNTRY_OF_RISK',
        'name': 'country',
    },
    {
        'field': 'BICS_LEVEL_1_SECTOR_NAME',
        'name': 'bics_sector',
    },
    {
        'field': 'BICS_LEVEL_2_INDUSTRY_GROUP_NAME',
        'name': 'bics_industry',
    },
    {
        'field': 'AMT_ISSUED',
        'name': 'amount_issued',
    },
    {
        'field': 'ISSUE_DT',
        'name': 'issue_date',
    },
    {
        'field': 'MATURITY',
        'name': 'maturity',
    },
    {
        'field': 'CALC_MATURITY',
        'name': 'calc_maturity',
    },
    {
        'field': 'WORKOUT_DT_MID',
        'name': 'workout_date',
    },
    {
        'field': 'MTY_TYP',
        'name': 'maturity_type',
    },
    {
        'field': 'CPN',
        'name': 'coupon',
    },
    {
        'field': 'CPN_TYP',
        'name': 'coupon_type',
    },
    {
        'field': 'COUPON_FREQUENCY_DESCRIPTION',
        'name': 'coupon_freq',
    },
    {
        'field': 'DAY_CNT_DES',
        'name': 'day_count',
    },
    {
        'field': 'RTG_SP',
        'name': 'rating_sp',
    },
    {
        'field': 'RTG_MOODY',
        'name': 'rating_moody',
    },
    {
        'field': 'RTG_FITCH',
        'name': 'rating_fitch',
    },
    {
        'field': 'BB_COMPOSITE',
        'name': 'rating_bbg',
    },
    {
        'field': 'FIXED',
        'name': 'is_fixed',
    },
    {
        'field': 'CALLABLE',
        'name': 'is_callable',
    },
    {
        'field': 'IS_PERPETUAL',
        'name': 'is_perpetual',
    },
    {
        'field': 'CONVERTIBLE',
        'name': 'is_convertible',
    },
    {
        'field': 'IS_SUBORDINATED',
        'name': 'is_subordinated',
    },
    {
        'field': 'PAYMENT_RANK',
        'name': 'payment_rank',
    },
    {
        'field': 'ISSUER_EQUITY_TICKER',
        'name': 'issuer_equity_ticker',
    },
    {
        'field': 'ISSUER',
        'name': 'issuer_name',
    },
    {
        'field': 'YAS_BNCHMRK_BOND',
        'name': 'bmk_bond',
    },
    {
        'field': 'CDS_SPREAD_TICKER_5Y',
        'name': 'cds_ticker_5y',
        'fn': lambda series: series + ' Curncy'
    }
]

bond_history_fields = [
    {
        "field": "px_last",
        "name": "last_price",
    },
    {
        "field": "yld_ytm_mid",
        "name": "yield_to_maturity",
    },
    {
        "field": "z_sprd_mid",
        "name": "z_spread",
    },
    {
        "field": "risk_mid",
        "name": "risk",

    },
]


cds_reference_fields = [
    {
        'field': 'NAME',
        'name': 'name',
        'fn': lambda series: series + ' Curncy'
    },
    {
        'field': 'CRNCY',
        'name': 'currency',
    },
    {
        'field': 'COUNTRY',
        'name': 'country',
    },
    {
        'field': 'SW_SENIORITY',
        'name': 'seniority',
    },
    {
        'field': 'TENOR',
        'name': 'tenor',
        'fn': parse_tenor
    },
    {
        'field': 'MATURITY',
        'name': 'maturity',
    },
    {
        'field': 'SW_SPREAD',
        'name': 'running_spread',
    },
    {
        'field': 'SW_PAY_FREQ',
        'name': 'spread_freq',
    },
    {
        'field': 'DAY_CNT_DES',
        'name': 'day_count',
    },
    {
        'field': 'ISDA_DEFINITIONS_YEAR',
        'name': 'isda_def',
    },
    {
        'field': 'RESTRUCTURING_TYPE_SHORT_CODE',
        'name': 'restruct_code',
    },
    {
        'field': 'CDS_RESTRUCTURING_TYPE',
        'name': 'restruct_name',
    },
    {
        'field': 'CDS_RECOVERY_RT',
        'name': 'recovery',
    },
]


cds_history_fields = [
    {
        "field": 'PX_LAST',
        "name": 'last_price',
    },
]


yas_history_fields = [
    {
        "field": "YAS_ZSPREAD",
        "name": "z_spread",
    },
    {
        "field": "YAS_XCCY_Z_SPREAD",
        "name": "z_spread_xccy_usd",
        "overrides": [
            ("YAS_XCCY_FOREIGN_CURRENCY", "USD"),
        ]
    },
    {
        "field": "YAS_ZSPREAD_BASIS_CONSTANT_MTY",
        "name": "z_spread_basis",
    },

]