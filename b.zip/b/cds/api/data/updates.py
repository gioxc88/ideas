import json
import shutil
import sys
from pathlib import Path


import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay

from ..blpw import BlpQuery
from .base import tables, data_path
from .fields import bond_history_fields, bond_reference_fields
from .processing import post_process
from .utils import add_pcs, unparse_results_securities


sources_ = ['BGN', 'BVAL', 'CBBT']
sep_ = '@'

options = {
    'calendarCodeOverride': '5D',
    "nonTradingDayFillOption": "ALL_CALENDAR_DAYS",
    "nonTradingDayFillMethod": "PREVIOUS_VALUE",
    "pricingOption": "PRICING_OPTION_PRICE"
}

start_date_ = pd.Timestamp(2006, 1, 1)
end_date_ = pd.Timestamp.today().floor('d') - BDay()
bbg_dt_fmt = '%Y%m%d'


def get_bmk_bonds(bond_ref, bq=None):
    all_securities = bond_ref['security']
    securities = bond_ref['bmk_bond'].drop_duplicates().dropna()

    if not bq:
        bq = BlpQuery(timeout=50000).start()

    res = []
    while True:

        securities = securities.loc[~securities.isin(all_securities)]
        if securities.empty:
            break

        res_ = bq.bdp(
            securities=securities.to_list(),
            fields=[field['field'] for field in bond_reference_fields],
        )

        res_ = post_process(res_)

        all_securities = pd.concat([all_securities, res_['security']]).drop_duplicates().dropna()
        securities = res_['bmk_bond'].drop_duplicates().dropna()

        res.append(res_)

    return pd.concat(res) if res else pd.DataFrame()


def update_bonds_ref(
        securities=None,
        fields=None,
        has_history=False,
        save=True,
):
    timestamp = f"{pd.Timestamp.today():%Y%m%d_%H%M%S}"
    bonds_ref = tables.bonds_reference
    if securities is None:
        securities = bonds_ref['security']
    else:
        securities = pd.Series(securities)
        securities = securities.loc[~securities.isin(bonds_ref['security'])]

    bq = BlpQuery(timeout=50000).start()
    fields = fields or bond_reference_fields

    res_ = bq.bdp(
        securities=[*securities],
        fields=[field['field'] for field in fields],
    )

    res_.to_csv(data_path / 'temp' / f"add_bonds_reference_{timestamp}.csv", index=False)
    res = post_process(res_)
    res['has_history'] = has_history  # it means if it has the timeseries in our history database
    shutil.copy2(data_path / 'bonds_reference.csv', data_path / 'bonds_reference_backup.csv')
    new_bond_ref = pd.concat([bonds_ref, res])

    if save:
        new_bond_ref.to_csv(data_path / 'bonds_reference.csv', index=False)

    bmk_bonds = get_bmk_bonds(new_bond_ref, bq=bq)
    if not bmk_bonds.empty:
        bmk_bonds['has_history'] = has_history
        new_bond_ref = pd.concat([new_bond_ref, bmk_bonds])
        if save:
            new_bond_ref.to_csv(data_path / 'bonds_reference.csv', index=False)
    return new_bond_ref


def bonds_daily_history_update(
        securities=None,
        fields=None,
        start_date=None,
        end_date=None,
        sources=None,
        sep=None,
        daily_update=True,
        bulk_update=True,
        save=True
):

    # with open(data_path / 'bonds_history_meta.json', 'r+') as h:
    #     meta = json.load(h)
    bonds_ref = tables.bonds_reference
    bonds_hist = pd.read_csv(data_path / 'bonds_history_all.csv', parse_dates=['date'], dayfirst=True)

    sources = sources or sources_
    sep = sep or sep_
    # last_date = meta['last_date']
    last_date = bonds_hist['date'].max()

    daily_update_securities = bonds_ref.query(f"workout_date > '{last_date:%Y-%m-%d}' and has_history == True")['security'].to_list()
    bulk_update_securities = bonds_ref.fillna(False).query(f"has_history == False")['security'].to_list()
    fields = fields or bond_history_fields
    bbg_fields = [field['field'] for field in fields]

    bq = BlpQuery(timeout=50000).start()

    if daily_update_securities and daily_update:
        end_date_daily = end_date or end_date_
        start_date_daily = start_date or pd.to_datetime(last_date) + BDay()
        if end_date_daily >= start_date_daily:
            print(f'updating DAILY for {len(daily_update_securities if securities is None else securities)} securities')
            res_daily = []
            for source in sources:
                res_ = bq.bdh(
                    securities=daily_update_securities if securities is None else securities,
                    fields=bbg_fields,
                    start_date=start_date_daily.strftime(bbg_dt_fmt),
                    end_date=end_date_daily.strftime(bbg_dt_fmt),
                    options=options,
                    pcs=source,
                    sep=sep
                )
                res_ = res_.assign(source=source)
                res_daily.append(res_.dropna(subset=bbg_fields[:-1], how='all'))
            if res_daily:
                res_all_sources_daily = pd.concat(res_daily)
                res_all_sources_daily = res_all_sources_daily.rename(
                    {field['field']: field['name'] for field in fields},
                    axis=1
                )
            else:
                res_all_sources_daily = pd.DataFrame()
                print(f'after calling bbg DAILY no history returned for {daily_update_securities if securities is None else securities}')
        else:
            res_all_sources_daily = pd.DataFrame()
            print('skipping DAILY update')
    else:
        res_all_sources_daily = pd.DataFrame()
        print('skipping DAILY update')

    if bulk_update_securities and bulk_update:
        start_date_bulk = start_date or start_date_
        end_date_bulk = end_date or end_date_
        if end_date_bulk >= start_date_bulk:
            print(f'updating bulk for {len(bulk_update_securities if securities is None else securities)} securities')
            res_bulk = []
            for source in sources:
                res_ = bq.bdh(
                    securities=bulk_update_securities if securities is None else securities,
                    fields=bbg_fields,
                    start_date=start_date_bulk.strftime(bbg_dt_fmt),
                    end_date=end_date_bulk.strftime(bbg_dt_fmt),
                    options=options,
                    pcs=source,
                    sep=sep
                )
                res_ = res_.assign(source=source)
                res_bulk.append(res_.dropna(subset=bbg_fields[:-1], how='all'))
            if res_bulk:
                res_all_sources_bulk = pd.concat(res_bulk)
                res_all_sources_bulk = res_all_sources_bulk.rename(
                    {field['field']: field['name'] for field in fields},
                    axis=1
                )
            else:
                res_all_sources_bulk = pd.DataFrame()
                print(f'after calling bbg BULK no history returned for {bulk_update_securities if securities is None else securities}')
        else:
            res_all_sources_bulk = pd.DataFrame()
            print('skipping BULK update')
    else:
        res_all_sources_bulk = pd.DataFrame()
        print('skipping BULK update')

    new_data = pd.concat([res_all_sources_daily, res_all_sources_bulk])

    if not new_data.empty:
        print('concatenating results')
        res_all = pd.concat([bonds_hist, new_data]).sort_values('date').drop_duplicates()
        if save:
            print('saving results')
            if not res_all_sources_bulk.empty:
                bonds_ref.loc[bonds_ref['security'].isin(bulk_update_securities), 'has_history'] = True
                print('backup reference')
                shutil.copy2(data_path / 'bonds_reference.csv', data_path / 'bonds_reference_backup.csv')
                print('writing reference')
                bonds_ref.to_csv(data_path / 'bonds_reference.csv', index=False)
            print('backup history')
            shutil.copy2(data_path / 'bonds_history_all.csv', data_path / 'bonds_history_all_backup.csv')
            # bonds_hist.to_csv(data_path / 'bonds_history_all_backup.csv', index=False)
            print('writing history')
            res_all.to_csv(data_path / 'bonds_history_all.csv', index=False)
            print('DONE')
        return res_all
    print('DONE')
    return bonds_hist


def parse_securities(**kwargs):
    securities = pd.read_clipboard(sep=',', **kwargs).squeeze(axis=1)
    return securities.str.replace('[\s]{2,}', ' ', regex=True)
