import pandas as pd

from .utils import add_pcs
# curves = [
#     {
#         "ticker": "YCSW0260 Index",
#         "name": "USD ISDA CDS Fixing SWAP CURVE",
#         "tenors": {
#             "1M": "USLFD1M Curncy",
#             "3M": "USLFD3M Curncy",
#             "6M": "USLFD6M Curncy",
#             "1Y": "USLFD12M Curncy",
#             "2Y": "USSWAP2 Curncy",
#             "3Y": "USSWAP3 Curncy",
#             "4Y": "USSWAP4 Curncy",
#             "5Y": "USSWAP5 Curncy",
#             "6Y": "USSWAP6 Curncy",
#             "7Y": "USSWAP7 Curncy",
#             "8Y": "USSWAP8 Curncy",
#             "9Y": "USSWAP9 Curncy",
#             "10Y": "USSWAP10 Curncy",
#             "12Y": "USSWAP12 Curncy",
#             "15Y": "USSWAP15 Curncy",
#             "20Y": "USSWAP20 Curncy",
#             "25Y": "USSWAP25 Curncy",
#             "30Y": "USSWAP30 Curncy",
#         },
#         "fields": [
#             {
#                 "field": 'PX_LAST',
#                 "name": "last_price"
#             }
#         ]
#     }
# ]


# def get_curve(curve_name, curves):
#     return [curve for curve in curves if curve['name'] == curve_name]
#
#
# def get_curve_members(curve_name, curves):
#     curve = get_curve(curve_name, curves)[0]
#     members = [memb['ticker'] for memb in curve['members']]
#     if pcs := curve.get('pcs'):
#         sep = curve.get('sep', ' ')
#         members = add_pcs(members, pcs, sep)
#     return members


curves = [
    {
        'name': 'USD ISDA Standard Rates Swap Curve',
        'pcs': 'ISCF',
        'members': [
            {
                'tenor': '1M',
                'ticker': 'USLFD1M Curncy'
            },
            {
                'tenor': '3M',
                'ticker': 'USLFD3M Curncy'
            },
            {
                'tenor': '6M',
                'ticker': 'USLFD6M Curncy'
            },
            {
                'tenor': '12M',
                'ticker': 'USLFD12M Curncy'
            },
            {
                'tenor': '2Y',
                'ticker': 'USSWAP2 Curncy'
            },
            {
                'tenor': '3Y',
                'ticker': 'USSWAP3 Curncy'
            },
            {
                'tenor': '4Y',
                'ticker': 'USSWAP4 Curncy'
            },
            {
                'tenor': '5Y',
                'ticker': 'USSWAP5 Curncy'
            },
            {
                'tenor': '6Y',
                'ticker': 'USSWAP6 Curncy'
            },
            {
                'tenor': '7Y',
                'ticker': 'USSWAP7 Curncy'
            },
            {
                'tenor': '8Y',
                'ticker': 'USSWAP8 Curncy'
            },
            {
                'tenor': '9Y',
                'ticker': 'USSWAP9 Curncy'
            },
            {
                'tenor': '10Y',
                'ticker': 'USSWAP10 Curncy'
            },
            {
                'tenor': '12Y',
                'ticker': 'USSWAP12 Curncy'
            },
            {
                'tenor': '15Y',
                'ticker': 'USSWAP15 Curncy'
            },
            {
                'tenor': '20Y',
                'ticker': 'USSWAP20 Curncy'
            },
            {
                'tenor': '25Y',
                'ticker': 'USSWAP25 Curncy'
            },
            {
                'tenor': '30Y',
                'ticker': 'USSWAP30 Curncy'
            }
        ],
        "fields": [
            {
                "field": 'PX_LAST',
                "name": "last_price"
            }
        ]
    },
    {

        'name': 'EUR ISDA Standard Rates Swap Curve',
        'pcs': 'ISCR',
        'members': [
            {
                'tenor': '1M',
                'ticker': 'EULFD1M ISCF Curncy'
            },
            {
                'tenor': '3M',
                'ticker': 'EULFD3M ISCF Curncy'
            },
            {
                'tenor': '6M',
                'ticker': 'EULFD6M ISCF Curncy'
            },
            {
                'tenor': '12M',
                'ticker': 'EULFD12M ISCF Curncy'
            },
            {
                'tenor': '2Y',
                'ticker': 'EUSA2 ISCF Curncy'
            },
            {
                'tenor': '3Y',
                'ticker': 'EUSA3 ISCF Curncy'
            },
            {
                'tenor': '4Y',
                'ticker': 'EUSA4 ISCF Curncy'
            },
            {
                'tenor': '5Y',
                'ticker': 'EUSA5 ISCF Curncy'
            },
            {
                'tenor': '6Y',
                'ticker': 'EUSA6 ISCF Curncy'
            },
            {
                'tenor': '7Y',
                'ticker': 'EUSA7 ISCF Curncy'
            },
            {
                'tenor': '8Y',
                'ticker': 'EUSA8 ISCF Curncy'
            },
            {
                'tenor': '9Y',
                'ticker': 'EUSA9 ISCF Curncy'
            },
            {
                'tenor': '10Y',
                'ticker': 'EUSA10 ISCF Curncy'
            },
            {
                'tenor': '12Y',
                'ticker': 'EUSA12 ISCF Curncy'
            },
            {
                'tenor': '15Y',
                'ticker': 'EUSA15 ISCF Curncy'
            },
            {
                'tenor': '20Y',
                'ticker': 'EUSA20 ISCF Curncy'
            },
            {
                'tenor': '30Y',
                'ticker': 'EUSA30 ISCF Curncy'
            }
        ],
        "fields": [
            {
                "field": 'PX_LAST',
                "name": "last_price"
            }
        ]
    },
    {
        "name": "USD ISDA CDS SOFR Rates Swap Curve",
        "pcs": 'ISCR',
        "members": [
            {
                "tenor": "1M",
                "ticker": "USOSFRA Curncy",
            },
            {
                "tenor": "2M",
                "ticker": "USOSFRB Curncy",
            },
            {
                "tenor": "3M",
                "ticker": "USOSFRC Curncy",
            },
            {
                "tenor": "6M",
                "ticker": "USOSFRF Curncy",
            },
            {
                "tenor": "1Y",
                "ticker": "USOSFR1 Curncy",
            },
            {
                "tenor": "2Y",
                "ticker": "USOSFR2 Curncy",
            },
            {
                "tenor": "3Y",
                "ticker": "USOSFR3 Curncy",
            },
            {
                "tenor": "4Y",
                "ticker": "USOSFR4 Curncy",
            },
            {
                "tenor": "5Y",
                "ticker": "USOSFR5 Curncy",
            },
            {
                "tenor": "6Y",
                "ticker": "USOSFR6 Curncy",
            },
            {
                "tenor": "7Y",
                "ticker": "USOSFR7 Curncy",
            },
            {
                "tenor": "8Y",
                "ticker": "USOSFR8 Curncy",
            },
            {
                "tenor": "9Y",
                "ticker": "USOSFR9 Curncy",
            },
            {
                "tenor": "10Y",
                "ticker": "USOSFR10 Curncy",
            },
            {
                "tenor": "12Y",
                "ticker": "USOSFR12 Curncy",
            },
            {
                "tenor": "15Y",
                "ticker": "USOSFR15 Curncy",
            },
            {
                "tenor": "20Y",
                "ticker": "USOSFR20 Curncy",
            },
            {
                "tenor": "25Y",
                "ticker": "USOSFR25 Curncy",
            },
            {
                "tenor": "30Y",
                "ticker": "USOSFR30 Curncy",
            },
        ],
        "fields": [
            {
                "field": 'PX_LAST',
                "name": "last_price"
            }
        ]
    },
    {
        "ticker": "YCSW0260 Index",
        "name": "USD ISDA CDS Fixing SWAP CURVE",
        "members": [
            {
                "tenor": "1M",
                "ticker": "USLFD1M Curncy",
            },
            {
                "tenor": "3M",
                "ticker": "USLFD3M Curncy",
            },
            {
                "tenor": "6M",
                "ticker": "USLFD6M Curncy",
            },
            {
                "tenor": "1Y",
                "ticker": "USLFD12M Curncy",
            },
            {
                "tenor": "2Y",
                "ticker": "USSWAP2 Curncy",
            },
            {
                "tenor": "3Y",
                "ticker": "USSWAP3 Curncy",
            },
            {
                "tenor": "4Y",
                "ticker": "USSWAP4 Curncy",
            },
            {
                "tenor": "5Y",
                "ticker": "USSWAP5 Curncy",
            },
            {
                "tenor": "6Y",
                "ticker": "USSWAP6 Curncy",
            },
            {
                "tenor": "7Y",
                "ticker": "USSWAP7 Curncy",
            },
            {
                "tenor": "8Y",
                "ticker": "USSWAP8 Curncy",
            },
            {
                "tenor": "9Y",
                "ticker": "USSWAP9 Curncy",
            },
            {
                "tenor": "10Y",
                "ticker": "USSWAP10 Curncy",
            },
            {
                "tenor": "12Y",
                "ticker": "USSWAP12 Curncy",
            },
            {
                "tenor": "15Y",
                "ticker": "USSWAP15 Curncy",
            },
            {
                "tenor": "20Y",
                "ticker": "USSWAP20 Curncy",
            },
            {
                "tenor": "25Y",
                "ticker": "USSWAP25 Curncy",
            },
            {
                "tenor": "30Y",
                "ticker": "USSWAP30 Curncy",
            },
        ],
        "fields": [
            {
                "field": 'PX_LAST',
                "name": "last_price"
            }
        ]
    }
]
