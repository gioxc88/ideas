import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd

try:
    import config
except ModuleNotFoundError:
    pass

from api.blpw import BlpQuery
from .fields import bond_reference_fields
from .processing import post_process, apply_function
from .base import tables, root_path, data_path


def add_bond_ref(
        securities,
        fields=None,
        bond_ref=None,
        backup=True,
        post_process_fn=None,
):
    ### Bloomberg Connection

    timestamp = f"{pd.Timestamp.today():%Y%m%d_%H%M%S}"
    bq = BlpQuery(timeout=50000).start()

    if backup and bond_ref is None:
        _bond_ref = pd.read_csv(data_path / 'bonds_reference.csv')
        _bond_ref.to_csv(data_path / 'bonds_reference_backup.csv')
        bond_ref = _bond_ref

    bond_ref = bond_ref if bond_ref is not None else pd.read_csv(data_path / 'bonds_reference.csv')
    fields = fields or bond_reference_fields

    res_ = bq.bdp(
        securities=securities,
        fields=[field['field'] for field in fields],
    ).rename({field['field']: field['name'] for field in fields}, axis=1)

    if post_process_fn is not False:
        post_process_fn = post_process_fn or post_process
        res_ = post_process_fn(res_, fields)

    res = pd.concat([bond_ref, res_])
    res.to_csv(data_path / 'bonds_reference.csv', index=False)
    return res_
