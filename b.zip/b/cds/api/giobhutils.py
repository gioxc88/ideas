import sys
from inspect import signature, getdoc, Parameter, Signature

import ipywidgets as w
import pandas as pd
import bhutils as bh
from IPython.display import display


this_module = sys.modules[__name__]
_bh_fns = [f for f in dir(bh) if not f.startswith('_') and f.lower().startswith('bh')]

__all__ = tuple([
    'BHWrapper',
    'prettybh',
    *_bh_fns
])


private_args = [
    'class'
]

def parse_signature_and_doc(fn):
    doc = getdoc(fn)
    to_replace = doc.split('(')[1].split(')', 1)[0]
    args = [arg.split('=')[0] for arg in to_replace.split(' _')]
    args[0] = args[0][1:]

    for i, arg in enumerate(args):
        for private_arg in private_args:
            if arg == private_arg:
                args[i] = f"_{arg}"

    params = [
        Parameter(
            name=arg,
            default=None,
            kind=Parameter.POSITIONAL_OR_KEYWORD
        ) for arg in args
    ]
    new_signature = Signature(params)
    new_doc = doc
    for arg in args:
        new_doc = new_doc.replace(f" _{arg}", arg)
    new_doc = new_doc.replace('(_', '(')
    return new_signature, new_doc


def db_pandas(db):
    df = pd.DataFrame(bh.bhDbGetValues(db, _columnheadings=True))
    df = df.set_axis(df.iloc[0], axis=1).drop(df.index[0]).infer_objects().squeeze()
    return df


class BHWrapper:
    def __init__(self, value):
        self.value = value
        self._py = None

    @property
    def py(self):
        if self._py is None:
            value = self.value
            try:
                df = db_pandas(value)
                self._py = df
            except:
                pass

        return self._py

    def _ipython_display_(self):
        viewer = self.py
        display(w.HTML('BH Handle'))
        display(viewer)

    def __repr__(self):
        repr_ = self.py.__repr__()
        return f"BH Handle: {repr_}"


def prettybh(fn):
    def wrapper(*args, **kwargs):
        args = [arg.value if isinstance(arg, BHWrapper) else arg for arg in args]
        kwargs = {f"_{key}" if not key.startswith('_') else key: arg.value if isinstance(arg, BHWrapper) else arg for key, arg in kwargs.items()}
        res = fn(*args, **kwargs)
        if isinstance(res, str) and res.startswith('.'):
            try:
                py = db_pandas(res)
            except:
                return res
            else:
                bhw = BHWrapper(res)
                bhw._py = py
                return bhw

    new_signature, new_doc = parse_signature_and_doc(fn)
    wrapper.__signature__ = new_signature
    wrapper.__doc__ = new_doc
    wrapper.__name__ = fn.__name__
    wrapper.__qualname__ = fn.__name__
    return wrapper


_failed = []
for fn in _bh_fns:
    try:
        setattr(this_module, fn, prettybh(getattr(bh, fn)))
    except:
        setattr(this_module, fn, getattr(bh, fn))
        _failed.append(fn)

# def __dir__():
#     return [*dir(), *_bh_fns]
