import pandas as pd
import QuantLib as ql

from .utils import get_ql_date, get_term_date


def get_isda_cds(
        risk_free_curve: [dict, pd.Series],
        trade_date: pd.Timestamp,
        currency='USD',
        tenor='5Y',
        recovery=0.25,
        cds_spread: float = None,
        cds_curve: [dict, pd.Series] = None,
        notional=10000000,
        coupon=100,
        upfront=0,
        rebates_accrual=True
):
    if not any([cds_spread, cds_curve is not None, upfront]):
        raise ValueError('one between "cds_spread", "upfront" or "cds_curve" must be specified')
    if sum([bool(cds_spread), cds_curve is not None, bool(upfront)]) > 1:
        raise ValueError('only one one between "cds_spread", "upfront" or "cds_curve" must be specified')

    if cds_spread or upfront:
        spread = cds_spread
    elif cds_curve is not None:
        if isinstance(cds_curve, dict):
            cds_curve = pd.Series(cds_curve)
        # tenor_str = f"{tenor:.0f}Y" if tenor > 1 else f"{int(12 * tenor):.0f}M"
        spread = cds_curve[tenor]

    ql_currency = getattr(ql, f"{currency}Currency")()
    side = ql.Protection.Buyer if notional > 0 else ql.Protection.Seller
    notional = abs(notional)

    if currency == 'EUR':
        ibor_float_freq = 6
        swap_fixed_freq = ql.Annual
    else:
        ibor_float_freq = 3
        swap_fixed_freq = ql.Semiannual

    deposit_tenors = [
        '1M',
        '2M',
        '3M',
        '6M',
        '1Y'
    ]
    swap_tenors = [
        '2Y',
        '3Y',
        '4Y',
        '5Y',
        '6Y',
        '7Y',
        '8Y',
        '9Y',
        '10Y',
        '12Y',
        '15Y',
        '20Y',
        '25Y',
        '30Y'
    ]

    deposit_data = {tenor: risk_free_curve[tenor] for tenor in deposit_tenors if tenor in risk_free_curve}
    swap_data = {tenor: risk_free_curve[tenor] for tenor in swap_tenors if tenor in risk_free_curve}
    # deposit_data = risk_free_curve.loc[risk_free_curve.index.intersection(deposit_tenors)]
    # swap_data = risk_free_curve.loc[risk_free_curve.index.intersection(swap_tenors)]

    ql_trade_date = get_ql_date(trade_date)
    ql_term_date = get_ql_date(get_term_date(trade_date, tenor))
    ql_upfront_date = ql.WeekendsOnly().advance(ql_trade_date, 3 * ql.Period(ql.Daily))
    period_parser = ql.PeriodParser()
    ql.Settings.instance().setEvaluationDate(ql_trade_date)

    deposit_rate_helpers = [
        ql.DepositRateHelper(
            rate / 100,  # rate
            period_parser.parse(tenor),  # tenor
            2,  # fixingDays
            ql.WeekendsOnly(),
            ql.ModifiedFollowing,
            False,
            ql.Actual360()
        ) for tenor, rate in deposit_data.items()
    ]

    isda_ibor = ql.IborIndex(
        'IsdaIbor',  # familyName
        ibor_float_freq * ql.Period(ql.Monthly),  # tenor
        2,  # settlementDays
        ql_currency,  # currency
        ql.WeekendsOnly(),  # fixingCalendar
        ql.ModifiedFollowing,  # convention
        False,  # endOfMonth
        ql.Actual360(),  # dayCounter
    )

    swap_rate_helpers = [
        ql.SwapRateHelper(
            rate / 100,  # rate
            period_parser.parse(tenor),  # tenor
            ql.WeekendsOnly(),  # calendar
            swap_fixed_freq,  # fixedFrequency
            ql.ModifiedFollowing,  # fixedConvention
            ql.Thirty360(),  # fixedDayCount
            isda_ibor,  # iborIndex
        ) for tenor, rate in swap_data.items()
    ]

    isda_rate_helpers = [*deposit_rate_helpers, *swap_rate_helpers]
    rate_curve = ql.PiecewiseFlatForward(ql_trade_date, isda_rate_helpers, ql.Actual365Fixed())
    discount_curve = ql.YieldTermStructureHandle(rate_curve)

    cds_schedule = ql.Schedule(
        ql_trade_date,
        ql_term_date,
        3 * ql.Period(ql.Monthly),
        ql.WeekendsOnly(),
        ql.Following,
        ql.Unadjusted,
        ql.DateGeneration.CDS,
        False
    )

    quoted_trade = ql.CreditDefaultSwap(
        side,  # side
        notional,  # nominal
        upfront / 100,  # upfront
        (spread if spread else coupon) / 10000,  # spread
        cds_schedule,  # Schedule
        ql.Following,
        ql.Actual360(),
        True,
        True,
        ql_trade_date,
        ql_upfront_date,
        ql.FaceValueClaim(),
        ql.Actual360(True),
        True
    )

    if cds_spread or upfront:  # assuming FlatHazardRate
        h = quoted_trade.impliedHazardRate(
            0,
            discount_curve,
            ql.Actual365Fixed(),
            recovery,
            1e-10,
            ql.CreditDefaultSwap.ISDA
        )
        pd_curve_ = ql.FlatHazardRate(
            0,
            ql.WeekendsOnly(),
            ql.QuoteHandle(ql.SimpleQuote(h)),
            ql.Actual365Fixed()
        )
    else:  # assuming cds_curve has been passed as an argument
        cds_helpers = [
            ql.SpreadCdsHelper(
                spread / 10000,  # running_spread
                period_parser.parse(tenor),  # tenor
                0,  # settlementDays ?
                ql.WeekendsOnly(),  # calendar
                ql.Quarterly,  # frequency
                ql.Following,  # paymentConvention
                ql.DateGeneration.CDS,  # rule
                ql.Actual360(),  # dayCounter
                recovery,  # recoveryRate
                discount_curve,  # discountCurve
                True,  # settlesAccrual
                True,  # paysAtDefaultTime
            ) for tenor, spread in cds_curve.items()]
        pd_curve_ = ql.PiecewiseFlatHazardRate(trade_date, cds_helpers, ql.Actual365Fixed())

    pd_curve = ql.DefaultProbabilityTermStructureHandle(pd_curve_)
    engine = ql.IsdaCdsEngine(pd_curve, recovery, discount_curve)

    if upfront:

        conventional_trade = quoted_trade
        conventional_trade = ql.CreditDefaultSwap(
            side,  # side
            notional,  # notional
            0,  # upfront
            coupon / 10000,  # spread
            cds_schedule,  # schedule
            ql.Following,  # paymentConvention
            ql.Actual360(),  # dayCounter
            True,  # settlesAccrual
            True,  # paysAtDefaultTime
            ql_trade_date,  # protectionStart
            ql_upfront_date,  # upfrontDate
            ql.FaceValueClaim(),  # Claim
            ql.Actual360(True),  # lastPeriodDayCounter
            rebates_accrual,  # rebatesAccrual
        )
    else:
        conventional_trade = ql.CreditDefaultSwap(
            side,  # side
            notional,  # notional
            0,  # upfront
            coupon / 10000,  # spread
            cds_schedule,  # schedule
            ql.Following,  # paymentConvention
            ql.Actual360(),  # dayCounter
            True,  # settlesAccrual
            True,  # paysAtDefaultTime
            ql_trade_date,  # protectionStart
            ql_upfront_date,  # upfrontDate
            ql.FaceValueClaim(),  # Claim
            ql.Actual360(True),  # lastPeriodDayCounter
            rebates_accrual,  # rebatesAccrual
        )
    conventional_trade.setPricingEngine(engine)
    return conventional_trade