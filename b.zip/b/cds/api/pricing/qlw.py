import QuantLib as ql

ql.Bond()
