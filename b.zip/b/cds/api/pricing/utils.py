import re

import pandas as pd
import QuantLib as ql

from ..blpw import BlpQuery
from ..data.utils import add_pcs

dt_fmt = '%Y-%m-%d'
bbg_dt_fmt = '%Y%m%d'


def get_cds_specs(cds_name, cds_ref):
    return cds_ref.query(f"name == '{cds_name}'").squeeze()


def get_curve(curve_name, curves):
    return [curve for curve in curves if curve['name'] == curve_name][0]


def get_curve_members(curve_name, curves):
    curve = get_curve(curve_name, curves)
    members = [memb['ticker'] for memb in curve['members']]
    if pcs := curve.get('pcs'):
        sep = curve.get('sep', ' ')
        members = add_pcs(members, pcs, sep)
    return members


def get_cds_spreads(cds_name, cds_hist):
    return cds_hist.query(f"name == '{cds_name}'").set_index('date').dropna()


def get_risk_free_curve(curve_name, curves, curve_hist):
    curve = [curve for curve in curves if curve['name'] == curve_name][0]
    curve_hist_ = curve_hist.query(f'curve_name == "{curve["name"]}"')
    curve_hist_ = curve_hist_.assign(
        tenor=pd.Categorical(
            curve_hist_["tenor"],
            categories=[memb['tenor'] for memb in curve['members']],
            ordered=True
        )
    )
    return curve_hist_


def get_cds_curve(cds_name, cds_ref, cds_hist):
    cds_name_ref = cds_ref.loc[cds_ref.name.str.contains(get_cds_name_root(cds_name))]
    cds_curve_ = cds_hist.loc[cds_hist['security'].isin(cds_name_ref['security'])]
    cds_curve_ = cds_curve_.merge(cds_ref[['security', 'tenor']], on='security')
    cds_curve_['tenor'] = cds_curve_['tenor'].apply(lambda x: get_tenor_des(x))
    return cds_curve_


def get_cds_name_root(cds_name):
    pattern = re.compile(r'([a-zA-Z,\s]+) \d+.+')
    match = pattern.match(cds_name)
    return match.groups()[0]


def get_tenor_des(tenor: float):
    return f"{tenor:.0f}Y" if tenor > 1 else f"{int(12 * tenor):.0f}M"


def get_ql_date(date):
    return ql.Date(date.day, date.month, date.year)


def get_term_date(date, tenor):
    y, m, d = date.year, date.month, date.day
    day = 20
    if date < pd.Timestamp(year=y, month=3, day=20):
        year = y - 1
        month = 12
    elif date < pd.Timestamp(year=y, month=9, day=20):
        year = y
        month = 6
    else:
        year = y
        month = 12
    start = pd.Timestamp(year=year, month=month, day=day)
    return start + pd.tseries.frequencies.to_offset(tenor)


def get_cds_implied_price(cds_name, dates, spreads, bq=None):

    bq = bq or BlpQuery(timeout=50000).start()
    if isinstance(dates, pd.DatetimeIndex):
        dates = dates.to_series()
    if isinstance(dates, pd.Series):
        dates = dates.dt.strftime(bbg_dt_fmt).to_list()
    if isinstance(spreads, pd.Series):
        spreads = spreads.to_list()

    cds_implied_prices = bq.bdph(
        securities=[cds_name],
        fields=["CDS_QUOTED_PRICE"],
        id_override=dates,
        id_override_field="SW_CURVE_DT",
        CDS_FLAT_SPREAD=spreads,
        id_date=True
    )
    cds_implied_prices = cds_implied_prices.rename({'SW_CURVE_DT': 'date', 'CDS_QUOTED_PRICE': 'cds_implied_price'},
                                                   axis=1)
    return cds_implied_prices