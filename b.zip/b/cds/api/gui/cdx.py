import json
import sys
import copy
import re
import os
from pathlib import Path
from itertools import chain
from functools import partial

import blpapi
# import clarion
import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
import QuantLib as ql
from IPython.display import display
from ipydatagrid import DataGrid, TextRenderer, BarRenderer, Expr
from bqplot import LinearScale, ColorScale, OrdinalColorScale, OrdinalScale
from pandas.tseries.offsets import DateOffset, BDay
from pandas.tseries.frequencies import to_offset
# from clarion import positions

from .base import View, Tabs, Store
from ..blpw import BlpQuery
from ..bbg import BBGRequestParams, BBGField, BBGSecurity, BBGOverrides
from .collectors import CollectorL


pcs = 'MSG1'
sep = ' '

dt_fmt = '%Y-%m-%d'
bbg_dt_fmt = '%Y%m%d'

new_cdx_mapping = {
    "PEOPLE'S REPUBLIC OF CHINA": "CCHIN1U5 Curncy",
    "UNITED MEXICAN STATES": "CMEX1U5 Curncy",
    "FEDERATIVE REPUBLIC OF BRAZIL": "CBRZ1U5 Curncy",
    "REPUBLIC OF TURKEY": "CTURK1U5 Curncy",
    "REPUBLIC OF SOUTH AFRICA": "CSOAF1U5 Curncy",
    "REPUBLIC OF INDONESIA": "CINO1U5 Curncy",
    "REPUBLIC OF COLOMBIA": "CCOL1U5 Curncy",
    "REPUBLIC OF CHILE": "CCHIL1U5 Curncy",
    "REPUBLIC OF THE PHILIPPINES": "CPHIL1U5 Curncy",
    "MALAYSIA": "CMLAY1U5 Curncy",
    "KINGDOM OF SAUDI ARABIA": "CT965307 Curncy",
    "REPUBLIC OF PERU": "CPERU1U5 Curncy",
    "STATE OF QATAR": "CQTA1U5 Curncy",
    "ARGENTINE REPUBLIC": "CT350188 Curncy",
    "REPUBLIC OF PANAMA": "CPAN1U5 Curncy",
    "ARAB REPUBLIC OF EGYPT": "CEGY1U5 Curncy",
    "ABU DHABI": "CX855707 Curncy",
    "SULTANATE OF OMAN": "CT991547 Curncy",
}


def parse_runz(**kwargs):
    d = pd.read_clipboard(**kwargs)
    for c in d:
        ba = d[c].str.split('/')
        d[c] = (ba.str[0].astype(float) + ba.str[1].astype(float)) / 2
    d.to_clipboard()


def get_index_members(index, bq=None):
    # try:
    #     bq
    # except NameError:
    #     bq = BlpQuery(timeout=50000).start()
    members = bq.bds(
        security=index,
        field='indx_members'
    ).iloc[:, :-1].set_axis(['issuer', 'wgt', 'currency', 'seniority', 'security'], axis=1)
    members['security'] = members['security'] + ' Curncy'
    members['wgt'] = members['wgt'] / 100
    return members


def get_cdx_intrinsic_data(members, cdx_data=None, pcs=None, sep=None, maturity=None, override_spread=False, bq=None):
    cdx_data = get_members_data(members, pcs=pcs, sep=sep, bq=bq) if cdx_data is None else cdx_data

    # if 'spread' in members and override_spread:
    #     spread_override = members.loc[members['spread'].isna(), :]
    #     cdx_data.loc[cdx_data['security'].isin([*spread_override['security']]), 'spread'] = [*spread_override['spread']]

    cdx_data = cdx_data.merge(members[['security', 'wgt']], on='security', how='left')
    bbg_securities = [
        BBGSecurity(
            id=row['security'],
            overrides=[
                BBGOverrides(
                    CDS_FLAT_SPREAD=row['spread'],
                    MATURITY=maturity
                ) if maturity else BBGOverrides(CDS_FLAT_SPREAD=row['spread'])
            ]
        ) for index, row in cdx_data.iterrows()]
    bbg_fields = [
        BBGField("cds_quoted_price"),
        BBGField("SW_PAY_ACC_INT", ),
    ]

    cdx_quoted_price = bq.bdpx(BBGRequestParams(securities=bbg_securities, fields=bbg_fields)).rename(
        {"SW_PAY_ACC_INT": "accrued"}, axis=1)
    cdx_final = cdx_data.merge(cdx_quoted_price[['security', 'cds_quoted_price', "accrued"]], on='security', how='left')
    cdx_final.loc[cdx_final['is_upfront'] == 1, 'cds_quoted_price'] = 100 - cdx_final.loc[
        cdx_final['is_upfront'] == 1, 'upfront']
    cdx_final["cds_quoted_price_net"] = cdx_final["cds_quoted_price"] - (cdx_final["accrued"] / 100000)
    return cdx_final


def parse_new_cdx_members(mapping=None):
    mapping = mapping or new_cdx_mapping

    wgt = pd.read_clipboard()

    for i in [1, 2]:
        wgt.iloc[:, i] = wgt.iloc[:, i].str.replace('%', '').astype(float) / 100

    wgt = wgt.set_axis(['security', '', 'wgt'], axis=1)
    wgt['security'] = wgt['security'].replace(mapping)
    return wgt[['security', 'wgt']]


def get_members_data(members, pcs=None, sep=None, bq=None):
    pcs = pcs or 'MSG1'
    sep = sep or ' '
    fields = [
        'security_des',
        'issuer_bulk',
        'crncy',
        'tenor',
        'upfront_format_indicator',
        'sw_spread',
        'px_last',
        'upfront_last',
        # '5y_mid_cds_spread',
    ]
    cdx_data = bq.bdp(
        securities=[*members['security']],
        fields=fields,
        pcs=pcs,
        sep=sep
    )

    return cdx_data.rename({'px_last': 'spread', 'upfront_format_indicator': 'is_upfront', 'upfront_last': 'upfront'},
                           axis=1)


def on_change_change_label(widget, event, payload):
    if widget.label == 's1':
        widget.label = 's2'
    elif widget.label == 's2':
        widget.label = 's1'


def on_click_get_members_and_data(widget, event, payload, self):
    widget.loading = True
    try:
        self.get_all_members_and_data()
        display(self.dg_all)
    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False


def on_click_get_intrinsic(widget, event, payload, self):
    widget.loading = True
    try:
        self.get_intrinsic()
        display(self.get_html())
    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False


def on_click_copy(widget, event, payload, self):
    widget.loading = True
    try:
        self.copy_countries()
    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False


def on_click_change(widget, event, payload, self):
    widget.loading = True
    try:
        self.change_spread()
    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False


def on_click_copy_intrinsic(widget, event, payload, self):
    widget.loading = True
    try:
        self.copy_intrinsic()
    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False


def copy_sel(dg):
    sels = [dg.data.iloc[sel['r1']: sel['r2'] + 1, sel['c1']: sel['c2'] + 1] for sel in dg.selections]
    try:
        cols = np.vstack([sel.columns for sel in sels])
        test = np.all(cols == cols[0])
        if test:
            res = pd.concat(sels)
    except Exception as e:
        print(e)

        try:
            res = pd.concat(sels, axis=1)
        except Exception as e:
            print(e)

    res.to_clipboard()
    return res


class CDXComp(View, CollectorL):
    def get_index_name(self, s):
        return f'CDX EM CDSI S{s} 5Y PRC Corp'

    def get_html(self):
        i1 = self.s1_intrinsic['wgt'].fillna(0) @ self.s1_intrinsic['cds_quoted_price'].fillna(0)
        i2 = self.s2_intrinsic['wgt'].fillna(0) @ self.s2_intrinsic['cds_quoted_price'].fillna(0)
        diff = i2 - i1
        return w.HTML(f"<h2> <b> S{self.s1}</b>: {i1:.2f}  -  <b> S{self.s2}</b>: {i2:.2f}  -  <b> diff</b>: {diff:.2f} </h2> ")

    # def __init__(self, s1, s2, quote='s1'):
    #     if s1 > s2:
    #         s1, s2 = s2, s1
    #     self.s1 = s1
    #     self.s2 = s2
    #     self.quote = quote

    def make_widgets(self, **kwargs):
        s1_tf = v.TextField(
            v_model=None,
            label='s1',
            clearable=True,
            dense=True,
            type="number",
            outlined=True
        )

        s2_tf = v.TextField(
            v_model=None,
            label='s2',
            clearable=True,
            dense=True,
            type="number",
            outlined=True
        )

        s_sw = v.Switch(
            v_model=False,
            label='s1',
            dense=True,
            # class_='d-inline',
            hide_details=True
        )

        dl_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-download'])]
        )

        dl_btn2 = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-download'])]
        )

        copy_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-content-copy'])]
        )

        change_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-swap-horizontal'])]
        )

        copy_intrinsic_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-content-copy'])]
        )


        self.s1_tf = s1_tf
        self.s2_tf = s2_tf
        self.s_sw = s_sw
        self.dl_btn = dl_btn
        self.dl_btn2 = dl_btn2
        self.copy_btn = copy_btn
        self.change_btn = change_btn
        self.copy_intrinsic_btn = copy_intrinsic_btn
        self.out = w.Output()
        self.out2 = w.Output()

    def make_view(self, **kwargs):

        s1_tf = self.s1_tf
        s2_tf = self.s2_tf
        s_sw = self.s_sw
        dl_btn = self.dl_btn
        dl_btn2 = self.dl_btn2
        copy_btn = self.copy_btn
        change_btn = self.change_btn
        copy_intrinsic_btn = self.copy_intrinsic_btn
        out = self.out
        out2 = self.out2

        param_box = v.Container(
            fluid=True,
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=1.0,
                            children=[s_sw],
                            class_="my-0 py-0",
                            # align_self='center'
                        ),
                        v.Col(
                            cols=1.0,
                            children=[s1_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1.0,
                            children=[s2_tf],
                            class_="my-0 py-0"
                        ),

                        v.Col(
                            cols=3,
                            children=[dl_btn, dl_btn2, copy_btn, change_btn, copy_intrinsic_btn],
                            class_="my-0 py-0",
                            # align_self='center'
                        ),

                    ],
                    # align='center',
                    # justify='center'
                ),
            ],
            # fill_height=True,
            # fluid=True
        )

        view = w.VBox(
            children=[
                param_box,
                out2,
                out,
            ]
        )

        self.param_box = param_box
        self.view = view

    def link(self, **kwargs):
        s_sw = self.s_sw
        dl_btn = self.dl_btn
        dl_btn2 = self.dl_btn2
        copy_btn = self.copy_btn
        change_btn = self.change_btn
        copy_intrinsic_btn = self.copy_intrinsic_btn
        out = self.out
        out2 = self.out2

        s_sw.on_event('change', on_change_change_label)

        dl_btn.on_event(
            'click',
            partial(
                out.capture(clear_output=True)(on_click_get_members_and_data),
                self=self
            )
        )

        dl_btn2.on_event(
            'click',
            partial(
                out2.capture(clear_output=True)(on_click_get_intrinsic),
                self=self
            )
        )

        copy_btn.on_event(
            'click',
            partial(
                on_click_copy,
                self=self
            )
        )

        change_btn.on_event(
            'click',
            partial(
                on_click_change,
                self=self
            )
        )

        copy_intrinsic_btn.on_event(
            'click',
            partial(
                on_click_copy_intrinsic,
                self=self
            )
        )

        super().link()

    @property
    def s1(self):
        s1 = int(self.s1_tf.v_model)
        s2 = int(self.s2_tf.v_model)
        if s1 > s2:
            s1, s2 = s2, s1
        return s1

    @property
    def s2(self):
        s1 = int(self.s1_tf.v_model)
        s2 = int(self.s2_tf.v_model)
        if s1 > s2:
            s1, s2 = s2, s1
        return s2

    @property
    def quote(self):
        return 's1' if not self.s_sw.v_model else 's2'

    def get_all_members_and_data(self, s1=None, s2=None):
        s1 = s1 or self.s1
        s2 = s2 or self.s2
        bq = self.bq
        if s1 > s2:
            s1, s2 = s2, s1
        index_name1 = f'CDX EM CDSI S{s1} 5Y PRC Corp'
        index_name2 = f'CDX EM CDSI S{s2} 5Y PRC Corp'
        old_members = get_index_members(index_name1, bq=bq)

        try:
            new_members = get_index_members(index_name2, bq=bq)
        except Exception:
            new_members = parse_new_cdx_members()

        old_data = get_members_data(old_members, bq=bq)
        new_data = get_members_data(new_members, bq=bq)

        all_data = pd.concat([old_data, new_data.loc[~new_data['security'].isin(old_data['security']), :]]).reset_index(
            drop=True)

        self.s1_members = old_members
        self.s2_members = new_members
        self.s1_data = old_data
        self.s2_data = new_data
        self.all_data = all_data

        self.dg_all = self.make_dg1(all_data)

    def get_intrinsic(self):
        cdx_data = self.dg_all.data.copy()
        s1_data = cdx_data.loc[cdx_data['security'].isin(self.s1_members['security']), :]
        s2_data = cdx_data.loc[cdx_data['security'].isin(self.s2_members['security']), :]

        if self.quote == 's1':
            s2_data.loc[s2_data['is_upfront'] == 0, 'spread'] = \
            (s2_data['spread'] + s2_data['roll'].fillna(0).astype(float)).loc[s2_data['is_upfront'] == 0]
            s2_data.loc[s2_data['is_upfront'] == 1, 'upfront'] = \
            (s2_data['upfront'] + s2_data['roll'].fillna(0).astype(float)).loc[s2_data['is_upfront'] == 1]
        else:
            s1_data.loc[s1_data['is_upfront'] == 0, 'spread'] = \
            (s1_data['spread'] - s1_data['roll'].fillna(0).astype(float)).loc[s1_data['is_upfront'] == 0]
            s1_data.loc[s1_data['is_upfront'] == 1, 'upfront'] = \
            (s1_data['upfront'] - s1_data['roll'].fillna(0).astype(float)).loc[s1_data['is_upfront'] == 1]

        bq = self.bq
        s1_maturity = bq.bdp(
            securities=[self.get_index_name(s=self.s1)],
            fields=['maturity']
        )['maturity'].squeeze()

        s2_maturity = s1_maturity + pd.tseries.offsets.DateOffset(months=6)

        s1_intrinsic = get_cdx_intrinsic_data(members=self.s1_members, cdx_data=s1_data,
                                              maturity=f"{s1_maturity:{bbg_dt_fmt}}", bq=bq)
        s2_intrinsic = get_cdx_intrinsic_data(members=self.s2_members, cdx_data=s2_data,
                                              maturity=f"{s2_maturity:{bbg_dt_fmt}}", bq=bq)

        self.s1_intrinsic = s1_intrinsic
        self.s2_intrinsic = s2_intrinsic
        self.s1_dgi = self.make_dg1(s1_intrinsic)
        self.s2_dgi = self.make_dg1(s2_intrinsic)

    def make_dg1(self, data):
        if 'accrued' in data:
            data = data.drop('accrued', axis=1)
        renderer = TextRenderer(
            text_value=Expr("format(cell.value, '.2f')"),
            # horizontal_alignment="center",
        )

        pct_renderer = TextRenderer(
            text_value=Expr("format(cell.value, '.2%')"),
            # horizontal_alignment="center",
        )

        dg = DataGrid(
            data.assign(roll=None),
            base_column_size=90,
            column_widths={
                'security': 130,
                'security_des': 250,
                'issuer_bulk': 250,
                'cds_quoted_price': 110,
                'cds_quoted_price_net': 110,
            },
            renderers={
                'spread': renderer,
                'upfront': renderer,
                'roll': renderer,
                'cds_quoted_price': renderer,
                'cds_quoted_price_net': renderer,
                'wgt': pct_renderer,
            },
            selection_mode='cell',
            editable=True
        )

        return dg

    def change_spread(self):
        to_change = pd.read_clipboard()
        dg = self.dg_all
        data = dg.data
        for index, row in to_change.iterrows():
            country, su, roll = row
            row_to_change = data.loc[
                data['security_des'].str.lower().str.split(' ', 1).str[0] == country.lower()].squeeze()
            pk = row_to_change.name  # primary key
            column = 'upfront' if row_to_change['is_upfront'] else 'spread'
            dg.set_cell_value(column, pk, su)
            dg.set_cell_value('roll', pk, roll)

    def copy_countries(self):
        self.dg_all.data['security_des'].str.split(' ', 1).str[0].to_clipboard(index=False)

    def copy_intrinsic(self):
        intr = pd.concat([self.s1_intrinsic, self.s2_intrinsic], keys=[self.s1, self.s2]).droplevel(1)
        intr.to_clipboard()
