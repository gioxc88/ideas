from functools import partial
from io import StringIO

import blpapi
import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
import QuantLib as ql
from IPython.display import display
from ipydatagrid import DataGrid, TextRenderer, BarRenderer, Expr
from bqplot import LinearScale, ColorScale, OrdinalColorScale, OrdinalScale
# from clarion import positions

from .base import View, years_to_maturity_col
from .collectors import CollectorH
from .utils import get_issuers_curves, get_bond_ref, DatePicker, get_bday
from ..blpw import BlpQuery
from ..utils import today, BDay


dt_fmt = '%Y-%m-%d'
bbg_dt_fmt = '%Y%m%d'


def on_click_make_high_diff_grid(widget, event, payload, self):
    widget.loading = True
    try:
        df_res = self.get_data()
        dg = make_grid(df_res)
        self.dg = dg
        display(dg)
    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False



def make_high_diff_df(
        b_mkt,
        field,
        fields,
        fld_lbound=None,
        fld_ubound=None,
        yrs_lbound=None,
        yrs_ubound=None,
):
    finals = {}
    for index, group in b_mkt.groupby(['ticker', 'currency'], sort=False):
        group = group.dropna(subset=field)

        g = group[[
            'ticker',
            'security',
            'name',
            'currency',
            'custom_rating',
            years_to_maturity_col,
            'maturity_bucket',
            *fields
        ]]

        fld_lbound_ = fld_lbound if fld_lbound is not None else g[field].min()
        fld_ubound_ = fld_ubound if fld_ubound is not None else g[field].max()
        yrs_lbound_ = yrs_lbound if yrs_lbound is not None else g[years_to_maturity_col].min()
        yrs_ubound_ = yrs_ubound if yrs_ubound is not None else g[years_to_maturity_col].max()
        g = g.loc[g[field].between(fld_lbound_, fld_ubound_)]
        g = g.loc[g[years_to_maturity_col].between(yrs_lbound_, yrs_ubound_)]
        if len(g) > 1:
            gg = g.loc[[g[field].idxmin(), g[field].idxmax()]].sort_values(by=field)
            ggm = gg[['name', 'custom_rating', years_to_maturity_col, *fields]].melt()
            ggm['lh'] = ['low', 'high'] * (len(ggm) // 2)
            final = ggm.set_index(['variable', 'lh']).T.reset_index(drop=True)
            finals[index] = final

    df_res = pd.concat(finals).droplevel(-1).rename_axis([None, None], axis=1).rename_axis(['ticker', 'currency'])
    diff_cols = [*df_res.columns[df_res.columns.get_level_values(0).str.contains(field)]]

    df_res[('', 'diff')] = df_res[diff_cols[1]] - df_res[diff_cols[0]]
    df_res = df_res.sort_values(('', 'diff'), ascending=False)
    df_res = df_res.reset_index(col_level=1)

    for col in df_res:
        try:
            df_res[col] = df_res[col].astype(float)
        except ValueError:
            pass
    return df_res


def make_grid(data):
    renderer = TextRenderer(
        text_value=Expr("format(cell.value, '.2f')"),
        horizontal_alignment="center",
    )

    diff_col = ('', 'diff')
    bar_renderer = BarRenderer(
        text_value=Expr("format(cell.value, '.2f')"),
        horizontal_alignment="center",
        # bar_horizontal_alignment="center",
        bar_color=ColorScale(min=data[diff_col].min(), max=data[diff_col].max()),
        bar_value=LinearScale(min=data[diff_col].min(), max=data[diff_col].max())
    )

    name_columns = [*data.columns[data.columns.get_level_values(0) == 'name'], ('', '2y_name')]
    name_width = {name: 150 for name in name_columns}
    dg = DataGrid(
        data,
        selection_mode='cell',
        base_column_size=70,
        renderers={
            **{col: renderer for col in data.columns if data[col].dtype != object},
            diff_col: bar_renderer
        },
        column_widths=name_width
    )
    return dg


class LowestFieldCurveH(View, CollectorH):
    _default_fields = ['last_price', 'z_spread']

    def __init__(self, bond_hist=None, **kwargs):
        self._bond_hist = bond_hist
        super().__init__(**kwargs)

    @property
    def bond_ref_nobmk(self):
        return get_bond_ref()

    def make_widgets(self, **kwargs):
        fld_lbound_tf = v.TextField(
            v_model=None,
            label='fld lbound',
            clearable=True,
            dense=True,
            outlined=True,
            type="number",
            hide_details=True,
        )

        fld_ubound_tf = v.TextField(
            v_model=None,
            label='fld ubound',
            clearable=True,
            dense=True,
            outlined=True,
            type="number",
            hide_details=True,
        )

        yrs_lbound_tf = v.TextField(
            v_model=None,
            label='yrs lbound',
            clearable=True,
            dense=True,
            outlined=True,
            type="number",
            hide_details=True,

        )

        yrs_ubound_tf = v.TextField(
            v_model=None,
            label='yrs ubound',
            clearable=True,
            dense=True,
            outlined=True,
            type="number",
            hide_details=True,
        )

        pcs_tf = v.TextField(
            v_model='BGN',
            label='pcs',
            clearable=True,
            dense=True,
            outlined=True,
            hide_details=True,

        )

        date_pk = DatePicker(
            value=today() - BDay(),
            label='date',
            outlined=True
        )

        sep_tf = v.TextField(
            v_model='@',
            label='sep',
            clearable=True,
            dense=True,
            outlined=True,
            disabled=True,
            hide_details = True,
        )

        field_ac = v.Autocomplete(
            v_model='last_price',
            items=self._default_fields,
            label='field',
            dense=True,
            outlined=True,
            hide_details=True,
        )

        dl_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-download'])]
        )

        table_btn = v.Btn(
            fab=True,
            small=True,
            plain=True,
            left=True,
            children=[v.Icon(children=['mdi-table'])]
        )

        self.fld_lbound_tf = fld_lbound_tf
        self.fld_ubound_tf = fld_ubound_tf
        self.yrs_lbound_tf = yrs_lbound_tf
        self.yrs_ubound_tf = yrs_ubound_tf
        self.pcs_tf = pcs_tf
        self.sep_tf = sep_tf
        self.field_ac = field_ac
        self.dl_btn = dl_btn
        self.table_btn = table_btn
        self.date_pk = date_pk
        self.out = w.Output()

    def make_view(self, **kwargs):
        date_pk = self.date_pk
        fld_lbound_tf = self.fld_lbound_tf
        fld_ubound_tf = self.fld_ubound_tf
        yrs_lbound_tf = self.yrs_lbound_tf
        yrs_ubound_tf = self.yrs_ubound_tf
        pcs_tf = self.pcs_tf
        sep_tf = self.sep_tf
        field_ac = self.field_ac
        dl_btn = self.dl_btn
        table_btn = self.table_btn
        out = self.out

        param_box = v.Container(
            fluid=True,
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=2,
                            children=[fld_lbound_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[fld_ubound_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[yrs_lbound_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[yrs_ubound_tf],
                            class_="my-0 py-0"
                        ),
                    ],
                    align='end',
                    class_='mb-3'
                ),
                v.Row(
                    children=[
                        v.Col(
                            cols=2,
                            children=[date_pk.view],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[pcs_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[sep_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[field_ac],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1,
                            children=[table_btn],
                            class_="my-0 py-0"
                        ),
                    ],
                    align='end'
                ),
            ]
        )
        view = w.VBox(
            children=[
                param_box,
                out,
            ]
        )

        self.param_box = param_box
        self.view = view

    def link(self, **kwargs):
        fld_lbound_tf = self.fld_lbound_tf
        fld_ubound_tf = self.fld_ubound_tf
        yrs_lbound_tf = self.yrs_lbound_tf
        yrs_ubound_tf = self.yrs_ubound_tf
        pcs_tf = self.pcs_tf
        date_pk = self.date_pk
        sep_tf = self.sep_tf
        field_ac = self.field_ac
        dl_btn = self.dl_btn
        table_btn = self.table_btn
        out = self.out

        table_btn.on_event(
            'click',
            partial(
                out.capture(clear_output=True)(on_click_make_high_diff_grid),
                self=self
            )
        )
        super().link()

    def get_mkt_data(self):
        bond_ref_nobmk = self.bond_ref_nobmk
        df = self.bond_hist
        source = self.pcs_tf.v_model
        fields = self.field_ac.items
        d = df.query(f"source =='{source}'")[['date', 'security', *fields]].set_index('date').loc[
            get_bday(self.date_pk.date)]

        b_mkt = bond_ref_nobmk.merge(d, on='security', how='left')
        self.bond_mkt = b_mkt
        return b_mkt

    def get_data(self):
        bond_ref_nobmk = self.bond_ref_nobmk
        fld_lbound = self.fld_lbound_tf.v_model if self.fld_lbound_tf.v_model is None else float(
            self.fld_lbound_tf.v_model)
        fld_ubound = self.fld_ubound_tf.v_model if self.fld_ubound_tf.v_model is None else float(
            self.fld_ubound_tf.v_model)
        yrs_lbound = self.yrs_lbound_tf.v_model if self.yrs_lbound_tf.v_model is None else float(
            self.yrs_lbound_tf.v_model)
        yrs_ubound = self.yrs_ubound_tf.v_model if self.yrs_ubound_tf.v_model is None else float(
            self.yrs_ubound_tf.v_model)
        field = self.field_ac.v_model
        fields = self.field_ac.items

        b_mkt = self.get_mkt_data()
        df_res = make_high_diff_df(b_mkt, field, fields, fld_lbound, fld_ubound, yrs_lbound, yrs_ubound)

        to_add = self.get_2y_bonds_z_spread(bond_ref=bond_ref_nobmk, bond_mkt=b_mkt)
        if to_add is not None:

            df_res = pd.merge(df_res, to_add, on=[('', 'ticker'), ('', 'currency')])

        self.df_res = df_res
        return df_res

    def get_2y_bonds(self, bond_ref=None):
        bond_ref = self.bond_ref_nobmk if bond_ref is None else bond_ref
        b2y = {
            cur: get_issuers_curves(bond_ref, maturities=[2], currency=cur, thresholds={2: (0.5, 4)})
            for cur in bond_ref['currency'].drop_duplicates()
        }
        return pd.concat(b2y.values())

    def get_2y_bonds_z_spread(self, bond_ref=None, bond_mkt=None):
        bond_ref = self.bond_ref_nobmk if bond_ref is None else bond_ref
        bond_mkt = self.bond_mkt if bond_mkt is None else bond_mkt
        b2y = self.get_2y_bonds(bond_ref=bond_ref)

        if not b2y.empty:
            b2y = b2y['security']
        else:
            return

        to_add = bond_mkt.loc[bond_mkt['security'].isin(b2y), ['ticker', 'currency', 'name', 'z_spread']]\
            .rename({'z_spread': '2y_z', 'name': '2y_name'}, axis=1)
        to_add = pd.concat([to_add], axis=1, keys=[''])
        return to_add



