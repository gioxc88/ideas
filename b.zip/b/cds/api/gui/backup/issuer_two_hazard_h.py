import warnings
from functools import partial

import ipyvuetify as v
import ipywidgets as w
import numpy as np
import pandas as pd
from IPython.display import display
from ipydatagrid import DataGrid, TextRenderer
from pandas.tseries.offsets import BDay
from plotly import graph_objects as go

from api.gui.base import View
from api.gui.collectors import CollectorH
from api.gui.utils import get_issuer_curve, get_bond_ref, get_bday, DatePicker
from api.utils import parse_offset, today

pd.options.plotting.backend = "plotly"


class HazardH(View, CollectorH):

    def __init__(self, bond_ref=None, bond_hist=None, **kwargs):
        self._bond_ref = bond_ref
        self._bond_hist = bond_hist
        super().__init__(**kwargs)

    @property
    def bond_ref(self):
        return get_bond_ref()

    def get_secs(self, date=None, issuer=None, currency=None):
        bond_ref = get_bond_ref(date=date)
        issuer_curve = get_issuer_curve(bond_ref, issuer, currency=currency)
        return issuer_curve

    def get_input_df(self, date=None, issuer=None, currency=None, rr=None):
        pcs = self.pcs_ac.v_model
        d = get_bday(date) if date else self.date_pk.date
        ic = self.get_secs(date=date, issuer=issuer, currency=currency)
        #rr = self.rr_tf.v_model
        secs = [*ic['security']]
        df = self.bond_hist.query(f"security in {secs} and source == '{pcs}' and date == {d: %Y%m%d}")
        df = ic.merge(df, on='security', how='left')
        df["hr"] = (df['z_spread'] / 10000) / (1 - rr + (0.25 * df['z_spread'] / 10000 * 0.5))
        df["surv"] = np.exp(-(df["hr"] * df["years_to_maturity"]).astype(float))
        cols = [
            'name',
            'maturity_label',
            'hr',
            'surv',
            'z_spread'
        ]
        return df[cols]

    def get_final_input(self, offsets=None):
        if not offsets:
            offsets = self.offset_cb.v_model
        date = self.date_pk.date
        dates = [date, *[date - parse_offset(offset) for offset in offsets]]
        final = {}
        for issuer, currency, rr in [
            (self.issuer1_ac.v_model, self.currency1_ac.v_model, self.rr1_tf.v_model),
            (self.issuer2_ac.v_model, self.currency2_ac.v_model, self.rr2_tf.v_model)
        ]:
            if issuer:
                data = pd.concat({(date, offset): self.get_input_df(date, issuer, currency, rr)
                                  for date, offset in zip(dates, ['last', *offsets])})
                data = data.reset_index(level=[0, 1]).rename({'level_0': 'date', 'level_1': 'offset'}, axis=1).infer_objects()
                final[issuer] = data
        data = pd.concat(final).reset_index(level=0).rename({'level_0': 'issuer'}, axis=1).infer_objects()
        self.data = data
        return self.data

    def get_data(self):
        df = self.get_final_input()
        return df

    def make_widgets(self, **kwargs):

        issuer1_ac = v.Autocomplete(
            v_model=None,
            items=self.bond_ref['ticker'].drop_duplicates().sort_values().to_list(),
            label='issuer',
            dense=True,
            outlined=True,
            clearable=True,
            hide_details=True,
        )

        currency1_ac = v.Autocomplete(
            v_model='USD',
            items=self.bond_ref['currency'].drop_duplicates().to_list(),
            label='currency',
            dense=True,
            outlined=True,
            hide_details=True,
        )

        rr1_tf = v.TextField(
            v_model=None,
            label='recovery',
            clearable=True,
            dense=True,
            outlined=True,
            type="number",
            hide_details=True,

        )

        pcs_ac = v.Autocomplete(
            v_model='BGN',
            items=['BGN', 'BVAL', 'CBBT'],
            label='pcs',
            dense=True,
            outlined=True,
            hide_details=True,

        )

        date_pk = DatePicker(
            value=today() - BDay(),
            label='date',
            outlined=True,
        )

        issuer2_ac = v.Autocomplete(
            v_model=None,
            items=self.bond_ref['ticker'].drop_duplicates().sort_values().to_list(),
            label='issuer',
            dense=True,
            outlined=True,
            clearable=True,
            hide_details=True,
        )

        currency2_ac = v.Autocomplete(
            v_model='USD',
            items=self.bond_ref['currency'].drop_duplicates().to_list(),
            label='currency',
            dense=True,
            outlined=True,
            hide_details=True,
        )

        rr2_tf = v.TextField(
            v_model=None,
            label='recovery',
            clearable=True,
            dense=True,
            outlined=True,
            type="number",
            hide_details=True,

        )

        issuer_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-cached'])]
        )

        maturity_cb = v.Combobox(
            v_model=[2, 3, 5, 7, 10, 30, 50],
            items=None,
            multiple=True,
            small_chips=True,
            deletable_chips=True,
            outlined=True,
            dense=True,
            clearable=True,
            label="maturities"
        )

        offset_cb = v.Combobox(
            v_model=['1w', '1m', '3m', '6m', 'ytd'],
            items=None,
            multiple=True,
            small_chips=True,
            deletable_chips=True,
            outlined=True,
            dense=True,
            clearable=True,
            label="time lag"
        )

        field_table_ac = v.Combobox(
            v_model='surv',
            items=['hr', 'surv', 'z_spread', 'name'],
            multiple=False,
            # small_chips=True,
            # deletable_chips=True,
            outlined=True,
            dense=True,
            # clearable=True,
            label="table field"
        )

        field_plot_ac = v.Combobox(
            v_model='surv',
            items=['hr', 'surv', 'z_spread'],
            multiple=False,
            # small_chips=True,
            # deletable_chips=True,
            outlined=True,
            dense=True,
            # clearable=True,
            label="plot field"
        )

        out = w.Output()

        self.issuer1_ac = issuer1_ac
        self.currency1_ac = currency1_ac
        self.rr1_tf = rr1_tf

        self.pcs_ac = pcs_ac
        self.date_pk = date_pk

        self.issuer2_ac = issuer2_ac
        self.currency2_ac = currency2_ac
        self.rr2_tf = rr2_tf

        self.issuer_btn = issuer_btn
        self.maturity_cb = maturity_cb
        self.offset_cb = offset_cb
        self.field_table_ac = field_table_ac
        self.field_plot_ac = field_plot_ac

        self.out = out

    def make_view(self, **kwargs):

        issuer1_ac = self.issuer1_ac
        currency1_ac = self.currency1_ac
        rr1_tf = self.rr1_tf

        pcs_ac = self.pcs_ac
        date_pk = self.date_pk

        issuer2_ac = self.issuer2_ac
        currency2_ac = self.currency2_ac
        rr2_tf = self.rr2_tf

        issuer_btn = self.issuer_btn
        maturity_cb = self.maturity_cb
        offset_cb = self.offset_cb
        field_table_ac = self.field_table_ac
        field_plot_ac = self.field_plot_ac

        out = self.out

        param_box = v.Container(
            fluid=True,
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=2,
                            children=[issuer1_ac],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[currency1_ac],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[rr1_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[pcs_ac],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[date_pk.view],
                            class_="my-0 py-0"
                        ),

                    ],
                    align='end',
                    class_='mb-5'
                ),
                v.Row(
                    children=[
                        v.Col(
                            cols=2,
                            children=[issuer2_ac],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[currency2_ac],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[rr2_tf],
                            class_="my-0 py-0"
                        ),
                    ],
                    align='end',
                    class_='mb-5'
                ),
                v.Row(
                    children=[
                        v.Col(
                            cols=6,
                            children=[maturity_cb],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=6,
                            children=[offset_cb],
                            class_="my-0 py-0"
                        ),
                    ],
                    align='end',
                ),
                v.Row(
                    children=[
                        v.Col(
                            cols=2,
                            children=[field_plot_ac],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[field_table_ac],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1,
                            children=[issuer_btn],
                            class_="my-0 py-0"
                        ),
                    ],
                ),
            ]
        )
        view = w.VBox(
            children=[
                param_box,
                out,
            ]
        )
        self.param_box = param_box
        self.view = view

    def link(self, **kwargs):

        out = self.out

        self.issuer_btn.on_event(
            'click',
            partial(
                out.capture(clear_output=True)(on_click_show),
                self=self,
                update=True
            )
        )

        self.field_plot_ac.on_event(
            'change',
            self.on_change_update_chart
        )

        self.field_table_ac.on_event(
            'change',
            self.on_change_update_table
        )

        self.issuer1_ac.on_event(
            'change',
            self.on_change_update_rr
        )

        self.issuer2_ac.on_event(
            'change',
            self.on_change_update_rr
        )

    def on_change_update_chart(self, widget, event, payload):
        if hasattr(self, 'data') and hasattr(self, 'out_cont1'):
            if self.issuer1_ac.v_model:
                data1 = self.data.query(f"issuer == '{self.issuer1_ac.v_model}'")
                self.fig1_updated = make_plot(data1, self.field_plot_ac.v_model)
            else:
                self.fig1_updated = ''
            if self.issuer2_ac.v_model:
                data2 = self.data.query(f"issuer == '{self.issuer2_ac.v_model}'")
                self.fig2_updated = make_plot(data2, self.field_plot_ac.v_model)
            else:
                self.fig2_updated = ''

            self.out_cont1.children = [
                v.Row(
                    children=[
                        v.Col(
                            cols=6,
                            children=[self.fig1_updated],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=6,
                            children=[self.fig2_updated],
                            class_="my-0 py-0"
                        )
                    ]
                )
            ]

    def on_change_update_table(self, widget, event, payload):
        if hasattr(self, 'data') and hasattr(self, 'out_cont2'):
            if self.issuer1_ac.v_model:
                data1 = self.data.query(f"issuer == '{self.issuer1_ac.v_model}'")
                self.dg1_updated= make_grid2(data1, self.field_table_ac.v_model)
            else:
                self.dg1_updated = ''
            if self.issuer2_ac.v_model:
                data2 = self.data.query(f"issuer == '{self.issuer2_ac.v_model}'")
                self.dg2_updated = make_grid2(data2, self.field_table_ac.v_model)
            else:
                self.dg2_updated = ''

            self.out_cont2.children = [
                v.Row(
                    children=[
                        v.Col(
                            cols=6,
                            children=[self.dg1_updated],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=6,
                            children=[self.dg2_updated],
                            class_="my-0 py-0"
                        )
                    ]
                )
            ]

    def on_change_update_rr(self, widget, event, payload):
        issuer = widget.v_model
        try:
            rr = self.cds_ref.query(f"ticker == '{issuer}'")['recovery'].iloc[0]
        except:
            rr = 0.25
        if widget == self.issuer1_ac:
            self.rr1_tf.v_model = rr
        elif widget == self.issuer2_ac:
            self.rr2_tf.v_model = rr


fmt_map = {
    'hr': '.2%',
    'surv': '.2%',
    'z_spread': '.2f'
}


def make_plot(df, field, fmt=None, **kwargs):
    fmt = fmt or fmt_map.get(field)
    fig = df.plot(
        x='maturity_label',
        y=field,
        color='offset',
        hover_data=['name'],
        template='plotly_white',
        height=500
    ).update_layout(
        xaxis=dict(
            tickmode='array',  # change 1
            tickvals=df['maturity_label'].unique(),  # change 2
            # ticktext = [0,5,10,15,20,25],
        ),
        yaxis=dict(tickformat=fmt),
        # font=dict(size=18, color="black")
    )
    return go.FigureWidget(fig)


def make_grid(data):
    renderer = TextRenderer(
        format='.2f',
        horizontal_alignment="center",
    )
    pct_renderer = TextRenderer(
        format='.2%',
        horizontal_alignment="center",
    )
    pct_cols = [
        "hr",
        "surv",
    ]
    date_renderer = TextRenderer(
        format="%Y-%m-%d",
        format_type="time",
        horizontal_alignment="center",
    )
    renderers = {
        **{col: renderer for col in data.columns if data[col].dtype == 'float64'},
        'date': date_renderer
    }
    renderers.update({col: pct_renderer for col in pct_cols})
    dg = DataGrid(
        data,
        selection_mode='cell',
        base_column_size=70,
        column_widths={'date': 90, 'name': 150},
        renderers=renderers,
        editable=True,
    )
    return dg


def get_pivot_table(df, value, index='offset'):
    df_ = df.pivot(index=index, columns='maturity_label', values=value)
    try:
        df_ = df_.astype(float)
    except:
        pass

    return df_.loc[[*df[index].unique()]]


def make_grid2(data, field, fmt=None):
    df = get_pivot_table(data, field)
    fmt = fmt or fmt_map.get(field)
    dg = DataGrid(
        df,
        default_renderer=TextRenderer(format=fmt),
        base_column_size=150 if field == 'name' else 64,
        layout={"height": "120px"}
    )
    return dg


def on_click_show(widget, event, data, self, update=False):
    widget.loading = True
    try:
        with warnings.catch_warnings():
            warnings.simplefilter(action='ignore', category=FutureWarning)
            hazard_df = self.get_data()

            plots = {}
            grids_main = {}
            grids_small = {}
            for issuer in [self.issuer1_ac.v_model, self.issuer2_ac.v_model]:
                if issuer:
                    hazard_df_issuer = hazard_df.query(f"issuer == '{issuer}'")
                    fig = make_plot(hazard_df_issuer, self.field_plot_ac.v_model)
                    dg_main = make_grid(hazard_df_issuer.drop(columns=['issuer']))
                    dg_small = make_grid2(hazard_df_issuer, self.field_table_ac.v_model)
                    plots[issuer] = fig
                    grids_main[issuer] = dg_main
                    grids_small[issuer] = dg_small
                else:
                    plots[issuer] = ''
                    grids_main[issuer] = ''
                    grids_small[issuer] = ''

        self.out_cont0 = v.Container(
            fluid=True,
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=6,
                            children=[w.HTML(f"<br> <b> {self.issuer1_ac.v_model if self.issuer1_ac.v_model else ''} <b>")],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=6,
                            children=[w.HTML(f"<br> <b> {self.issuer2_ac.v_model if self.issuer2_ac.v_model else ''} <b>")],
                            class_="my-0 py-0"
                        )
                    ]
                ),
            ]
        )

        self.out_cont1 = v.Container(
            fluid=True,
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=6,
                            children=[plots[self.issuer1_ac.v_model]],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=6,
                            children=[plots[self.issuer2_ac.v_model]],
                            class_="my-0 py-0"
                        )
                    ]
                ),
            ]
        )

        self.out_cont2 = v.Container(
            fluid=True,
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=6,
                            children=[grids_small[self.issuer1_ac.v_model]],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=6,
                            children=[grids_small[self.issuer2_ac.v_model]],
                            class_="my-0 py-0"
                        )
                    ]
                ),
            ]
        )

        self.out_cont3 = v.Container(
            fluid=True,
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=6,
                            children=[grids_main[self.issuer1_ac.v_model]],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=6,
                            children=[grids_main[self.issuer2_ac.v_model]],
                            class_="my-0 py-0"
                        )
                    ]
                )
            ]
        )

        display(self.out_cont0)
        display(self.out_cont1)
        display(self.out_cont2)
        display(self.out_cont3)

    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False
