from functools import partial

import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
from IPython.display import display
from ipydatagrid import DataGrid, TextRenderer
from pandas.tseries.offsets import BDay, YearBegin
from plotly import graph_objects as go, express as px
from plotly.subplots import make_subplots

from .base import View
from ..data.fields import bond_history_fields
from ..utils import parse_offset, today
from .utils import get_bond_ref, get_bday, DatePicker
from .collectors import CollectorH

pd.options.plotting.backend = "plotly"


class ForwardH(View, CollectorH):

    def __init__(self, bond_ref=None, bond_hist=None, **kwargs):
        self._bond_ref = bond_ref
        self._bond_hist = bond_hist
        super().__init__(**kwargs)

    @property
    def bond_ref(self):
        return get_bond_ref()

    def get_secs(self):
        return self.name1_ac.v_model.split(SEP)[0], self.name2_ac.v_model.split(SEP)[0]

    def make_widgets(self, **kwargs):
        start_date_pk = DatePicker(
            value=today() - YearBegin(),
            label='start date',
            outlined=True,
        )

        end_date_pk = DatePicker(
            value=pd.Timestamp.today() - BDay(),
            label='end date',
            outlined=True,
        )

        start_date_chart_pk = DatePicker(
            value=pd.Timestamp.today() - BDay(30),
            label='start date chart',
            outlined=True,
        )

        end_date_chart_pk = DatePicker(
            value=pd.Timestamp.today() - BDay(),
            label='end date chart',
            outlined=True,
        )

        field_lookup_ac = v.Autocomplete(
            v_model='name',
            items=['name', 'security', 'isin'],
            label='field',
            dense=True,
            outlined=True,
            hide_details=True,
        )

        name1_ac = v.Autocomplete(
            v_model=None,
            items=None,
            label='security 1',
            dense=True,
            outlined=True,
            hide_details=True,
        )

        name2_ac = v.Autocomplete(
            v_model=None,
            items=None,
            label='security 2',
            dense=True,
            outlined=True,
            hide_details=True,
        )

        pcs_tf = v.TextField(
            v_model='BGN',
            label='pcs',
            clearable=True,
            dense=True,
            outlined=True,
            hide_details=True,

        )

        window_tf = v.TextField(
            v_model=20,
            label='window',
            clearable=True,
            dense=True,
            outlined=True,
            type="number",
            hide_details=True,

        )

        rr_tf = v.TextField(
            v_model=0.25,
            label='recovery',
            clearable=True,
            dense=True,
            outlined=True,
            type="number",
            hide_details=True,

        )

        table_btn = v.Btn(
            fab=True,
            small=True,
            plain=True,
            left=True,
            children=[v.Icon(children=['mdi-table'])]
        )

        refresh_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-sync'])]
        )

        out = w.Output()

        self.start_date_pk = start_date_pk
        self.end_date_pk = end_date_pk
        self.start_date_chart_pk = start_date_chart_pk
        self.end_date_chart_pk = end_date_chart_pk
        self.field_lookup_ac = field_lookup_ac
        self.name1_ac = name1_ac
        self.name2_ac = name2_ac
        self.pcs_tf = pcs_tf
        self.rr_tf = rr_tf
        self.window_tf = window_tf
        self.table_btn = table_btn
        self.refresh_btn = refresh_btn
        self.out = out

    def make_view(self, **kwargs):
        start_date_pk = self.start_date_pk
        end_date_pk = self.end_date_pk
        start_date_chart_pk = self.start_date_chart_pk
        end_date_chart_pk = self.end_date_chart_pk
        field_lookup_ac = self.field_lookup_ac
        name1_ac = self.name1_ac
        name2_ac = self.name2_ac
        pcs_tf = self.pcs_tf
        rr_tf = self.rr_tf
        window_tf = self.window_tf
        table_btn = self.table_btn
        refresh_btn = self.refresh_btn
        out = self.out

        param_box = v.Container(
            fluid=True,
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=2,
                            children=[start_date_pk.view],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[end_date_pk.view],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[rr_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[window_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[start_date_chart_pk.view],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[end_date_chart_pk.view],
                            class_="my-0 py-0"
                        ),
                    ],
                    align='end',
                    class_='mb-5'
                ),
                v.Row(
                    children=[
                        v.Col(
                            cols=1.0,
                            children=[field_lookup_ac],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[name1_ac],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[name2_ac],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1.0,
                            children=[pcs_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[table_btn, refresh_btn],
                            class_="my-0 py-0"
                        ),
                    ],
                ),
            ]
        )
        view = w.VBox(
            children=[
                param_box,
                out,
            ]
        )
        self.param_box = param_box
        self.view = view

    def link(self, **kwargs):
        field_lookup_ac = self.field_lookup_ac
        out = self.out

        field_lookup_ac.on_event(
            'change',
            partial(
                on_change_update_items,
                self=self,
            )
        )
        field_lookup_ac.fire_event('change', None)

        self.table_btn.on_event(
            'click',
            partial(
                out.capture(clear_output=True)(on_click_show),
                self=self
            )
        )

        self.refresh_btn.on_event(
            'click',
            partial(
                out.capture(clear_output=True)(on_click_show),
                self=self,
                update=True
            )
        )

    def get_fwd_inputs(self):
        field = self.field_lookup_ac.v_model
        pcs = self.pcs_tf.v_model
        bond_ref = self.bond_ref
        sec1, sec2 = self.get_secs()
        securities = bond_ref.loc[bond_ref[field].isin([sec1, sec2]), ['security', 'maturity', 'name']].sort_values(
            'maturity').set_index('security')
        secs = [*securities.index]
        d1 = get_bday(self.start_date_pk.date)
        d2 = get_bday(self.end_date_pk.date)
        ts = self.bond_hist.query(f"security in {secs} and source == '{pcs}' and {d1: %Y%m%d} <= date <= {d2: %Y%m%d}")
        ts = ts.drop('source', axis=1).pivot(index='date', columns='security').reorder_levels([1, 0], axis=1)
        if ts.index[-1] == today() - BDay():
            bq = self.bq
            today_data = bq.bdp(
                securities=[*securities.index],
                fields={field['field']: field['name'] for field in bond_history_fields},
                pcs=pcs,
                sep='@'
            )
            today_data['date'] = today()
            today_data = today_data.pivot(index='date', columns='security').reorder_levels([1, 0], axis=1)
            ts = pd.concat([ts, today_data])

        self.fwd_inputs = ts
        return ts

    def get_fwd_df(self, fwd_inputs):
        win = int(self.window_tf.v_model)
        rr = float(self.rr_tf.v_model)
        bond_ref = self.bond_ref
        field = self.field_lookup_ac.v_model
        sec1, sec2 = self.get_secs()
        securities = bond_ref.loc[bond_ref[field].isin([sec1, sec2]), ['security', 'maturity', 'name']].sort_values(
            'maturity').set_index('security')
        secs = [*securities.index]

        ts = fwd_inputs.copy()
        fwd_mat = securities['maturity'].diff().dropna().squeeze().days / 365.2425
        for sec in secs:
            ts[(sec, 'years_to_maturity')] = (securities.loc[sec, 'maturity'] - ts.index).days / 365.2425
            ts[(sec, "hr")] = (ts[(sec, 'z_spread')] / 10000) / (1 - rr + (0.25 * ts[(sec, 'z_spread')] / 10000 * 0.5))
            ts[(sec, "surv")] = np.exp(-ts[(sec, "hr")] * ts[(sec, "years_to_maturity")])

        ts = ts.loc[:, (secs)]
        ts[("", 'risk_ratio')] = ts.loc[:, (secs[0], 'risk')] / ts.loc[:, (secs[1], 'risk')]
        ts[("", 'fwd')] = (ts.loc[:, (secs[1], 'z_spread')] - ts.loc[:, (secs[0], 'z_spread')] * ts.loc[:, ("",
                                                                                                            'risk_ratio')]) / (
                                  1 - ts.loc[:, ("", 'risk_ratio')])
        ts[("", 'fwd_mat')] = fwd_mat
        ts[("", 'fwd_hr')] = (ts[("", 'fwd')] / 10000) / (1 - rr + (0.25 * ts[("", 'fwd')] / 10000 * 0.5))
        ts[("", 'fwd_surv')] = np.exp(-ts[("", "fwd_hr")] * ts[("", "fwd_mat")])
        ts[("", 'surv_btsr')] = ts[("", 'fwd_surv')] * ts[(secs[0], "surv")]
        ts[("", 'price_diff')] = ts[(secs[0], "last_price")] - ts[(secs[-1], "last_price")]
        ts[("", 'surv_vol')] = ts[("", 'surv_btsr')].diff().rolling(win).std() * (252 ** 0.5)
        self.fwd_df = ts.rename(securities['name'], level=0, axis=1)
        return self.fwd_df

    def get_data(self):
        ts = self.get_fwd_inputs()
        fwd_df = self.get_fwd_df(ts)
        return fwd_df

    def get_dg_inputs(self):
        bond_ref = self.bond_ref
        field = self.field_lookup_ac.v_model
        ts = self.fwd_inputs
        sec1, sec2 = self.get_secs()
        securities = bond_ref.loc[bond_ref[field].isin([sec1, sec2]), ['security', 'maturity', 'name']].sort_values(
            'maturity').set_index('security')
        data = self.dg.data.sort_values(('', 'date'))
        data.columns = pd.MultiIndex.from_tuples(data.columns)
        data = data.set_index(('', 'date')).loc[:,
               (slice(None), [field['name'] for field in bond_history_fields])].rename_axis('date').rename_axis(
            ['security', None], axis=1)
        inputs = data.rename(securities.reset_index().set_index('name')['security'], axis=1, level=0)
        inputs = inputs.loc[:, ts.columns]

        bq = self.bq
        ovrds = []
        for sec in securities.index:
            res = bq.bdp(
                securities=[sec],
                fields={
                    'yas_bond_px': 'last_price',
                    'yas_bond_yld': 'yield_to_maturity',
                    'yas_risk': 'risk'
                },
                overrides=[('yas_zspread', inputs.loc[inputs.index[-1], (sec, 'z_spread')])]
            )
            ovrds.append(res)

        res = pd.concat(ovrds)
        to_change = inputs.loc[inputs.index[-1], (securities.index, res.columns[1:])]
        new_vals = res.melt(id_vars='security').set_index(['security', 'variable']).rename_axis(['security', None]).loc[
            to_change.index]
        inputs.loc[inputs.index[-1], (securities.index, res.columns[1:])] = new_vals.squeeze(axis=1)

        return inputs

    def make_scatter(self, data):
        covid_period = ['2020-02-01', '2020-05-01']
        sec1, sec2 = data.columns.get_level_values(0).drop_duplicates()[:-1]
        scatter_plot_df = pd.concat([
            data.loc[:, (sec1, "surv")],
            data.loc[:, (slice(None), "surv_btsr")]
        ], axis=1).droplevel(0, axis=1).rename({'surv': 'surv short bond', 'surv_btsr': 'surv long bond'}, axis=1)
        covid_mask = (covid_period[0] <= scatter_plot_df.index) & (scatter_plot_df.index <= covid_period[1])
        color_mask = (self.start_date_chart_pk.date <= scatter_plot_df.index) & (
                scatter_plot_df.index <= self.end_date_chart_pk.date)

        scatter_plot_df['color'] = None
        scatter_plot_df.loc[covid_mask, 'color'] = 'covid'
        scatter_plot_df.loc[color_mask, 'color'] = 'last period'
        scatter_plot_df['color'] = scatter_plot_df['color'].fillna('rest')

        fig = px.scatter(
            data_frame=scatter_plot_df.reset_index(),
            x='surv short bond',
            y='surv long bond',
            color='color',
            template='plotly_white',
            hover_data=['date', 'surv short bond', 'surv long bond'],
            height=500,
        ).update_yaxes(tickformat='.0%').update_xaxes(tickformat='.0%')

        fig.update_layout(
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            )
        )

        return go.FigureWidget(fig)

    def make_vol_hist_plot(self, data):
        fig = data.droplevel(0, axis=1)["surv_vol"].plot(template='plotly_white').update_yaxes(tickformat='.0%')
        fig.update_layout(
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            )
        )
        return go.FigureWidget(fig)

    def make_surv_vs_price_plot(self, data):

        sec1, sec2 = data.columns.get_level_values(0).drop_duplicates()[:-1]
        y1 = data[("", 'surv_btsr')].rename('surv_btsr')
        y2 = data[(sec2, 'last_price')].rename(f'{sec2} price')
        fig = make_subplots(specs=[[{"secondary_y": True}]])

        p1 = y1.plot()
        p2 = y2.plot()
        p2.data[0].line.color = 'lightgray'
        fig = fig.add_trace(
            p1.data[0],
            secondary_y=False,
        ).add_trace(
            p2.data[0],
            secondary_y=True,
        ).update_yaxes(tickformat='.0%', secondary_y=False)
        fig.update_layout(height=500, template='plotly_white') \
            .update_yaxes(secondary_y=False, showgrid=False) \
            .update_yaxes(secondary_y=True, showgrid=False)

        fig.update_layout(
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            )
        )
        return go.FigureWidget(fig)

    def make_price_diff_surv_vol_plot(self, data):
        sec1, sec2 = data.columns.get_level_values(0).drop_duplicates()[:-1]
        y1 = data[("", 'price_diff')].rename('price diff')
        y2 = data[("", 'surv_vol')].rename(f'{sec2} surv vol')
        fig = make_subplots(specs=[[{"secondary_y": True}]])

        p1 = y1.plot()
        p2 = y2.plot()
        p2.data[0].line.color = 'lightgray'
        fig = fig.add_trace(
            p1.data[0],
            secondary_y=False,
        ).add_trace(
            p2.data[0],
            secondary_y=True,
        ).update_yaxes(tickformat='.0%', secondary_y=True)
        fig.update_layout(height=500, template='plotly_white') \
            .update_yaxes(secondary_y=False, showgrid=False) \
            .update_yaxes(secondary_y=True, showgrid=False)

        fig.update_layout(
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            )
        )
        return go.FigureWidget(fig)

    def make_fwd_plot(self, data):
        sec1, sec2 = data.columns.get_level_values(0).drop_duplicates()[:-1]
        ts_plot = pd.concat([
            data.loc[:, ([sec1, sec2], 'z_spread')].droplevel(1, axis=1),
            data.loc[:, ("", 'fwd')].rename('fwd'),
        ], axis=1)

        fig = ts_plot.plot(height=500, template='plotly_white')
        fig.update_layout(
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            )
        )
        return go.FigureWidget(fig)


SEP = ' -> '

def on_change_update_items(widget, event, data, self):
    for widget_name in ['name1_ac', 'name2_ac']:
        widget2 = getattr(self, widget_name)
        items = self.bond_ref[widget.v_model] + SEP + self.bond_ref['currency']
        widget2.items = [*items.sort_values()]


def make_grid(data):
    renderer = TextRenderer(
        format='.2f',
        horizontal_alignment="center",
    )

    pct_renderer = TextRenderer(
        format='.2%',
        horizontal_alignment="center",
    )
    pct_cols = [
        "hr",
        "surv",
    ]

    date_renderer = TextRenderer(
        format="%Y-%m-%d",
        format_type="time",
        horizontal_alignment="center",
    )

    renderers = {
        **{col: renderer for col in data.columns if data[col].dtype == 'float64'},
        ("", 'date'): date_renderer
    }
    renderers.update({col: pct_renderer for col in data if any(i in col[1] for i in pct_cols)})

    dg = DataGrid(
        data,
        selection_mode='cell',
        base_column_size=70,
        column_widths={'date': 90},
        renderers=renderers,
        editable=True,
    )
    return dg


def on_click_show(widget, event, data, self, update=False):
    widget.loading = True
    try:
        if not update:
            fwd_df = self.get_data()
        else:
            ts = self.get_dg_inputs()
            fwd_df = self.get_fwd_df(ts)
        self.dg = make_grid(self.fwd_df.sort_index(ascending=False).reset_index(col_level=1))
        self.fig = self.make_fwd_plot(fwd_df)
        self.scatter = self.make_scatter(fwd_df)
        self.price_diff_surv_vol_plot = self.make_price_diff_surv_vol_plot(fwd_df)
        self.surv_vs_price_plot = self.make_surv_vs_price_plot(fwd_df)

        display(self.dg)

        self.fig_box = v.Container(
            fluid=True,
            children=[
                v.Row(
                    children=[
                        v.Col(cols=6, children=[self.fig]),
                        v.Col(cols=6, children=[self.scatter]),
                    ]
                ),
                v.Row(
                    children=[
                        v.Col(cols=6, children=[self.price_diff_surv_vol_plot]),
                        v.Col(cols=6, children=[self.surv_vs_price_plot]),
                    ]
                ),
            ]
        )

        display(self.fig_box)

    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False
