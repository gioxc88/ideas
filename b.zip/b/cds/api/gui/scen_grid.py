from functools import partial
from io import StringIO

import blpapi
# import clarion
import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
import QuantLib as ql
from IPython.display import display
from ipydatagrid import DataGrid, TextRenderer, BarRenderer, Expr
from bqplot import LinearScale, ColorScale, OrdinalColorScale, OrdinalScale
from pandas.tseries.offsets import BDay

from .base import View, Tabs, Store, store
from ..blpw import BlpQuery

from .utils import get_bond_ref, get_bday, DatePicker
from ..utils import get_securities, today
from .collectors import CollectorL

SEP = ' -> '
bbg_dt_fmt = '%Y%m%d'


class Grid(View, CollectorL):

    def get_secs(self, n=None):

        if n:
            return getattr(self, f"name{n}_ac").v_model.split(SEP)[0]

        return self.name1_ac.v_model.split(SEP)[0], self.name2_ac.v_model.split(SEP)[0]

    def get_bbg(self, n=None):
        secs = self.get_secs(n=n)
        if n:
            typ = getattr(self, f"sec{n}_dd").v_model
            pcs = getattr(self, f"pcs{n}_tf").v_model
            if typ == 'bond':
                secs = self.bond_ref.query(f"name == '{secs}'").squeeze()['security']
            return secs, typ, pcs

        res = []
        for sec, typ, pcs in zip(secs, [self.sec1_dd.v_model, self.sec2_dd.v_model],
                                 [self.pcs1_tf.v_model, self.pcs2_tf.v_model]):
            if typ == 'bond':
                sec = self.bond_ref.query(f"name == '{sec}'").squeeze()['security']
            res.append((sec, typ, pcs))
        return res

    def make_widgets(self, **kwargs):
        sec1_dd = v.Autocomplete(
            v_model=None,
            items=['cds', 'bond'],
            label='type1',
            dense=True,
            outlined=True,
            hide_details=True
        )

        sec2_dd = v.Autocomplete(
            v_model=None,
            items=['cds', 'bond'],
            label='type2',
            dense=True,
            outlined=True,
            hide_details=True
        )

        name1_ac = v.Autocomplete(
            v_model=None,
            items=None,
            label='security1',
            dense=True,
            outlined=True,
            class_='ml-2',
            hide_details=True
        )

        name2_ac = v.Autocomplete(
            v_model=None,
            items=None,
            label='security2',
            dense=True,
            outlined=True,
            class_='ml-2',
            hide_details=True
        )

        date_pk = DatePicker(
            value=today(),
            label='start date',
            outlined=True,
        )

        # date_pk = w.DatePicker(value=today())

        pcs1_tf = v.TextField(
            v_model=None,
            label='pcs1',
            clearable=True,
            dense=True,
            outlined=True,
            class_='ml-2',
            hide_details=True
        )

        pcs2_tf = v.TextField(
            v_model=None,
            label='pcs1',
            clearable=True,
            dense=True,
            outlined=True,
            class_='ml-2',
            hide_details=True
        )

        notional1_tf = v.TextField(
            v_model=None,
            label='notional1',
            clearable=True,
            dense=True,
            outlined=True,
            # type="number",
            class_='ml-2',
            hide_details=True
        )

        notional2_tf = v.TextField(
            v_model=None,
            label='notional2',
            clearable=True,
            dense=True,
            outlined=True,
            # type="number",
            class_='ml-2',
            hide_details=True
        )

        price1_tf = v.TextField(
            v_model=None,
            label='price1',
            clearable=True,
            dense=True,
            outlined=True,
            type="number",
            class_='ml-2',
            hide_details=True
        )

        price2_tf = v.TextField(
            v_model=None,
            label='price2',
            clearable=True,
            dense=True,
            outlined=True,
            type="number",
            class_='ml-2',
            hide_details=True
        )

        spread1_tf = v.TextField(
            v_model=None,
            label='spread1',
            clearable=True,
            dense=True,
            outlined=True,
            type="number",
            class_='ml-2',
            hide_details=True
        )

        spread2_tf = v.TextField(
            v_model=None,
            label='spread2',
            clearable=True,
            dense=True,
            outlined=True,
            type="number",
            class_='ml-2',
            hide_details=True

        )

        inc_tf = v.TextField(
            v_model=25,
            label='increment',
            clearable=True,
            dense=True,
            outlined=True,
            type="number",
            class_='ml-2',
            hide_details=True
        )
        table_btn = v.Btn(
            fab=True,
            x_small=True,
            plain=True,
            left=True,
            children=[v.Icon(children=['mdi-table'])],
            class_='ml-2 my-1'
        )

        out = w.Output(layout={'justify_content': 'center'})

        self.sec1_dd = sec1_dd
        self.sec2_dd = sec2_dd
        self.name1_ac = name1_ac
        self.name2_ac = name2_ac
        self.date_pk = date_pk
        self.pcs1_tf = pcs1_tf
        self.pcs2_tf = pcs2_tf
        self.notional1_tf = notional1_tf
        self.notional2_tf = notional2_tf
        self.price1_tf = price1_tf
        self.price2_tf = price2_tf
        self.spread1_tf = spread1_tf
        self.spread2_tf = spread2_tf
        self.inc_tf = inc_tf
        self.table_btn = table_btn
        self.out = out

    def make_view(self, **kwargs):

        sec1_dd = self.sec1_dd
        sec2_dd = self.sec2_dd
        name1_ac = self.name1_ac
        name2_ac = self.name2_ac
        date_pk = self.date_pk
        pcs1_tf = self.pcs1_tf
        pcs2_tf = self.pcs2_tf
        notional1_tf = self.notional1_tf
        notional2_tf = self.notional2_tf
        price1_tf = self.price1_tf
        price2_tf = self.price2_tf
        spread1_tf = self.spread1_tf
        spread2_tf = self.spread2_tf
        inc_tf = self.inc_tf
        table_btn = self.table_btn

        self.param_box = w.VBox(
            [
                w.HBox(
                    [
                        sec1_dd,
                        name1_ac,
                        pcs1_tf,
                        notional1_tf,
                        price1_tf,
                        spread1_tf,
                    ],
                    layout=dict(margin='0 0 5px 0')
                ),
                w.HBox(
                    [
                        sec2_dd,
                        name2_ac,
                        pcs2_tf,
                        notional2_tf,
                        price2_tf,
                        spread2_tf,
                    ],
                    layout=dict(margin='0 0 5px 0')
                ),
                w.HBox(
                    [
                        date_pk.view,
                        inc_tf,
                        table_btn
                    ],
                    layout={'align_items': 'flex-end'}
                )
            ]
        )

        self.view = w.VBox([self.param_box, w.HBox([self.out], layout={'align_content': 'center'})])

    def link(self, **kwargs):
        self.sec1_dd.on_event(
            'change',
            partial(self.on_change_update_items, widget2=self.name1_ac)
        )
        self.sec2_dd.on_event(
            'change',
            partial(self.on_change_update_items, widget2=self.name2_ac)
        )

        self.table_btn.on_event(
            'click', partial(
                self.out.capture(clear_output=True)(on_click_make_grid),
                self=self
            )
        )

        self.name1_ac.on_event(
            'change',
            partial(on_change_populate, self=self, n=1)
        )

        self.name2_ac.on_event(
            'change',
            partial(on_change_populate, self=self, n=2)
        )

        self.pcs1_tf.on_event(
            'change',
            partial(on_change_populate, self=self, n=1)
        )

        self.pcs2_tf.on_event(
            'change',
            partial(on_change_populate, self=self, n=2)
        )

        self.date_pk.dp.on_event(
            'change',
            partial(on_change_populate_history, self=self)
        )

        self.date_pk.tf.on_event(
            'click:clear',
            partial(on_change_populate_history, self=self, cleared=True)
        )

    def on_change_update_items(self, widget, event, payload, widget2):
        if payload == 'bond':
            items = (self.bond_ref['name'] + SEP + self.bond_ref['currency']).sort_values()
        else:
            items = (self.cds_ref['name'] + SEP + self.cds_ref['currency']).sort_values()
        widget2.items = [*items]
        # for widget_name in ['name1_ac', 'name2_ac']:
        #     widget2 = getattr(self, widget_name)
        #     widget2.items = [*self.bond_ref[widget.v_model].sort_values()]

    def get_bond_prices(self, name, spreads, date, pcs):
        bq = self.bq
        price_field = "yas_bond_px"
        spread_field = 'yas_zspread'
        name_ = name.split(SEP)[0]
        ticker = self.bond_ref.query(f"name == '{name_}'").squeeze()['security']
        ticker = get_securities(ticker, pcs=pcs, sep='@', ensure_list=False)
        prices = bq.bdpm(
            args=[
                dict(
                    security=ticker,
                    fields=[price_field],
                    overrides={spread_field: spreads}
                ),
            ],
            common_overrides={'user_local_trade_date': f"{date:{bbg_dt_fmt}}"}
        )
        prices = prices.rename({price_field: 'price', spread_field: 'spread'}, axis=1)
        prices['spread'] = prices['spread'].astype(int)
        return prices.sort_values('spread')

    def get_cds_prices(self, name, spreads, date, pcs):
        bq = self.bq
        price_field = "upfront_last"
        spread_field = "cds_flat_spread"
        name_ = name.split(SEP)[0]
        ticker = get_securities(name_, pcs=pcs, ensure_list=False)
        # return ticker
        prices = bq.bdpm(
            args=[
                dict(
                    security=ticker,
                    fields=[price_field],
                    overrides={spread_field: spreads}
                ),
            ],
            common_overrides={'SW_CURVE_DT': f"{date:{bbg_dt_fmt}}"}
        )

        prices['price'] = 100 - prices[price_field]
        prices = prices.rename({spread_field: 'spread'}, axis=1)
        prices['spread'] = prices['spread'].astype(int)
        return prices.sort_values('spread')

    def get_all_prices(self):
        sec1 = self.sec1_dd.v_model
        sec2 = self.sec2_dd.v_model
        name1 = self.name1_ac.v_model
        name2 = self.name2_ac.v_model
        pcs1 = self.pcs1_tf.v_model
        pcs2 = self.pcs2_tf.v_model
        # notional1 = self.notional1_tf.v_model
        # notional2 = self.notional2_tf.v_model
        # price1 = self.price1_tf.v_model
        # price2 = self.price2_tf.v_model
        spread1 = int(self.spread1_tf.v_model)
        spread2 = int(self.spread2_tf.v_model)
        date = self.date_pk.date
        inc = int(self.inc_tf.v_model)

        n_inc = 10
        inc1 = make_increments(spread1, inc, n_inc, n_inc)
        inc2 = make_increments(spread2, inc, n_inc, n_inc)

        p1 = self.get_bond_prices(name=name1, spreads=inc1, date=date, pcs=pcs1) if sec1 == 'bond' \
            else self.get_cds_prices(name=name1, spreads=inc1, date=date, pcs=pcs1)

        p2 = self.get_bond_prices(name=name2, spreads=inc2, date=date, pcs=pcs2) if sec2 == 'bond' \
            else self.get_cds_prices(name=name2, spreads=inc2, date=date, pcs=pcs2)

        return p1, p2

    def make_grid(self):
        SCALE = 1e6
        notional1 = parse_number(self.notional1_tf.v_model)
        notional2 = parse_number(self.notional2_tf.v_model)
        price1 = float(self.price1_tf.v_model)
        price2 = float(self.price2_tf.v_model)

        d1, d2 = self.get_all_prices()
        self.all_prices = (d1, d2)
        p1 = d1['price'].reset_index(drop=True)
        p2 = d2['price'].reset_index(drop=True)
        s1 = ((p1 - price1) / 100 * notional1) / SCALE
        s2 = ((p2 - price2) / 100 * notional2) / SCALE
        data = pd.DataFrame(s1.to_frame().to_numpy() + s2.to_frame().to_numpy().T)
        idx = pd.MultiIndex.from_frame(pd.concat([d1['price'].round(2), d1['spread']], axis=1))
        cols = pd.MultiIndex.from_frame(pd.concat([d2['price'].round(2), d2['spread']], axis=1))
        data = data.set_axis(idx).set_axis(cols, axis=1)
        self.matrix = data

        self.dg = DataGrid(
            data,
            default_renderer=TextRenderer(format='.2f', horizontal_alignment='center'),
            base_row_header_size=65
        )
        return data

    def get_style(self, data):
        m = data
        spread1 = int(self.spread1_tf.v_model)
        spread2 = int(self.spread2_tf.v_model)

        s = m.style \
            .format('{:.2f}') \
            .format_index('{:.2f}', level=0) \
            .format_index('{:.2f}', axis=1, level=0) \
            .set_table_styles(get_selectors(padding_top=6, padding_bottom=6, padding_left=10, padding_right=10))

        loc1 = m.index[m.index.get_loc_level(spread1, level=1)[0]]
        loc2 = m.columns[m.columns.get_loc_level(spread2, level=1)[0]]
        start_index = m.index.get_loc(loc1[0])
        start_col = m.columns.get_loc(loc2[0])
        pairs_left_up = zip(range(0, start_index), range(0, start_col))
        pairs_right_down = zip(range(start_index, len(m.index)), range(start_col, len(m.columns)))
        pairs = [*pairs_left_up, *pairs_right_down]
        pairs_loc = [pd.IndexSlice[m.index[a], m.columns[b]] for a, b in pairs]

        ss = s.applymap(highlight, subset=pd.IndexSlice[loc1, :]).applymap(highlight, subset=pd.IndexSlice[:, loc2])
        for pair in pairs_loc:
            ss = ss.applymap(highlight, subset=pair, color='#98FB98')
        ss = ss.applymap(negative_red)

        return ss

    def _populate(self, n, cleared=False):
        sec = self.get_bbg(n=n)
        bq = self.bq
        price_tf = getattr(self, f'price{n}_tf')
        spread_tf = getattr(self, f'spread{n}_tf')
        date = self.date_pk.date
        typ = sec[1]

        if typ == 'bond':
            if date == today() or not date or cleared:
                res = bq.bdp(
                    [sec[0]],
                    fields={'px_last': 'price', 'z_sprd_mid': 'spread'},
                    pcs=sec[2],
                    sep='@'
                )
            else:
                res = bq.bdh(
                    [sec[0]],
                    fields={'px_last': 'price', 'z_sprd_mid': 'spread'},
                    start_date=date,
                    end_date=date,
                    pcs=sec[2],
                    sep='@'
                )
        else:
            if date == today() or not date or cleared:
                res = bq.bdp(
                    [sec[0]],
                    fields={'px_last': 'spread', 'upfront_last': 'price'},
                    pcs=sec[2]
                )
                res['price'] = 100 - res['price']
            else:
                res = bq.bdp(
                    [sec[0]],
                    fields={'cds_flat_spread': 'spread', 'cds_quoted_price': 'price'},
                    overrides=[('SW_CURVE_DT', f"{date:{bbg_dt_fmt}}")],
                    pcs=sec[2]
                )
                # res = bq.bdh(
                #     [sec[0]],
                #     fields={'px_last': 'spread', 'upfront_last': 'price'},
                #     start_date=date,
                #     end_date=date,
                #     pcs=sec[2]
                # )

        price_tf.v_model = round(res['price'], 3)
        spread_tf.v_model = round(res['spread'], 3)


def on_change_populate(widget, event, data, self, n):
    try:
        self._populate(n)
    except Exception as e:
        raise e


def on_change_populate_history(widget, event, data, self, cleared=False):
    for n in [1, 2]:
        try:
            self._populate(n, cleared=cleared)
        except Exception as e:
            print(e)
            pass


def make_increments(start, step, up, down):
    return [*range(start - step * down, start, step), *range(start, start + (step * up + 1), step)]


def on_click_make_grid(widget, event, data, self):
    widget.loading = True
    try:
        data = self.make_grid()
        style = self.get_style(data)
        secs = self.get_secs()
        display(w.HTML(f"<h3>{secs[0]} (y-axis) vs {secs[1]} (x-axis)</h3>"))
        display(style)
    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False


def hover(hover_color="#FFFAFA"):
    return [
        dict(
            selector="tr:hover",
            props=[("background-color", "%s" % hover_color)]
        ),
        dict(
            selector="th:hover",
            props=[("background-color", "%s" % hover_color)]
        ),
    ]


def highlight(s, color="#ffff99"):
    return f'background-color: {color}'


def negative_red(val):
    """
    Takes a scalar and returns a string with
    the css property `'color: red'` for negative
    strings, black otherwise.
    """
    color = 'red' if val < 0 else 'black'
    return f'color: {color}'


def get_selectors(
        hover_color='#F5F5F5',
        line_height=12,
        header_font_size=12,
        data_font_size=12,
        padding_top=2.5,
        padding_bottom=2.5,
        padding_left=2.5,
        padding_right=2.5,
        padding=None
):
    if padding:
        padding_top = padding_bottom = padding_left = padding_right = padding

    th_props = [
        ('font-size', f'{header_font_size}px'),
        ('text-align', 'center'),
        ('font-weight', 'bold'),
        # ('color', '#6d6d6d'),
        ('background-color', '#f7f7f9'),
        ('border-bottom', '1px solid  #d7d7d7'),
        ('white-space', 'nowrap !important')
    ]

    tr_props = [
        ("line-height", f"{line_height}px"),
        # ('border-color', 'white'),
        ('background-color', 'white'),
        ('border-bottom', '1px solid  #d7d7d7'),
        # ('white-space', 'nowrap !important')
    ]
    td_props = [
        ('font-size', f'{data_font_size}px'),
        ('white-space', 'nowrap !important')
    ]

    selectors = [
        {"selector": "tr", "props": tr_props},
        {"selector": "td, th",
         "props": f"line-height: inherit; padding-top: {padding_top}px; padding-bottom: {padding_bottom}px; padding-left: {padding_left}px; padding-right: {padding_right}px;"},
        {'selector': 'th', 'props': th_props},
        {'selector': 'td', 'props': td_props},
        *hover(hover_color)
    ]
    return selectors


mult_map = {
    'k': 1e3,
    'm': 1e6,
}


def parse_number(x):
    if isinstance(x, str):
        x, m = float(x[:-1]), x[-1]
        x = x * mult_map[m]
        return x if x % 1 else int(x)
    return x

# SEP = ' -> '
# self.sec1_dd.fire_event('change', 'bond')
# self.sec2_dd.fire_event('change', 'bond')
# self.sec1_dd.v_model = 'bond'
# self.sec2_dd.v_model = 'bond'
# self.name1_ac.v_model = 'COLOM 3 7/8 04/25/27 -> USD'
# self.name2_ac.v_model = 'COLOM 3 7/8 02/15/61 -> USD'
# self.pcs1_tf.v_model = 'BGN' # 'MSG1'
# self.pcs2_tf.v_model = 'BGN'
# self.notional1_tf.v_model = -15000000
# self.notional2_tf.v_model = 15000000
# self.price1_tf.v_model = 82
# self.price2_tf.v_model = 48
# self.spread1_tf.v_model = 465
# self.spread2_tf.v_model = 500
# self.inc_tf.v_model = 25
# self.date_pk.dp.v_model = '2022-10-18'
