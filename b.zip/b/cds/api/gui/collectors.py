import pandas as pd

class Collector:
    @property
    def bond_hist(self):
        return self.store.data['bond_hist'] if getattr(self, '_bond_hist', None) is None else self._bond_hist

    @property
    def cds_ref(self):
        return self.store.data['cds_ref'] if getattr(self, '_cds_ref', None) is None else self._cds_ref


    @property
    def bq(self):
        return self.store.bq if getattr(self, '_bq', None) is None else self._bq


class CollectorH(Collector):
    # @property
    # def bond_ref(self):
    #     if hasattr(self, 'date_pk'):
    #         date = self.date_pk.date
    #     else:
    #         date = today() - BDay()
    #     bond_ref = get_bond_ref(date=date)
    #     return bond_ref.loc[~bond_ref['security'].isin(bond_ref['bmk_bond'])]
    @property
    def bond_ref(self):
        return self.store.data['bond_ref_hist'] if getattr(self, '_bond_ref', None) is None else self._bond_ref

    @bond_ref.setter
    def bond_ref(self, value):
        if getattr(self, '_bond_ref', None) is None:
            self.store.data['bond_ref_hist'] = value
        else:
            self._bond_ref = value

    def get_bond_ref(self, date=None):
        if not date:
            if hasattr(self, 'date_pk'):
                date = self.date_pk.date
            else:
                date = pd.Timestamp.today().floor('d') - BDay()
        bond_ref = get_bond_ref(date=date)
        return bond_ref.loc[~bond_ref['security'].isin(bond_ref['bmk_bond'])]

    @property
    def issuers_curves(self):
        return self.store.data['issuers_curves_hist'] if getattr(self, '_issuers_curves', None) is None else self._issuers_curves

    @issuers_curves.setter
    def issuers_curves(self, value):
        if getattr(self, '_issuers_curves', None) is None:
            self.store.data['issuers_curves_hist'] = value
        else:
            self._issuers_curves = value


class CollectorL(Collector):
    # @property
    # def bond_ref(self):
    #     if hasattr(self, 'date_pk'):
    #         date = self.date_pk.date
    #     else:
    #         date = today() - BDay()
    #     bond_ref = get_bond_ref(date=date)
    #     return bond_ref.loc[~bond_ref['security'].isin(bond_ref['bmk_bond'])]
    @property
    def bond_ref(self):
        return self.store.data['bond_ref'] if getattr(self, '_bond_ref', None) is None else self._bond_ref

    @bond_ref.setter
    def bond_ref(self, value):
        if getattr(self, '_bond_ref', None) is None:
            self.store.data['bond_ref'] = value
        else:
            self._bond_ref = value

    @property
    def issuers_curves(self):
        return self.store.data['issuers_curves'] if getattr(self, '_issuers_curves',
                                                                 None) is None else self._issuers_curves

    @issuers_curves.setter
    def issuers_curves(self, value):
        if getattr(self, '_issuers_curves', None) is None:
            self.store.data['issuers_curves'] = value
        else:
            self._issuers_curves = value