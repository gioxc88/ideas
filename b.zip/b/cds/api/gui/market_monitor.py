import json
import sys
import re
import os
from pathlib import Path
from itertools import chain
from functools import partial
from io import StringIO
from numbers import Number

import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
import QuantLib as ql
from IPython.display import display
from ipydatagrid import DataGrid, TextRenderer, BarRenderer, Expr
from bqplot import LinearScale, ColorScale, OrdinalColorScale, OrdinalScale

from .base import View, Tabs, years_to_maturity_col
from .utils import get_issuers_curves
from ..blpw import BlpQuery
from ..bbg import BBGField, BBGOverrides
from ..data.base import data_path, tables
from ..data.utils import add_pcs, make_rating_categories
from ..utils import parse_offset, get_securities, unparse_results_securities

from ..data.processing import (
    add_years_to_maturity,
    add_maturity_bucket,
    add_custom_rating,
    add_rating_bucket,
    add_geo_area
)
from .collectors import CollectorL

dt_fmt = '%Y-%m-%d'
bbg_dt_fmt = '%Y%m%d'


maturity_thresholds = {
    2: 0.5,
    3: 1,
    5: 1,
    7: 1.5,
    10: 3.5,
    20: 3,
    30: 7,
    50: 10,
}


def get_interval_fields(name, field, base_name, intervals, **kwargs):
    return [
        {
            "field": f"interval_{name}",
            "name": f"{base_name}_{name}_{i}",
            "overrides": [
                ("MARKET_DATA_OVERRIDE", field),
                ("CALC_INTERVAL", i),
                *[*kwargs.items()],
            ]
        } for i in intervals
    ]


def on_click_download(widget, event, payload, self):
    widget.loading = True
    try:
        self.download()
    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False


class CurvesViewer(View, CollectorL):

    _default_maturities = [2, 3, 5, 7, 10, 30, 50]

    def get_curves(self):
        bond_ref = self.bond_ref
        maturities = [int(i) for i in self.maturity_cb.v_model] if hasattr(self, 'maturity_cb') else self._default_maturities
        curves = {
            cur: get_issuers_curves(
                bond_ref,
                maturities=maturities,
                currency=cur,
                thresholds=maturity_thresholds
            )
            for cur in bond_ref['currency'].drop_duplicates()
        }
        curves = {cur: df for cur, df in curves.items() if not df.empty}
        self.issuers_curves = curves

    def __init__(self, bond_ref=None, issuers_curves=None, **kwargs):
        super().__init__(**kwargs)
        self._bond_ref = bond_ref
        self._issuers_curves = issuers_curves

    def build(self, **kwargs):
        self.get_curves()
        super().build(**kwargs)

    def reset_curves(self):

        maturities = [int(i) for i in self.maturity_cb.v_model] if hasattr(self,
                                                                           'maturity_cb') else self._default_maturities

        issuers_curves = {cur: get_issuers_curves(self.bond_ref, maturities=maturities, currency=cur, thresholds=maturity_thresholds) for cur in
                          self.bond_ref['currency'].drop_duplicates()}
        self.store.data['issuers_curves'] = issuers_curves

    def parse_ta(self):
        return pd.read_csv(StringIO(self.sub_ta.v_model), header=None, skipinitialspace=True).set_axis(
            ['currency', 'ticker', 'maturity_label', 'security'], axis=1)

    def override(self):
        bond_ref = self.bond_ref
        ic = self.store.data['issuers_curves']
        for index, row in self.parse_ta().iterrows():
            curve_df = ic[row[0]]
            mask = pd.concat([curve_df[key] == value for key, value in row[1:-1].items()], axis=1).all(axis=1)
            to_sub = curve_df.loc[mask].squeeze()
            sub = bond_ref.query(f"security == '{row[-1]}'").squeeze()

            if to_sub.empty:
                pass
            else:
                if sub.empty:
                    curve_df.loc[curve_df['security'] == to_sub['security'], 'security'] = row[-1]
                else:
                    sub['maturity_label'] = row['maturity_label']
                    sub = sub
                    curve_df.drop(to_sub.name, inplace=True)
                    curve_df.loc[sub.name] = sub

    def make_widgets(self, **kwargs):
        curr_sel = v.Autocomplete(
            v_model='USD',
            items=[*self.issuers_curves],
            label='currency',
            dense=True,
            outlined=True
        )

        maturity_cb = v.Combobox(
            v_model=self._default_maturities,
            items=None,
            multiple=True,
            small_chips=True,
            deletable_chips=True,
            outlined=True,
            dense=True,
            clearable=True,
            label="maturities"
        )

        build_curve_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-vector-curve'])]
        )

        sub_ta = v.Textarea(
            v_model=None,
            label='override',
            outlined=True,
            dense=True,
            clearable=True,
            auto_grow=True,
            rows=3,
        )

        ovrd_btn = v.Btn(
            fab=True,
            x_small=True,
            plain=True,
            class_='mb-1 ml-2',
            children=[v.Icon(children=['mdi-skip-forward'])]
        )

        reset_btn = v.Btn(
            fab=True,
            x_small=True,
            plain=True,
            class_='mt-1 ml-2',
            children=[v.Icon(children=['mdi-skip-backward'])]
        )

        hint_html = w.HTML(
            '''
                <b>Syntax</b>: currency, issuer, maturity, new_id 
                <br> 
                <b>Example</b>: USD, MEX, 5, BT316586 Corp
            ''')


        self.sub_ta = sub_ta
        self.ovrd_btn = ovrd_btn
        self.reset_btn = reset_btn

        self.curr_sel = curr_sel
        self.maturity_cb = maturity_cb
        self.build_curve_btn = build_curve_btn
        self.sub_ta = sub_ta
        self.ovrd_btn = ovrd_btn
        self.reset_btn = reset_btn
        self.hint_html = hint_html

        self.out = w.Output()

    def make_view(self, **kwargs):
        curr_sel = self.curr_sel
        maturity_cb = self.maturity_cb
        build_curve_btn = self.build_curve_btn
        sub_ta = self.sub_ta
        ovrd_btn = self.ovrd_btn
        reset_btn = self.reset_btn
        hint_html = self.hint_html

        self.param_box = v.Container(
            fluid=True,
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=3,
                            children=[curr_sel],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=5,
                            children=[maturity_cb],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1.0,
                            children=[build_curve_btn],
                            class_="my-0 py-0"
                        ),
                    ]
                ),
                v.Row(
                    children=[
                        v.Col(children=[sub_ta], cols=3),
                        v.Col(children=[w.VBox([ovrd_btn, reset_btn])], cols=1.0),
                        v.Col(children=[hint_html], cols=3),
                    ]
                )
            ]
        )

        self.view = w.VBox(
            [
                self.param_box,
                self.out
            ]
        )

    def link(self, **kwargs):
        curr_sel = self.curr_sel
        build_curve_btn = self.build_curve_btn
        out = self.out
        sub_ta = self.sub_ta
        ovrd_btn = self.ovrd_btn
        reset_btn = self.reset_btn

        curr_sel.on_event(
            'change',
            partial(
                out.capture(clear_output=True)(on_change_dg),
                self=self
            )
        )
        # curr_sel.fire_event('change', None)

        build_curve_btn.on_event(
            'click',
            partial(
                onclick_rebuild_curves,
                self=self
            )
        )

        ovrd_btn.on_event(
            'click',
            partial(
                on_click_override,
                self=self
            )
        )

        reset_btn.on_event(
            'click',
            partial(
                on_click_reset,
                self=self
            )
        )

        super().link()


def onclick_rebuild_curves(widget, event, payload, self):
    widget.loading = True
    try:
        self.get_curves()
        self.curr_sel.fire_event('change', None)
    except Exception:
        pass
    finally:
        widget.loading = False


def on_change_dg(widget, event, data, self):
    widget.loading = True
    try:
        float_renderer = TextRenderer(
            text_value=Expr("format(cell.value, '.2f')"),
        )

        dg = DataGrid(

            self.issuers_curves[self.curr_sel.v_model].set_index('name'),
            selection_mode='cell',
            base_column_size=90,
            renderers={years_to_maturity_col: float_renderer},
            column_widths={
                'name': 150,
                'security': 110,
                'isin': 110
            }
        )
        # dg.auto_fit_columns = True
        display(w.HTML('<b>CURVES</b>'))
        display(dg)
        # dgb = DataGrid(
        #     self.bond_ref.set_index('name'),
        #     selection_mode='cell',
        #     base_column_size=90,
        #     renderers={years_to_maturity_col: float_renderer},
        #     column_widths={
        #         'name': 150,
        #         'security': 110,
        #         'isin': 110
        #     }
        # )
        #
        # display(w.HTML('<br> <br> <b>BONDS</b>'))
        # display(dgb)

    except Exception:
        pass
    finally:
        widget.loading = False


def make_datagrid(data, field=None):
    if data.index.nlevels > 1:
        data = data.reset_index(level=[*range(1, data.index.nlevels)])

    field = field or ''
    renderers = {
        col: BarRenderer(
            text_value=Expr("format(cell.value, '.2f')"),
            text_color=Expr('"red" if cell.value < 0 else default_value'),
            horizontal_alignment="center",
            # bar_horizontal_alignment="center",
            bar_color=ColorScale(min=data[col].quantile(0.1), mid=0 if 'change' in field else None,
                                 max=data[col].quantile(0.9)),
            bar_value=LinearScale(min=data[col].quantile(0.1), mid=0 if 'change' in field else None,
                                  max=data[col].quantile(0.9))
        ) for col in data if data[col].dtype == 'float64'
    }

    dg = DataGrid(
        data,
        renderers=renderers,
        editable=False,
        selection_mode='cell',
        base_column_size=100,
    )

    copy_btn = v.Btn(
        fab=True,
        # small=True,
        x_small=True,
        plain=True,
        class_='ma-2',
        children=[v.Icon(children=['mdi-content-copy'])]
    )

    copy_btn.on_event('click', lambda widget, event, payload: data.to_clipboard())
    box = w.VBox([copy_btn, dg])

    # dg.auto_fit_columns = True
    # return [dg]
    return box


def get_pivot(df, field, index, columns, filters=None):
    if filters:
        q = ' and '.join([f"{key} == {value}" for key, value in filters.items()])
        df = df.query(q)

    return df.pivot_table(
        values=field,
        index=index,
        columns=columns
    )


def make_slopes_df(pivot_df, slopes=None):

    _default_slopes = [5, 10, 30]
    if not pivot_df.columns.isin(_default_slopes).all():
        if pivot_df.shape[1] > 4:
            _default_slopes = [*pivot_df.columns[[1, -2, -3]]]
        else:
            _default_slopes = [*pivot_df.columns[[0, 1, -1]]]

    slopes = slopes or [
        (_default_slopes[1], _default_slopes[2]),
        (_default_slopes[0], _default_slopes[1]),
        (_default_slopes[0], _default_slopes[1], _default_slopes[2])
    ]

    slope_series = []
    for slope in slopes:
        if len(slope) == 2:
            s = pivot_df[slope[1]] - pivot_df[slope[0]]
            slope_series.append(s.rename(f"{slope[1]} - {slope[0]}"))
        else:
            s = pivot_df[slope[0]] - 2 * pivot_df[slope[1]] + pivot_df[slope[2]]
            slope_series.append(s.rename(f"{slope[0]} - 2*{slope[1]} + {slope[2]}"))

    return pd.concat(slope_series, axis=1).dropna(how='all')


def make_pct_grid(data):
    renderer = BarRenderer(
        text_value=Expr("format(cell.value, '.2%')"),
        horizontal_alignment="center",
        # bar_horizontal_alignment="center",
        bar_color=ColorScale(min=0, max=1),
        bar_value=LinearScale(min=0, max=1)
    )

    dg = DataGrid(
        data,
        default_renderer=renderer,
        selection_mode='cell',
        base_column_size=100
    )

    return dg


def get_slope_pct(slopes_df):
    s = np.sign(slopes_df).replace({-1: 'negative', 1: 'positive', np.nan: 'NA'})
    return s.apply(lambda series: series.value_counts(dropna=False, normalize=True))


def on_click_make_pivot(widget, event, payload, self):
    # data = get_issuers_curves(bond_ref, currency=self.curr_sel.v_model)
    # data = data.merge(mkt, on='security', how='left')
    widget.loading = True
    try:
        data = self.get_data()

        pivot_df = get_pivot(
            df=data,
            field=self.value_sel.v_model,
            index=self.index_ac.v_model,
            columns=self.cols_ac.v_model
        )

        try:
            offset = parse_offset(self.value_sel.v_model.split('_')[-1], b=True)
            print(f"changes from {pd.Timestamp.today().floor('d') - offset + pd.tseries.offsets.BDay():%d %b %Y}")
        except Exception:
            pass

        dg = make_datagrid(pivot_df, self.value_sel.v_model)
        self._pivot = pivot_df
        self.dg1 = dg

        # display(dg)

        if self.cols_ac.v_model == 'maturity_label':
            slopes_df = make_slopes_df(pivot_df, slopes=self.parse_slopes())
            self._slopes = slopes_df
            dg2 = make_datagrid(slopes_df)
            self.dg2 = dg2

            slopes_pct_df = get_slope_pct(slopes_df)
            self._slopes_pct = slopes_pct_df

            dg3 = make_pct_grid(slopes_pct_df)

            # display(box)

            box = v.Container(
                fluid=True,
                children=[
                    v.Row(
                        children=[
                            v.Col(children=[dg], cols=7),
                            v.Col(children=[dg2], cols=5),
                        ]
                    ),
                    v.Row(
                        children=[
                            v.Col(children=[dg3], cols=5, offset=7),
                        ]
                    )
                ]
            )
            # box = w.HBox(children=[*dg, *dg2])
            display(box)
        else:
            display(dg)
    finally:
        widget.loading = False


class Pivot(View, CollectorL):

    fields_mapping = {
        "blp_z_sprd_mid": "z_spread_mid",
        "yld_ytm_mid": "yield_to_maturity",
        "px_last": "price",
        "z_sprd_mid": "z_sprd_mid"
    }

    def __init__(self, issuers_curves=None, mkt=None, **kwargs):
        super().__init__(**kwargs)
        self._issuers_curves = issuers_curves
        self.mkt = mkt

    def get_data(self):
        try:
            mkt = self.store.data['mkt']
        except KeyError:
            mkt = self.mkt

        if not self.curr_sel.v_model:
            data = pd.concat(self.issuers_curves.values())
        else:
            data = self.issuers_curves[self.curr_sel.v_model]
        data = data.merge(mkt, on='security', how='left')
        return data

    def make_widgets(self, **kwargs):
        curr_sel = v.Autocomplete(
            v_model=None,
            items=[*self.issuers_curves.keys()],
            label='currency',
            dense=True,
            outlined=True,
            small_chips=True,
            clearable=True,
        )

        value_sel = v.Autocomplete(
            v_model='z_spread',
            # items=[field.name for field in bbg_fields],
            label='field',
            dense=True,
            outlined=True,
            small_chips=True,
        )

        index_ac = v.Autocomplete(
            v_model=['ticker', 'currency', 'rating_bucket'],
            label='index',
            items=[
                'ticker',
                'country_name',
                'currency',
                'region',
                'subregion',
                'rating_bucket',
            ],
            outlined=True,
            multiple=True,
            chips=True,
            small_chips=True,
            dense=True,
            clearable=True,
            deletable_chips=True
            # style_='width: 250px',
            # class_='ma-0 pa-0'
        )

        cols_ac = v.Autocomplete(
            v_model='maturity_label',
            label='cols',
            items=['maturity_label', 'rating_bucket'],
            outlined=True,
            # multiple=True,
            chips=True,
            small_chips=True,
            dense=True,
            clearable=True,
            # style_='width: 250px',
            # class_='ma-0 pa-0'
        )

        slopes_ta = v.Textarea(
            v_model=None,
            outlined=True,
            dense=True,
            label='slopes',
            clearable=True,
            auto_grow=False,
            rows=3,
            no_resize=True
        )

        table_btn = v.Btn(
            fab=True,
            small=True,
            plain=True,
            left=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-table'])]
        )

        pcs_tf = v.TextField(
            v_model='BGN',
            label='pcs',
            clearable=True,
            dense=True,
            outlined=True,

        )

        sep_tf = v.TextField(
            v_model='@',
            label='sep',
            clearable=True,
            dense=True,
            outlined=True,
            disabled=True
        )

        interval_cb = v.Combobox(
            v_model=None,  # ["12m", "ytd", "6m", "3m", "1m", "1w", "2d"],
            items=["12m", "ytd", "6m", "3m", "1m", "1w", "2d"],
            multiple=True,
            small_chips=True,
            deletable_chips=True,
            outlined=True,
            dense=True,
            clearable=True,
            label="intervals"
        )

        fields_cb = v.Combobox(
            v_model=[*self.fields_mapping],  # ["blp_z_sprd_mid", "yld_ytm_mid", "px_last"],
            items=[*self.fields_mapping],
            multiple=True,
            small_chips=True,
            deletable_chips=True,
            outlined=True,
            dense=True,
            clearable=True,
            label="fields"
        )

        dl_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-download'])]
        )

        out = w.Output()

        self.curr_sel = curr_sel
        self.value_sel = value_sel
        self.index_ac = index_ac
        self.cols_ac = cols_ac
        self.slopes_ta = slopes_ta
        self.table_btn = table_btn



        self.pcs_tf = pcs_tf
        self.sep_tf = sep_tf
        self.interval_cb = interval_cb
        self.fields_cb = fields_cb
        self.dl_btn = dl_btn


        self.out = out

    def make_view(self, **kwargs):
        curr_sel = self.curr_sel
        value_sel = self.value_sel
        index_ac = self.index_ac
        cols_ac = self.cols_ac
        slopes_ta = self.slopes_ta
        table_btn = self.table_btn

        pcs_tf = self.pcs_tf
        sep_tf = self.sep_tf
        interval_cb = self.interval_cb
        fields_cb = self.fields_cb
        dl_btn = self.dl_btn

        out = self.out

        param_box = v.Container(
            fluid=True,
            children=[
                v.Row(
                    children=[

                        v.Col(
                            cols=1.0,
                            children=[pcs_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1.0,
                            children=[sep_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=3,
                            children=[fields_cb],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=3,
                            children=[interval_cb],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1.0,
                            children=[dl_btn],
                            class_="my-0 py-0"
                        ),
                    ]
                ),
                v.Row(
                    children=[
                        v.Col(
                            cols=6,
                            children=[
                                v.Row(
                                    children=[

                                        v.Col(
                                            cols=6,
                                            children=[curr_sel],
                                            class_="my-0 py-0"
                                        ),
                                        v.Col(
                                            cols=6,
                                            children=[value_sel],
                                            class_="my-0 py-0"
                                        ),
                                    ]
                                ),
                                v.Row(
                                    children=[
                                        v.Col(
                                            cols=6,
                                            children=[index_ac],
                                            class_="my-0 py-0"
                                        ),
                                        v.Col(
                                            cols=6,
                                            children=[cols_ac],
                                            class_="my-0 py-0"
                                        ),
                                        ],
                                )
                            ],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[slopes_ta],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1,
                            children=[table_btn],
                            class_="my-0 py-0"
                        ),
                    ]
                ),

            ]
        )

        view = w.VBox(
            children=[
                param_box,
                out,
            ]
        )

        self.param_box = param_box
        self.view = view

    def link(self, **kwargs):
        # curr_sel = self.curr_sel
        value_sel = self.value_sel
        index_ac = self.index_ac
        cols_ac = self.cols_ac
        slopes_ta = self.slopes_ta
        table_btn = self.table_btn
        out = self.out
        pcs_tf = self.pcs_tf
        sep_tf = self.sep_tf
        interval_cb = self.interval_cb
        fields_cb = self.fields_cb
        dl_btn = self.dl_btn

        dl_btn.on_event(
            'click',
            partial(
                out.capture(clear_output=True)(on_click_download),
                self=self
            )
        )

        table_btn.on_event(
            'click',
            partial(
                out.capture(clear_output=True)(on_click_make_pivot),
                self=self
            )
        )
        super().link()

    def parse_slopes(self):
        slopes_ta = self.slopes_ta
        if not slopes_ta.v_model:
            return
        try:
            slopes = pd.read_csv(StringIO(slopes_ta.v_model), names=range(3))
        except Exception:
            slopes = pd.read_csv(StringIO(slopes_ta.v_model), names=range(2))
        return [tuple(row.dropna().astype(int)) for index, row in slopes.iterrows()]

    def make_fields(self):
        return [*chain.from_iterable([
            [
                {"field": field, "name": self.fields_mapping.get(field, field)},
                *(get_interval_fields(
                    name='net_change',
                    field=field,
                    base_name=self.fields_mapping.get(field, field),
                    intervals=self.interval_cb.v_model,
                ) if self.interval_cb.v_model else [])
            ] for field in self.fields_cb.v_model])]

    def get_bbg_securities(self):
        securities = pd.concat([value['security'] for key, value in self.issuers_curves.items()]).drop_duplicates()
        securities = get_securities(securities, pcs=self.pcs_tf.v_model, sep=self.sep_tf.v_model)
        return securities

    def get_bbg_fields(self):
        fields = self.make_fields()
        bbg_fields = [
            BBGField(
                field=field['field'],
                name=field['name'],
                overrides=BBGOverrides(**dict(field['overrides'])) if field.get('overrides') else None
            ) for field in fields
        ]
        return bbg_fields

    def download(self):
        bq = self.bq
        securities = self.get_bbg_securities()
        bbg_fields = self.get_bbg_fields()
        mkt = bq.bdpy(securities=securities, bbg_fields=bbg_fields)
        mkt = unparse_results_securities(mkt, pcs=self.pcs_tf.v_model, sep=self.sep_tf.v_model)
        self.mkt = mkt
        self.store.data['mkt'] = mkt
        try:
            self.value_sel.items = [*mkt.columns[1:]]
        except Exception as e:
            raise e


def on_click_override(widget, event, data, self):
    widget.loading = True
    try:
        self.override()
    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False


def on_click_reset(widget, event, data, self):
    widget.loading = True
    try:
        self.reset_curves()
    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False
