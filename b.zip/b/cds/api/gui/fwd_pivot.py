from itertools import chain, combinations
from functools import partial
from io import StringIO

import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
from IPython.display import display
from ipydatagrid import DataGrid, TextRenderer, BarRenderer, Expr
from bqplot import LinearScale, ColorScale, OrdinalColorScale, OrdinalScale
from pandas.tseries.offsets import BDay

from .base import View, Tabs
from .market_monitor import get_issuers_curves
from .market_monitor_h import get_bond_ref, DatePicker
from ..utils import parse_offset



maturity_thresholds = {
    2: 0.5,
    3: 1,
    5: 1,
    7: 1.5,
    10: 3.5,
    20: 3,
    30: 7,
    50: 10,
}


def get_fwd_z_spread(bonds, cols=None):
    bonds = bonds.sort_values('years_to_workout')
    cols = cols or [*bonds.columns]
    risk_ratio = bonds.iloc[0]['risk'] / bonds.iloc[1]['risk']
    fwd = (bonds.iloc[1]['z_spread'] - bonds.iloc[0]['z_spread'] * risk_ratio) / (1 - risk_ratio)
    name = f"{bonds.iloc[0]['maturity_label']}y{bonds.iloc[1]['maturity_label'] - bonds.iloc[0]['maturity_label']}y"
    fwd_series = bonds.iloc[0][cols]
    fwd_series['z_spread'] = fwd
    fwd_series['maturity_label'] = name
    return fwd_series


class PivotForward(View):
    _default_maturities = [2, 5, 10]

    def __init__(self, bond_ref=None, bond_hist=None, issuers_curves=None, **kwargs):
        super().__init__(**kwargs)
        self._bond_ref = bond_ref
        self._bond_hist = bond_hist
        self._issuers_curves = issuers_curves

    def build(self, **kwargs):
        self.get_curves()
        super().build(**kwargs)

    def get_curves(self):
        bond_ref = self.bond_ref

        maturities = [int(i) for i in self.maturity_cb.v_model] if hasattr(self,
                                                                           'maturity_cb') else self._default_maturities
        curves = {
            cur: get_issuers_curves(
                bond_ref,
                maturities=maturities,
                currency=cur,
                thresholds=maturity_thresholds
            )
            for cur in bond_ref['currency'].drop_duplicates()
        }
        curves = {cur: df for cur, df in curves.items() if not df.empty}
        return curves

    @property
    def bond_ref(self):
        if hasattr(self, 'date_pk'):
            date = self.date_pk.date
        else:
            date = pd.Timestamp.today().floor('d')
        bond_ref = get_bond_ref(date=date)
        bond_ref = bond_ref.loc[~bond_ref['security'].isin(bond_ref['bmk_bond'])]
        return bond_ref

    @property
    def bond_hist(self):
        return self.store.data['bond_hist'] if self._bond_hist is None else self._bond_hist

    @property
    def issuers_curves(self):
        return self.get_curves()

    def make_widgets(self, **kwargs):
        maturity_cb = v.Combobox(
            v_model=self._default_maturities,
            items=None,
            multiple=True,
            small_chips=True,
            deletable_chips=True,
            outlined=True,
            dense=True,
            clearable=True,
            label="maturities"
        )

        date_pk = DatePicker(
            value=pd.Timestamp.today(),
            label='date',
            outlined=True
        )

        curr_sel = v.Autocomplete(
            v_model=None,
            items=[*self.issuers_curves.keys()],
            label='currency',
            dense=True,
            outlined=True,
            clearable=True,
        )

        index_ac = v.Autocomplete(
            v_model=['ticker', 'currency', 'rating_bucket'],
            label='index',
            items=[
                'ticker',
                'country_name',
                'currency',
                'region',
                'subregion',
                'rating_bucket',
            ],
            outlined=True,
            multiple=True,
            chips=True,
            small_chips=True,
            dense=True,
            clearable=True,
            deletable_chips=True
            # style_='width: 250px',
            # class_='ma-0 pa-0'
        )

        cols_ac = v.Autocomplete(
            v_model='maturity_label',
            label='cols',
            items=['maturity_label', 'rating_bucket'],
            outlined=True,
            # multiple=True,
            dense=True,
            clearable=True,
            # style_='width: 250px',
            # class_='ma-0 pa-0'
        )

        slopes_ta = v.Textarea(
            v_model=None,
            outlined=True,
            dense=True,
            label='slopes',
            clearable=True,
            auto_grow=False,
            rows=4,
            no_resize=True
        )

        table_btn = v.Btn(
            fab=True,
            small=True,
            plain=True,
            left=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-table'])]
        )

        pcs_tf = v.TextField(
            v_model='BGN',
            label='pcs',
            clearable=True,
            dense=True,
            outlined=True,

        )

        change_cb = v.Combobox(
            v_model=None,  # ["12m", "ytd", "6m", "3m", "1m", "1w", "2d"],
            multiple=False,
            outlined=True,
            dense=True,
            clearable=True,
            label="change"
        )

        field_ac = v.Autocomplete(
            v_model='z_spread',  # ["blp_z_sprd_mid", "yld_ytm_mid", "px_last"],
            items=['z_spread'],
            multiple=False,
            outlined=True,
            dense=True,
            clearable=True,
            label="field"
        )

        dl_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-download'])]
        )

        self.curr_sel = curr_sel
        self.field_ac = field_ac
        self.index_ac = index_ac
        self.cols_ac = cols_ac
        self.slopes_ta = slopes_ta
        self.table_btn = table_btn
        self.pcs_tf = pcs_tf
        self.change_cb = change_cb
        self.dl_btn = dl_btn
        self.maturity_cb = maturity_cb
        self.date_pk = date_pk

        self.out = w.Output()

    def make_view(self, **kwargs):
        curr_sel = self.curr_sel
        maturity_cb = self.maturity_cb
        date_pk = self.date_pk
        field_ac = self.field_ac
        index_ac = self.index_ac
        cols_ac = self.cols_ac
        slopes_ta = self.slopes_ta
        table_btn = self.table_btn
        pcs_tf = self.pcs_tf
        change_cb = self.change_cb

        self.param_box = v.Container(
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=2,
                            children=[date_pk.view],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=5,
                            children=[maturity_cb],
                            class_="my-0 py-0"
                        ),
                    ]
                ),
                v.Row(
                    children=[
                        v.Col(
                            cols=7,
                            children=[
                                v.Row(
                                    children=[

                                        v.Col(
                                            cols=3,
                                            children=[pcs_tf],
                                            class_="my-0 py-0"
                                        ),
                                        v.Col(
                                            cols=5,
                                            children=[field_ac],
                                            class_="my-0 py-0"
                                        ),
                                        v.Col(
                                            cols=4,
                                            children=[change_cb],
                                            class_="my-0 py-0"
                                        ),
                                        # v.Col(
                                        #     cols=1.0,
                                        #     children=[dl_btn],
                                        #     class_="my-0 py-0"
                                        # ),
                                    ]
                                ),
                                v.Row(
                                    children=[
                                        v.Col(
                                            cols=3,
                                            children=[curr_sel],
                                            class_="my-0 py-0"
                                        ),
                                        v.Col(
                                            cols=6,
                                            children=[index_ac],
                                            class_="my-0 py-0"
                                        ),
                                        v.Col(
                                            cols=3,
                                            children=[cols_ac],
                                            class_="my-0 py-0"
                                        )
                                        # v.Col(
                                        #     cols=1,
                                        #     children=[table_btn],
                                        #     class_="my-0 py-0"
                                        # ),
                                    ],
                                ),
                            ],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[slopes_ta],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1.0,
                            children=[table_btn],
                            class_="my-0 py-0"
                        ),
                    ]
                )
            ]
        )

        self.view = w.VBox(
            [
                self.param_box,
                self.out
            ]
        )

    def link(self):

        out = self.out
        table_btn = self.table_btn

        table_btn.on_event(
            'click',
            partial(
                out.capture(clear_output=True)(on_click_make_pivot),
                self=self
            )
        )
        super().link()

    def get_mkt_data(self, date=None):
        relevant_fields = [
            'security',
            'z_spread',
            'risk',
        ]

        date = date or get_bday(self.date_pk.date)
        source = self.pcs_tf.v_model
        ic = pd.concat(self.get_curves().values())
        mkt_data = self.bond_hist.query(
            f"date == {date:%Y%m%d} and source == '{source}' and security in {[*ic['security'].unique()]}")[
            relevant_fields]
        data = ic.merge(mkt_data, on='security', how='left')
        return data

    def get_fwd_df(self, mkt_data=None, date=None):

        data = mkt_data if mkt_data is not None else self.get_mkt_data(date=date)
        fwds = []

        for index, group in data.groupby(['ticker', 'currency'], sort=False):
            if len(group) > 1:
                combs = combinations(range(len(group)), 2)
                for comb in combs:
                    bonds = group.iloc[[*comb], :]
                    fwd = get_fwd_z_spread(bonds, self.index_ac.items)
                    fwds.append(fwd)
        fwd_df = pd.concat(fwds, axis=1).T
        self.fwd_df = fwd_df
        return fwd_df

    def get_data(self):

        fwd_data = self.get_fwd_df()

        if self.change_cb.v_model:
            fwd_prev = self.get_fwd_df(date=get_bday(self.date - parse_offset(self.change_cb.v_model)))
            fwd_data[self.field_ac.v_model] = fwd_data[self.field_ac.v_model] - fwd_prev[self.field_ac.v_model]

        return fwd_data

    def parse_slopes(self):
        slopes_ta = self.slopes_ta
        if not slopes_ta.v_model:
            return
        try:
            slopes = pd.read_csv(StringIO(slopes_ta.v_model), names=range(3))
        except Exception:
            slopes = pd.read_csv(StringIO(slopes_ta.v_model), names=range(2))
        return [tuple(row.dropna().astype(int)) for index, row in slopes.iterrows()]


def get_pivot(df, field, index, columns, filters=None):
    if filters:
        q = ' and '.join([f"{key} == {value}" for key, value in filters.items()])
        df = df.query(q)

    return df.pivot_table(
        values=field,
        index=index,
        columns=columns
    )


def get_history_table(df, field, source='BGN'):
    df_ = df.query(f"source =='{source}'")[['date', 'security', field]]
    df_ = df_.pivot(index='date', columns='security', values=field).resample('B').ffill()
    return df_


def get_bday(date, previous=True):
    return date - BDay() + BDay() if not previous else date + BDay() - BDay()


def make_slopes_df(pivot_df, slopes=None):

    _default_slopes = []
    if not pivot_df.columns.isin(_default_slopes).all():
        if pivot_df.shape[1] > 4:
            _default_slopes = [*pivot_df.columns[[1, -2, -3]]]
        elif pivot_df.shape[1] == 2:
            _default_slopes = [*pivot_df.columns[[0, 1]]]
        else:
            _default_slopes = [*pivot_df.columns[[0, 1, -1]]]

    if not slopes:
        if len(_default_slopes) == 2:
            slopes = [(_default_slopes[0], _default_slopes[1])]
        elif len(_default_slopes) == 3:

            slopes = [
                (_default_slopes[1], _default_slopes[2]),
                (_default_slopes[0], _default_slopes[1]),
                (_default_slopes[0], _default_slopes[1], _default_slopes[1])
            ]
        else:
            return

    slope_series = []
    for slope in slopes:
        if len(slope) == 2:
            s = pivot_df[slope[1]] - pivot_df[slope[0]]
            slope_series.append(s.rename(f"{slope[1]} - {slope[0]}"))
        else:
            s = pivot_df[slope[0]] - 2 * pivot_df[slope[1]] + pivot_df[slope[2]]
            slope_series.append(s.rename(f"{slope[0]} - 2*{slope[1]} + {slope[2]}"))

    return pd.concat(slope_series, axis=1).dropna(how='all')


def make_pct_grid(data):
    renderer = BarRenderer(
        text_value=Expr("format(cell.value, '.2%')"),
        horizontal_alignment="center",
        # bar_horizontal_alignment="center",
        bar_color=ColorScale(min=0, max=1),
        bar_value=LinearScale(min=0, max=1)
    )

    dg = DataGrid(
        data,
        default_renderer=renderer,
        selection_mode='cell',
        base_column_size=100
    )

    return dg


def get_slope_pct(slopes_df):
    s = np.sign(slopes_df).replace({-1: 'negative', 1: 'positive', np.nan: 'NA'})
    return s.apply(lambda series: series.value_counts(dropna=False, normalize=True))


def make_datagrid(data, field=None):
    if data.index.nlevels > 1:
        data = data.reset_index(level=[*range(1, data.index.nlevels)])

    field = field or ''
    renderers = {
        col: BarRenderer(
            text_value=Expr("format(cell.value, '.2f')"),
            text_color=Expr('"red" if cell.value < 0 else default_value'),
            horizontal_alignment="center",
            # bar_horizontal_alignment="center",
            bar_color=ColorScale(min=data[col].quantile(0.1), mid=0 if 'change' in field else None,
                                 max=data[col].quantile(0.9)),
            bar_value=LinearScale(min=data[col].quantile(0.1), mid=0 if 'change' in field else None,
                                  max=data[col].quantile(0.9))
        ) for col in data if data[col].dtype == 'float64'
    }

    dg = DataGrid(
        data,
        renderers=renderers,
        editable=False,
        selection_mode='cell',
        base_column_size=100,
    )

    copy_btn = v.Btn(
        fab=True,
        # small=True,
        x_small=True,
        plain=True,
        class_='ma-2',
        children=[v.Icon(children=['mdi-content-copy'])]
    )

    copy_btn.on_event('click', lambda widget, event, payload: data.to_clipboard())
    box = w.VBox([copy_btn, dg])

    # dg.auto_fit_columns = True
    # return [dg]
    return box


def on_click_make_pivot(widget, event, payload, self):
    # data = get_issuers_curves(bond_ref, currency=self.curr_sel.v_model)
    # data = data.merge(mkt, on='security', how='left')
    widget.loading = True
    try:
        data = self.get_fwd_df()
        if curr := self.curr_sel.v_model:
            data = data.query(f"currency == '{curr}'")

        field = self.field_ac.v_model

        pivot_df = get_pivot(
            df=data,
            field=field,
            index=self.index_ac.v_model,
            columns=self.cols_ac.v_model
        )

        try:
            offset = parse_offset(self.value_sel.v_model.split('_')[-1], b=True)
            print(f"changes from {pd.Timestamp.today().floor('d') - offset + pd.tseries.offsets.BDay():%d %b %Y}")
        except Exception:
            pass

        dg = make_datagrid(pivot_df, field)
        self._pivot = pivot_df
        self.dg1 = dg

        # display(dg)

        if self.cols_ac.v_model == 'maturity_label':
            slopes_df = make_slopes_df(pivot_df, slopes=self.parse_slopes())
            if slopes_df is not None:
                self._slopes = slopes_df
                dg2 = make_datagrid(slopes_df)
                self.dg2 = dg2

                slopes_pct_df = get_slope_pct(slopes_df)
                self._slopes_pct = slopes_pct_df

                dg3 = make_pct_grid(slopes_pct_df)

                # display(box)

                box = v.Container(
                    children=[
                        v.Row(
                            children=[
                                v.Col(children=[dg], cols=7),
                                v.Col(children=[dg2], cols=5),
                            ]
                        ),
                        v.Row(
                            children=[
                                v.Col(children=[dg3], cols=5, offset=7),
                            ]
                        )
                    ]
                )
                # box = w.HBox(children=[*dg, *dg2])
                display(box)
            else:
                display(dg)
        else:
            display(dg)
    finally:
        widget.loading = False


class Pivot(View):

    fields_mapping = {
        "blp_z_sprd_mid": "z_spread_mid",
        "yld_ytm_mid": "yield_to_maturity",
        "px_last": "price"
    }

    def __init__(self, issuers_curves=None, mkt=None, **kwargs):
        super().__init__(**kwargs)
        self._issuers_curves = issuers_curves
        self.mkt = mkt

    @property
    def issuers_curves(self):
        return self.store.data['issuers_curves'] if self._issuers_curves is None else self._issuers_curves

    def get_data(self):
        try:
            mkt = self.store.data['mkt']
        except KeyError:
            mkt = self.mkt

        if not self.curr_sel.v_model:
            data = pd.concat(self.issuers_curves.values())
        else:
            data = self.issuers_curves[self.curr_sel.v_model]
        data = data.merge(mkt, on='security', how='left')
        return data

    def make_widgets(self):
        curr_sel = v.Autocomplete(
            v_model=None,
            items=[*self.issuers_curves.keys()],
            label='currency',
            dense=True,
            outlined=True,
            small_chips=True,
            clearable=True,
        )

        value_sel = v.Autocomplete(
            v_model='z_spread',
            # items=[field.name for field in bbg_fields],
            label='field',
            dense=True,
            outlined=True,
            small_chips=True,
        )

        index_ac = v.Autocomplete(
            v_model=['ticker', 'currency', 'rating_bucket'],
            label='index',
            items=[
                'ticker',
                'country_name',
                'currency',
                'region',
                'subregion',
                'rating_bucket',
            ],
            outlined=True,
            multiple=True,
            chips=True,
            small_chips=True,
            dense=True,
            clearable=True,
            deletable_chips=True
            # style_='width: 250px',
            # class_='ma-0 pa-0'
        )

        cols_ac = v.Autocomplete(
            v_model='maturity_label',
            label='cols',
            items=['maturity_label', 'rating_bucket'],
            outlined=True,
            # multiple=True,
            chips=True,
            small_chips=True,
            dense=True,
            clearable=True,
            # style_='width: 250px',
            # class_='ma-0 pa-0'
        )

        slopes_ta = v.Textarea(
            v_model=None,
            outlined=True,
            dense=True,
            label='slopes',
            clearable=True,
            auto_grow=False,
            rows=3,
            no_resize=True
        )

        table_btn = v.Btn(
            fab=True,
            small=True,
            plain=True,
            left=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-table'])]
        )

        pcs_tf = v.TextField(
            v_model='BGN',
            label='pcs',
            clearable=True,
            dense=True,
            outlined=True,

        )

        sep_tf = v.TextField(
            v_model='@',
            label='sep',
            clearable=True,
            dense=True,
            outlined=True,
            disabled=True
        )

        interval_cb = v.Combobox(
            v_model=None,  # ["12m", "ytd", "6m", "3m", "1m", "1w", "2d"],
            items=["12m", "ytd", "6m", "3m", "1m", "1w", "2d"],
            multiple=True,
            small_chips=True,
            deletable_chips=True,
            outlined=True,
            dense=True,
            clearable=True,
            label="intervals"
        )

        fields_cb = v.Combobox(
            v_model=[*self.fields_mapping],  # ["blp_z_sprd_mid", "yld_ytm_mid", "px_last"],
            items=[*self.fields_mapping],
            multiple=True,
            small_chips=True,
            deletable_chips=True,
            outlined=True,
            dense=True,
            clearable=True,
            label="fields"
        )

        dl_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-download'])]
        )

        out = w.Output()

        self.curr_sel = curr_sel
        self.value_sel = value_sel
        self.index_ac = index_ac
        self.cols_ac = cols_ac
        self.slopes_ta = slopes_ta
        self.table_btn = table_btn



        self.pcs_tf = pcs_tf
        self.sep_tf = sep_tf
        self.interval_cb = interval_cb
        self.fields_cb = fields_cb
        self.dl_btn = dl_btn


        self.out = out

    def make_view(self):
        curr_sel = self.curr_sel
        value_sel = self.value_sel
        index_ac = self.index_ac
        cols_ac = self.cols_ac
        slopes_ta = self.slopes_ta
        table_btn = self.table_btn

        pcs_tf = self.pcs_tf
        sep_tf = self.sep_tf
        interval_cb = self.interval_cb
        fields_cb = self.fields_cb
        dl_btn = self.dl_btn

        out = self.out

        param_box = v.Container(
            children=[
                v.Row(
                    children=[

                        v.Col(
                            cols=1.0,
                            children=[pcs_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1.0,
                            children=[sep_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=3,
                            children=[fields_cb],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=3,
                            children=[interval_cb],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1.0,
                            children=[dl_btn],
                            class_="my-0 py-0"
                        ),
                    ]
                ),
                v.Row(
                    children=[
                        v.Col(
                            cols=6,
                            children=[
                                v.Row(
                                    children=[

                                        v.Col(
                                            cols=6,
                                            children=[curr_sel],
                                            class_="my-0 py-0"
                                        ),
                                        v.Col(
                                            cols=6,
                                            children=[value_sel],
                                            class_="my-0 py-0"
                                        ),
                                    ]
                                ),
                                v.Row(
                                    children=[
                                        v.Col(
                                            cols=6,
                                            children=[index_ac],
                                            class_="my-0 py-0"
                                        ),
                                        v.Col(
                                            cols=6,
                                            children=[cols_ac],
                                            class_="my-0 py-0"
                                        ),
                                        ],
                                )
                            ],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[slopes_ta],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1,
                            children=[table_btn],
                            class_="my-0 py-0"
                        ),
                    ]
                ),

            ]
        )

        view = w.VBox(
            children=[
                param_box,
                out,
            ]
        )

        self.param_box = param_box
        self.view = view

    def link(self, **kwargs):
        # curr_sel = self.curr_sel
        value_sel = self.value_sel
        index_ac = self.index_ac
        cols_ac = self.cols_ac
        slopes_ta = self.slopes_ta
        table_btn = self.table_btn
        out = self.out
        pcs_tf = self.pcs_tf
        sep_tf = self.sep_tf
        interval_cb = self.interval_cb
        fields_cb = self.fields_cb
        dl_btn = self.dl_btn

        dl_btn.on_event(
            'click',
            partial(
                out.capture(clear_output=True)(on_click_download),
                self=self
            )
        )

        table_btn.on_event(
            'click',
            partial(
                out.capture(clear_output=True)(on_click_make_pivot),
                self=self
            )
        )
        super().link()

    def parse_slopes(self):
        slopes_ta = self.slopes_ta
        if not slopes_ta.v_model:
            return
        try:
            slopes = pd.read_csv(StringIO(slopes_ta.v_model), names=range(3))
        except Exception:
            slopes = pd.read_csv(StringIO(slopes_ta.v_model), names=range(2))
        return [tuple(row.dropna().astype(int)) for index, row in slopes.iterrows()]

    def make_fields(self):
        return [*chain.from_iterable([
            [
                {"field": field, "name": self.fields_mapping.get(field, field)},
                *(get_interval_fields(
                    name='net_change',
                    field=field,
                    base_name=self.fields_mapping.get(field, field),
                    intervals=self.interval_cb.v_model,
                ) if self.interval_cb.v_model else [])
            ] for field in self.fields_cb.v_model])]

    def get_bbg_securities(self):
        securities = pd.concat([value['security'] for key, value in self.issuers_curves.items()]).drop_duplicates()
        securities = get_securities(securities, pcs=self.pcs_tf.v_model, sep=self.sep_tf.v_model)
        return securities

    def get_bbg_fields(self):
        fields = self.make_fields()
        bbg_fields = [
            BBGField(
                field=field['field'],
                name=field['name'],
                overrides=BBGOverrides(**dict(field['overrides'])) if field.get('overrides') else None
            ) for field in fields
        ]
        return bbg_fields

    def download(self):
        securities = self.get_bbg_securities()
        bbg_fields = self.get_bbg_fields()
        mkt = bq.bdpy(securities=securities, bbg_fields=bbg_fields)
        mkt = unparse_results_securities(mkt, pcs=self.pcs_tf.v_model, sep=self.sep_tf.v_model)
        self.mkt = mkt
        self.store.data['mkt'] = mkt
        try:
            self.store.tabs['pivot'].value_sel.items = [*mkt.columns[1:]]
        except Exception as e:
            raise e
