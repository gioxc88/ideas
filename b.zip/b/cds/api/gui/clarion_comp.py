from functools import partial

import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
from IPython.display import display
from ipydatagrid import DataGrid, TextRenderer, BarRenderer, Expr
from bqplot import LinearScale, ColorScale, OrdinalColorScale, OrdinalScale


from .base import View
from ..blpw import BlpQuery
from ..data.utils import add_pcs, parse_tenor
from ..bbg import BBGRequestParams, BBGField, BBGSecurity, BBGOverrides
from .collectors import CollectorL
from ..utils import get_securities

dt_fmt = '%Y-%m-%d'
bbg_dt_fmt = '%Y%m%d'


class Comp(View, CollectorL):

    def make_widgets(self, **kwargs):
        paste_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-0',
            children=[v.Icon(children=['mdi-content-paste'])]
        )

        refresh_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-sync'])]
        )

        update_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-calculator'])]
        )

        pcs1_tf = v.TextField(
            v_model='CBBT',
            outlined=True,
            dense=True,
            label='pcs bond',
            clearable=True
        )


        pcs2_tf = v.TextField(
            v_model='MSG1',
            outlined=True,
            dense=True,
            label='pcs cds',
            clearable=True
        )

        cds_cb = v.Checkbox(
            v_model=True,
            dense=True,
            label='cds'
        )

        self.paste_btn = paste_btn
        self.refresh_btn = refresh_btn
        self.update_btn = update_btn
        self.pcs1_tf = pcs1_tf
        self.pcs2_tf = pcs2_tf
        self.cds_cb = cds_cb

        self.out = w.Output()

    def make_view(self, **kwargs):
        paste_btn = self.paste_btn
        refresh_btn = self.refresh_btn
        update_btn = self.update_btn
        pcs1_tf = self.pcs1_tf
        pcs2_tf = self.pcs2_tf
        cds_cb = self.cds_cb
        out = self.out

        param_box = v.Container(
            fluid=True,
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=2,
                            children=[pcs1_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[pcs2_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1.0,
                            children=[cds_cb],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=3,
                            children=[paste_btn, refresh_btn, update_btn],
                            class_="my-0 py-0"
                        ),

                    ],
                    align_content='center',
                ),
            ]
        )

        view = w.VBox(
            children=[
                param_box,
                out,
            ]
        )

        self.param_box = param_box
        self.view = view

    def link(self, **kwargs):
        paste_btn = self.paste_btn
        refresh_btn = self.refresh_btn
        update_btn = self.update_btn
        out = self.out

        paste_btn.on_event(
            'click',
            partial(on_click_paste, self=self)
        )

        refresh_btn.on_event(
            'click',
            partial(
                out.capture(clear_output=True)(on_click_refresh_grid2),
                self=self
            )
        )

        update_btn.on_event(
            'click',
            partial(
                out.capture(clear_output=True)(on_click_update_grid),
                self=self
            )
        )

    def _display(self, comp_data):
        self.comp_data = comp_data
        dg = make_datagrid(comp_data)

        adj_str = f"<b>The total adjustment is: {get_millify(2)(N(comp_data['adjustment'].sum()))} <b>"
        clarion_str = f"<b>Clarion PNL is: {get_millify(2)(N(comp_data['clarion pnl'].sum()))} <b>"
        real_str = f"<b>Real PNL is: {get_millify(2)(N(comp_data['real pnl'].sum()))} <b>"
        html = w.HTML(f"{adj_str} || {clarion_str} || {real_str}")
        display(html)
        display(w.HTML(f"<br> <b> Breakdown by Instrument <b>"))
        self.dg = dg
        display(dg)
        agg_data = self.comp_data.groupby(['Issuer', 'Ccy'], sort=False, as_index=False) \
            [['Notional', 'adjustment', 'clarion pnl', 'real pnl']].sum().sort_values('adjustment', ascending=False)
        self.agg_data = agg_data
        dg2 = make_datagrid2(agg_data)
        self.dg2 = dg2
        display(w.HTML(f"<br> <b> Breakdown by Issuer <b>"))
        display(dg2)

    def _display2(self, comp_data):
        self.comp_data = comp_data
        dg = make_datagrid(comp_data)

        total_sum = comp_data[['clarion pnl', 'real pnl', 'adjustment']].sum().rename('Total').to_frame().T
        trade_sum = comp_data.groupby('Trade Type')[['clarion pnl', 'real pnl', 'adjustment']].sum()
        df_pnl = pd.concat([total_sum, trade_sum]).infer_objects()

        display(w.HTML(f"<br> <b> Total P&L <b>"))
        dg_pnl = make_datagrid_pnl(df_pnl)
        display(dg_pnl)
        ##############

        display(w.HTML(f"<br> <b> Breakdown by Instrument <b>"))
        self.dg = dg
        display(dg)
        agg_data = self.comp_data.groupby(['Issuer', 'Ccy'], sort=False, as_index=False) \
            [['Notional', 'adjustment', 'clarion pnl', 'real pnl']].sum().sort_values('adjustment', ascending=False)
        self.agg_data = agg_data
        dg2 = make_datagrid2(agg_data)
        self.dg2 = dg2
        display(w.HTML(f"<br> <b> Breakdown by Issuer <b>"))
        display(dg2)


def millify(cell):
    n = abs(float(cell.value))

    if n < 1000:
        return format(cell.value, '.3f')
    elif n < 1000000:
        return format(cell.value / 1000, '.3f') + 'k'
    elif n < 1000000000:
        return format(cell.value / 1000000, '.3f') + 'm'
    elif n < 1000000000000:
        return format(cell.value / 1000000000, '.3f') + 'b'
    else:
        return format(cell.value / 1000000000000, '.3f') + 't'


def millify0(cell):
    n = abs(float(cell.value))

    if n < 1000:
        return format(cell.value, '.0f')
    elif n < 1000000:
        return format(cell.value / 1000, '.0f') + 'k'
    elif n < 1000000000:
        return format(cell.value / 1000000, '.0f') + 'm'
    elif n < 1000000000000:
        return format(cell.value / 1000000000, '.0f') + 'b'
    else:
        return format(cell.value / 1000000000000, '.0f') + 't'


def millify1(cell):
    n = abs(float(cell.value))

    if n < 1000:
        return format(cell.value, '.1f')
    elif n < 1000000:
        return format(cell.value / 1000, '.1f') + 'k'
    elif n < 1000000000:
        return format(cell.value / 1000000, '.1f') + 'm'
    elif n < 1000000000000:
        return format(cell.value / 1000000000, '.1f') + 'b'
    else:
        return format(cell.value / 1000000000000, '.1f') + 't'


def get_millify(decimal=3):
    def millify(cell):
        n = abs(float(cell.value))

        if n < 1000:
            return format(cell.value, ".{}f".format(decimal))
        elif n < 1000000:
            return format(cell.value / 1000, ".{}f".format(decimal)) + 'k'
        elif n < 1000000000:
            return format(cell.value / 1000000, ".{}f".format(decimal)) + 'm'
        elif n < 1000000000000:
            return format(cell.value / 1000000000, ".{}f".format(decimal)) + 'b'
        else:
            return format(cell.value / 1000000000000, ".{}f".format(decimal)) + 't'

    return millify


def text_color(cell):
    pass


def bond_comp(bond_data, pcs=None, bq=None, id_type='isin'):
    data_ = bond_data
    securities = get_securities(data_['ISIN'], pcs=pcs, id_type=id_type)
    fields = [
        'px_last',
    ]

    bbg_data = bq.bdp(
        securities=securities,
        fields=fields
    )
    bbg_data['security'] = bbg_data['security'].replace(data_['ISIN'].set_axis(securities))
    comp_data = data_.merge(bbg_data, how='left', left_on='ISIN', right_on='security').drop('security', axis=1)
    return comp_data


def cds_comp(cds_data, pcs=None, bq=None):
    cds_issuer_mapping = {
        'BRAZIL': 'BRAZIL',
        'CHILE': 'CHILE',
        'COLOM': 'COLOM',
        'EGYPT': 'EGYPT',
        'SAUDI': 'SAUDI',
        'MEX': 'MEX',
        'MOROC': 'MOROC',
        'PERU': 'PERU',
        'CHINA': 'CHINAGOV',
        'SOAF': 'REPSOU',
        'TURKEY': 'TURKEY'
    }

    cds_bbg = pd.concat(
        [
            (cds_data['Issuer'].map(cds_issuer_mapping) + f' CDS ' + cds_data[
                'Ccy'] + f' SR 5Y D14 {f"{pcs} " if pcs else ""}Curncy').rename('ticker'),
            cds_data['Expiry/ Maturity'].dt.strftime(bbg_dt_fmt).rename('mat'),
            cds_data['Description'].str.split(' ').str[2].astype(float).rename('coupon'),
            cds_data['Description']
        ], axis=1
    )

    bbg_securities = [
        BBGSecurity(
            id=row['ticker'],
            overrides=[
                BBGOverrides(
                    MATURITY=row['mat'],
                    SW_SPREAD=row['coupon'],
                    label=row['Description']
                )
            ]
        ) for index, row in cds_bbg.iterrows()]
    bbg_fields = [
        # if I download cds_quoted_price this is not always accurate for cds that quote upfront. if I download 100 - upfront_last I don't have this problem
        # BBGField("cds_quoted_price"),
        BBGField("upfront_last"),
    ]

    cds_quoted_price = bq.bdpx(BBGRequestParams(securities=bbg_securities, fields=bbg_fields))\
        .rename({'security_label': 'Description'}, axis=1)
    cds_quoted_price['px_last'] = 100 - cds_quoted_price['upfront_last']
    comp_data = cds_data.merge(cds_quoted_price[['Description', 'px_last']], on='Description')
    return comp_data


def cds_index_comp(cds_index_data,  bq=None, ):
    cds_index_map = {
        'CDXNAIG': 'CDX IG CDSI',
        'CDXEM': 'CDX EM CDSI'

    }
    fields = [
        'cds_quoted_price',
    ]

    securities = cds_index_data['Description'].str.split('-').set_axis(cds_index_data['Description'])
    index = securities.str[0].map(cds_index_map)
    series = securities.str[1].str.split(' ').str[0]
    tenor = securities.str[2].str.split(' ').str[0]
    securities = (index + ' ' + series + ' ' + tenor + ' Corp').rename('security')

    bbg_data = bq.bdp(
        securities=[*securities],
        fields=fields
    ).rename({'cds_quoted_price': 'px_last'}, axis=1)

    bbg_data = securities.to_frame().reset_index().merge(bbg_data, on='security').drop('security', axis=1)
    comp_data = cds_index_data.merge(bbg_data, on='Description')
    return comp_data


def bbg_comp2(data_, pcs1=None, pcs2=None, cds=True, bq=None):
    bond_data = data_.query('`Trade Type` in  ["Bond"]')  # ["CDS Index", "Bond"]'
    comp_data = bond_comp(bond_data, pcs=pcs1, bq=bq)

    cds_index_data = data_.query('`Trade Type` in  ["CDS Index"]')  # ["CDS Index", "Bond"]'
    if not cds_index_data.empty:
        cds_index_mkt = cds_index_comp(cds_index_data, bq=bq)
        comp_data = pd.concat([comp_data, cds_index_mkt])

    if cds:
        cds_data = data_.query('`Trade Type` ==  "CDS"')
        if not cds_data.empty:
            comp_data_cds = cds_comp(cds_data, pcs=pcs2, bq=bq)
            comp_data = pd.concat([comp_data, comp_data_cds])

    return _make_calc(comp_data)


def _make_calc(comp_data):

    rename = {
        'Total': 'clarion pnl',
        'Quoted Price': 'clarion price',
        'Quoted Price Change': 'clarion chg',
        'px_last': 'bloomberg price',
        'notional_diff': 'adjustment'
    }

    comp_data = comp_data.rename(rename, axis=1)
    comp_data['price_diff'] = (comp_data['bloomberg price'] - comp_data['clarion price'])
    comp_data['adjustment'] = (comp_data['price_diff'] * comp_data['Notional']) / 100
    comp_data['real pnl'] = comp_data['clarion pnl'] + comp_data['adjustment']
    comp_data = comp_data.sort_values('adjustment', ascending=False)

    return comp_data


def update_tables(comp_data):
    comp_data['bloomberg price'] = comp_data['bloomberg price'].fillna(comp_data['clarion price'])
    return _make_calc(comp_data)


def make_datagrid(comp_data):
    renderers = {

        'Notional': TextRenderer(
            text_value=Expr(millify1),
            text_color=Expr('"red" if cell.value < 0 else default_value')
        ),
        'Expiry/ Maturity': TextRenderer(format='%Y-%m-%d', format_type='time'),
        'clarion price': TextRenderer(format='.3f'),
        'clarion chg': TextRenderer(
            format='.2f',
            text_color=Expr('"red" if cell.value < 0 else "green"')
        ),
        'bloomberg price': TextRenderer(format='.3f'),
        'clarion pnl': TextRenderer(
            text_value=Expr(millify0),
            text_color=Expr('"red" if cell.value < 0 else default_value')
        ),
        'adjustment': BarRenderer(
            text_value=Expr(millify0),
            text_color=Expr('"red" if cell.value < 0 else default_value'),
            horizontal_alignment="center",
            bar_color=ColorScale(min=comp_data['adjustment'].min(), max=comp_data['adjustment'].max()),
            bar_value=LinearScale(min=comp_data['adjustment'].min(), max=comp_data['adjustment'].max())
        ),
        'price_diff': BarRenderer(
            text_value=Expr("format(cell.value, '.2f')"),
            text_color=Expr('"red" if cell.value < 0 else default_value'),
            horizontal_alignment="center",
            bar_color=ColorScale(min=comp_data['price_diff'].min(), max=comp_data['price_diff'].max()),
            bar_value=LinearScale(min=comp_data['price_diff'].min(), max=comp_data['price_diff'].max())
        ),
        'real pnl': TextRenderer(
            text_value=Expr(millify0),
            text_color=Expr('"red" if cell.value < 0 else default_value')
        ),
    }

    dg = DataGrid(
        comp_data,
        renderers=renderers,
        base_column_size=80,
        editable=True,
        selection_mode='cell',
        column_widths={
            'Description': 250,
            'Expiry/ Maturity': '90',
            'Issuer': 80,
            'bloomberg price': 120,
            'Ccy': 60,
            'adjustment': 90,
            'clarion pnl': 90,
            'clarion price': 95,
            'clarion chg': 95
        }

    )
    # dg.auto_fit_columns = True
    return dg


def make_datagrid2(comp_data):
    renderers = {

        'Notional': TextRenderer(
            text_value=Expr(millify1),
            text_color=Expr('"red" if cell.value < 0 else default_value')
        ),
        'clarion pnl': TextRenderer(
            text_value=Expr(millify0),
            text_color=Expr('"red" if cell.value < 0 else default_value')
        ),
        'adjustment': BarRenderer(
            text_value=Expr(millify0),
            text_color=Expr('"red" if cell.value < 0 else default_value'),
            horizontal_alignment="center",
            bar_color=ColorScale(min=comp_data['adjustment'].min(), max=comp_data['adjustment'].max()),
            bar_value=LinearScale(min=comp_data['adjustment'].min(), max=comp_data['adjustment'].max())
        ),
        'real pnl': TextRenderer(
            text_value=Expr(millify0),
            text_color=Expr('"red" if cell.value < 0 else default_value')
        ),
    }

    dg = DataGrid(
        comp_data,
        renderers=renderers,
        base_column_size=80,
        editable=False,
        selection_mode='cell',
        column_widths={
            'Issuer': 80,
            'Ccy': 60,
            'clarion pnl': 90,
            'clarion price': 95,
            'adjustment': 90,
        }

    )
    # dg.auto_fit_columns = True
    return dg


def make_datagrid_pnl(data_pnl):
    renderers = {
        'clarion pnl': TextRenderer(
            text_value=Expr(millify1),
            text_color=Expr('"red" if cell.value < 0 else default_value')
        ),
        'real pnl': TextRenderer(
            text_value=Expr(millify1),
            text_color=Expr('"red" if cell.value < 0 else default_value')
        ),
        'adjustment': TextRenderer(
            text_value=Expr(millify1),
            text_color=Expr('"red" if cell.value < 0 else default_value'),
        ),
    }

    dg = DataGrid(
        data_pnl,
        renderers=renderers,
        base_column_size=90,
        editable=False,
        selection_mode='cell',
        column_widths={
            'Clarion P&L': 90,
            'Real P&L': 90,
            'Adjustment': 90,
        },
        layout={"height": "130px"}

    )
    # dg.auto_fit_columns = True
    return dg


class N:
    def __init__(self, n):
        self.value = n


def parse_clipboard2():
    data = pd.read_clipboard(sep='\t', header=[1])
    data['Notional'] = data['Notional'].str.replace(',', '').astype(float)
    data['Expiry/ Maturity'] = pd.to_datetime(data['Expiry/ Maturity'].str.replace(',', ''))

    cols = [
        'Issuer',
        'Trade Type',
        'Description',
        'Ccy',
        'Expiry/ Maturity',
        'ISIN',
        'Total',
        'Notional',
        'Quoted Price',
        'Quoted Price Change'
    ]
    data = data[cols].dropna(subset=['Trade Type', 'Notional'])
    data_ = data.drop(['Total', 'Notional'], axis=1) \
        .drop_duplicates(subset='Description')
    data_ = data_.merge(data.groupby('Description', as_index=False, sort=False)[['Total', 'Notional']].sum(), on='Description')
    data_ = data_[[*data_.columns[:-2], data_.columns[-1], data_.columns[-2]]]
    data_ = data_.loc[data_['Notional'] != 0, :]
    return data_


def on_click_paste(widget, event, data, self):
    try:
        self.data_ = parse_clipboard2()
    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False


def on_click_update_grid(widget, event, data, self):
    widget.loading = True
    try:
        comp_data = update_tables(self.dg.data)
        self._display2(comp_data)
        # box = w.HBox([dg, dg2])
    except Exception as e:
        widget.color = 'error'
        raise e
    finally:
        widget.loading = False


def on_click_refresh_grid2(widget, event, data, self):
    widget.loading = True
    try:
        data_ = self.data_
        pcs1 = self.pcs1_tf.v_model
        pcs2 = self.pcs2_tf.v_model
        cds_ind = self.cds_cb.v_model
        comp_data = bbg_comp2(data_, pcs1, pcs2, cds_ind, bq=self.bq)
        self._display2(comp_data)
        # box = w.HBox([dg, dg2])
    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False