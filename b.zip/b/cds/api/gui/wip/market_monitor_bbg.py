import json
import sys
import re
import os
from pathlib import Path
from itertools import chain
from functools import partial
from io import StringIO
from numbers import Number

import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
import QuantLib as ql
from IPython.display import display
from ipydatagrid import DataGrid, TextRenderer, BarRenderer, Expr
from bqplot import LinearScale, ColorScale, OrdinalColorScale, OrdinalScale
from pandas.tseries.offsets import BDay

from api.gui.base import View, Tabs, years_to_maturity_col
from api.gui.market_monitor import get_issuers_curves
from api.blpw import BlpQuery
from api.bbg import BBGField, BBGOverrides
from api.data.base import data_path, tables
from api.data.utils import add_pcs, make_rating_categories
from api.utils import parse_offset

from api.data.processing import (
    add_years_to_maturity,
    add_maturity_bucket,
    add_custom_rating,
    add_rating_bucket,
    add_geo_area
)


dt_fmt = '%Y-%m-%d'

maturity_thresholds = {
    2: 0.5,
    3: 1,
    5: 1,
    7: 1.5,
    10: 3.5,
    20: 3,
    30: 7,
    50: 10,
}


class DatePicker(View):
    dt_fmt = '%Y-%m-%d'

    def __init__(
            self,
            value=None,
            label=None,
            style=None,
            dense=True,
            outlined=None,
            **kwargs
    ):
        if isinstance(value, pd.Timestamp):
            value = f"{value:{self.dt_fmt}}"
        self._value = value
        self._label = label
        self._style = style
        self._dense = dense
        self._outlined = outlined

        super().__init__(**kwargs)

    def make_widgets(self, **kwargs):
        self.dp = v.DatePicker(
            v_model=self._value,
        )
        self.tf = v.TextField(
            v_model=None,
            label=self._label,
            clearable=True,
            dense=self._dense,
            outlined=self._outlined,
            prepend_icon="mdi-calendar",
            # readonly=True,
            v_on='menu.on',
            v_bind='menu.attrs',
            style_=self._style
        )
        w.jslink((self.dp, 'v_model'), (self.tf, 'v_model'))

        self.menu = v.Menu(
            v_model=None,
            close_on_content_click=False,
            nudge_right=40,
            transition="scale-transition",
            offset_y=True,
            min_width="auto",
            v_slots=[
                {
                    'name': 'activator',
                    'variable': 'menu',
                    'children': self.tf
                }
            ],
            children=[
                self.dp
            ]
        )

    def make_view(self, **kwargs):
        self.view = self.menu

    def link(self, **kwargs):
        def close_menu(*args, **kwargs):
            self.menu.v_model = False

        self.dp.on_event('input', close_menu)

    @property
    def components(self):
        return {
            'dp': self.dp,
            'tf': self.tf,
            'menu': self.menu
        }

    @property
    def date(self):
        return pd.to_datetime(self.tf.v_model)


def get_bond_ref(bond_ref=None, date=None):
    date = date or pd.Timestamp.today().floor('d')
    bond_ref = bond_ref if bond_ref is not None else \
        tables.bonds_reference.query(f"issue_date <= '{date:%Y-%m-%d}' and maturity > '{date:%Y-%m-%d}'")
    bond_ref = add_maturity_bucket(
        add_years_to_maturity(bond_ref, date=date),
        maturity_bins=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20, 25, 30, 35, 40, 45, 50, 60]
    )
    bond_ref = add_rating_bucket(add_custom_rating(bond_ref))
    bond_ref = add_geo_area(bond_ref, more_cols={'name': 'country_name'})
    return bond_ref


class CurvesViewer(View):

    _default_maturities = [2, 3, 5, 7, 10, 30, 50]

    def get_curves(self):
        if hasattr(self, 'date_pk'):
            date = self.date_pk.date
        else:
            date = pd.Timestamp.today().floor('d')
        bond_ref = get_bond_ref(date=date)
        self.bond_ref = bond_ref

        maturities = [int(i) for i in self.maturity_cb.v_model] if hasattr(self, 'maturity_cb') else self._default_maturities
        curves = {
            cur: get_issuers_curves(
                bond_ref,
                maturities=maturities,
                currency=cur,
                thresholds=maturity_thresholds
            )
            for cur in bond_ref['currency'].drop_duplicates()
        }
        curves = {cur: df for cur, df in curves.items() if not df.empty}
        self.issuers_curves = curves

    def __init__(self, bond_ref=None, issuers_curves=None, **kwargs):
        super().__init__(**kwargs)
        self._bond_ref = bond_ref
        self._issuers_curves = issuers_curves

    def build(self, **kwargs):
        self.get_curves()
        super().build(**kwargs)

    @property
    def issuers_curves(self):
        return self.store.data['issuers_curves'] if self._issuers_curves is None else self._issuers_curves

    @issuers_curves.setter
    def issuers_curves(self, value):
        if self._issuers_curves is None:
            self.store.data['issuers_curves'] = value
        else:
            self._issuers_curves = value

    @property
    def bond_ref(self):
        return self.store.data['bond_ref'] if self._bond_ref is None else self._bond_ref

    @bond_ref.setter
    def bond_ref(self, value):
        if self._bond_ref is None:
            self.store.data['bond_ref'] = value
        else:
            self._bond_ref = value

    def reset_curves(self):

        maturities = [int(i) for i in self.maturity_cb.v_model] if hasattr(self, 'maturity_cb') else self._default_maturities

        issuers_curves = {cur: get_issuers_curves(self.bond_ref, maturities=maturities, currency=cur, thresholds=maturity_thresholds) for cur in
                          self.bond_ref['currency'].drop_duplicates()}
        self.store.data['issuers_curves'] = issuers_curves

    def parse_ta(self):
        return pd.read_csv(StringIO(self.sub_ta.v_model), header=None, skipinitialspace=True).set_axis(
            ['currency', 'ticker', 'maturity_label', 'security'], axis=1)

    def override(self):
        bond_ref = self.bond_ref
        ic = self.store.data['issuers_curves']
        for index, row in self.parse_ta().iterrows():
            curve_df = ic[row[0]]
            mask = pd.concat([curve_df[key] == value for key, value in row[1:-1].items()], axis=1).all(axis=1)
            to_sub = curve_df.loc[mask].squeeze()
            sub = bond_ref.query(f"security == '{row[-1]}'").squeeze()

            if to_sub.empty:
                pass
            else:
                if sub.empty:
                    curve_df.loc[curve_df['security'] == to_sub['security'], 'security'] = row[-1]
                else:
                    sub['maturity_label'] = row['maturity_label']
                    sub = sub
                    curve_df.drop(to_sub.name, inplace=True)
                    curve_df.loc[sub.name] = sub

    def make_widgets(self, **kwargs):
        curr_sel = v.Autocomplete(
            v_model='USD',
            items=[*self.issuers_curves],
            label='currency',
            dense=True,
            outlined=True
        )

        maturity_cb = v.Combobox(
            v_model=self._default_maturities,
            items=None,
            multiple=True,
            small_chips=True,
            deletable_chips=True,
            outlined=True,
            dense=True,
            clearable=True,
            label="maturities"
        )

        build_curve_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-vector-curve'])]
        )

        date_pk = DatePicker(
            value=pd.Timestamp.today(),
            label='date',
            outlined=True
        )

        sub_ta = v.Textarea(
            v_model=None,
            label='override',
            outlined=True,
            dense=True,
            clearable=True,
            auto_grow=True,
            rows=3,
        )

        ovrd_btn = v.Btn(
            fab=True,
            x_small=True,
            plain=True,
            class_='mb-1 ml-2',
            children=[v.Icon(children=['mdi-skip-forward'])]
        )

        reset_btn = v.Btn(
            fab=True,
            x_small=True,
            plain=True,
            class_='mt-1 ml-2',
            children=[v.Icon(children=['mdi-skip-backward'])]
        )

        hint_html = w.HTML(
            '''
                <b>Syntax</b>: currency, issuer, maturity, new_id 
                <br> 
                <b>Example</b>: USD, MEX, 5, BT316586 Corp
            ''')


        self.sub_ta = sub_ta
        self.ovrd_btn = ovrd_btn
        self.reset_btn = reset_btn

        self.curr_sel = curr_sel
        self.maturity_cb = maturity_cb
        self.build_curve_btn = build_curve_btn
        self.date_pk = date_pk
        self.sub_ta = sub_ta
        self.ovrd_btn = ovrd_btn
        self.reset_btn = reset_btn
        self.hint_html = hint_html

        self.out = w.Output()

    def make_view(self, **kwargs):
        curr_sel = self.curr_sel
        maturity_cb = self.maturity_cb
        build_curve_btn = self.build_curve_btn
        date_pk = self.date_pk
        sub_ta = self.sub_ta
        ovrd_btn = self.ovrd_btn
        reset_btn = self.reset_btn
        hint_html = self.hint_html

        self.param_box = v.Container(
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=2,
                            children=[date_pk.view],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[curr_sel],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=5,
                            children=[maturity_cb],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1.0,
                            children=[build_curve_btn],
                            class_="my-0 py-0"
                        ),
                    ]
                ),
                v.Row(
                    children=[
                        v.Col(children=[sub_ta], cols=3),
                        v.Col(children=[w.VBox([ovrd_btn, reset_btn])], cols=1.0),
                        v.Col(children=[hint_html], cols=3),
                    ]
                )
            ]
        )

        self.view = w.VBox(
            [
                self.param_box,
                self.out
            ]
        )

    def link(self):
        curr_sel = self.curr_sel
        build_curve_btn = self.build_curve_btn
        out = self.out
        sub_ta = self.sub_ta
        ovrd_btn = self.ovrd_btn
        reset_btn = self.reset_btn

        curr_sel.on_event(
            'change',
            partial(
                out.capture(clear_output=True)(on_change_dg),
                self=self
            )
        )
        curr_sel.fire_event('change', None)

        build_curve_btn.on_event(
            'click',
            partial(
                onclick_rebuild_curves,
                self=self
            )
        )

        ovrd_btn.on_event(
            'click',
            partial(
                on_click_override,
                self=self
            )
        )

        reset_btn.on_event(
            'click',
            partial(
                on_click_reset,
                self=self
            )
        )

        super().link()


def onclick_rebuild_curves(widget, event, payload, self):
    widget.loading = True
    try:
        self.get_curves()
        self.curr_sel.fire_event('change', None)
    except Exception:
        pass
    finally:
        widget.loading = False


def on_change_dg(widget, event, data, self):
    widget.loading = True
    try:
        float_renderer = TextRenderer(
            text_value=Expr("format(cell.value, '.2f')"),
        )

        dg = DataGrid(

            self.issuers_curves[self.curr_sel.v_model].set_index('name'),
            selection_mode='cell',
            base_column_size=90,
            renderers={years_to_maturity_col: float_renderer},
            column_widths={
                'name': 150,
                'security': 110,
                'isin': 110
            }
        )
        # dg.auto_fit_columns = True
        display(w.HTML('<b>CURVES</b>'))
        display(dg)
        dgb = DataGrid(
            self.bond_ref.set_index('name'),
            selection_mode='cell',
            base_column_size=90,
            renderers={years_to_maturity_col: float_renderer},
            column_widths={
                'name': 150,
                'security': 110,
                'isin': 110
            }
        )

        display(w.HTML('<br> <br> <b>BONDS</b>'))
        display(dgb)

    except Exception:
        pass
    finally:
        widget.loading = False


def make_datagrid(data, field=None):
    if data.index.nlevels > 1:
        data = data.reset_index(level=[*range(1, data.index.nlevels)])

    field = field or ''
    renderers = {
        col: BarRenderer(
            text_value=Expr("format(cell.value, '.2f')"),
            text_color=Expr('"red" if cell.value < 0 else default_value'),
            horizontal_alignment="center",
            # bar_horizontal_alignment="center",
            bar_color=ColorScale(min=data[col].quantile(0.1), mid=0 if 'change' in field else None,
                                 max=data[col].quantile(0.9)),
            bar_value=LinearScale(min=data[col].quantile(0.1), mid=0 if 'change' in field else None,
                                  max=data[col].quantile(0.9))
        ) for col in data if data[col].dtype == 'float64'
    }

    dg = DataGrid(
        data,
        renderers=renderers,
        editable=False,
        selection_mode='cell',
        base_column_size=100,
    )

    copy_btn = v.Btn(
        fab=True,
        # small=True,
        x_small=True,
        plain=True,
        class_='ma-2',
        children=[v.Icon(children=['mdi-content-copy'])]
    )

    copy_btn.on_event('click', lambda widget, event, payload: data.to_clipboard())
    box = w.VBox([copy_btn, dg])

    # dg.auto_fit_columns = True
    # return [dg]
    return box


def get_pivot(df, field, index, columns, filters=None):
    if filters:
        q = ' and '.join([f"{key} == {value}" for key, value in filters.items()])
        df = df.query(q)

    return df.pivot_table(
        values=field,
        index=index,
        columns=columns
    )


def get_history_table(df, field, source='BGN'):
    df_ = df.query(f"source =='{source}'")[['date', 'security', field]]
    df_ = df_.pivot(index='date', columns='security', values=field).resample('B').ffill()
    return df_


def get_bday(date, previous=True):
    return date - BDay() + BDay() if not previous else date + BDay() - BDay()


def make_slopes_df(pivot_df, slopes=None):

    _default_slopes = [5, 10, 30]
    if not pivot_df.columns.isin(_default_slopes).all():
        if pivot_df.shape[1] > 4:
            _default_slopes = [*pivot_df.columns[[1, -2, -3]]]
        else:
            _default_slopes = [*pivot_df.columns[[0, 1, -1]]]

    slopes = slopes or [
        (_default_slopes[1], _default_slopes[2]),
        (_default_slopes[0], _default_slopes[1]),
        (_default_slopes[0], _default_slopes[1], _default_slopes[2])
    ]

    slope_series = []
    for slope in slopes:
        if len(slope) == 2:
            s = pivot_df[slope[1]] - pivot_df[slope[0]]
            slope_series.append(s.rename(f"{slope[1]} - {slope[0]}"))
        else:
            s = pivot_df[slope[0]] - 2 * pivot_df[slope[1]] + pivot_df[slope[2]]
            slope_series.append(s.rename(f"{slope[0]} - 2*{slope[1]} + {slope[2]}"))

    return pd.concat(slope_series, axis=1).dropna(how='all')


def make_pct_grid(data):
    renderer = BarRenderer(
        text_value=Expr("format(cell.value, '.2%')"),
        horizontal_alignment="center",
        # bar_horizontal_alignment="center",
        bar_color=ColorScale(min=0, max=1),
        bar_value=LinearScale(min=0, max=1)
    )

    dg = DataGrid(
        data,
        default_renderer=renderer,
        selection_mode='cell',
        base_column_size=100
    )

    return dg


def get_slope_pct(slopes_df):
    s = np.sign(slopes_df).replace({-1: 'negative', 1: 'positive', np.nan: 'NA'})
    return s.apply(lambda series: series.value_counts(dropna=False, normalize=True))


def on_click_make_pivot(widget, event, payload, self):
    # data = get_issuers_curves(bond_ref, currency=self.curr_sel.v_model)
    # data = data.merge(mkt, on='security', how='left')
    widget.loading = True
    try:
        data = self.get_data()

        field = self.field_ac.v_model if not self.change_cb.v_model else f'{self.field_ac.v_model}_change_{self.change_cb.v_model}'

        pivot_df = get_pivot(
            df=data,
            field=field,
            index=self.index_ac.v_model,
            columns=self.cols_ac.v_model
        )

        try:
            offset = parse_offset(self.value_sel.v_model.split('_')[-1], b=True)
            print(f"changes from {pd.Timestamp.today().floor('d') - offset + pd.tseries.offsets.BDay():%d %b %Y}")
        except Exception:
            pass

        dg = make_datagrid(pivot_df, field)
        self._pivot = pivot_df
        self.dg1 = dg

        # display(dg)

        if self.cols_ac.v_model == 'maturity_label':
            slopes_df = make_slopes_df(pivot_df, slopes=self.parse_slopes())
            self._slopes = slopes_df
            dg2 = make_datagrid(slopes_df)
            self.dg2 = dg2

            slopes_pct_df = get_slope_pct(slopes_df)
            self._slopes_pct = slopes_pct_df

            dg3 = make_pct_grid(slopes_pct_df)

            # display(box)

            box = v.Container(
                children=[
                    v.Row(
                        children=[
                            v.Col(children=[dg], cols=7),
                            v.Col(children=[dg2], cols=5),
                        ]
                    ),
                    v.Row(
                        children=[
                            v.Col(children=[dg3], cols=5, offset=7),
                        ]
                    )
                ]
            )
            # box = w.HBox(children=[*dg, *dg2])
            display(box)
        else:
            display(dg)
    finally:
        widget.loading = False


class Pivot(View):

    _default_fields = [
        "last_price",
        "z_spread",
        "yield_to_maturity",
    ]

    def __init__(self, bond_ref=None, bond_hist=None, issuers_curves=None, mkt=None, date=None, **kwargs):
        super().__init__(**kwargs)
        self._bond_ref = bond_ref
        self._bond_hist = bond_hist
        self._issuers_curves = issuers_curves
        self.mkt = mkt
        self._date = date

    @property
    def issuers_curves(self):
        return self.store.data['issuers_curves'] if self._issuers_curves is None else self._issuers_curves

    @property
    def bond_ref(self):
        return self.store.data['bond_ref'] if self._bond_ref is None else self._bond_ref

    @property
    def bond_hist(self):
        return self.store.data['bond_hist'] if self._bond_hist is None else self._bond_hist

    @property
    def date(self):
        return self.store.tabs['curves'].date_pk.date if self._date is None else self._date

    def get_data(self):
        ht = get_history_table(self.bond_hist, self.field_ac.v_model, self.pcs_tf.v_model)
        mkt = ht.loc[get_bday(self.date)].dropna()
        mkt = mkt.rename(self.field_ac.v_model)

        if self.change_cb.v_model:
            mkt_prev = ht.loc[get_bday(self.date - parse_offset(self.change_cb.v_model))].dropna()
            mkt = (mkt - mkt_prev).dropna()
            mkt = mkt.rename(f'{self.field_ac.v_model}_change_{self.change_cb.v_model}')

        mkt = mkt.reset_index()

        if not self.curr_sel.v_model:
            data = pd.concat(self.issuers_curves.values())
        else:
            data = self.issuers_curves[self.curr_sel.v_model]
        data = data.merge(mkt, on='security', how='left')
        return data

    def make_widgets(self, **kwargs):
        curr_sel = v.Autocomplete(
            v_model=None,
            items=[*self.issuers_curves.keys()],
            label='currency',
            dense=True,
            outlined=True,
            clearable=True,
        )

        index_ac = v.Autocomplete(
            v_model=['ticker', 'currency', 'rating_bucket'],
            label='index',
            items=[
                'ticker',
                'country_name',
                'currency',
                'region',
                'subregion',
                'rating_bucket',
            ],
            outlined=True,
            multiple=True,
            chips=True,
            small_chips=True,
            dense=True,
            clearable=True,
            deletable_chips=True
            # style_='width: 250px',
            # class_='ma-0 pa-0'
        )

        cols_ac = v.Autocomplete(
            v_model='maturity_label',
            label='cols',
            items=['maturity_label', 'rating_bucket'],
            outlined=True,
            # multiple=True,
            dense=True,
            clearable=True,
            # style_='width: 250px',
            # class_='ma-0 pa-0'
        )

        slopes_ta = v.Textarea(
            v_model=None,
            outlined=True,
            dense=True,
            label='slopes',
            clearable=True,
            auto_grow=False,
            rows=4,
            no_resize=True
        )

        table_btn = v.Btn(
            fab=True,
            small=True,
            plain=True,
            left=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-table'])]
        )

        pcs_tf = v.TextField(
            v_model='BGN',
            label='pcs',
            clearable=True,
            dense=True,
            outlined=True,

        )

        change_cb = v.Combobox(
            v_model=None,  # ["12m", "ytd", "6m", "3m", "1m", "1w", "2d"],
            multiple=False,
            outlined=True,
            dense=True,
            clearable=True,
            label="change"
        )

        field_ac = v.Autocomplete(
            v_model=None,  # ["blp_z_sprd_mid", "yld_ytm_mid", "px_last"],
            items=self._default_fields,
            multiple=False,
            outlined=True,
            dense=True,
            clearable=True,
            label="field"
        )

        out = w.Output()

        self.curr_sel = curr_sel
        self.field_ac = field_ac
        self.index_ac = index_ac
        self.cols_ac = cols_ac
        self.slopes_ta = slopes_ta
        self.table_btn = table_btn
        self.pcs_tf = pcs_tf
        self.change_cb = change_cb
        self.out = out

    def make_view(self, **kwargs):
        curr_sel = self.curr_sel
        field_ac = self.field_ac
        index_ac = self.index_ac
        cols_ac = self.cols_ac
        slopes_ta = self.slopes_ta
        table_btn = self.table_btn
        pcs_tf = self.pcs_tf
        change_cb = self.change_cb
        out = self.out

        param_box = v.Container(

            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=6,
                            children=[
                                v.Row(
                                    children=[

                                        v.Col(
                                            cols=3,
                                            children=[pcs_tf],
                                            class_="my-0 py-0"
                                        ),
                                        v.Col(
                                            cols=5,
                                            children=[field_ac],
                                            class_="my-0 py-0"
                                        ),
                                        v.Col(
                                            cols=4,
                                            children=[change_cb],
                                            class_="my-0 py-0"
                                        ),
                                        # v.Col(
                                        #     cols=1.0,
                                        #     children=[dl_btn],
                                        #     class_="my-0 py-0"
                                        # ),
                                    ]
                                ),
                                v.Row(
                                    children=[
                                        v.Col(
                                            cols=3,
                                            children=[curr_sel],
                                            class_="my-0 py-0"
                                        ),
                                        v.Col(
                                            cols=6,
                                            children=[index_ac],
                                            class_="my-0 py-0"
                                        ),
                                        v.Col(
                                            cols=3,
                                            children=[cols_ac],
                                            class_="my-0 py-0"
                                        )
                                        # v.Col(
                                        #     cols=1,
                                        #     children=[table_btn],
                                        #     class_="my-0 py-0"
                                        # ),
                                    ],
                                ),
                            ],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[slopes_ta],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1.0,
                            children=[table_btn],
                            class_="my-0 py-0"
                        ),
                    ]
                )
            ]
        )

        view = w.VBox(
            children=[
                param_box,
                out,
            ]
        )

        self.param_box = param_box
        self.view = view

    def link(self, **kwargs):
        # curr_sel = self.curr_sel
        field_ac = self.field_ac
        index_ac = self.index_ac
        cols_ac = self.cols_ac
        slopes_ta = self.slopes_ta
        table_btn = self.table_btn
        out = self.out
        pcs_tf = self.pcs_tf
        change_cb = self.change_cb

        table_btn.on_event(
            'click',
            partial(
                out.capture(clear_output=True)(on_click_make_pivot),
                self=self
            )
        )
        super().link()

    def parse_slopes(self):
        slopes_ta = self.slopes_ta
        if not slopes_ta.v_model:
            return
        try:
            slopes = pd.read_csv(StringIO(slopes_ta.v_model), names=range(3))
        except Exception:
            slopes = pd.read_csv(StringIO(slopes_ta.v_model), names=range(2))
        return [tuple(row.dropna().astype(int)) for index, row in slopes.iterrows()]


def on_click_override(widget, event, data, self):
    widget.loading = True
    try:
        self.override()
    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False


def on_click_reset(widget, event, data, self):
    widget.loading = True
    try:
        self.reset_curves()
    except Exception as e:
        widget.color = 'error'
        raise e
    else:
        widget.color = 'success'
    finally:
        widget.loading = False
