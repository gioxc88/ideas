import json
import sys
from pathlib import Path

import ipywidgets as w
import ipyvuetify as v
import pdblp
import numpy as np
import pandas as pd
from IPython.display import display
from ipydatagrid import DataGrid
from sklearn.linear_model import LinearRegression
from inflection import underscore
years_to_maturity_col = 'years_to_maturity'


class Tab:
    def __init__(self, tab, name=None):
        self.tab = tab
        self.name = name

    def _ipython_display_(self):
        display(self.tab)


class Store:
    def __init__(self):
        self.data = {}
        self.components = {}
        self.registry = NameRegistry()

    def add(self, value):
        self.components[value.name] = value

    def __getitem__(self, item):
        return self.components[item]

    def reset(self):
        self.components = {}

    @property
    def router(self):
        return self.components.get('router')

    def __repr__(self):
        return self.components.__repr__()

    def _ipython_display(self):
        display(self.components)


class NameRegistry:
    def __init__(self):
        self.registry = {}

    def register(self, name):
        reg = self.registry
        count = reg.get(name, 0)
        if not count:
            reg[name] = 1
            return name
        else:
            new_name = f"{name}{count + 1}"
            reg[new_name] = 1
            reg[name] += 1
            return new_name


store = Store()
name_registry = NameRegistry()


class View:
    def __init__(self, *args, **kwargs):
        self._store = kwargs.pop('store', store)
        self.name = kwargs.get('name', getattr(
            self,
            'name',
            self._store.registry.register(underscore(self.__class__.__name__))
        ))
        self._store.add(self)
        if kwargs.pop('build', True):
            self.build(**kwargs)

    @property
    def store(self):
        return self._store

    @store.setter
    def store(self, value):
        if isinstance(value, Store):
            self._store = value

    def build(self, **kwargs):
        self.make_widgets(**kwargs)
        self.make_view(**kwargs)

        _built = True

        if kwargs.pop('link', True):
            self.link(**kwargs)

    def make_widgets(self, **kwargs):
        pass

    def make_view(self, **kwargs):
        pass

    def link(self, **kwargs):
        _linked = True

    def _ipython_display_(self):
        if hasattr(self, 'view'):
            display(self.view)


class Router(View):
    def __init__(
            self,
            components=None,
            **kwargs
    ):
        self.components = components or {}
        self._value = None
        super().__init__(**kwargs)
        self.value = None if not components else [*components][0]

    @property
    def value(self):
        return self._value

    def make_view(self, **kwargs):
        # self.view = v.Container(fluid=True, class_="ma-0 pa-0")
        self.out = w.Output()
        self.view = self.out

    # @value.setter
    # def value(self, value):
    #     from copy import deepcopy
    #     if value in self.components:
    #         self._value = value
    #         # self. view = v.Container(children=[self.components[value]], fluid=True, class_="ma-0 pa-0")
    #         self.view.children = [self.components[value]]

    @value.setter
    def value(self, value):
        if value in self.components:
            self._value = value
            # self. view = v.Container(children=[self.components[value]], fluid=True, class_="ma-0 pa-0")
            with self.out:
                self.out.clear_output(wait=True)
                display(self.components[value])

    def register(self, components):
        update_view = True if not self.components and not self.value else False
        self.components.update(components)
        if update_view:
            self.value = [*components][0]


class Router(View):
    def __init__(
            self,
            components=None,
            **kwargs
    ):
        self.components = components or {}
        self._value = None
        super().__init__(**kwargs)
        self.value = None if not components else [*components][0]

    @property
    def value(self):
        return self._value

    def make_view(self, **kwargs):
        # self.view = v.Container(
        #     children=[c for k, c in self.components.items()],
        #     fluid=True, class_="ma-0 pa-0"
        # )
        self.view = w.VBox(children=[c for k, c in self.components.items()])

    @value.setter
    def value(self, value):
        if value in self.components:
            self._value = value
            for i, (k, c) in enumerate(self.components.items()):
                if k != value:
                    c.layout.display = 'none'
                else:
                    c.layout.display = None

            # self. view = v.Container(children=[self.components[value]], fluid=True, class_="ma-0 pa-0")
            # self.view.children = [self.components[value]]
    def register(self, components):
        update_view = True if not self.components and not self.value else False
        self.components.update(components)
        self.view.children = [*self.view.children, *[c for k, c in components.items()]]
        if update_view:
            self.value = [*components][0]


router = Router()


class Tabs(View):
    def __init__(self, tabs, *args, **kwargs):
        self.tabs = tabs
        self.data = {}
        store_ = kwargs.pop('store', store)
        # store.tabs = self
        for key, value in tabs.items():
            value.store = store
            value.build(link=False)
        for key, value in tabs.items():
            value.link()
        super().__init__(store=store)

    def make_widgets(self):
        self.tabs_bar = v.Tabs(
            # dark=True,
            v_model=None,
            children=[v.Tab(children=[name]) for name in self.tabs]
        )

        self.tabs_items = v.TabsItems(
            v_model=None,
            # dark=True,
            children=[v.TabItem(children=[tab.view]) for name, tab in self.tabs.items()]
        )

    def make_view(self):
        self.view = v.Card(
            children=[
                self.tabs_bar,
                self.tabs_items
            ]
        )

    def link(self):
        w.jslink((self.tabs_bar, 'v_model'), (self.tabs_items, 'v_model'))

    def __getitem__(self, item):
        return self.tabs[item]



