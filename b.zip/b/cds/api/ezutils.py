from uuid import uuid4

import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay

import bhutils
from bhutils import bhutilspy as bh

from .utils import parse_offset, today


def date_to_xl(date=None):
    if not date:
        return
    return (date - pd.Timestamp("1900-01-01")).days + 2


bh.bhInit('test1')

mkt_defs = bh.bhDbMktDefs(
    _handle="mkt_defs",
    _name="LiveCurves",
    _dbserver="SQLP1-A",
    _dbname="Quants"
)

ccy_cals = bh.bhDbCalendars(
    _handle='ccy_cals',
    _name="CURRENCY",
    _dbserver="SQLP1-A",
    _dbname="Quants",
    _usenull=True,
)

mx_cals = bh.bhDbCalendars(
    _handle='mx_cals',
    _name="MUREX",
    _dbserver="SQLP1-A",
    _dbname="Quants",
    _usenull=True,
)

calendars = bh.bhCalendarProviderDb(
    _handle='calendars',
    _calprov=ccy_cals,
    _namecol="Currency",
    _calcol="Calendar"
)


mtg_dts = bh.bhFiReadMeetingDates(
    _handle='mtg_dts',
    _quantsdb='quants',
    _quantsserver='SQLP-A',
)

gens = bh.bhFiReadGenerators(
    _handle='gens',
    _quantsdb="Quants",
    _quantsserver="SQLP1-A",
    _cals=mx_cals,
    _asof=pd.Timestamp.today().floor('d')
)




bh_cash_settle_map = {
    'c': 'Cash',
    'cp': 'CashZC',
    'p': 'Physical',
    'pc': 'PhysicalCleared',
}

bh_metric_map = {
    'spotpremium': 'PV',
    'fwdpremium': 'Premium',
    'spotpremcent': 'PV',
    'bpvol': 'Vol'
}

bh_metric_scaling = {
    'pv': 0.001,
    'strike': 100,
    'rate': 100,
    'spotpremium': 0.001,
    'fwdpremium': -0.001,
    'vol': 100,
    'bpvol': 10000 * 252 ** -0.5,
    'ann01': 1,
    'spotpremcent': 0.01,
}

bh_remote_db_columns = {
    'TradeId': 'int',
    'ccy': 'string',
    'SVMInstrument': 'string',
    'GeneratorInput': 'string',
    'EffExp': 'string',
    'MtyTnrIn': 'string',
    'Strike': 'string',
    'StrikeTerm': 'string',
    'PayoutType': 'string',
    'SwaptionSettleTypeIn': 'string',
    'ForwardSettled': 'int',
    'Nominal': 'double',
    'FwdTenor': 'string',
    'ForceCapToImm': 'int',
    'Generator': 'string',
    'MtyTnr': 'string',
    'StrikeDate': 'date',
    'SwaptionSettleType': 'string',
    'PaySettleType': 'string',
    'TradeLabel': 'string',
    'UnderlyingClearingHouse': 'string',
    'CollateralCcy': 'string',
}


def parse_expr(expr):
    expr = expr.replace('[', '').replace(']', '')
    split = expr.split(' ')
    instrument = split[0]
    curve_name = split[1]
    period = split[2]

    return instrument, curve_name, period


def parse_period(period):
    split = period.split('x')
    if len(split) == 1:
        split = (None, split[0])
    return split


def parse_dates(start_date=None, end_date=None, history=None):
    if not any([start_date, end_date, history]):
        end_date = today()
        start_date = end_date - parse_offset('1y')
    elif history and start_date:
        end_date = start_date + parse_offset(history)
    elif history and end_date:
        start_date = end_date - parse_offset(history)
    elif history and not any([start_date, end_date]):
        end_date = today()
        start_date = end_date - parse_offset(history)
    return start_date, end_date


def bh_get_swap_ts(
        expr=None,
        period=None,
        curve_name=None,
        forward_start=None,
        tenor=None,
        start_date=None,
        end_date=None,
        history=None,
):

    if expr:
        instrument, curve_name, period = parse_expr(expr)
    if period:
        forward_start, tenor = parse_period(period)

    start_date, end_date = parse_dates(start_date=start_date, end_date=end_date, history=history)
    _curvename = f"{curve_name.upper()}.STD" if all(i not in curve_name for i in ["sofr", "ois"]) else curve_name.upper()

    dbh = bh.bhReadMergedTsCurves(
        _dbhandle='dbtest',
        _tscrvhandle='crv1',
        _startdate=date_to_xl(start_date - pd.tseries.offsets.Day(504)),
        _enddate=date_to_xl(end_date),
        _market="COB_COMPLETE",
        _curvename=_curvename,
        _source="CRV",
        _category="O",
        _class="BHCURVE",
        _curvesdbname="Curves",
        _curvesdbserver="SQLP1-A",
        _histdbname="Histories",
        _histdbserver="SQLP1-A",
    )

    calendar = bh.bhDbLookUp(
        calendars,
        curve_name[:3].upper(),
        "Currency",
        "Calendar",
        0
    )

    crvh = bh.bhDbGetColValues(dbh, "TsCurve")[0][0]

    _type = "sw" if (start_date + parse_offset(tenor) - start_date).days > 360 else "dp"
    _ccy = f"{curve_name[:3].upper()}.STD" if all(i not in curve_name for i in ["sofr", "ois"]) else curve_name.upper()

    rates_ts = bh.bhTsRate(
        'ts1',
        _crvstsid=crvh,
        _efforfwd=forward_start.upper(),
        _mtyortenor=tenor.upper(),
        _type=_type,
        _ccy=_ccy,
        _mktdefs=mkt_defs,
        _calprovider=calendar,
        _leavemtyflag=1
    )


    try:
        ts = pd.Series(
            bh.bhTsGet(rates_ts, "v", date_to_xl(start_date), date_to_xl(end_date)).squeeze(axis=1),
            index=bh.bhTsGet(rates_ts, "d", date_to_xl(start_date), date_to_xl(end_date)).squeeze(axis=1),
            dtype='float'
        )
    except AttributeError:
        print(
            expr,
            period,
            curve_name,
            forward_start,
            tenor,
            start_date,
            end_date,
            history,
        )
        
        print(bh.bhTsGet(rates_ts, "v", date_to_xl(start_date), date_to_xl(end_date)))
    return ts.rename(f"s {curve_name.lower()} {forward_start.lower()}x{tenor.lower()}")


def bh_get_ts(expr, **kwargs):
    instrument = expr.split(' ', 1)[0]
    if instrument.lower() == 's':
        return bh_get_swap_ts(expr=expr, **kwargs)


def tsh_to_series(tsh):
    return pd.Series(
        bh.bhTsGet(tsh, "v").squeeze(axis=1),
        index=bh.bhTsGet(tsh, "d").squeeze(axis=1),
        dtype='float'
    )


class Servers:
    Snap = 'SQLP1-B'
    Quants = 'SQLP1-A'
    Curves = 'SQLP1-A'
    Histories = 'SQLP1-A'
    FITradePricer = 'SQLP2-A'
    Products = 'SQLP1-A'
    TradeReporter = 'SQLP1-A'
    SVM = 'SQLP1-A'



class Databases:
    Snap = 'Snap'
    Quants = 'Quants'
    Curves = 'Curves'
    Histories = 'Histories'
    Quants = 'Quants'
    RiskVar = 'RiskVar'
    MurexData = 'MurexData'
    Ticks = 'Ticks'
    SVM = 'SVM'
    FITradePricer = 'FITradePricer'


_sa = 'SQLP1-A'
_sb = 'SQLP1-B'
_sc = 'SQLP1-C'
_s2a = 'SQLP2-A'

class SQL:
    class Snap:
        server = _sb
        db = 'Snap'

    class Quants:
        server = _sa
        db = 'Quants'

    class Curves:
        server = _sa
        db = 'Curves'

    class Products:
        server = _sa
        db = 'Products'

    class TradeReporter:
        server = _sa
        db = 'TradeReporter'

    class Histories:
        server = _sa
        db = 'Histories'

    class MurexData:
        server = _sb
        db = 'MurexData'

    class Ticks:
        server = _sb
        db = 'Ticks'

    class SVM:
        server = _sa
        db = 'SVM'

    class FITradePricer:
        server = _s2a
        db = 'FITradePricer'

    class RiskVar:
        server = _sc
        db = 'RiskVar'


def get_irbt_server_query(db=None):
    db = db or Servers.FITradePricer
    return f"SELECT [value] FROM Config WHERE name='{db}.RemoteServer'"


class IRBTServer:
    port = 5557

    @classmethod
    def get_name(cls):
        h = bh.bhDbReadSql(uuid4().hex, Servers.FITradePricer, Databases.FITradePricer, get_irbt_server_query(),
                           _addspaces=True)
        return bh.bhDbGetValues(h, 0).squeeze()[()]


class Counter:
    _id = 0

    @classmethod
    def get_id(cls):
        cls._id += 1
        return cls._id


def get_null():
    return None


def parse_ccy(ccy):
    return ccy.upper()


def parse_instrument(instrument):
    return instrument.lower()


def parse_generator(generator):
    return generator.upper()


def parse_pay_receive(pay_receive):
    return pay_receive.lower()


def parse_strike(strike=None):
    return strike or "a"


def parse_tenor_mty(tenor_mty):
    from pandas.errors import ParserError
    try:
        return pd.to_datetime(tenor_mty)
    # except ParserError:
    except Exception as e:
        return tenor_mty.lower()


def parse_atm_fixed_date(atm_fixed_date=None, date=None):
    if not atm_fixed_date:
        return
    atm_fixed_date = parse_tenor_mty(atm_fixed_date)

    if isinstance(atm_fixed_date, pd.Timestamp):
        return atm_fixed_date
    else:
        if not date:
            date = pd.Timestamp.today().floor('d')
        return date - parse_offset('1y')


def parse_metric(metric=None, metric_map=None):
    metric_map = metric_map or bh_metric_map
    return metric_map.get(metric, metric)


def parse_pay_settle_type(metric=None):
    return 'x' if parse_metric(metric).lower() == 'premium' else 's'


def parse_collateral(collateral=None, ccy=None):
    if not collateral:
        return 'USD'

    if collateral.lower() == 'local' and ccy:
        return ccy.upper()
    else:
        return collateral.upper()


def parse_clearing_house(settle):
    if settle[:2] == 'pc':
        try:
            return settle.split('_')[1].upper()
        except IndexError:
            pass
    return get_null()


def parse_swaptions_settle_type(settle, cash_settle_map=None):
    cash_settle_map = cash_settle_map or bh_cash_settle_map
    key = settle.split('_')[0].lower()
    return bh_cash_settle_map.get(key)


def get_trade_label(
        ccy=None,
        instrument=None,
        generator=None,
        eff_exp=None,
        tenor_mty=None,
        strike=None,
        atm_fixed_date=None,
        pay_receive=None,
):
    atm_fixed_date = parse_atm_fixed_date(atm_fixed_date)

    label = f"{ccy} {instrument} {generator}{f' {eff_exp}' if eff_exp else ''}{f'x{tenor_mty}' if tenor_mty else ''} {pay_receive}{f' @{strike}' if strike else ''}{f' ({atm_fixed_date})' if atm_fixed_date else ''}".strip()
    return label


def parse_irb_remote_args(
        ccy=None,
        instrument=None,
        generator=None,
        eff_exp=None,
        tenor_mty=None,
        strike=None,
        atm_fixed_date=None,
        pay_receive=None,
        settle=None,
        collateral=None,
        metric=None,
        nominal=1e6
):
    data = [
        Counter.get_id(),
        parse_ccy(ccy) if ccy else get_null(),
        parse_instrument(instrument) if instrument else get_null(),
        parse_generator(generator) if generator else get_null(),
        eff_exp if eff_exp else get_null(),
        tenor_mty if tenor_mty else get_null(),
        parse_strike(strike) if ccy else get_null(),
        atm_fixed_date if atm_fixed_date else get_null(),
        parse_pay_receive(pay_receive) if pay_receive else get_null(),
        settle if settle else get_null(),
        get_null(),
        nominal,
        get_null(),
        get_null(),
        parse_generator(generator) if generator else get_null(),
        parse_tenor_mty(tenor_mty) if tenor_mty else get_null(),
        parse_atm_fixed_date(atm_fixed_date),
        parse_swaptions_settle_type(settle) if settle else get_null(),
        parse_pay_settle_type(metric) if ccy else get_null(),
        get_trade_label(
            ccy=ccy,
            instrument=instrument,
            generator=generator,
            eff_exp=eff_exp,
            tenor_mty=tenor_mty,
            strike=strike,
            atm_fixed_date=atm_fixed_date,
            pay_receive=pay_receive
        ),
        parse_clearing_house(settle) if settle else get_null(),
        parse_collateral(collateral, ccy)
    ]

    return data


def get_irbt_ts(
        ccy=None,
        instrument=None,
        generator=None,
        eff_exp=None,
        tenor_mty=None,
        strike=None,
        atm_fixed_date=None,
        pay_receive=None,
        settle=None,
        collateral=None,
        metric=None,
        nominal=1e6,
        start_date=None,
        end_date=None,
        history=None
):
    data = parse_irb_remote_args(
        ccy=ccy,
        instrument=instrument,
        generator=generator,
        eff_exp=eff_exp,
        tenor_mty=tenor_mty,
        strike=strike,
        atm_fixed_date=atm_fixed_date,
        pay_receive=pay_receive,
        settle=settle,
        collateral=collateral,
        metric=metric,
        nominal=nominal
    )

    db = bh.bhDbCreate(
        'irbtremote',
        _columnnames=[*bh_remote_db_columns],
        _columntype=[*bh_remote_db_columns.values()],
        _data=[data]
    )

    start_date, end_date = parse_dates(start_date=start_date, end_date=end_date, history=history)
    irbt_metric = parse_metric(metric)

    remote_call = bh.bhTsFiRemoteRiskCalc(
        _handle=f"{data[0]}",
        _tradesdb=db,
        _pblevals=irbt_metric,
        _startdate=start_date,
        _enddate=end_date,
        _irbtdbname=Databases.FITradePricer,
        _irbtdbsrvname=Servers.FITradePricer,
        _remoteservername=IRBTServer.get_name(),
        _remoteserverport=IRBTServer.port,
        _timeout=120
    )

    status = bh.bhDbGetColValues(remote_call, "Status").squeeze()[()]

    if isinstance(status, str) and status == "OK":
        remote_db = bh.bhDbLookUp(remote_call, irbt_metric, "Metric", "TS")
        ts_filtered = bh.bhTsFilter(uuid4().hex, remote_db, "v")
        # ts = tsh_to_series(ts_filtered).rename(data[-3])
        ts_scaled = bh.bhTsCalcM(
            _newid=uuid4().hex,
            _tsids=ts_filtered,
            _calctype="mult",
            _calcarg=float(bh_metric_scaling.get(irbt_metric.lower(), 1))
        )

        ts = tsh_to_series(ts_scaled).rename(data[-3])
        return ts
    else:
        print(status)
        raise ValueError


class LiveCurvesLocal:
    def __init__(self, date=None, curves=None):
        self.date = date or pd.Timestamp.today().floor('d')
        self.curves = curves
        try:
            self.sheet_mkt = bh.bhCreateSheetMarket(
                _handle='sheet_mkt',
                _mkt='LIVE',
                _asof=self.date,
                _mktdefs=mkt_defs,
                _calprov=mx_cals,
                _mtgdts=mtg_dts,
                _crvdbsvr="SQLP1-A",
                _crvdbname="Curves",
                _mktdatasvr="localhost",
                _mktdataport=60000,
                _snapdbsvr="SQLP1-B",
                _snapdbname="Snap",
            )
        except TypeError:
            self.sheet_mkt = bh.bhCreateSheetMarket(
                _hdl='sheet_mkt',
                _mkt='LIVE',
                _asof=self.date,
                _mktdefs=mkt_defs,
                _calprov=mx_cals,
                _mtgdts=mtg_dts,
                _crvdbsvr="SQLP1-A",
                _crvdbnm="Curves",
                _mdssvr="localhost",
                _mdsport=60000,
                _snapdbsvr="SQLP1-B",
                _snapdbnm="Snap",
            )

    @property
    def mkt_snap(self):
        return bh.bhCurveMarketSnap(
            _handle='crv_mkt_snap',
            _market=self.sheet_mkt,
            _curves=self.curves
        )

    @property
    def mkt_snap_db(self):
        return bh.bhCurveMarketSnapAsDb(
            _handle='crv_mkt_snap_db',
            _marketsnap=self.mkt_snap
        )

    @property
    def mkt_snap_db_curves(self):
        return bh.bhDbLookUp(
            _rsid=self.mkt_snap_db,
            _lookupvalues="LIVE",
            _lookupcols="name",
            _returncols="curves"
        )

    @property
    def db_curves(self):
        return self.mkt_snap_db_curves


class COBCurvesRemote:
    def __init__(self, date=None, curves=None, offset=None):
        self.date = date or pd.Timestamp.today().floor('d') - BDay()
        if offset:
            self.date = pd.Timestamp.today().floor('d') - parse_offset(offset)
        self.curves = curves

        self.db_mkt = bh.bhCreateCurvesDbMarket(
            _handle=f'crv_db_mkt_{self.date}',
            _mktname="COB",
            _asofdate=self.date,
            _datadate=self.date,
            _mktdefs=mkt_defs,
            _cals=mx_cals,
            _curvesserver="SQLP1-A",
            _curvesdb="Curves",
            _minextraptnr='80y'
        )

        self.mkt_snap_cob = bh.bhMarketSnap(
            _handle=f'mkt_snap_cob_{self.date:%Y%m%d}',
            _market=self.db_mkt,
            _curves=self.curves
        )

        self.db_curves = self.mkt_snap_cob