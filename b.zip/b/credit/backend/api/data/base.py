from pathlib import Path

import numpy as np
import pandas as pd


root_path = Path('/dev/projects/credit/backend/')
shared_path = Path('//rivagecapital.com/Root/BHCM/Trading/TeamSKal')
data_path = shared_path / 'data'
logs_path = root_path / 'data/logs'


date_columns = [
    'issue_date',
    'maturity',
    'calc_maturity',
    'workout_date'
]


class Tables:
    _tables = {
        'indices_history': ('indices_history.csv', {'parse_dates': ['date'], 'dayfirst': True}),
        'indices': ('indices.csv', {}),
        'indices_reference': ('indices_reference.csv', {}),
        'country': ('tables/country.csv', {}),
        'maturity': ('tables/maturity.csv', {}),
        'rating': ('tables/rating.csv', {}),
        'bonds_reference': ('bonds_reference.csv', {'index_col': ['security'], 'parse_dates': date_columns}),
        'bonds_market': ('bonds_market.csv', {'index_col': ['security']}),
        'bonds_history': ('bonds_history_all.csv', {'parse_dates': ['date'], 'dayfirst': True})
    }

    def __init__(self, path=data_path):
        self.path = path
        self._loaded = []

    def load(self, tables=None):
        path = self.path
        if isinstance(tables, str):
            tables = {tables: self._tables[tables]}
        elif tables:
            tables = {k: v for k, v in self._tables if k in tables}
        else:
            tables = self._tables

        for attr_name, args in tables.items():
            table = pd.read_csv(path / args[0], **args[1])
            setattr(self, attr_name, table)
            self._loaded.append(attr_name)

    def __getattr__(self, item):
        if item in self._tables and item not in self._loaded:
            self.load(item)
            return getattr(self, item)

        raise AttributeError(f"{self.__class__} object has no attribute {item}")


tables = Tables()


