import bqwidgets as bw
import bql

bw.TagsInput
bq = bql.Service()

bq.data.spread

bql.combined_df