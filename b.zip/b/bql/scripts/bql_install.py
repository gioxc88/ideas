import shutil
import sys
from pathlib import Path

bqnt_library_path = Path(r'C:\blp\bqnt\environments\bqnt-3\Lib\site-packages')
env_library_path = Path(sys.executable).parents[1] / 'Lib\site-packages'

dependencies = [
    'bql',
    'bqlmetadata',
    'bqutil',
    'bqbreg',
    'bqrequest',
    'bqapi',
    # 'blpapi',
    # 'ciso8601',
]

for package in dependencies:
    dst = env_library_path / package
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(bqnt_library_path / package, dst)
