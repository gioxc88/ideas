try:
    import config
except ImportError:
    pass
from api.data.base import data_path


def save_axes(search_name, output_path=None):
    import bql
    import pandas as pd
    bq = bql.Service()

    BQL_DT_FMT = '%Y-%m-%d'
    date_end = pd.Timestamp.today().floor('d')
    output_path = output_path or data_path / f'axes_{date_end:%Y%m%d}.csv'

    srch_univ = bq.univ.screenresults(type='srch', screen_name=search_name)

    filtered_univ = bq.univ.filter(
        srch_univ,
        bq.data.is_axed()
    )

    items = {
        'name': bq.data.security_des(),
        'axes': bq.data.axes("SECURITY_DEALER"),
    }

    req = bql.Request(filtered_univ, items, with_params=dict(mode='cached'))
    res = bq.execute(req)

    df_dealers = res[0].df().merge(res[1].df(), on='ID')
    df_dealers = df_dealers.assign(date=date_end)
    df_dealers.to_csv(output_path)


if __name__ == '__main__':
    save_axes('basil')
