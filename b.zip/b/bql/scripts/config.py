import sys
from pathlib import Path

root_path = Path('/dev/projects/bql')
if (path := str(root_path.resolve())) not in sys.path:
    sys.path.append(path)