from pathlib import Path

import numpy as np
import pandas as pd


root_path = Path('/dev/projects/bql')
# shared_path = Path('//rivagecapital.com/Root/BHCM/Trading/TeamSKal')
data_path = root_path / 'data'
logs_path = root_path / 'data/logs'