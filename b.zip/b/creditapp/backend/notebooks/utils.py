def get_isins(isins, source=None):
    
    return [f"/isin/{isin}{f'@{source}' if source else ''}" for isin in isins]