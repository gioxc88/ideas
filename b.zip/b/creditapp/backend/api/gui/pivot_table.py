from functools import partial

import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
from IPython.display import display
from ipydatagrid import DataGrid

from .base import View
from .utils import tables, custom_sort, make_data_table
from ..data.processing import get_current_data

data = get_current_data()
cols = [
    'ticker',
    'name',
    'currency',
    'country',
    'custom_area',
    'bics_sector',
    'capital_stack',
    'maturity_bucket',
    'rating_bucket',
    'area',
    'last_price',
    'yield_to_call',
    'ytm_flat',
    'ytm_fwd',
    'xccy_usd',
    'i_spread',
    'z_spread',
    'aws_spread'
]
currency_items = data['currency'].drop_duplicates().to_list()
capital_stack_items = data['capital_stack'].drop_duplicates().to_list()
items = [
    'yield_to_call',
    'yield_to_worst',
    'ytm_flat',
    'ytm_fwd',
    'xccy_usd',
    'i_spread',
    'z_spread',
    'aws_spread'
]
relevant_fields = [
    'ticker',
    'country',
    'currency',
    'maturity_bucket',
    'rating_bucket',
]


def get_mat():
    return [
        '2yr',
        '5yr',
        '7yr',
        '10yr',
        '15yr'
    ]


def get_rtg():
    return [
        'AA',
        'A',
        'BBB',
        'BB',
        'B'
    ]


class Pivot(View):
    def make_widgets(self):
        curr_sel = v.Autocomplete(
            v_model='EUR',
            items=currency_items,
            label='currency',
            dense=True,
            outlined=True
        )

        cap_stack_sel = v.Autocomplete(
            v_model='at1',
            items=capital_stack_items,
            label='capital stack',
            dense=True,
            outlined=True
        )

        spread_sel = v.Autocomplete(
            v_model='z_spread',
            items=items,
            label='field',
            dense=True,
            outlined=True
        )

        index_ac = v.Autocomplete(
            v_model=['country', 'ticker'],
            label='index',
            items=[
                'ticker',
                'country',
                'custom_area',
                'maturity_bucket',
                'rating_bucket',
            ],
            outlined=True,
            multiple=True,
            chips=True,
            dense=True,
            clearable=True,
            # style_='width: 250px',
            # class_='ma-0 pa-0'
        )

        cols_ac = v.Autocomplete(
            v_model='maturity_bucket',
            label='cols',
            items=relevant_fields,
            outlined=True,
            # multiple=True,
            chips=True,
            dense=True,
            clearable=True,
            # style_='width: 250px',
            # class_='ma-0 pa-0'
        )

        table_btn = v.Btn(
            left=True,
            children=[
                v.Icon(children=['mdi-table']),
                'Table',
            ],
        )

        out = w.Output()

        self.curr_sel = curr_sel
        self.cap_stack_sel = cap_stack_sel
        self.spread_sel = spread_sel
        self.index_ac = index_ac
        self.cols_ac = cols_ac
        self.table_btn = table_btn
        self.out = out

    def make_view(self):
        curr_sel = self.curr_sel
        cap_stack_sel = self.cap_stack_sel
        spread_sel = self.spread_sel
        index_ac = self.index_ac
        cols_ac = self.cols_ac
        table_btn = self.table_btn
        out = self.out

        param_box = v.Container(
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=2,
                            children=[curr_sel],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[cap_stack_sel],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[spread_sel],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[table_btn],
                            class_="my-0 py-0"
                        ),
                    ],
                    align_content='center',
                ),
                v.Row(
                    children=[
                        v.Col(
                            cols=3,
                            children=[index_ac],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=3,
                            children=[cols_ac],
                            class_="my-0 py-0"
                        ),
                    ],
                    align_content='center',
                )
            ]
        )

        view = w.VBox(
            children=[
                param_box,
                out,
            ]
        )

        self.param_box = param_box
        self.view = view

    def link(self):
        curr_sel = self.curr_sel
        cap_stack_sel = self.cap_stack_sel
        spread_sel = self.spread_sel
        index_ac = self.index_ac
        cols_ac = self.cols_ac
        table_btn = self.table_btn
        out = self.out

        table_btn.on_event(
            'click',
            out.capture(clear_output=True)(
                partial(
                    on_click_make_pivot,
                    curr_sel=curr_sel,
                    cap_stack_sel=cap_stack_sel,
                    spread_sel=spread_sel,
                    index_ac=index_ac,
                    cols_ac=cols_ac
                )
            )
        )


def get_pivot(df, currency, capital_stack, field, index, columns):
    filters = [
        f"currency == '{currency}'",
        " and ", f"capital_stack == '{capital_stack}'",
        " and ", f"maturity_bucket in {get_mat()}",
        " and ", f"rating_bucket in {get_rtg()}"
    ]

    df_ = df.query(''.join(filters))
    return df_.dropna(subset=field).pivot_table(
        values=field,
        index=index,
        columns=columns
    )


def on_click_make_pivot(widgets, event, payload, curr_sel, cap_stack_sel, spread_sel, index_ac, cols_ac):
    pivot_df = get_pivot(
        data,
        curr_sel.v_model,
        cap_stack_sel.v_model,
        spread_sel.v_model,
        index_ac.v_model,
        cols_ac.v_model
    )
    pivot_df = custom_sort(pivot_df, axis=1)
    pivot_df = custom_sort(pivot_df, axis=0)
    cont = make_data_table(pivot_df)
    display(cont.box)


