import json
import sys
from pathlib import Path

import ipywidgets as w
import ipyvuetify as v
import pdblp
import numpy as np
import pandas as pd
from IPython.display import display
from ipydatagrid import DataGrid
from sklearn.linear_model import LinearRegression


class Tab:
    def __init__(self, tab, name=None):
        self.tab = tab
        self.name = name

    def _ipython_display_(self):
        display(self.tab)


class View:
    def __init__(self, *args, **kwargs):
        self.store = kwargs.pop('store', None)
        if kwargs.pop('build', True):
            self.build()

    def build(self, **kwargs):
        self.make_widgets()
        self.make_view()

        if kwargs.pop('link', True):
            self.link()

    def link(self):
        pass

    def set_store(self, store):
        self.store = store

    def _ipython_display_(self):
        if hasattr(self, 'view'):
            display(self.view)


class Tabs(View):
    def __init__(self, tabs, *args, **kwargs):
        self.tabs = tabs
        self.data = {}
        for key, value in tabs.items():
            value.set_store(self)
            value.build(link=False)
        for key, value in tabs.items():
            value.link()
        super().__init__()

    def make_widgets(self):
        self.tabs_bar = v.Tabs(
            # dark=True,
            v_model=None,
            children=[v.Tab(children=[name]) for name in self.tabs]
        )

        self.tabs_items = v.TabsItems(
            v_model=None,
            # dark=True,
            children=[v.TabItem(children=[tab.view]) for name, tab in self.tabs.items()]
        )

    def make_view(self):
        self.view = v.Card(
            children=[
                self.tabs_bar,
                self.tabs_items
            ]
        )

    def link(self):
        w.jslink((self.tabs_bar, 'v_model'), (self.tabs_items, 'v_model'))


class MultiTab:
    def __init__(self, tabs):
        self.tabs = tabs
        self.build()

    def build(self):
        self.tabs_bar = v.Tabs(
            # dark=True,
            v_model=None,
            children=[v.Tab(children=[c.name]) for c in self.tabs]
        )

        self.tabs_items = v.TabsItems(
            v_model=None,
            # dark=True,
            children=[v.TabItem(children=[t.tab]) for t in self.tabs]
        )

        self.box = v.Card(
            children=[
                self.tabs_bar,
                self.tabs_items
            ]
        )

        w.jslink((self.tabs_bar, 'v_model'), (self.tabs_items, 'v_model'))

    def _ipython_display_(self):
        display(self.box)