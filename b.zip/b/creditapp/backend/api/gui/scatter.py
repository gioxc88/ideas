from functools import partial

import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
from IPython.display import display
from ipydatagrid import DataGrid
from plotly import graph_objects as go, express as px

from .base import View
from ..data.processing import get_current_data

bonds_data = get_current_data()
bonds_data['rating_bucket'] = bonds_data['rating_bucket'].fillna('NA')


default_group_items = [
    'issuer_name',
    'bics_sector',
    'bics_industry',
    'country',
    'currency',
    'rating_bucket',
    'payment_rank',
    'area',
    'macroarea'
]
default_currency_items = [
    'EUR',
    'USD',
    'GBP',
    'all'
]
default_capital_stack_items = [
    'at1',
    'lt2',
    'sp',
    'snp',
    'all'
]
default_y_items = [
    'yield_to_call',
    'ytm_flat',
    'ytm_fwd',
    'yield_to_worst',
    'xccy_usd',
    'i_spread',
    'z_spread',
    'aws_spread',
    'z_spread_basis',
    'reset_spread',
    'yield_to_call_high_12m',
    'yield_to_call_high_ytd',
    'yield_to_call_high_6m',
    'yield_to_call_high_3m',
    'yield_to_call_high_1m',
    'yield_to_call_high_1w',
    'yield_to_call_low_12m',
    'yield_to_call_low_ytd',
    'yield_to_call_low_6m',
    'yield_to_call_low_3m',
    'yield_to_call_low_1m',
    'yield_to_call_low_1w',
    'yield_to_call_change_12m',
    'yield_to_call_change_ytd',
    'yield_to_call_change_6m',
    'yield_to_call_change_3m',
    'yield_to_call_change_1m',
    'yield_to_call_change_1w',
    'z_spread_high_12m',
    'z_spread_high_ytd',
    'z_spread_high_6m',
    'z_spread_high_3m',
    'z_spread_high_1m',
    'z_spread_high_1w',
    'z_spread_low_12m',
    'z_spread_low_ytd',
    'z_spread_low_6m',
    'z_spread_low_3m',
    'z_spread_low_1m',
    'z_spread_low_1w',
    'z_spread_change_12m',
    'z_spread_change_ytd',
    'z_spread_change_6m',
    'z_spread_change_3m',
    'z_spread_change_1m',
    'z_spread_change_1w',
    'ytm_high_12m',
    'ytm_high_ytd',
    'ytm_high_6m',
    'ytm_high_3m',
    'ytm_high_1m',
    'ytm_high_1w',
    'ytm_low_12m',
    'ytm_low_ytd',
    'ytm_low_6m',
    'ytm_low_3m',
    'ytm_low_1m',
    'ytm_low_1w',
    'ytm_change_12m',
    'ytm_change_ytd',
    'ytm_change_6m',
    'ytm_change_3m',
    'ytm_change_1m',
    'ytm_change_1w'
]
default_x_items = [
    'years_to_workout',
    'mod_dur',
]


class Scatter(View):
    def __init__(
            self,
            data=None,
            group_items=None,
            currency_items=None,
            capital_stack_items=None,
            x_items=None,
            y_items=None,
            **kwargs,
    ):
        self.data = data if data is not None else bonds_data
        self.group_items = group_items if group_items is not None else default_group_items
        self.currency_items = currency_items if currency_items is not None else default_currency_items
        self.capital_stack_items = capital_stack_items if capital_stack_items is not None else default_capital_stack_items
        self.x_items = x_items if x_items is not None else default_x_items
        self.y_items = y_items if y_items is not None else default_y_items
        super().__init__(**kwargs)

    def make_widgets(self):
        group_sel = v.Autocomplete(
            v_model=self.group_items[0],
            items=self.group_items,
            label='group',
            dense=True,
            outlined=True
        )

        cap_stack_sel = v.Autocomplete(
            v_model=self.capital_stack_items[0],
            items=self.capital_stack_items,
            label='capital stack',
            dense=True,
            outlined=True
        )

        curr_sel = v.Autocomplete(
            v_model=self.currency_items[0],
            items=self.currency_items,
            label='currency',
            dense=True,
            outlined=True
        )

        issuer_sel = v.Autocomplete(
            v_model=['all'],
            items=['all', *self.data['issuer_name'].drop_duplicates()],
            label='issuer',
            dense=True,
            outlined=True,
            multiple=True,
            clearable=True
        )

        country_sel = v.Autocomplete(
            v_model=['all'],
            items=['all', *self.data['country'].drop_duplicates()],
            label='country',
            dense=True,
            outlined=True,
            multiple=True,
            clearable=True
        )

        x_sel = v.Autocomplete(
            v_model=self.x_items[0],
            items=self.x_items,
            label='x',
            dense=True,
            outlined=True
        )

        y_sel = v.Autocomplete(
            v_model=self.y_items[0],
            items=self.y_items,
            label='y',
            dense=True,
            outlined=True
        )

        chart_btn = v.Btn(
            left=True,
            children=[
                v.Icon(children=['mdi-chart-line']),
                'Chart'
            ],
        )

        out = w.Output()

        self.group_sel = group_sel
        self.cap_stack_sel = cap_stack_sel
        self.curr_sel = curr_sel
        self.issuer_sel = issuer_sel
        self.country_sel = country_sel
        self.x_sel = x_sel
        self.y_sel = y_sel
        self.chart_btn = chart_btn
        self.out = out

    def make_view(self):

        group_sel = self.group_sel
        cap_stack_sel = self.cap_stack_sel
        curr_sel = self.curr_sel
        issuer_sel = self.issuer_sel
        country_sel = self.country_sel
        x_sel = self.x_sel
        y_sel = self.y_sel
        chart_btn = self.chart_btn
        out = self.out

        param_box = v.Container(
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=1.0,
                            children=[group_sel],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1.0,
                            children=[country_sel],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[issuer_sel],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1.0,
                            children=[cap_stack_sel],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=1.0,
                            children=[curr_sel],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[chart_btn],
                            class_="my-0 py-0"
                        ),
                    ],
                    align_content='center',
                ),
                v.Row(
                    children=[
                        v.Col(
                            cols=3,
                            children=[x_sel],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=3,
                            children=[y_sel],
                            class_="my-0 py-0"
                        ),
                    ],
                    align_content='center',
                )
            ]
        )

        view = w.VBox(
            children=[
                param_box,
                out,
            ]
        )

        self.param_box = param_box
        self.view = view

    def link(self):
        data = self.data
        group_sel = self.group_sel
        cap_stack_sel = self.cap_stack_sel
        issuer_sel = self.issuer_sel
        country_sel = self.country_sel
        curr_sel = self.curr_sel
        x_sel = self.x_sel
        y_sel = self.y_sel
        chart_btn = self.chart_btn
        out = self.out

        chart_btn.on_event(
            'click',
            out.capture(clear_output=True)(
                partial(
                    on_click_chart,
                    data=data,
                    curr_sel=curr_sel,
                    issuer_sel=issuer_sel,
                    country_sel=country_sel,
                    cap_stack_sel=cap_stack_sel,
                    x_sel=x_sel,
                    y_sel=y_sel,
                    group_sel=group_sel

                )
            )
        )


def on_click_chart(widget, event, payload, data, curr_sel, cap_stack_sel, issuer_sel, country_sel, x_sel, y_sel, group_sel):
    currency = curr_sel.v_model
    capital_stack = cap_stack_sel.v_model
    issuers = issuer_sel.v_model
    contries = country_sel.v_model
    x = x_sel.v_model
    y = y_sel.v_model
    group = group_sel.v_model

    data_ = data
    strings = []
    if currency != 'all':
        strings.append(f"currency=='{currency}'")
    if capital_stack != 'all':
        strings.append(f"capital_stack=='{capital_stack}'")
    if issuers != ['all']:
        strings.append(f"issuer_name in {issuers}")
    if contries != ['all']:
        strings.append(f"country in {contries}")
    if strings:
        data_ = data.query(' and '.join(strings))

    fig = px.scatter(
        data_,
        x=x,
        y=y,
        color=group,
        hover_name='name',
        height=800,
        template='plotly_white',
        text='name'
    )

    fig.update_traces(
        textposition='bottom center',
        textfont_size=8
    )
    display(fig)