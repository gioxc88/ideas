from functools import partial

import ipywidgets as w
import ipyvuetify as v
from IPython.display import display

from .base import View
from ..data.base import tables

indices = tables.indices
indices_history = tables.indices_history
indices_reference = tables.indices_reference

indices = indices.assign(
    combined_name=indices.drop('ticker', axis=1).apply(lambda x: '_'.join(x.dropna()), axis=1),
)


class Details(View):
    def make_widgets(self):
        idx1_sel = v.Autocomplete(
            v_model=None,
            items=indices_reference['name'].to_list(),
            label='idx1',
            dense=True,
            outlined=True
        )

        idx2_sel = v.Autocomplete(
            v_model=None,
            items=indices_reference['name'].to_list(),
            label='idx2',
            dense=True,
            outlined=True
        )

        chart_btn = v.Btn(
            left=True,
            children=[
                v.Icon(children=['mdi-chart-line']),
                'Chart'
            ],
        )
        out = w.Output()

        self.idx1_sel = idx1_sel
        self.idx2_sel = idx2_sel
        self.chart_btn = chart_btn
        self.out = out

    def make_view(self):
        idx1_sel = self.idx1_sel
        idx2_sel = self.idx2_sel
        chart_btn = self.chart_btn
        out = self.out

        param_box = v.Container(
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=4,
                            children=[idx1_sel]
                        ),
                        v.Col(
                            cols=4,
                            children=[idx2_sel]
                        ),
                        v.Col(
                            cols=2,
                            children=[chart_btn]
                        ),
                    ]
                )
            ]
        )

        view = w.VBox(
            children=[
                param_box,
                out,
            ]
        )

        self.param_box = param_box
        self.view = view

    def link(self):
        idx1_sel = self.idx1_sel
        idx2_sel = self.idx2_sel
        chart_btn = self.chart_btn
        out = self.out

        chart_btn.on_event(
            'click',
            out.capture(clear_output=True)(partial(on_click_chart, idx1_sel=idx1_sel, idx2_sel=idx2_sel))
        )


def make_fig(tickers):
    df = indices_history.loc[indices_history['security'].isin(tickers)] \
        .pivot(index='date', columns='security') \
        .droplevel(level=0, axis=1).dropna()[tickers]
    ratio = (df.iloc[:, 0] / df.iloc[:, 1]).rename(' / '.join(tickers))
    fig = ratio.plot(backend='plotly', height=500, template='plotly_white')
    return fig.update_layout(
        legend=
        dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0
        )
    )


def on_click_chart(widget, event, data, idx1_sel, idx2_sel):
    widget.loading = True
    try:
        names = [idx1_sel.v_model, idx2_sel.v_model]
        tickers = indices_reference.loc[indices_reference['name'].isin(names)]
        tickers = tickers.sort_values(by='name', key=lambda x: [names.index(i) for i in x])['ticker'].to_list()
        fig = make_fig(tickers)
        display(fig)
    except Exception:
        pass
    finally:
        widget.loading = False

