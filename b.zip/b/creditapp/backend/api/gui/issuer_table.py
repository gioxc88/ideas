from functools import partial

import ipywidgets as w
import ipyvuetify as v
import numpy as np
import pandas as pd
from IPython.display import display
from ipydatagrid import DataGrid

from .utils import make_data_table, custom_sort
from .base import View
from ..data.processing import get_current_data, get_current_cds_data
from ..data.utils import _capital_stack as cds_capital_stack_items
from ..data.base import tables

data = get_current_data()
cds_data = get_current_cds_data()

currency_items = data['currency'].drop_duplicates().to_list()
capital_stack_items = data['capital_stack'].drop_duplicates().to_list()
items = [
    'yield_to_call',
    'yield_to_worst',
    'ytm_flat',
    'ytm_fwd',
    'xccy_coupon_usd',
    'z_spread',
    'i_spread',
    'aws_spread',
    'z_spread_basis'
]

ranges = ['1w', '1m', '3m', '6m', 'ytd', '12m']


class Issuer(View):
    def make_widgets(self):
        issuer_sel = v.Autocomplete(
            v_model=None,
            items=data['issuer_name'].drop_duplicates().to_list(),
            label='issuer',
            dense=True,
            outlined=True
        )

        curr_sel = v.Autocomplete(
            v_model=None,
            items=currency_items,
            label='currency',
            dense=True,
            outlined=True
        )

        cap_stack_sel = v.Autocomplete(
            v_model=None,
            items=capital_stack_items,
            label='capital stack',
            dense=True,
            outlined=True
        )

        spread_sel = v.Autocomplete(
            v_model=None,
            items=items,
            label='field',
            dense=True,
            outlined=True
        )

        range_sel = v.Autocomplete(
            v_model='12m',
            items=ranges,
            label='range',
            dense=True,
            outlined=True
        )

        table_btn = v.Btn(
            left=True,
            children=[
                v.Icon(children=['mdi-table']),
                'Table',
            ],
        )

        out = w.Output()

        self.issuer_sel = issuer_sel
        self.curr_sel = curr_sel
        self.cap_stack_sel = cap_stack_sel
        self.spread_sel = spread_sel
        self.range_sel = range_sel
        self.table_btn = table_btn
        self.out = out

    def make_view(self):
        issuer_sel = self.issuer_sel
        curr_sel = self.curr_sel
        cap_stack_sel = self.cap_stack_sel
        spread_sel = self.spread_sel
        range_sel = self.range_sel
        table_btn = self.table_btn
        out = self.out

        param_box = v.Container(
            children=[
                v.Row(
                    children=[

                        v.Col(
                            cols=2,
                            children=[issuer_sel],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[curr_sel],
                            class_="my-0 py-0"
                        ),
                        # v.Col(
                        #     cols=2,
                        #     children=[cap_stack_sel],
                        #     class_="my-0 py-0"
                        # ),
                        v.Col(
                            cols=2,
                            children=[spread_sel],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[range_sel],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[table_btn],
                            class_="my-0 py-0"
                        ),
                    ],
                    align_content='center',
                ),
            ]
        )

        view = w.VBox(
            children=[
                param_box,
                out,
            ]
        )

        self.param_box = param_box
        self.view = view

    def link(self):

        issuer_sel = self.issuer_sel
        curr_sel = self.curr_sel
        cap_stack_sel = self.cap_stack_sel
        spread_sel = self.spread_sel
        range_sel = self.range_sel
        table_btn = self.table_btn
        out = self.out

        table_btn.on_event(
            'click',
            out.capture(clear_output=True)(
                partial(
                    on_click_show_table,
                    issuer_sel=issuer_sel,
                    curr_sel=curr_sel,
                    range_sel=range_sel,
                    spread_sel=spread_sel
                )
            )
        )


def on_click_show_table(widget, event, payload, issuer_sel, curr_sel, range_sel, spread_sel):
    issuer = issuer_sel.v_model
    currency = curr_sel.v_model
    _range = range_sel.v_model
    item = spread_sel.v_model

    _more_cols = ['yield_to_call', 'ytm', 'z_spread']
    intervals = ['high', 'low', 'change']
    additional_cols = [f"{_field}_{interval}_{_range}" for _field in _more_cols for interval in intervals]
    additional_cols = sorted([*items, *additional_cols])

    data_ = data.query(f"issuer_name == '{issuer}' and currency == '{currency}'").sort_values('capital_stack')[
        [
            'name',
            'maturity_bucket',
            'rating_bucket', 'capital_stack',
            'currency',
            *additional_cols,
            'reset_spread',
            'reset_index'
        ]
    ]

    table1 = make_data_table(data_, title='CASH', items_per_page=10, parser_options={'autoresize': False})
    # table1 = DataGrid(data_)
    # table1.auto_fit_columns = True
    display(table1.box)
    # display(table1)

    res = {}
    for cs in capital_stack_items:
        data__ = data_.query(f"capital_stack == '{cs}' and currency == '{currency}'")[['maturity_bucket', item]]
        res[cs] = data__.groupby('maturity_bucket').mean()

    pairs = [
        ('at1', 'lt2'),
        ('lt2', 'snp'),
        ('snp', 'sp')
    ]

    ratios = {}
    for pair in pairs:
        cs1, cs2 = pair
        ratios[pair] = (res[cs1] / res[cs2]).squeeze(axis=1).rename(' / '.join(pair))
    all_ratios = pd.concat(ratios.values(), axis=1)
    table2 = make_data_table(custom_sort(all_ratios, axis=0), title='CASH ratio',  parser_options={'autoresize': False})
    # table2 = DataGrid(custom_sort(all_ratios, axis=0))
    # table2.auto_fit_columns = True

    # CDS
    mask = ((cds_data['issuer_name'] == issuer) & (cds_data['currency'] == currency))
    cds_data_ = cds_data.loc[mask]

    _more_cols = ['last_price']
    to_drop = [f"{_field}_{interval}_{rng}" for _field in _more_cols for interval in intervals for rng in ranges if rng != _range]
    cds_data_ = cds_data_.drop(to_drop, axis=1)

    if not cds_data_.empty:
        table3 = make_data_table(cds_data_, title='CDS', parser_options={'autoresize': False})
        # table3 = DataGrid(cds_data_)
        # table3.auto_fit_columns = True
        display(table3.box)
        # display(table3)
        cds_res = {}
        for cs in cds_capital_stack_items:
            cds_data__ = cds_data_.query(f"cds_capital_stack == '{cs}' and currency == '{currency}'")[
                ['cds_years', 'cds_spread']]
            cds_res[cs] = cds_data__.groupby('cds_years').mean()

        cds_pairs = [
            ('SLA', 'SR'),
            ('SUB', 'SLA'),
            ('SUB', 'SR')
        ]

        cds_ratios = {}
        for pair in cds_pairs:
            cs1, cs2 = pair
            cds_ratios[pair] = (cds_res[cs1] / cds_res[cs2]).squeeze(axis=1).rename(' / '.join(pair))
        all_cds_ratios = pd.concat(cds_ratios.values(), axis=1)
        table4 = make_data_table(all_cds_ratios, title='CDS ratio', items_per_page=100, parser_options={'autoresize': False})
        # table4 = DataGrid(all_cds_ratios)
        # table4.auto_fit_columns = True

        display(table2.box)
        display(table4.box)
        # display(table2)
        # display(table4)
    else:
        display(table2.box)
        # display(table2)
