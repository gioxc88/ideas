import json
import sys
from pathlib import Path

import ipywidgets as w
import ipyvuetify as v
import pdblp
import numpy as np
import pandas as pd
from IPython.display import display
from ipydatagrid import DataGrid
from sklearn.linear_model import LinearRegression

from .base import Tab
from ..data.base import tables
from ..data.pairs import pairs


indices_history = tables.indices_history


def make_fig(tickers, op='/', mult=None):
    if not mult:
        mult = 1
    df = indices_history.loc[indices_history['security'].isin(tickers)] \
        .pivot(index='date', columns='security') \
        .droplevel(level=0, axis=1).dropna()[tickers]

    res = eval(f"df.iloc[:, 0] {op} df.iloc[:, 1]") * mult
    ser = res.rename(f' {op} '.join(tickers))
    fig = ser.plot(backend='plotly', height=500, template='plotly_white')
    return fig.update_layout(
        legend=
        dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0
        )
    )


area_sel = v.Autocomplete(
    v_model=None,
    items=[*pairs],
    label='currency',
    dense=True,
    outlined=True
)

pair_sel = v.Autocomplete(
    v_model=None,
    items=None,
    label='pair',
    dense=True,
    outlined=True
)

chart_btn = v.Btn(
    left=True,
    children=[
        v.Icon(children=['mdi-chart-line']),
        'Chart'
    ],
)

out = w.Output()


def on_change_populate_dd(widget, event, data):
    pair_sel.items = [*pairs[widget.v_model]]


area_sel.on_event('change', on_change_populate_dd)

param_box = v.Container(
    children=[
        v.Row(
            children=[
                v.Col(
                    cols=2,
                    children=[area_sel]
                ),
                v.Col(
                    cols=2,
                    children=[pair_sel]
                ),
                v.Col(
                    cols=2,
                    children=[chart_btn]
                ),
            ]
        )
    ]
)

tab = w.VBox(
    children=[
        param_box,
        out,
    ]
)


def on_click_chart(widget, event, data):
    widget.loading = True
    try:
        pair = pairs[area_sel.v_model][pair_sel.v_model]
        tickers = pair['tickers']
        op = pair['op']
        mult = pair.get('mult')
        fig = make_fig(tickers, op, mult)
        with out:
            out.clear_output()
            display(fig)
    except Exception as e:
        print(e)
    finally:
        widget.loading = False


chart_btn.on_event('click', on_click_chart)

tab_ = Tab(tab, name='pairs')
