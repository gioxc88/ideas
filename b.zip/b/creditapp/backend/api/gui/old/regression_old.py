import json
import sys
from pathlib import Path

import ipywidgets as w
import ipyvuetify as v
import pdblp
import numpy as np
import pandas as pd
from IPython.display import display
from ipydatagrid import DataGrid
from sklearn.linear_model import LinearRegression

from .base import Tab
from ..data.base import tables
from ..data.pairs import pairs


indices_history = tables.indices_history



def make_fig(ser, **kwargs):

    if title := kwargs.get('title'):
        ser = ser.rename(title)
    fig = ser.plot(backend='plotly', height=500, template='plotly_white')
    return fig.update_layout(
        legend=
        dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0
        )
    )


### Regression

area_sel = v.Autocomplete(
    v_model=None,
    items=[*pairs],
    label='currency',
    dense=True,
    outlined=True
)

pair_sel = v.Autocomplete(
    v_model=None,
    items=None,
    label='pair',
    dense=True,
    outlined=True
)

window_sel = v.TextField(
    v_model=3,
    type="number",
    dense=True,
    outlined=True,
    label='window (yr)'
    # hide_details=True

)

chart_btn = v.Btn(
    left=True,
    children=[
        v.Icon(children=['mdi-chart-line']),
        'Chart',
    ],
)

out = w.Output()


def on_change_populate_dd(widget, event, data):
    pair_sel.items = [*pairs[widget.v_model]]


area_sel.on_event('change', on_change_populate_dd)

param_box = v.Container(
    children=[
        v.Row(
            children=[
                v.Col(
                    cols=2,
                    children=[area_sel]
                ),
                v.Col(
                    cols=2,
                    children=[pair_sel]
                ),
                v.Col(
                    cols=2,
                    children=[window_sel]
                ),
                v.Col(
                    cols=2,
                    children=[chart_btn]
                ),
            ],
            align_content='center'
        )
    ]
)

tab = w.VBox(
    children=[
        param_box,
        out,
    ]
)


class RollingOLS:
    def __init__(self, window=3):
        self.window = window

    def fit(self, df, window=None, y=None, X=None):
        if window:
            self.window = window
        window = self.window

        yr = df.iloc[:, 0] if not y else df[y]
        y = yr.name
        Xr = df.drop(y, axis=1) if not X else df[X]

        lms = []
        for i in range(len(Xr) - window + 1):
            Xw = Xr[i: i + window]
            yw = yr[i: i + window]
            lm = LinearRegression().fit(Xw, yw)
            lms.append(lm)
        self.X = Xr
        self.y = yr
        self.lms = lms
        return self

    def chain_residual(self):
        ress = []
        for i in range(len(self.X) - self.window + 1):
            Xw = self.X[i: i + self.window]
            yw = self.y[i: i + self.window]
            lm = self.lms[i]
        # for Xw, yw, lm in zip(self.X, self.y, self.lms):
            res = yw - lm.predict(Xw)
            ress.append(res.iloc[-1:])
        return pd.concat(ress).rename(f"residuals")

    def get_mean_coefs(self):
        a = [lm.intercept_ for lm in self.lms]
        b = [lm.coef_ for lm in self.lms]

        return pd.Series(a).mean(), pd.DataFrame(b).squeeze().mean()


def ols(df, y=None, X=None):
    yr = df.iloc[:, 0] if not y else df[y]
    y = yr.name
    Xr = df.drop(y, axis=1) if not X else df[X]
    lm = LinearRegression().fit(Xr, yr)
    res = yr - lm.predict(Xr)
    return res.iloc[-1:]


def rolling_ols(df, window, y=None, X=None):
    ress = []
    for i in range(len(df) - window + 1):
        # df_ = df[i: i + window]
        res = ols(df[i: i + window], y=y, X=X)
        ress.append(res)

    return pd.concat(ress).rename(f"residuals")


def on_click_chart(widget, event, data):
    widget.loading = True
    window = int(window_sel.v_model) * 252
    try:
        pair = pairs[area_sel.v_model][pair_sel.v_model]
        tickers = pair['tickers']
        df = indices_history.query(f'security in {tickers}') \
            .pivot(index='date', columns='security') \
            .droplevel(level=0, axis=1).dropna()[tickers]
        rols = RollingOLS(window=window).fit(df)
        res = rols.chain_residual()
        # res = rolling_ols(df, window)
        y, x = pair_sel.v_model.split(' vs ')
        a, b = rols.get_mean_coefs()
        # f"{y} - α - β * {x} + residuals"
        fig = make_fig(res, title=f"residuals = {y} - {a:.2f} - {b:.2f} * {x}")
        with out:
            out.clear_output()
            display(fig)
    except Exception as e:
        print(e)
    finally:
        widget.loading = False


chart_btn.on_event('click', on_click_chart)

tab_ = Tab(tab, name='regression')
