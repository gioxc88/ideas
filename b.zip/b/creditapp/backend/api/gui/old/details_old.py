import json
import sys
from pathlib import Path

import ipywidgets as w
import ipyvuetify as v
import pdblp
import numpy as np
import pandas as pd
from IPython.display import display
from ipydatagrid import DataGrid
from sklearn.linear_model import LinearRegression

from .base import Tab
from ..data.base import tables

indices = tables.indices
indices_history = tables.indices_history
indices_reference = tables.indices_reference

indices = indices.assign(
    combined_name=indices.drop('ticker', axis=1).apply(lambda x: '_'.join(x.dropna()), axis=1),
)


def make_fig(tickers):
    df = indices_history.loc[indices_history['security'].isin(tickers)] \
        .pivot(index='date', columns='security') \
        .droplevel(level=0, axis=1).dropna()[tickers]
    print(df)
    ratio = (df.iloc[:, 0] / df.iloc[:, 1]).rename(' / '.join(tickers))
    fig = ratio.plot(backend='plotly', height=500, template='plotly_white')
    return fig.update_layout(
        legend=
        dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0
        )
    )


idx1_sel = v.Autocomplete(
    v_model=None,
    items=indices_reference['name'].to_list(),
    label='idx1',
    dense=True,
    outlined=True
)

idx2_sel = v.Autocomplete(
    v_model=None,
    items=indices_reference['name'].to_list(),
    label='idx2',
    dense=True,
    outlined=True
)

chart_btn = v.Btn(
    left=True,
    children=[
        v.Icon(children=['mdi-chart-line']),
        'Chart'
    ],
)
out = w.Output()

param_box = v.Container(
    children=[
        v.Row(
            children=[
                v.Col(
                    cols=4,
                    children=[idx1_sel]
                ),
                v.Col(
                    cols=4,
                    children=[idx2_sel]
                ),
                v.Col(
                    cols=2,
                    children=[chart_btn]
                ),
            ]
        )
    ]
)

tab = w.VBox(
    children=[
        param_box,
        out,
    ]
)


def on_click_chart(widget, event, data):
    widget.loading = True
    try:
        names = [idx1_sel.v_model, idx2_sel.v_model]
        tickers = indices_reference.loc[indices_reference['name'].isin(names)]
        tickers = tickers.sort_values(by='name', key=lambda x: [names.index(i) for i in x])['ticker'].to_list()
        fig = make_fig(tickers)
        with out:
            out.clear_output()
            display(fig)
    except Exception:
        pass
    finally:
        widget.loading = False


chart_btn.on_event('click', on_click_chart)

tab_ = Tab(tab, name='details')
