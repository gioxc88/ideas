import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd
import ipyvuetify as v
import ipywidgets as w

from IPython.display import display
from plotly import graph_objects as go


from .base import Tab
from ..data.base import tables, data_path
from ..data.utils import _years, _capital_stack


cds_hist = pd.read_csv(data_path / 'cds_history.csv', parse_dates=['date'], dayfirst=True)
cds_ref = pd.read_csv(data_path / 'cds_reference.csv').query('exists == True').drop_duplicates(subset='security')
cds_data = cds_hist.merge(cds_ref, on='security', how='left') \
    .drop(['exists', 'ticker', 'cds_ticker_5y'], axis=1) \
    .dropna(subset='last_price')

cds_pairs = [
    'SLA / SR',
    'SUB / SLA',
    'SUB / SR'
]

issuer_sel = v.Autocomplete(
    v_model=None,
    items=cds_ref['issuer_equity_ticker'].drop_duplicates().to_list(),
    label='issuer',
    dense=True,
    outlined=True
)

year_sel = v.Autocomplete(
    v_model=None,
    items=_years,
    label='years',
    dense=True,
    outlined=True
)

cap_stack_sel = v.Autocomplete(
    v_model=None,
    items=cds_pairs,
    label='capital stack',
    dense=True,
    outlined=True
)

chart_btn = v.Btn(
    left=True,
    children=[
        v.Icon(children=['mdi-chart-line']),
        'Chart'
    ],
)

param_box = v.Container(
    children=[
        v.Row(
            children=[
                v.Col(
                    cols=2,
                    children=[issuer_sel],
                    class_="my-0 py-0"
                ),
                v.Col(
                    cols=2,
                    children=[year_sel],
                    class_="my-0 py-0"
                ),
                v.Col(
                    cols=2,
                    children=[cap_stack_sel],
                    class_="my-0 py-0"
                ),
                v.Col(
                    cols=2,
                    children=[chart_btn],
                    class_="my-0 py-0"
                ),
            ],
            align_content='center',
        ),
    ]
)
out = w.Output()
tab = w.VBox(
    children=[
        param_box,
        out,
    ]
)


@out.capture(clear_output=True)
def on_click_plot(widget, event, payload):
    issuer = issuer_sel.v_model
    years = year_sel.v_model
    cds_data_ = cds_data.query(f'issuer_equity_ticker == "{issuer}" and years == {years}')
    pair = cap_stack_sel.v_model.split(' / ')
    s1 = cds_data_.query(f'capital_stack == "{pair[0]}"').set_index('date')['last_price']
    s2 = cds_data_.query(f'capital_stack == "{pair[1]}"').set_index('date')['last_price']

    ratio = (s1 / s2).dropna().rename(cap_stack_sel.v_model)
    fig = ratio.plot(backend='plotly', template='plotly_white', height=500)
    display(fig)


chart_btn.on_event('click', on_click_plot)
tab_ = Tab(tab, name='CDS')