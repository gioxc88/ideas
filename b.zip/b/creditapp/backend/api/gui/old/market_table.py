import json
import sys
from pathlib import Path
from typing import Union, List, Dict
from PIL import ImageFont

import ipywidgets as w
import ipyvuetify as v
import pdblp
import numpy as np
import pandas as pd
from IPython.display import display
from ipydatagrid import DataGrid

from .base import Tab
from .utils import tables, custom_sort, make_data_table
from ..data.processing import get_current_data

data = get_current_data()

cols = [
    'ticker',
    'name',
    'currency',
    'country',
    'bics_sector',
    'capital_stack',
    'maturity_bucket',
    'rating_bucket',
    'area',
    'last_price',
    'yield_to_call',
    'ytm_flat',
    'ytm_fwd',
    'xccy_usd',
    'i_spread',
    'z_spread',
    'aws_spread'
]

currency_items = data['currency'].drop_duplicates().to_list()
capital_stack_items = data['capital_stack'].drop_duplicates().to_list()
items = [
    'yield_to_call',
    'yield_to_worst',
    'ytm_flat',
    'ytm_fwd',
    'xccy_usd',
    'i_spread',
    'z_spread',
    'aws_spread'
]

curr_sel = v.Autocomplete(
    v_model='EUR',
    items=currency_items,
    label='currency',
    dense=True,
    outlined=True
)

cap_stack_sel = v.Autocomplete(
    v_model='at1',
    items=capital_stack_items,
    label='capital stack',
    dense=True,
    outlined=True
)

spread_sel = v.Autocomplete(
    v_model='z_spread',
    items=items,
    label='field',
    dense=True,
    outlined=True
)

index_ac = v.Autocomplete(
    v_model=['country', 'ticker'],
    label='index',
    items=[
        'ticker',
        'country',
        'currency',
        'maturity_bucket',
        'rating_bucket',
    ],
    outlined=True,
    multiple=True,
    chips=True,
    dense=True,
    clearable=True,
    # style_='width: 250px',
    # class_='ma-0 pa-0'
)

relevant_fields = [
    'ticker',
    'country',
    'currency',
    'maturity_bucket',
    'rating_bucket',
]

cols_ac = v.Autocomplete(
    v_model=['maturity_bucket'],
    label='cols',
    items=relevant_fields,
    outlined=True,
    multiple=True,
    chips=True,
    dense=True,
    clearable=True,
    # style_='width: 250px',
    # class_='ma-0 pa-0'
)

table_btn = v.Btn(
    left=True,
    children=[
        v.Icon(children=['mdi-table']),
        'Table',
    ],
)

out = w.Output()

param_box = v.Container(
    children=[
        v.Row(
            children=[
                v.Col(
                    cols=2,
                    children=[curr_sel],
                    class_="my-0 py-0"
                ),
                v.Col(
                    cols=2,
                    children=[cap_stack_sel],
                    class_="my-0 py-0"
                ),
                v.Col(
                    cols=2,
                    children=[spread_sel],
                    class_="my-0 py-0"
                ),
                v.Col(
                    cols=2,
                    children=[table_btn],
                    class_="my-0 py-0"
                ),
            ],
            align_content='center',
        ),
        v.Row(
            children=[
                v.Col(
                    cols=3,
                    children=[index_ac],
                    class_="my-0 py-0"
                ),
                v.Col(
                    cols=3,
                    children=[cols_ac],
                    class_="my-0 py-0"
                ),
            ],
            align_content='center',
        )
    ]
)

tab = w.VBox(
    children=[
        param_box,
        out,
    ]
)


def get_col():
    return [
        *relevant_fields,
        spread_sel.v_model,
    ]


def get_mat():
    return [
        '2yr',
        '5yr',
        '7yr',
        '10yr',
        '15yr'
    ]


def get_rtg():
    return [
        'AA',
        'A',
        'BBB',
        'BB',
        'B'
    ]


filters = [
    f"currency == '{curr_sel.v_model}'",
    " and ", f"capital_stack == '{cap_stack_sel.v_model}'",
    " and ", f"maturity_bucket in {get_mat()}",
    " and ", f"rating_bucket in {get_rtg()}"
]


def get_pivot(df):
    filters = [
        f"currency == '{curr_sel.v_model}'",
        " and ", f"capital_stack == '{cap_stack_sel.v_model}'",
        " and ", f"maturity_bucket in {get_mat()}",
        " and ", f"rating_bucket in {get_rtg()}"
    ]

    df_ = df.query(''.join(filters))
    return df_.dropna(subset=spread_sel.v_model).pivot_table(values=spread_sel.v_model, index=index_ac.v_model,
                                                             columns=cols_ac.v_model)


def on_click_make_pivot(widgets, event, payload):
    pivot_df = get_pivot(data)
    pivot_df = custom_sort(pivot_df, axis=1)
    pivot_df = custom_sort(pivot_df, axis=0)
    cont = make_data_table(pivot_df)
    with out:
        out.clear_output()
        display(cont.box)


table_btn.on_event('click', on_click_make_pivot)
tab_ = Tab(tab, name='pivot')
