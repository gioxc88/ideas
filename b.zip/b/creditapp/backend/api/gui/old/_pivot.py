from IPython.display import IFrame, HTML
import json, io
from typing import Iterable
from html import unescape, escape


class IFrame:
    """
    Generic class to embed an iframe in an IPython notebook
    """

    iframe = """
        <iframe
            width="{width}"
            height="{height}"
            srcdoc="{srcdoc}"
            frameborder="0"
            allowfullscreen
            {extras}
        ></iframe>
        """

    def __init__(self, srcdoc, width='100%', height='100%', extras: Iterable[str] = None, **kwargs):
        if extras is None:
            extras = []

        self.srcdoc = srcdoc
        self.width = width
        self.height = height
        self.extras = extras
        self.params = kwargs

    def _repr_html_(self):
        """return the embed iframe"""
        if self.params:
            from urllib.parse import urlencode
            params = "?" + urlencode(self.params)
        else:
            params = ""
        return self.iframe.format(
            srcdoc=self.srcdoc,
            width=self.width,
            height=self.height,
            params=params,
            extras=" ".join(self.extras),
        )


TEMPLATE = f"""
<html>
    <head>
        <meta charset="UTF-8">
        <title>PivotTable.js</title>
        <!-- external libs from cdnjs -->
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/c3/0.4.11/c3.min.css">
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/d3/3.5.5/d3.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/c3/0.4.11/c3.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-csv/0.71/jquery.csv-0.71.min.js"></script>
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/pivottable/2.23.0/pivot.min.css">
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pivottable/2.23.0/pivot.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pivottable/2.23.0/d3_renderers.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pivottable/2.23.0/c3_renderers.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pivottable/2.23.0/export_renderers.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pivottable/2.23.0/plotly_renderers.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/subtotal@1.11.0-alpha.0/dist/subtotal.min.js"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/subtotal@1.11.0-alpha.0/dist/subtotal.min.css">

        <style>
            body {{font-family: Verdana;}}
            .node {{
              border: solid 1px white;
              font: 10px sans-serif;
              line-height: 12px;
              overflow: hidden;
              position: absolute;
              text-indent: 2px;
            }}
            .c3-line, .c3-focused {{stroke-width: 3px !important;}}
            .c3-bar {{stroke: white !important; stroke-width: 1;}}
            .c3 text {{ font-size: 12px; color: grey;}}
            .tick line {{stroke: white;}}
            .c3-axis path {{stroke: grey;}}
            .c3-circle {{ opacity: 1 !important; }}
            .c3-xgrid-focus {{visibility: hidden !important;}}
        </style>
    </head>
    <body>
        <script type="text/javascript">
            $(function(){{
                var dataClass = $.pivotUtilities.SubtotalPivotData
                var renderers = $.extend(
                            $.pivotUtilities.renderers,
                            $.pivotUtilities.c3_renderers,
                            $.pivotUtilities.d3_renderers,
                            $.pivotUtilities.export_renderers,
                            $.pivotUtilities.subtotal_renderers,
                            $.pivotUtilities.plotly_renderers,
                        );
                if(window.location != window.parent.location)
                    $("<a>", {{target:"_blank", href:""}})
                        .text("[pop out]").prependTo($("body"));
                $("#output").%(pivot_type)s(
                    $.csv.toArrays($("#output").text()),
                    $.extend({{
                        dataClass: dataClass,
                        renderers: $.pivotUtilities.subtotal_renderers,
                        hiddenAttributes: [""]
                    }}, %(kwargs)s)
                ).show();
             }});
        </script>
        <div id="output" style="display: none;">%(csv)s</div>
    </body>
</html>
"""

def pivot_ui(
        df,
        pivot_type='pivotUI',
        width="100%",
        height="500",
        **kwargs
):
    csv = df.to_csv(encoding='utf8').replace("\r\n", "\n")
    code = TEMPLATE % dict(csv=csv, pivot_type=pivot_type, kwargs=json.dumps(kwargs))
    return IFrame(escape(code), width=width, height=height)