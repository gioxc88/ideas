import numpy as np
import pandas as pd

from .utils import tables

fields = {
    'TICKER': 'ticker',
    'SECURITY_NAME': 'name',
    'ID_ISIN': 'isin',
    'CRNCY': 'currency',
    'CNTRY_OF_RISK': 'country',
    'BICS_LEVEL_1_SECTOR_NAME': 'bics_sector',
    'BICS_LEVEL_2_INDUSTRY_GROUP_NAME': 'bics_industry',
    'AMT_OUTSTANDING': 'amount_outstanding',
    'ISSUE_DT': 'issue_date',
    'MATURITY': 'maturity',
    'CALC_MATURITY': 'calc_maturity',
    'WORKOUT_DT_MID': 'workout_date',
    'MTY_TYP': 'maturity_type',
    'CPN': 'coupon',
    'CPN_TYP': 'coupon_type',
    'RTG_SP': 'rating_sp',
    'RTG_MOODY': 'rating_moody',
    'RTG_FITCH': 'rating_fitch',
    'BB_COMPOSITE': 'rating_bbg',
    'FIXED': 'is_fixed',
    'CALLABLE': 'is_callable',
    'IS_PERPETUAL': 'is_perpetual',
    'CONVERTIBLE': 'is_convertible',
    'IS_SUBORDINATED': 'is_subordinated',
    'PAYMENT_RANK': 'payment_rank',
    'BAIL_IN_BOND_DESIGNATION': 'bail_in_bond_designation',
    'BASEL_III_DESIGNATION': 'basel_iii_designation',
    'GREEN_BOND_LOAN_INDICATOR': 'is_green',
    'RESET_IDX': 'reset_index'
}


fields_history = [
    {
        "field": "PX_LAST",
        "name": "last_price",
    },
    {
        "field": "PX_LAST_EOD",
        "name": "eod_price",
        "overrides": [
            ('PRICING_SOURCE', 'CBBT')
        ]
    },
    {
        "field": "HIGH_52WEEK",
        "name": "high_52weeks",
    },
    {
        "field": "Low_52WEEK",
        "name": "low_52w",
    },
    {
        "field": "YLD_YTC_MID",
        "name": "yield_to_call",
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "yield_to_call_high_52w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "52w")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "yield_to_call_low_52w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "52w")
        ]
    },
    {
        "field": "YLD_YTM_MID",
        "name": "ytm_flat",
    },
    {
        "field": "YAS_BOND_YLD",
        "name": "ytm_fwd",
    },
    {
        "field": "YAS_BOND_YLD",
        "name": "yield_to_worst",
        "overrides": [
            ("YAS_YLD_FLAG", 15)
        ]
    },
    {
        "field": "YAS_XCCY_FIXED_COUPON_EQUIVALENT",
        "name": "xccy_usd",
        "overrides": [
            ("YAS_XCCY_FOREIGN_CURRENCY", "USD"),
        ]
    },
    {
        "field": "YAS_ISPREAD",
        "name": "i_spread",
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "i_spread_high_52w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "I_SPRD_MID"),
            ("CALC_INTERVAL", "52w")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "i_spread_low_52w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "I_SPRD_MID"),
            ("CALC_INTERVAL", "52w")
        ]
    },
    {
        "field": "Z_SPRD_MID",
        "name": "z_spread",
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "z_spread_high_52w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "52w")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "z_spread_low_52w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "52w")
        ]
    },
    {
        "field": "YAS_ASW_SPREAD",
        "name": "aws_spread",
    },
    {
        "field": "YAS_MOD_DUR",
        "name": "mod_dur",
    },
    {
        "field": "FLT_SPREAD",
        "name": "reset_spread",
    },
]


def add_custom_rating(res):
    watches = [
        "\*\+",
        "\*-",
        "\*S",
        "\*",
        'u',
        ' ',
        '\(EXP\)',
    ]

    not_rated = [
        'WD',
        'NR'
    ]

    rating_columns = [
        'rating_sp',
        'rating_moody',
        'rating_fitch',
        'rating_bbg',
    ]

    # replace watches
    for col in rating_columns:
        res[col] = res[col].str.replace('|'.join(watches), '', regex=True)

    # replace not rated with na
    for col in rating_columns:
        res.loc[res[col].isin(not_rated), col] = np.nan

    # map rating to internal rating
    custom_rating = res[rating_columns[0]].replace(tables.rating.set_index(rating_columns[0].rsplit('_')[1])['rating'])
    for col in rating_columns[1:-1]:
        fill = res[col].replace(tables.rating.set_index(col.rsplit('_')[1])['rating'])
        custom_rating = custom_rating.fillna(fill)

    res = res.assign(
        custom_rating=custom_rating
    )
    return res


def add_capital_stack(res, tickers):
    res = res.set_index('security')
    res = pd.concat(
        [
            res,
            tickers.reset_index().set_index('security').squeeze(axis=1).rename('capital_stack')
        ],
        axis=1,
        sort=False
    ).reset_index()
    return res


def add_rating_bucket(res):
    res = pd.merge(
        res,
        tables.rating.set_index('rating')['group'].rename('rating_bucket'),
        right_index=True,
        left_on='custom_rating',
        how='left',
    )
    return res


def add_geo_area(res):
    res = pd.merge(
        res,
        tables.country.set_index('iso')[['macroarea', 'area']],
        right_index=True,
        left_on='country',
        how='left',
    )
    return res


def post_process(res, tickers):
    res = res.copy(deep=True)
    res = res.rename(fields, axis=1)
    res = add_custom_rating(res)
    res = add_capital_stack(res, tickers)
    res = add_rating_bucket(res)
    res = add_geo_area(res)
    res = res.dropna(subset=['ticker', 'name', 'isin'])
    return res
