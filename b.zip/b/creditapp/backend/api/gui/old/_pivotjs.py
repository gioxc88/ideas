import json
import sys
from pathlib import Path

import ipywidgets as w
import ipyvuetify as v
import pdblp
import numpy as np
import pandas as pd
from IPython.display import display
from ipydatagrid import DataGrid
from sklearn.linear_model import LinearRegression

root_path = Path('/dev/projects/credit/backend/')

if (path := str(root_path.resolve())) not in sys.path:
    sys.path.append(path)

import utils
from api.gui.utils import tables
from api.gui.pairs import tab_ as pairs_tab
from api.gui.details import tab_ as details_tab
from api.gui.regression import tab_ as regression_tab
from api.gui.base import MultiTab, Tab
from api.gui.pivot import pivot_ui

data_path = root_path / 'data'

date_columns = [
    'issue_date',
    'maturity',
    'calc_maturity',
    'workout_date'
]

ref_data = pd.read_csv(data_path / 'bonds_reference.csv', index_col=['security'], parse_dates=date_columns)
mkt_data = pd.read_csv(data_path / 'bonds_market.csv', index_col=['security'])

data = pd.concat([ref_data, mkt_data], axis=1, join='inner')


def add_years_to_maturity(df):
    df = df.assign(
        years_to_maturity=(df['workout_date'] - pd.Timestamp.today()).dt.days / 365.2425
    )
    return df


def add_maturity_bucket(df):
    bins = [*tables.maturity['lower_bound'], np.inf]
    idx = np.digitize(df['years_to_maturity'].fillna(0), bins) - 1
    maturity_bucket = tables.maturity.iloc[idx, tables.maturity.columns.get_loc('label')].set_axis(df.index)
    maturity_bucket[df['years_to_maturity'].isna()] = np.nan
    return pd.concat([df, maturity_bucket.rename('maturity_bucket')], axis=1)


data = add_years_to_maturity(data)
data = add_maturity_bucket(data)

pivot = pivot_ui(
    data.reset_index(),
    height=1000,
    # pivot_type='pivot'
    rows=['country', 'ticker'],
    cols=['maturity_bucket']
)

out = w.Output()
with out:
    display(pivot)

tab_ = Tab(out, name='pivot')


