
from .pairs import tab_ as pairs_tab
from .base import MultiTab


app = MultiTab(
    tabs=[
        pairs_tab,

    ]
)