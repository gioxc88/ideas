from functools import partial

import ipywidgets as w
import ipyvuetify as v

from IPython.display import display

from ..data.base import tables
from ..data.pairs import pairs
from .base import View


indices_history = tables.indices_history


class Pairs(View):
    def make_widgets(self):
        area_sel = v.Autocomplete(
            v_model=None,
            items=[*pairs],
            label='currency',
            dense=True,
            outlined=True
        )

        pair_sel = v.Autocomplete(
            v_model=None,
            items=None,
            label='pair',
            dense=True,
            outlined=True
        )

        chart_btn = v.Btn(
            left=True,
            children=[
                v.Icon(children=['mdi-chart-line']),
                'Chart'
            ],
        )

        out = w.Output()

        self.area_sel = area_sel
        self.pair_sel = pair_sel
        self.chart_btn = chart_btn
        self.out = out

    def make_view(self):
        area_sel = self.area_sel
        pair_sel = self.pair_sel
        chart_btn = self.chart_btn
        out = self.out

        param_box = v.Container(
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=2,
                            children=[area_sel]
                        ),
                        v.Col(
                            cols=2,
                            children=[pair_sel]
                        ),
                        v.Col(
                            cols=2,
                            children=[chart_btn]
                        ),
                    ]
                )
            ]
        )

        view = w.VBox(
            children=[
                param_box,
                out,
            ]
        )

        self.param_box = param_box
        self.view = view

    def link(self):

        pair_sel = self.pair_sel
        area_sel = self.area_sel
        chart_btn = self.chart_btn
        out = self.out

        area_sel.on_event(
            'change',
            partial(on_change_populate_dd, pair_sel=pair_sel)
        )
        chart_btn.on_event(
            'click',
            out.capture(clear_output=True)(partial(on_click_chart, area_sel=area_sel, pair_sel=pair_sel))
        )


def make_fig(tickers, op='/', mult=None):
    if not mult:
        mult = 1
    df = indices_history.loc[indices_history['security'].isin(tickers)] \
        .pivot(index='date', columns='security') \
        .droplevel(level=0, axis=1).dropna()[tickers]

    res = eval(f"df.iloc[:, 0] {op} df.iloc[:, 1]") * mult
    ser = res.rename(f' {op} '.join(tickers))
    fig = ser.plot(backend='plotly', height=500, template='plotly_white')
    return fig.update_layout(
        legend=
        dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0
        )
    )


def on_change_populate_dd(widget, event, data, pair_sel):
    pair_sel.items = [*pairs[widget.v_model]]


def on_click_chart(widget, event, data, area_sel, pair_sel):
    widget.loading = True
    try:
        pair = pairs[area_sel.v_model][pair_sel.v_model]
        tickers = pair['tickers']
        op = pair['op']
        mult = pair.get('mult')
        fig = make_fig(tickers, op, mult)
        display(fig)
    except Exception as e:
        print(e)
    finally:
        widget.loading = False

