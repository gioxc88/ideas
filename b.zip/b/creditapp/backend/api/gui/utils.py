import pickle
from pathlib import Path
from typing import Union, List, Dict
from PIL import ImageFont

import numpy as np
import pandas as pd
import ipywidgets as w
import ipyvuetify as v

from IPython.display import display


from ..data.base import tables


def _is_intraday(series):
    return (series.dt.hour != 0).any()


def get_str_size(text, font_size, font_name):
    font = ImageFont.truetype(font_name, font_size)
    size = font.getsize(text)
    return size


def _get_width(series):
    k_scale = 1.4
    max_name = get_str_size((series.name or '') + ' ', 9, 'calibri.ttf')[0]
    max_value = get_str_size(series[series.str.len().idxmax()], 12, 'calibri.ttf')[0]
    max_all = max(max_name, max_value)

    return k_scale * max_all


def get_columns_width(df):
    dfstr = df.astype(str)
    return {col: _get_width(dfstr[col]) for col in dfstr}


def df_to_json(
        df,
        formats=None,
        headers=None,
        index_headers=None,
        autoresize=True,
):
    headers_ = headers or {}
    index_levels = df.index.nlevels

    df = df.reset_index()
    index_cols = [*df.columns[:index_levels]]
    df_format = _format_df(df, index_cols, formats).fillna('').replace('nan', '')

    #         if isinstance(df.index, pd.DatetimeIndex):
    #             df.index = df.index.strftime('%Y-%m-%d')
    # df = df.reset_index()  # .fillna('')
    #
    headers = [{
        "text": col,
        "value": col
    } for col in df_format.columns]

    for i, col in enumerate(index_cols):
        headers[i].update({'align': 'start'})
        if index_headers:
            headers[i].update(index_headers)

    if headers_:
        for h in headers[len(index_cols):]:
            h.update(headers_)

    if autoresize:
        dfstr = df_format.astype(str)
        for i, col in enumerate(dfstr):
            width = _get_width(dfstr[col])
            headers[i].update({'width': width})

    df = dict(
        items=df.to_dict(orient='records'),
        display_items=df_format.to_dict(orient='records'),
        headers=headers,
        index_cols=index_cols,
    )
    return df


def _format_dates(df, index_cols, formats=None):
    formats = formats or []
    df = df.copy(deep=True)
    for col in df:
        if col not in formats and df[col].dtype in (np.datetime64, np.dtype('<M8[ns]')):
            fmt = '{:%Y-%m-%d %H}' if _is_intraday(df[col]) else '{:%Y-%m-%d}'
            fmt = '%Y-%m-%d %H' if _is_intraday(df[col]) else '%Y-%m-%d'
            df[col] = df[col].dt.strftime(fmt)
    return df


def _format_floats(df, index_cols, formats=None):
    formats = formats or []
    df = df.copy(deep=True)
    for col in df:
        if col not in formats and df[col].dtype in (np.float_, float):
            fmt = '{:.2f}'
            df[col] = df[col].map(fmt.format)
    return df


def df_from_json(obj, self):
    df = pd.DataFrame(obj['items']).astype(self.dtypes).set_index(obj['index_cols'])
    return df


def _format_df(
        df: pd.DataFrame,
        index_cols: List = None,
        formats: Union[str, Dict[str, str]] = None,
):
    '''
    As of pandas 1.2.4 when you reset a single index which has no name the column is called 'index'
    If the index is a multi-index the columns are called 'level_0', 'level_1', etc ...
    :param df: the dataframe passed has the index reset already
    :param format:
    :param index_cols:
    :return:
    '''
    if not formats:
        df = _format_dates(df, index_cols, formats)
        df = _format_floats(df, index_cols, formats)
        return df

    elif isinstance(formats, dict):
        if format_star := formats.pop('*', None):
            columns_star = df.columns.difference([*formats, index_cols])
            for col in columns_star:
                formats[col] = format_star

            df_same = pd.DataFrame()
        else:
            df_same = df[df.columns.difference(formats)]

        df_format = pd.concat([df[key].map(value.format) for key, value in formats.items()])

    elif isinstance(formats, str):
        df_same = df[index_cols]
        df_format = df.drop(index_cols, axis=1).applymap(formats.format)
    else:
        raise ValueError(f'The formats parameter can be either a string or a dictionary but {formats} which is '
                         f'{type(formats)} was passed instead')

    df_final_format = pd.concat([df_same, df_format], axis=1)
    return _format_dates(df_final_format, index_cols, formats).reindex(columns=df.columns)


def custom_sort(df, axis=1):
    idx = df.columns if axis == 1 else df.index

    spec = {
        'maturity_bucket': lambda x: x.map(tables.maturity.set_index('label')['rank']),
        'rating_bucket': lambda x: x.map(tables.rating.set_index('rating')['rank'])
    }

    for col in idx.names:
        key = spec.get(col)
        if key:
            df = df.sort_index(level=col, key=key, axis=axis)
    return df


def make_data_table(
        df,
        title='',
        parser_options: dict = None,
        **kwargs
):
    multi_sort = kwargs.pop('multi_sort', True)
    class_ = kwargs.pop('class_', "elevation-1")
    dense = kwargs.pop('multi_sort', True)
    items_per_page = kwargs.pop('items_per_page', 20)
    dfj = df_to_json(df, **(parser_options or {}))
    table_ = v.DataTable(
        v_model=None,
        headers=dfj['headers'],
        items=dfj['display_items'],
        multi_sort=multi_sort,
        class_=class_,
        dense=dense,
        items_per_page=items_per_page,
        **kwargs
    )

    search_field_ = v.TextField(
        v_model=None,
        append_icon="mdi-magnify",
        label="Search",
        single_line=True,
    )
    w.jslink((table_, 'search'), (search_field_, 'v_model'))
    card = v.Card(
        children=[
            v.CardTitle(
                children=[
                    title,
                    v.Spacer(),
                    search_field_
                ]
            ),
            table_,
        ],
    )

    box_ = make_single_item_container(card, cols=11)

    class Table:
        table = table_
        search = search_field_
        box = box_

    return Table()


def make_single_item_container(item, cols=12):
    return v.Container(
        children=[

            v.Row(
                children=[
                    v.Col(
                        cols=cols,
                        children=[
                            item
                        ]
                    )
                ]
            )
        ]
    )




