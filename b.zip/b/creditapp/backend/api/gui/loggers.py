import logging


class CustomFormatter(logging.Formatter):
    """Custom formatter, overrides funcName with value of name_override if it exists"""

    def format(self, record):
        if hasattr(record, 'name_override'):
            record.funcName = record.name_override
        return super(CustomFormatter, self).format(record)


def get_logger():
    logger = logging.getLogger(__name__)
    # Prevent logging from propagating to the root logger
    level = logging.DEBUG
    logger.setLevel(level)

    formatter = CustomFormatter(
        fmt="%(asctime)s [%(levelname)s] (%(funcName)s): %(message)s",
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    if not logger.handlers:
        logger.propagate = 0

        handlers = [
            logging.FileHandler(filename="debug.log", mode='w'),
            logging.StreamHandler()
        ]

        for h in handlers:
            h.setFormatter(formatter)
            logger.addHandler(h)

    return logger