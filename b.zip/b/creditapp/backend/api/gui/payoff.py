import numpy as np
import pandas as pd
import ipywidgets as w
import ipyvuetify as v

from IPython.display import display
from plotly import graph_objects as go
from .base import Tab


def get_payoff(price, strike, premium, quantity, type='receiver'):
    po = price - strike if type == 'receiver' else strike - price
    return quantity * max(po - premium, - premium)


def get_break_points(strike, premium, quantity, type='receiver', price=None, m=.5):
    c = 1 if type == 'receiver' else -1

    if price:
        p = (price - strike)
    else:
        p = strike * m * c

    # xs.append([strike, strike - p])
    # xs.append([strike + c * premium, strike + p])
    # xs.append([strike, strike + c * premium])
    # ys.append([- quantity * premium, - quantity * premium])
    # ys.append([0, quantity * (c * p - premium)])
    # ys.append([- quantity * premium, 0])

    xs = [strike - p, strike, strike + c * premium, strike + p]
    # ys = [- quantity * premium, - quantity * premium, 0, quantity * (c * p - premium)]
    ys = [get_payoff(x, strike, premium, quantity, type) for x in xs]
    return xs, ys


def get_name(strike, premium, quantity, type):
    return f"{int(quantity)} {type} {strike} @ {premium}"


from ipywidgets import DOMWidget


class Form:
    name = 'payoff'

    def __init__(self):
        self.add_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-plus'])]
        )
        self.chart_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-2',
            children=[v.Icon(children=['mdi-chart-line'])]
        )

        self.row_out = v.Row(children=[v.Col()])
        self.c = v.Container(
            children=[
                v.Row(
                    children=[
                        v.Col(
                            children=[
                                self.add_btn,
                                self.chart_btn
                            ]
                        )
                    ]
                ),
                self.row_out
            ]
        )

        self.add_btn.on_event('click', lambda widget, event, payload: self.make_box())
        self.tab = self.c

        def on_click_plot(widget, event, data):
            fig = self.make_plot()
            self.row_out.children[0].children = [fig]

        self.chart_btn.on_event('click', on_click_plot)

        self.boxes = []

    def make_box(self):

        strike_fld = v.TextField(
            v_model=None,
            type='number',
            label='strike',
            class_='my-0',
            dense=True,
        )

        premium_fld = v.TextField(
            v_model=0,
            type='number',
            label='premium',
            class_='my-0',
            dense=True,
        )

        quantity_fld = v.TextField(
            v_model=1,
            type='number',
            label='quantity',
            class_='my-0',
            dense=True,
        )

        type_ac = v.Autocomplete(
            v_model='receiver',
            items=['receiver', 'payer'],
            dense=True,
            label='type',
            class_='my-0',
        )

        remove_btn = v.Btn(
            fab=True,
            # dark=True,
            x_small=True,
            plain=True,
            color='error',
            class_='my-0',
            children=[v.Icon(children=['mdi-close'])]
        )
        cols = 1.0
        box = v.Row(
            children=[
                v.Col(
                    children=[strike_fld],
                    cols=cols
                ),
                v.Col(
                    children=[premium_fld],
                    cols=cols
                ),
                v.Col(
                    children=[quantity_fld],
                    cols=cols
                ),
                v.Col(
                    children=[type_ac],
                    cols=2
                ),
                v.Col(
                    children=[remove_btn],
                    cols=1
                ),
            ],
            # align='center',
            dense=True
        )

        box_dict = {
            'strike': strike_fld,
            'premium': premium_fld,
            'quantity': quantity_fld,
            'type': type_ac
        }
        self.boxes.append(box_dict)
        self.c.children = [*self.c.children[:-1], box, self.c.children[-1]]

        def remove_box(widget, event, payload):
            self.c.children = [child for child in self.c.children if child is not box]
            self.boxes.remove(box_dict)

        remove_btn.on_event('click', remove_box)

    def get_coordinates(self):
        '''
        It returns two tuple of arrays (xs, ys), (xs_payoff, ys_payoff).
        The first tuple contains the coordinates of the single options and the second tuple of the payoff
        '''

        xs = []
        ys = []
        for box in self.boxes:
            strike, premium, quantity, typ = (
                float(box['strike'].v_model),
                float(box['premium'].v_model),
                float(box['quantity'].v_model),
                box['type'].v_model
            )

            x, y = get_break_points(strike=strike, premium=premium, quantity=quantity, type=typ)
            xs.append(x)
            ys.append(y)

        xs_payoff = np.sort(np.unique(np.concatenate(xs)))
        ys_payoff = []
        for box in self.boxes:
            ys_ = []
            strike, premium, quantity, typ = (
                float(box['strike'].v_model),
                float(box['premium'].v_model),
                float(box['quantity'].v_model),
                box['type'].v_model
            )
            for x in xs_payoff:
                ys_.append(get_payoff(price=x, strike=strike, premium=premium, quantity=quantity, type=typ))

            ys_payoff.append(ys_)
        ys_payoff = [*np.array(ys_payoff).sum(axis=0)]

        return (xs, ys), (xs_payoff, ys_payoff)

    def get_names(self):
        names = []
        for box in self.boxes:
            strike, premium, quantity, typ = (
                float(box['strike'].v_model),
                float(box['premium'].v_model),
                float(box['quantity'].v_model),
                box['type'].v_model
            )
            names.append(get_name(strike, premium, quantity, typ))
        return names

    def make_plot(self):
        (xs, ys), (xs_payoff, ys_payoff) = self.get_coordinates()
        names = self.get_names()

        scatters = [
            go.Scatter(
                x=x,
                y=y,
                line=dict(dash='dot'),
                mode='lines',
                opacity=0.5,
                name=name,
            ) for x, y, name in zip(xs, ys, names)
        ]
        scatters.append(go.Scatter(x=xs_payoff, y=ys_payoff, mode='lines', name='payoff'))
        fig = go.FigureWidget(data=scatters)
        total_premium = self.get_total_premium()
        title = f"{'You pay' if total_premium >= 0 else 'You get paid'} {abs(total_premium)}"
        fig.update_layout(
            template="plotly_white",
            title=title
        )
        return fig

    def get_total_premium(self):
        return sum([float(box['premium'].v_model) * float(box['quantity'].v_model) for box in self.boxes])

    def _ipython_display_(self):
        display(self.c)


