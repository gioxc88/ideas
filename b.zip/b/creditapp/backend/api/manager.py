import datetime
from itertools import product, chain, groupby
from inspect import signature
from pathlib import Path

import numpy as np
import pandas as pd
from inflection import camelize, underscore
from sqlalchemy import inspect, and_, or_
from sqlalchemy.orm.attributes import InstrumentedAttribute

from . import db, models
from . import utils
from .providers.bloomberg import Bloomberg
from .inputs import Records, Instruments, InstrumentUI
from .models import (
    Asset,
    AssetCategory,
    # Portfolio,
    AssetMap,
    DataProvider,
    # PortfolioCompositionLive,
    # PriceMap,
    # FXMap,
    # Trade,
    get_model,
    get_callable
)


temp_path = Path(__file__).parents[1] / 'db/temp'


class Clone:
    def __init__(self, model):
        self.model = model
        self.obj = None
        self.obj_exists = False
        self.inspector = inspect(model)

    @property
    def table_name(self):
        return self.model.__tablename__

    # @property
    # def foreign_keys(self):
    #     return {
    #         name: ([*fk][0].column.name, Clone(get_model([*fk][0].column.table.name)))
    #         for name, col in self.inspector.columns.items() if (fk := col.foreign_keys)}

    @property
    def foreign_keys(self):
        fks = {}
        exclude = self.inspector.inherits.class_ if self.inspector.inherits else None
        for name, col in self.inspector.columns.items():
            if fk := col.foreign_keys:
                fk = [*fk][0]
                fk_col = fk.column.name
                clone = Clone(get_model(fk.column.table.name))
                if exclude is not clone.model:
                    fks[name] = (fk_col, clone)
        return fks

    def get_relationships(self, exclude=None):
        exclude = exclude or []
        include = [k for k, v in vars(self.model).items() if isinstance(v, InstrumentedAttribute)]
        rels = {
            relationship_name: Clone(relationship.entity.class_)
            for relationship_name, relationship in self.inspector.relationships.items()
            if relationship_name in include
        }
        return rels

    def get_relationship_column(self, col):
        for key, rel in self.inspector.relationships.items():
            for c in rel.local_columns:
                if c.name == col:
                    return key
        raise ValueError(f'Cannot find a unique relationship associated column {col}')

    def __repr__(self):
        return f'Clone({self.model.__name__})'


class InstrumentManager:
    '''
    IMPORTANT:
    Why do I get Integrity Error if I have duplicates in the records?
    Maybe it has to do with threading but the point is that I need
    to check that no duplicates are submitted during the add method call
    '''

    def __init__(self, provider=None):
        self._clones = []
        self.provider = provider or Bloomberg()
        self._records = None
        self._data = None
        self.db = db

    @staticmethod
    def check_instruments(instruments):
        print(f'Checking {len(instruments)} instruments... ', end='')

        def exists(instrument):
            model = get_model(instrument['category'])
            return model.from_instrument(instrument)

        instruments = [instrument for instrument in instruments if not exists(instrument)]
        print('OK!')
        print(f'Remaining {len(instruments)}. Duplicates and existing entries have been removed')
        return Instruments(instruments)

    def get_provider_map(self, category, provider=None):
        ''' variation of the the original map which accepts wild cards '''
        provider = provider or self.provider.__class__.__name__.lower()
        mapping = AssetMap
        q = db.session.query(mapping).join(AssetCategory, or_(
            mapping.id_asset_category == AssetCategory.id,
            mapping.id_asset_category.is_(None))) \
            .join(DataProvider) \
            .filter(and_(
            DataProvider.name == provider,
            or_(
                AssetCategory.name == category,
                AssetCategory.id != mapping.id_asset_category
            )
        ))

        df = pd.read_sql(q.statement, con=db.engine)

        # here I change the target and parent columns to match the category, so I can leave it blank in the csv file
        df.loc[:, 'parent'] = df['parent'].mask(df['parent'].isnull() & df['parent_obj'].notnull(), category)
        df.loc[:, 'target'] = df['target'].mask(df['target'].isnull() & df['target_field'].notnull(), category)
        # df[['parent', 'parent_field']] = df[['parent', 'parent_field']].replace({None: '*'})

        g = df.groupby(
            ['parent', 'parent_obj', 'target', 'target_field'],
            as_index=False,
            dropna=False
        )
        df = g.apply(lambda x: x if len(x) == 1 else x.dropna(subset=['id_asset_category']))
        # df[['parent', 'parent_field']] = df[['parent', 'parent_field']].replace({'*': None})
        return df

    # def get_provider_map_old(self, category, provider=None):
    #     # join_id = models.AssetCategory.exists(name=record.asset_category_name).id
    #     # q = db.session.query(*[getattr(AssetMapping, col) for col in cols]).filter(
    #     #     or_(AssetMapping.id_asset_category == join_id,
    #     #         AssetMapping.id_asset_category.is_(None)))
    #     provider = provider or self.provider.__class__.__name__.lower()
    #     q = db.session.query(
    #         AssetCategory.name.label('asset_category_name'),
    #         AssetMap.parent,
    #         AssetMap.parent_field,
    #         AssetMap.target,
    #         AssetMap.target_field,
    #         AssetMap.provider_field,
    #         Provider.name.label('provider')) \
    #         .join(AssetCategory).join(Provider) \
    #         .filter(and_(AssetCategory.name == category, Provider.name == provider))
    #     df = pd.read_sql(q.statement, con=db.engine)
    #     return df

    def get_data(self, instruments):
        instruments = self.provider.check_instruments_code(instruments)

        def key_func(instrument):
            return instrument.category

        instruments = sorted(instruments, key=key_func)
        g = groupby(instruments, key_func)
        data = {}
        for category, iterator in g:
            instrument_group = Instruments(iterator)

            provider_map = self.get_provider_map(category)
            fields = provider_map['provider_field'].drop_duplicates().dropna().to_list()
            bulk_fields = provider_map['provider_bulk_field'].drop_duplicates().dropna().to_list()
            # instruments_code = instrument_group.values

            df = self.provider.get_data(
                instruments=instrument_group,
                fields=fields
            )  # .reindex(instruments_code)

            # record_group = instrument_group.records
            final_map = self.post_process2(
                instrument_group,
                provider_map.loc[provider_map['provider_field'].notnull(), :],
                df
            )

            # this is done because Asset category field is auto-populated based on the category
            for instrument in instrument_group:
                final_map[instrument.value][(instrument.category, 'asset_category', 'asset_category')] = {
                    **instrument.record.get('asset_category')
                }

            data[category] = {
                'data': df,
                'map': final_map,
                # 'provider_map': provider_map,
                'instruments': instrument_group,
                'records': instrument_group.records
            }

            # Get the bulk fields
            if bulk_fields:
                bulk_dict = self.provider.get_bulk_data(
                    instruments=instrument_group,
                    fields=bulk_fields
                )  # .reindex(instruments_code)

                bulk_data = {'data': [], 'map': []}
                for field, bulk_df in bulk_dict.items():
                    if not bulk_df.empty:
                        final_bulk_map = self.post_process2(
                            instrument_group,
                            provider_map.loc[provider_map['provider_bulk_field'] == field, :],
                            bulk_df.loc[:, field]
                        )

                        new_bulk_map = {}
                        for ident, value in final_bulk_map.items():
                            new_bulk_map[ident] = {}

                            if isinstance(value, list):
                                for elem in value:  # value is a list
                                    for k, v in elem.items():
                                        new_bulk_map[ident].setdefault(k, [])
                                        new_bulk_map[ident][k].append(v)
                            else:  # assuming it's a dictionary
                                new_bulk_map[ident] = value

                        bulk_data['data'].append(bulk_df)
                        bulk_data['map'].append(new_bulk_map)

                for bulk_field_map in bulk_data['map']:
                    for ident, value in bulk_field_map.items():
                        for k, v in value.items():
                            if k not in final_map[ident]:
                                final_map[ident][k] = v
                            else:
                                final_map[ident][k] = {**final_map[ident][k], **v}

                data[category]['bulk_data'] = bulk_data['data']
            provider_map = pd.concat(
                [
                    provider_map,
                    pd.DataFrame([{'parent': category, 'parent_obj': 'asset_category', 'target': 'asset_category'}])
                ]
            )
            data[category]['provider_map'] = provider_map
        utils.to_pickle(data, temp_path / f'data_{datetime.datetime.now():%Y-%m-%d %H.%M.%S}.pickle')
        return data

    def load_file(self, file):
        data = utils.read_pickle(file)
        return data

    def post_process(self, instrument_group, provider_map, provider_data_group):
        '''
        Thanks to this function it will be possible to allow multiple fields per model column
        The idea is that the asset mapping might have multiple fields associated to a single column
        For example I might want to download three fields for the name columns in the asset table and then
        take the first not null value or further process the data before attaching it to the database table.
        Since the get data function saves the provider_map and the provider_data for each asset category,
        before passing provider_map and provider_data to recursive_add I can further process those dataframes
        Such that I end up with a one to one correspondence between provider_field and target_field.
        This can be done for example by adding an additional column to the asset_mapping table with the name
        of the function that is called to process those fields.
        :return:
        '''

        new_provider_data_group = provider_data_group.copy()
        new_provider_map = provider_map.copy()
        for key, group in provider_map.groupby('target_field'):

            fn_name = group['provider_callable'].drop_duplicates()
            if len(fn_name) > 1:
                fn_name = fn_name.dropna()
            fn_name = fn_name.squeeze()

            if fn_name:
                params = [eval(params) if params else {} for params in group['provider_callable_params']]
                params = {k: v for d in params for k, v in d.items()}

                fn = models.get_callable(fn_name)
                # at the moment the rule is that the transformation is either rn to r or r to r so
                # the functions must always return a series
                new_data = fn(provider_data_group[group['provider_column']], **params).rename(key)
                new_provider_data_group = new_provider_data_group.assign(**{key: new_data})
                new_provider_map = new_provider_map.drop(group.index)
                new_provider_map_row = group.iloc[0, :].copy()
                new_provider_map_row['provider_column'] = key
                new_provider_map = pd.concat([new_provider_map, new_provider_map_row.to_frame().T])

        final_group_map = {}
        for instrument in instrument_group:
            try:
                provider_data = new_provider_data_group.loc[instrument.value]
            except KeyError:
                pass
            else:
                final_group_map[instrument.value] = self.post_process_one(instrument, new_provider_map, provider_data)

        # for instrument, (identifier, provider_data) in zip(instrument_group, new_provider_data_group.iterrows()):
        #     final_group_map[identifier] = self.post_process_one(instrument, new_provider_map, provider_data)
        return final_group_map

    def post_process2(self, instrument_group, provider_map, provider_data_group):
        '''
        This function handles:
        R to R
        R^n to R
        R^n to R^n for bulk data
        R to R^n is not yet implemented

        :return:
        '''

        new_provider_data_group = []
        for key, group in provider_map.groupby('provider_callable_group', sort=False, dropna=False):

            fn_name = group['provider_callable'].drop_duplicates()
            if len(fn_name) > 1:
                fn_name = fn_name.dropna()
            fn_name = fn_name.squeeze()
            new_column_names = group[['parent_obj', 'target_field']].drop_duplicates().squeeze()
            if fn_name:
                params = [eval(params) if params else {} for params in group['provider_callable_params']]
                params = {k: v for d in params for k, v in d.items()}

                fn = models.get_callable(fn_name)
                # at the moment the rule is that the transformation is either rn to r or r to r so
                # the functions must always return a series
                new_data = fn(provider_data_group[group['provider_column'].dropna()], **params)

                if isinstance(new_column_names, pd.Series) and isinstance(new_data, pd.Series):
                    new_data = new_data.rename(tuple(new_column_names))
                else:  # assume it's a dataframe (Rn to Rn in case of bulk)
                    group['provider_column'] = group['provider_column'].fillna(group['target_field'])
                    name_map = group[['parent_obj', 'target_field', 'provider_column']].set_index('provider_column')\
                                                                                       .squeeze(axis=1)\
                                                                                       .apply(tuple, axis=1)\
                                                                                       .to_dict()
                    new_data = new_data.rename(name_map, axis=1)
                    new_data = new_data.set_axis(pd.MultiIndex.from_tuples(new_data.columns), axis=1)
                # if isinstance(new_column_names, str) and isinstance(new_data, pd.Series):
                #     new_data = new_data.rename(new_column_names)
                # else:  # assume it's a dataframe (Rn to Rn in case of bulk)
                #     name_map = group[['target_field', 'provider_column']].dropna()\
                #                                                          .set_index('provider_column')\
                #                                                          .squeeze(axis=1)\
                #                                                          .to_dict()
                #     new_data = new_data.rename(name_map, axis=1)
                new_provider_data_group.append(new_data)
            else:  # in this case the group is one column

                new_provider_data_group.append(provider_data_group.loc[:, key].rename(tuple(new_column_names)))

        new_provider_data_group = pd.concat(new_provider_data_group, axis=1)

        final_group_map = {}
        for instrument in instrument_group:
            try:
                provider_data = new_provider_data_group.loc[instrument.value]
            except KeyError:
                pass
            else:
                if isinstance(provider_data, pd.Series):
                    final_group_map[instrument.value] = self.post_process_one2(instrument, provider_map, provider_data)
                else:
                    final_group_map[instrument.value] = \
                        [
                            self.post_process_one2(instrument, provider_map, provider_data_i)
                            for identifier, provider_data_i in provider_data.iterrows()
                            ]

        # for instrument, (identifier, provider_data) in zip(instrument_group, new_provider_data_group.iterrows()):
        #     final_group_map[identifier] = self.post_process_one(instrument, new_provider_map, provider_data)
        return final_group_map

    @staticmethod
    def post_process_one(instrument, provider_map, provider_data):
        record = instrument.record
        final_record_map = {}
        for (parent_table, target_table), provider_map_subset in provider_map.groupby(
                ['parent', 'target'], sort=False, dropna=False
        ):
            parent_table = None if pd.isna(parent_table) else parent_table
            target_table = None if pd.isna(target_table) else target_table
            field_subset = provider_map_subset['provider_column'].to_list()
            provider_data_subset = provider_data[field_subset].to_dict()
            provider_target_field_map = provider_map_subset.set_index('provider_column')['target_field'].to_dict()
            # IMPORTANT! add logic group by to handle rn to r
            provider_data_subset = {provider_target_field_map[k]: v for k, v in provider_data_subset.items()}
            # 2. extract the relevant parameters passed as input
            record_subset = record.get(target_table, {})
            # 3. merge parameters from provider and parameters from inputs
            params = {**provider_data_subset}
            params.update(record_subset)
            final_record_map[(parent_table, target_table)] = params

        final_record_map[(instrument.category, 'asset_category')] = {**record.get('asset_category')}

        return final_record_map

    @staticmethod
    def post_process_one2(instrument, provider_map, provider_data):
        record = instrument.record
        final_record_map = {}
        for (parent_table, attr, target_table), provider_map_subset in provider_map.groupby(
                ['parent', 'parent_obj', 'target'], sort=False, dropna=False
        ):
            parent_table = None if pd.isna(parent_table) else parent_table
            target_table = None if pd.isna(target_table) else target_table
            attr = None if pd.isna(attr) else attr
            indices = [*provider_map_subset[['parent_obj', 'target_field']].apply(tuple, axis=1)]
            provider_data_subset = provider_data[indices]
            provider_data_subset = provider_data_subset.droplevel(0).to_dict()
            # 2. extract the relevant parameters passed as input (meaning user input)
            record_subset = record.get(target_table, {})
            # 3. merge parameters from provider and parameters from inputs
            params = {**provider_data_subset}
            params.update(record_subset)
            final_record_map[(parent_table, attr, target_table)] = params

        return final_record_map

    def add(self, instruments):
        return self._action(instruments)

    def update(self, instruments):
        return self._action(instruments, update=True)

    def _action(
            self,
            instruments,
            update=False,
            check=True,
            fetch=True,
            commit=True,
    ):
        '''

        Parameters
        ----------
        instruments
        update
        check
        fetch: bool or file
        commit

        Returns
        -------

        '''

        if check:
            instruments = self.check_instruments(instruments)
        self._instruments = instruments

        if fetch == True:
            print('Fetching data... ', end='')
            data = self.get_data(instruments)
            print('OK!')
        elif isinstance(fetch, (Path, str)):
            data = utils.read_pickle(fetch)
        else:
            data = fetch

        print('Creating records... ')
        for category, value in data.items():
            final_map = value['map']
            records = value['records']
            provider_map = value['provider_map']

            model = get_model(category)

            if not isinstance(records, Records):
                records = Records(records)

            for i, (record, (identifier, final_record_map)) in enumerate(zip(records, final_map.items())):
                print(f'\t{i}. {record} => ', end='')
                clone = Clone(model)
                # with db.session.no_autoflush:
                recursive_make3(
                    child=clone,
                    final_map=final_record_map,
                    provider_map=provider_map,
                    update=update
                )

                self.db.session.add(clone.obj)
                # db.session.flush()
                self._clones.append(clone)
                print('UPDATED!')

        print('\nCommitting data to DB... ', end='')
        if commit and self._clones:
            self.db.session.commit()
        print('SUCCESS!')


def recursive_make(
        child,
        record,
        final_map,
        parent=None,
        key=None,
        update=False
):
    if not child:
        return

    if isinstance(child, dict):
        children = child
        for key, (fk_name, child) in children.items():
            recursive_make(
                child,
                record=record,
                final_map=final_map,
                parent=parent,
                key=key,
                update=update
            )
    else:
        target_table = child.table_name
        parent_table = parent.table_name if parent else None
        try:
            params = final_map[(parent_table, target_table)]
        except KeyError:  # this case should only apply when target_table = asset_category
            params = record.get(target_table, {})
        exists_params = child.model.get_exists_params()

        # 4. CREATE the object IF it does NOT exists
        if not (obj := child.model.exists(**params)):
            # 4.1 IMPORTANT if the object does not exists, before creating it
            # check if at least one parameter common to params AND exists_params is not None
            # This logic ensures that I don't add any NULL record in the db which is useless
            if any([params.get(k) for k in exists_params]) and not child.model._fixed:
                obj = child.model(**params)
        else:
            # 4.2 SPECIFY what happens if the object is already in the db
            # If you are not updating a record set it as a clone attribute and exit the recursion
            # IMPORTANT: this logic is a safeguard against continuing the recursion if an object exists.
            # For instance, say I check that an issuer exists, then it doesn't make sense to go through the
            # remaining children because if the child already exists it means that also all its descendants
            # have already been created by some previous add action.
            if not update:
                child.obj = obj
                # 5. IMPORTANT: update parent attribute (relationship) based on the corresponding column
                if parent and parent.obj:
                    # the parent object method has already been called in the previous recursion
                    setattr(parent.obj, parent.get_relationship_column(key), child.obj)
                # print(f'\n\t for parent {parent.model if parent else None} child {child.model} EXISTS() => ', end='')
                return child
            else:
                for k, v in params.items():
                    setattr(obj, k, v)
        child.obj = obj

        # 5. VERY IMPORTANT: update parent attribute (relationship) based on the corresponding column
        if parent and parent.obj:
            # the parent object method has already been called in the previous recursion
            setattr(parent.obj, parent.get_relationship_column(key), child.obj)

        children = child.foreign_keys
        recursive_make(
            children,
            record=record,
            final_map=final_map,
            parent=child,
            update=update
        )
    return child


def recursive_make3(
        child: [Clone, dict],
        final_map,
        provider_map=None,
        parent: Clone = None,
        params=None,
        attr=None,
        update=False
):
    if not child:
        return

    if isinstance(child, dict):
        children = child
        for attr, child in children.items():
            params = _get_params(child, parent, attr, final_map)
            params_list = [params] if not isinstance(params, list) else params
            for params in params_list:
                recursive_make3(
                    child,
                    final_map=final_map,
                    provider_map=provider_map,
                    parent=parent,
                    params=params,
                    attr=attr,
                    update=update
                )
    else:
        if not params:
            params = _get_params(child, parent, attr, final_map)

        res = _create_or_update(child, parent, params, attr, update)
        if res:
            return

        # children = child.get_relationships(exclude=[parent.table_name] if parent else None)
        children = _get_children(provider_map, final_map, child)
        recursive_make3(
            children,
            final_map=final_map,
            provider_map=provider_map,
            parent=child,
            update=update
        )
    return child


def _get_params(child, parent, attr, final_map):
    target_table = child.table_name
    parent_table = parent.table_name if parent else None
    params = final_map[(parent_table, attr, target_table)]
    return params


def _create_or_update(
        child,
        parent,
        params,
        attr,
        update
):
    exists_params = child.model.get_exists_params()
    # 4. CREATE the object IF it does NOT exists
    if not (obj := child.model.exists(**params)):
        # 4.1 IMPORTANT if the object does not exists, before creating it
        # check if at least one parameter common to params AND exists_params is not None
        # This logic ensures that I don't add any NULL record in the db which is useless
        if any([params.get(k) is not None for k in exists_params]) and not child.model._fixed:
            obj = child.model(**params)
    else:
        # 4.2 SPECIFY what happens if the object is already in the db
        # If you are not updating a record set it as a clone attribute and exit the recursion
        # IMPORTANT: this logic is a safeguard against continuing the recursion if an object exists.
        # For instance, say I check that an issuer exists, then it doesn't make sense to go through the
        # remaining children because if the child already exists it means that also all its descendants
        # have already been created by some previous add action.
        if not update:
            child.obj = obj
            # 5. IMPORTANT: update parent attribute (relationship) based on the corresponding column
            if parent and parent.obj:
                val = getattr(parent.obj, attr)
                if isinstance(val, list):
                    val.append(child.obj)
                else:
                    # the parent object method has already been called in the previous recursion
                    setattr(parent.obj, attr, child.obj)
            # print(f'\n\t for parent {parent.model if parent else None} child {child.model} EXISTS() => ', end='')
            return child
        else:
            for k, v in params.items():
                setattr(obj, k, v)
    child.obj = obj

    # 5. VERY IMPORTANT: update parent attribute (relationship) based on the corresponding column
    if parent and parent.obj:
        val = getattr(parent.obj, attr)
        if isinstance(val, list):
            val.append(child.obj)
        else:
            # the parent object method has already been called in the previous recursion
            setattr(parent.obj, attr, child.obj)


def _get_children(provider_map, final_map, child):
    include = [k[-1] for k in final_map if child.table_name == k[0]]
    dict_ = provider_map.loc[provider_map['parent'] == child.table_name, ['target', 'parent_obj']]\
        .dropna().drop_duplicates().set_index('parent_obj').squeeze(axis=1).to_dict()
    return {k: Clone(get_model(v)) for k, v in dict_.items() if v in include}
