from flask import Flask
from flask_sqlalchemy import SQLAlchemy
# from flask_login import LoginManager
# from flask_session import Session
# from flask_bcrypt import Bcrypt
# from flask_jwt_extended import JWTManager
# from flask_cors import CORS
# from .data_providers import eikon

# Create Flask's `app` object
db = SQLAlchemy()

extensions = [
    db,
]


def make_app():
    app = Flask(
        __name__,
        template_folder="templates",
        instance_relative_config=False
    )

    app.config.from_object('config.Config')

    # Initialize Plugins
    for extension in extensions:
        extension.init_app(app)

    with app.app_context():
        # Include our Routes
        from . import routes
        return app
