
fields_reference = [
    {
        'field': 'TICKER',
        'name': 'ticker',
    },
    {
        'field': 'SECURITY_NAME',
        'name': 'name',
    },
    {
        'field': 'ID_ISIN',
        'name': 'isin',
    },
    {
        'field': 'CRNCY',
        'name': 'currency',
    },
    {
        'field': 'CNTRY_OF_RISK',
        'name': 'country',
    },
    {
        'field': 'BICS_LEVEL_1_SECTOR_NAME',
        'name': 'bics_sector',
    },
    {
        'field': 'BICS_LEVEL_2_INDUSTRY_GROUP_NAME',
        'name': 'bics_industry',
    },
    {
        'field': 'AMT_OUTSTANDING',
        'name': 'amount_outstanding',
    },
    {
        'field': 'ISSUE_DT',
        'name': 'issue_date',
    },
    {
        'field': 'MATURITY',
        'name': 'maturity',
    },
    {
        'field': 'CALC_MATURITY',
        'name': 'calc_maturity',
    },
    {
        'field': 'WORKOUT_DT_MID',
        'name': 'workout_date',
    },
    {
        'field': 'MTY_TYP',
        'name': 'maturity_type',
    },
    {
        'field': 'CPN',
        'name': 'coupon',
    },
    {
        'field': 'CPN_TYP',
        'name': 'coupon_type',
    },
    {
        'field': 'RTG_SP',
        'name': 'rating_sp',
    },
    {
        'field': 'RTG_MOODY',
        'name': 'rating_moody',
    },
    {
        'field': 'RTG_FITCH',
        'name': 'rating_fitch',
    },
    {
        'field': 'BB_COMPOSITE',
        'name': 'rating_bbg',
    },
    {
        'field': 'FIXED',
        'name': 'is_fixed',
    },
    {
        'field': 'CALLABLE',
        'name': 'is_callable',
    },
    {
        'field': 'IS_PERPETUAL',
        'name': 'is_perpetual',
    },
    {
        'field': 'CONVERTIBLE',
        'name': 'is_convertible',
    },
    {
        'field': 'IS_SUBORDINATED',
        'name': 'is_subordinated',
    },
    {
        'field': 'PAYMENT_RANK',
        'name': 'payment_rank',
    },
    {
        'field': 'BAIL_IN_BOND_DESIGNATION',
        'name': 'bail_in_bond_designation',
    },
    {
        'field': 'BASEL_III_DESIGNATION',
        'name': 'basel_iii_designation',
    },
    {
        'field': 'GREEN_BOND_LOAN_INDICATOR',
        'name': 'is_green',
    },
    {
        'field': 'RESET_IDX',
        'name': 'reset_index',
    },
    {
        'field': 'ISSUER_EQUITY_TICKER',
        'name': 'issuer_equity_ticker',
    },
    {
        'field': 'ISSUER',
        'name': 'issuer_name',
    },
    {
        'field': 'CDS_SPREAD_TICKER_5Y',
        'name': 'cds_ticker_5y',
        'fn': lambda series: series + ' Curncy'
    }
]

fields_market = [
    {
        "field": "PX_LAST",
        "name": "last_price",
    },
    {
        "field": "PX_LAST_EOD",
        "name": "eod_price",
        "overrides": [
            ('PRICING_SOURCE', 'CBBT')
        ]
    },
    {
        "field": "YLD_YTC_MID",
        "name": "yield_to_call",
    },
    {
        "field": "YLD_YTM_MID",
        "name": "ytm_flat",
    },
    {
        "field": "YAS_BOND_YLD",
        "name": "ytm_fwd",
    },
    {
        "field": "YAS_BOND_YLD",
        "name": "yield_to_worst",
        "overrides": [
            ("YAS_YLD_FLAG", 15)
        ]
    },
    {
        "field": "YAS_XCCY_FIXED_COUPON_EQUIVALENT",
        "name": "xccy_coupon_usd",
        "overrides": [
            ("YAS_XCCY_FOREIGN_CURRENCY", "USD"),
        ]
    },
    {
        "field": "YAS_XCCY_Z_SPREAD",
        "name": "xccy_z_spread_usd",
        "overrides": [
            ("YAS_XCCY_FOREIGN_CURRENCY", "USD"),
        ]
    },
    {
        "field": "YAS_ISPREAD",
        "name": "i_spread",
    },
    {
        "field": "Z_SPRD_MID",
        "name": "z_spread",
    },
    {
        "field": "YAS_ASW_SPREAD",
        "name": "aws_spread",
    },
    {
        "field": "YAS_ZSPREAD_BASIS_CONSTANT_MTY",
        "name": "z_spread_basis",
    },
    {
        "field": "YAS_MOD_DUR",
        "name": "mod_dur",
    },
    {
        "field": "FLT_SPREAD",
        "name": "reset_spread",
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "yield_to_call_high_12m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "12m")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "yield_to_call_high_ytd",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "YTD")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "yield_to_call_high_6m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "6m")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "yield_to_call_high_3m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "3m")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "yield_to_call_high_1m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "1m")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "yield_to_call_high_1w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "1w")
        ]
    },

    {
        "field": "INTERVAL_LOW",
        "name": "yield_to_call_low_12m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "12m")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "yield_to_call_low_ytd",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "ytd")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "yield_to_call_low_6m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "6m")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "yield_to_call_low_3m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "3m")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "yield_to_call_low_1m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "1m")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "yield_to_call_low_1w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "1w")
        ]
    },

    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "yield_to_call_change_12m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "12m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "yield_to_call_change_ytd",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "YTD")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "yield_to_call_change_6m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "6m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "yield_to_call_change_3m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "3m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "yield_to_call_change_1m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "1m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "yield_to_call_change_1w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTC_MID"),
            ("CALC_INTERVAL", "1w")
        ]
    },




    {
        "field": "INTERVAL_HIGH",
        "name": "ytm_high_12m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "12m")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "ytm_high_ytd",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "YTD")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "ytm_high_6m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "6m")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "ytm_high_3m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "3m")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "ytm_high_1m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "1m")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "ytm_high_1w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "1w")
        ]
    },

    {
        "field": "INTERVAL_LOW",
        "name": "ytm_low_12m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "12m")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "ytm_low_ytd",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "ytd")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "ytm_low_6m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "6m")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "ytm_low_3m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "3m")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "ytm_low_1m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "1m")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "ytm_low_1w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "1w")
        ]
    },

    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "ytm_change_12m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "12m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "ytm_change_ytd",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "YTD")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "ytm_change_6m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "6m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "ytm_change_3m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "3m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "ytm_change_1m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "1m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "ytm_change_1w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "YLD_YTM_MID"),
            ("CALC_INTERVAL", "1w")
        ]
    },

    {
        "field": "INTERVAL_HIGH",
        "name": "z_spread_high_12m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "12m")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "z_spread_high_ytd",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "YTD")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "z_spread_high_6m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "6m")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "z_spread_high_3m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "3m")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "z_spread_high_1m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "1m")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "z_spread_high_1w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "1w")
        ]
    },

    {
        "field": "INTERVAL_LOW",
        "name": "z_spread_low_12m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "12m")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "z_spread_low_ytd",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "ytd")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "z_spread_low_6m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "6m")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "z_spread_low_3m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "3m")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "z_spread_low_1m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "1m")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "z_spread_low_1w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "1w")
        ]
    },


    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "z_spread_change_12m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "12m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "z_spread_change_ytd",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "YTD")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "z_spread_change_6m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "6m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "z_spread_change_3m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "3m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "z_spread_change_1m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "1m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "z_spread_change_1w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "Z_SPRD_MID"),
            ("CALC_INTERVAL", "1w")
        ]
    },



]

fields_history = [
    {
        "field": "PX_LAST",
        "name": "last_price",
        "overrides": [
            ('PRICING_SOURCE', 'CBBT')
        ]
    },
    {
        "field": "YLD_YTC_MID",
        "name": "yield_to_call",
        "overrides": [
            ('PRICING_SOURCE', 'CBBT')
        ]
    },
    {
        "field": "YLD_YTM_MID",
        "name": "ytm_flat",
        "overrides": [
            ('PRICING_SOURCE', 'CBBT')
        ]
    },
    {
        "field": "Z_SPRD_MID",
        "name": "z_spread",
        "overrides": [
            ('PRICING_SOURCE', 'CBBT')
        ]
    },
        {
        "field": "ASSET_SWAP_SPD_MID",
        "name": "asw_spread",
        "overrides": [
            ('PRICING_SOURCE', 'CBBT')
        ]
    },
]

fields_indices_history = [
    {
        "field": 'INDEX_Z_SPREAD',
        "name": 'z_spread',
    },
    {
        "field": 'CONTRBTD_ZSPREAD',
        "name": 'z_spread',
    },
    {
        "field": 'PX_LAST',
        "name": 'z_spread'
    },
]

fields_cds_market = [
    {
        "field": 'PX_LAST',
        "name": 'last_price',
        "overrides": [
            ('PRICING_SOURCE', 'CMAN')
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "last_price_high_12m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "12m")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "last_price_high_ytd",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "YTD")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "last_price_high_6m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "6m")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "last_price_high_3m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "3m")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "last_price_high_1m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "1m")
        ]
    },
    {
        "field": "INTERVAL_HIGH",
        "name": "last_price_high_1w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "1w")
        ]
    },

    {
        "field": "INTERVAL_LOW",
        "name": "last_price_low_12m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "12m")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "last_price_low_ytd",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "ytd")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "last_price_low_6m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "6m")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "last_price_low_3m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "3m")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "last_price_low_1m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "1m")
        ]
    },
    {
        "field": "INTERVAL_LOW",
        "name": "last_price_low_1w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "1w")
        ]
    },

    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "last_price_change_12m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "12m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "last_price_change_ytd",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "YTD")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "last_price_change_6m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "6m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "last_price_change_3m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "3m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "last_price_change_1m",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "1m")
        ]
    },
    {
        "field": "INTERVAL_NET_CHANGE",
        "name": "last_price_change_1w",
        "overrides": [
            ("MARKET_DATA_OVERRIDE", "PX_LAST"),
            ("CALC_INTERVAL", "1w")
        ]
    },
]

fields_cds_history = [
    {
        "field": 'PX_LAST',
        "name": 'last_price',
        "overrides": [
            ('PRICING_SOURCE', 'CMAN')
        ]
    },
]

fields_yas_history = [
    {
        "field": "YAS_ZSPREAD",
        "name": "z_spread",
    },
    {
        "field": "YAS_XCCY_Z_SPREAD",
        "name": "z_spread_xccy_usd",
        "overrides": [
            ("YAS_XCCY_FOREIGN_CURRENCY", "USD"),
        ]
    },
    {
        "field": "YAS_ZSPREAD_BASIS_CONSTANT_MTY",
        "name": "z_spread_basis",
    },

]