import numpy as np
import pandas as pd

from .base import DataProvider
from ..blp import BlpQuery


class Bloomberg(DataProvider):
    def __init__(self, *args, **kwargs):

        kwargs.setdefault('timeout', 30000)
        self.bq = BlpQuery(*args, **kwargs)

        super().__init__()

    def _get_data(self, instruments, fields, **kwargs):

        instruments = self._parse_instruments(instruments)

        bq = self.bq.start()
        data = bq.bdp(
            instruments,
            fields,
        )

        return data.drop_duplicates(subset='security') \
            .set_index('security') \
            .replace({'': None}) \
            .replace({np.nan: None}) \
            .squeeze(axis=0), None

    def _parse_instruments(self, instruments):
        return instruments.values

    def get_bulk_data(self, instruments, fields, **kwargs) -> dict:

        instruments = self._parse_instruments(instruments)

        bq = self.bq.start()

        res = {}
        for field in fields:
            res[field] = bq.bdsm(
                instruments,
                field,
            )
        return res


def to_bool(data, **kwargs):
    return data.replace({'Y': 1, 'N': 0}).astype(bool).squeeze(axis=1)


def to_list_str(data, **kwargs):
    return data.groupby(level=0, sort=False).apply(lambda g: g.squeeze(axis=1).to_list()).astype(str)


def structured_notes(data, **kwargs):
    return data.reset_index(level=1).rename({'level_1': 'id'}, axis=1)