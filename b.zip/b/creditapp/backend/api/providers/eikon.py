from importlib import reload
import abc
import os


import eikon as ek
import numpy as np
import pandas as pd
from dotenv import load_dotenv, find_dotenv

# internal
from .base import DataProvider
from ..inputs import Instruments

load_dotenv()


class Eikon(DataProvider):

    api = ek

    def __init__(self):
        super().__init__()
        self.key = os.getenv('EIKON_API_KEY')
        self.start()

    def _get_data(self, instruments, fields, **kwargs):
        print(instruments)

        df, err = ek.get_data(
            instruments=instruments,
            fields=fields,
            field_name=True
        )

        data = df \
            .drop_duplicates(subset='Instrument')\
            .set_index('Instrument') \
            .set_axis(fields, axis=1) \
            .replace({'': None}) \
            .replace({np.nan: None}) \
            .squeeze(axis=0)
        print(f'\t {self.__class__.__name__} => instruments received: {len(instruments)}, '
              f'instruments returned: {len(df)}')
        return data, err

    def check_instruments_code(self, instruments):
        codes = self.api.get_symbology(instruments.values)

        if len(codes) != len(instruments):
            raise ValueError(f'\t {self.__class__.__name__} => '
                             f'length of instruments returned by {self.__class__.__name__} '
                             f'is different from inputs length')

        codes = codes.set_axis(codes.columns.str.lower(), axis=1)
        new_instruments = []
        print('\n')
        for instrument, (index, row) in zip(instruments, codes.iterrows()):
            if not pd.isna(identifier := row[instrument.identifier]):
                instrument.value = identifier
                new_instruments.append(instrument)
            else:
                print(f'\t {self.__class__.__name__} => NO match for instrument: {instrument.value} with identifier: {instrument.identifier}')

        return Instruments(new_instruments)

    @staticmethod
    def get_fx_code(currency_in, currency_out):
        '''
        The logic should be that, if the currency in is equal to currency out I return None
        :param currency_in:
        :param currency_out:
        :return:
        '''

        if isinstance(currency_in, pd.Series):
            return (currency_out.str.upper() + currency_in.str.upper()).replace({'EURUSD': 'EUR', 'EUREUR': None}) + '='

        if currency_in == currency_out:
            return

        # upper is for handling GBp
        return f'{currency_out.upper()}{currency_in.upper() if currency_in != "USD" else ""}='

    def start(self):
        try:
            ek.set_app_key(os.getenv('EIKON_API_KEY'))
        except Exception as e:
            print(e)

        return self

    def restart(self):
        reload(ek)
        self.start()
        self.api = ek
        return self
