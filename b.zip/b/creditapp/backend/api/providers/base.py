class DataProvider:
    def __init__(self):
        self.calls = []

    def get_data(self, instruments, fields, **kwargs):
        data, err = self._get_data(instruments, fields)

        self.calls.append({
            'data': data,
            'err': err,
            'instruments': instruments,
            'fields': fields
        })

        return data

    def check_instruments_code(self, instruments):
        return instruments
