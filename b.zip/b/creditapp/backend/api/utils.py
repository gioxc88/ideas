import pickle
from inflection import underscore


def to_camel(s):
    return ''.join(w.title() for w in s.split('_'))


def recursive_find1(model, models=None):
    models = [] if models is None else models

    if isinstance(model, list):
        for m in model:
            recursive_find1(m, models)
    else:
        # if model not in models:
        models.append(model)
        fk_info = model.get_fk_info()

        if fk_info:
            for info in fk_info:
                # if (m := info['model']) not in models:
                recursive_find1(info['model'], models)
    return models


def recursive_find2(
        child,
        tree=None,
        parent=None,
        key=None,
        foreign_key=None
):
    tree = [] if tree is None else tree
    if not child:
        return tree

    if isinstance(child, dict):
        children = child
        for key, (fk_name, child) in children.items():
            recursive_find2(
                child,
                tree=tree,
                parent=parent,
                key=key,
                foreign_key=fk_name
            )
    else:
        provider_map = child.get_provider_map(parent=parent)
        tree.append(
            {
                'parent': parent,
                'child': child,
                'provider_map': provider_map,
                'key': key,
                'foreign_key': foreign_key
            }
        )

        children = child.foreign_keys
        recursive_find2(
            children,
            tree=tree,
            parent=child,
        )
    return tree


def read_pickle(file, **kwargs):
    with open(file, 'rb') as handle:
        obj = pickle.load(handle, **kwargs)
    return obj


def to_pickle(obj, file, **kwargs):
    with open(file, 'wb') as handle:
        pickle.dump(
            obj,
            handle,
            protocol=pickle.HIGHEST_PROTOCOL,
            **kwargs
        )


