import abc
import functools
import importlib
import sys

from inspect import signature, Parameter
from datetime import datetime, date

from concurrent.futures import ThreadPoolExecutor
from itertools import product, chain, groupby

import numpy as np
import pandas as pd
from sqlalchemy import (
    select,
    case,
    extract,
    or_,
    and_,
    desc,
    func,
    inspect,
    create_engine,
    CHAR,
    Column,
    Date,
    DateTime,
    Boolean,
    Float,
    ForeignKey,
    Index,
    Integer,
    LargeBinary,
    String,
    Table,
    Text,
    text,
)

from sqlalchemy.ext.associationproxy import association_proxy
from sqlalchemy.ext.hybrid import hybrid_property, hybrid_method
from sqlalchemy.orm import relationship, backref, join as orm_join, with_polymorphic
from inflection import underscore, camelize

from . import db

__all__ = (
    # 'Auth',
    'AssetCategory',
    'BondCategory',
    # 'Cash',
    'Currency',
    'CountryCurrency',
    'Country',
    # 'GeoArea',
    'Gics',
    'Bics',
    'Issuer',
    'Rating',
    'Asset',
    # 'IssuerCategory',
    'Bond',
    'BondCustomCategory',
    # 'Equity',
    # 'FX',
    # 'FundCategory',
    # 'Fund',
    # 'EquityIndicator',
    # 'Broker',
    # 'Operation',
    # 'Trade',
    # 'TradeEquity',
    # 'TradeBond',
    # 'TradeFund',
    # 'Portfolio',
    # 'PortfolioComposition',
    # 'PortfolioCompositionLive',
    'AssetMap',
    # 'PriceMap',
    # 'FXMap',
    'StructuredNoteCoupon',
    'DataProvider',
    # 'User'
)
thismodule = sys.modules.get(__name__)


def get_model(model):
    return getattr(thismodule, ([m for m in __all__ if underscore(m) == model.lower()][0]))


def get_callable(fn):
    module, fn = fn.rsplit('.', 1)
    if not module.startswith('api.'):
        module = f'api.{module}'
    module = importlib.import_module(module)
    return getattr(module, fn)


class TreeMixin:
    _fixed = False

    @classmethod
    def make(cls, **kwargs):
        return cls(**kwargs)

    @classmethod
    def from_pandas(cls, df):
        df = df.replace({np.nan: None})
        rows = [cls(**kwargs) for kwargs in df.to_dict('records')]
        db.session.add_all(rows)
        db.session.commit()

    @classmethod
    def get_foreign_keys(cls):
        return {
            name: ([*fk][0].column.name, get_model([*fk][0].column.table.name))
            for name, col in inspect(cls).columns.items() if (fk := col.foreign_keys)}

    @classmethod
    def get_relationships(cls):
        return inspect(cls).relationships

    @classmethod
    @abc.abstractmethod
    def exists(cls, **kwargs):
        '''
        1. The function MUST return either an instance of the class or None
        2. The signature MUST be (param1=None, param2=None, ..., **kwargs)
        3. The child classes MUST implement the function with the relevant signature
        :param kwargs:
        :return:
        '''
        params = {k: v for k, v in kwargs.items()}
        return cls.query.filter_by(**params).first()

    @classmethod
    def get_exists_params(cls):
        s = signature(cls.exists)
        return {key: p for key, p in s.parameters.items() if p.kind == Parameter.POSITIONAL_OR_KEYWORD}

    @classmethod
    def get_relationship_column(cls, col, rels=None):
        rels = rels or cls.get_relationships()
        for key, rel in rels.items():
            for c in rel.local_columns:
                if c.name == col:
                    return key
        raise ValueError(f'Cannot find a unique relationship associated column {col}')


# class User(db.Model, TreeMixin):
#     id = Column(Integer, primary_key=True, autoincrement=True)
#     first_name = Column(String(150))
#     last_name = Column(String(150))
#     role = Column(String(150))
#     id_auth = Column(ForeignKey('auth.id'))
#
#
# class Auth(db.Model, TreeMixin):
#     id = Column(Integer, primary_key=True)
#     name = Column(String(50), primary_key=True)


class AssetCategory(db.Model, TreeMixin):
    _fixed = True
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(150), unique=True, index=True)

    @classmethod
    def exists(cls, name=None, **kwargs):
        # category = kwargs.get('category')
        obj = cls.query.filter(func.lower(cls.name) == func.lower(name)).first()
        return obj


class BondCategory(db.Model, TreeMixin):
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(200), unique=True, index=True)
    is_fixed = Column(Boolean)

    @classmethod
    def exists(cls, name=None, **kwargs):
        return super().exists(name=name)


class Currency(db.Model, TreeMixin):
    _fixed = True
    id = Column(Integer, primary_key=True)
    name = Column(String(150), unique=True, index=True)
    iso = Column(String(32), unique=True, index=True)
    scale = Column(Float, default=1)

    @classmethod
    def exists(cls, iso=None, **kwargs):
        return super().exists(iso=iso)

    # @classmethod
    # def exists(cls, iso=None, **kwargs):
    #     return cls.query.filter(func.lower(cls.iso) == (iso.lower() if iso else iso)).first()


class CountryCurrency(db.Model, TreeMixin):
    _fixed = True

    id_country = Column(ForeignKey('country.id'), primary_key=True)
    id_currency = Column(ForeignKey('currency.id'), primary_key=True)


class Country(db.Model, TreeMixin):
    _fixed = True

    id = Column(Integer, primary_key=True)
    name = Column(String(150), unique=True, index=True)  # "TR.CoRPrimaryCountry"
    iso = Column(String(32), unique=True, index=True)
    iso3 = Column(String(32), unique=True, index=True)
    code = Column(Integer)

    # idGeoArea = Column(String(30))
    # idRiskArea = Column(String(30))
    # Undefaultable = Column(Boolean)
    # idRating = Column(String(30))
    # IsOCSE = Column(Boolean)
    # idPAArea = Column(String(50))
    # idStimulsoftArea = Column(String(30))

    @classmethod
    def exists(cls, iso=None, **kwargs):
        return super().exists(iso=iso)

#
# class GeoArea(db.Model, TreeMixin):
#     id = Column(Integer, primary_key=True, autoincrement=True)
#     name = Column(String(150), unique=True, index=True)
#
#     @classmethod
#     def exists(cls, name=None, **kwargs):
#         return super().exists(name=name)


class Gics(db.Model, TreeMixin):
    id = Column(Integer, primary_key=True, autoincrement=True)
    id_sector = Column(Integer)
    id_group = Column(Integer)
    id_industry = Column(Integer)
    id_subindustry = Column(Integer)
    sector = Column(String(150))
    group = Column(String(150))
    industry = Column(String(150))
    subindustry = Column(String(150))

    @classmethod
    def exists(
            cls,
            id_sector=None,
            id_group=None,
            id_industry=None,
            id_subindustry=None,
            **kwargs
    ):
        return super().exists(
            id_sector=id_sector,
            id_group=id_group,
            id_industry=id_industry,
            id_subindustry=id_subindustry,
        )


class Bics(db.Model, TreeMixin):
    id = Column(Integer, primary_key=True, autoincrement=True)
    id_sector = Column(Integer)
    id_industry = Column(Integer)
    sector = Column(String(150))
    industry = Column(String(150))


    @classmethod
    def exists(
            cls,
            id_sector=None,
            id_industry=None,
            **kwargs
    ):
        return super().exists(
            id_sector=id_sector,
            id_industry=id_industry,
        )


class Issuer(db.Model, TreeMixin):
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(300), index=True)
    ticker = Column(String(50), index=True)
    id_rating = Column(ForeignKey('rating.id'))

    rating = relationship('Rating', backref='issuers')

    @classmethod
    def exists(cls, name, ticker, **kwargs):
        obj = cls.query.filter(and_(
            cls.name == name,
            cls.ticker == ticker,
        )).first()
        return obj


# class IssuerCategory(db.Model, TreeMixin):
#     id = Column(Integer, primary_key=True, autoincrement=True)
#     name = Column(String(200), unique=True, index=True)
#
#     @classmethod
#     def exists(cls, name=None, **kwargs):
#         return super().exists(name=name)

#
# class IssuerHistory(db.Model, TreeMixin):
#     id_bond = Column(ForeignKey('bond.id'), primary_key=True, nullable=False)
#     date = Column(Date, primary_key=True, default=date.today)
#     id_rating = Column(Integer, ForeignKey('rating.id'))
#
#     issuer = relationship('Issuer')
#     rating = relationship('Rating', backref=backref('bonds'))


# class Coupon(db.Model, TreeMixin):
#     pass
#
#
# class CouponSchedule(db.Model, TreeMixin):
#     pass


class Rating(db.Model, TreeMixin):
    _fixed = True
    _watches = [
        "*+",
        "*-",
        "*S",
        "*",
        'u',
    ]

    id = Column(Integer, primary_key=True, autoincrement=True)
    provider = Column(String(300), index=True)
    rating = Column(String(300), index=True)
    ig = Column(Boolean)
    composite = Column(String(300), index=True)

    @staticmethod
    def _parse_inputs(rating=None, provider=None, **kwargs):

        for k, v in kwargs.items():
            if 'rating__' in k:
                k, provider = k.split('__', 1)
                rating = v
                break

        if not provider:
            raise ValueError(
                '''the argument provider must be specified either by passing provider explicitly or
                by using the convention rating__provider, e.g rating__sp'''
            )

        return rating, provider

    @classmethod
    def make(cls,  rating, provider=None, **kwargs):
        rating, provider = cls._parse_inputs(rating, provider)
        return cls(rating=rating, provider=provider, **kwargs)

    @classmethod
    def exists(cls, rating=None, provider=None, **kwargs):
        rating, provider = cls._parse_inputs(rating, provider, **kwargs)
        obj = cls.query.filter(and_(
            cls.rating == cls.clean_rating(rating),
            cls.provider == provider,
        )).first()
        return obj

    @classmethod
    def clean_rating(cls, rating):
        if not rating:
            return
        return functools.reduce(lambda s, r: s.replace(r, ''), cls._watches, rating)


def code_default(context):
    params = context.get_current_parameters()
    isin = params['isin']
    ric = params['ric']
    category = params['category']
    return isin or ric if category == 'bond' else ric or isin


class Asset(db.Model, TreeMixin):
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(300))
    security_name = Column(String(300))
    # code = Column(String(200), default=code_default)
    ticker = Column(String(32), unique=True, index=True)
    ric = Column(String(32), unique=True, index=True)
    isin = Column(String(32), unique=False, index=True)
    cusip = Column(String(32), unique=True, index=True)
    ticker_and_exchange_code = Column(String(32), unique=True, index=True)
    exchange_code = Column(String(32), unique=False, index=False)
    yellow_key = Column(String(32), unique=False, index=False)
    category = Column(String(32))
    id_asset_category = db.Column(ForeignKey('asset_category.id'))
    id_issuer = Column(ForeignKey('issuer.id'))
    id_country = Column(ForeignKey('country.id'))
    id_country_of_risk = Column(ForeignKey('country.id'))
    id_currency = Column(ForeignKey('currency.id'))
    id_gics = Column(ForeignKey('gics.id'))
    id_bics = Column(ForeignKey('bics.id'))

    date_insert = Column(DateTime, default=datetime.utcnow)
    date_last_update = Column(DateTime, onupdate=datetime.utcnow)

    __mapper_args__ = {
        'polymorphic_identity': 'asset',
        'polymorphic_on': category
    }

    asset_category = relationship('AssetCategory', backref='assets')
    issuer = relationship('Issuer', backref='assets')
    country = relationship('Country', foreign_keys=[id_country])
    country_of_risk = relationship('Country', backref='assets', foreign_keys=[id_country_of_risk])
    currency = relationship('Currency', backref='assets')
    gics = relationship('Gics', backref='assets')
    bics = relationship('Bics', backref='assets')

    @classmethod
    def exists(
            cls,
            code=None,
            ric=None,
            ticker=None,
            isin=None,
            name=None,
            **kwargs
    ):
        l = {**locals()}
        for k, v in l.items():
            if v and k not in ['cls', 'kwargs']:
                col = getattr(cls, k)
                break

        try:
            return cls.query.filter(func.lower(col) == v.lower()).first()
        except NameError:
            return

    @classmethod
    def from_instrument(cls, instrument):
        return cls.exists(**{instrument['identifier'].lower(): instrument['value']})


def bond_custom_category_default(context):
    params = context.get_current_parameters()
    payment_rank = params['payment_rank']
    b3d = params['basel_iii_designation']
    bbd = params['bail_in_bond_designation']

    if payment_rank in ['Jr Subordinated', 'Subordinated']:
        if b3d == 'Additional Tier 1':
            short_name = 'AT1'
        elif b3d == 'Tier 2':
            short_name = 'T2'
        else:
            return
    elif payment_rank in ['Sr Non Preferred', 'Sr Preferred', 'Sr Unsecured']:
        if bbd == 'Y':
            short_name = 'SNP'
        else:
            short_name = 'SP'
    else:
        return
    return BondCustomCategory.query.filter_by(short_name=short_name).first().id


class Bond(Asset):
    __mapper_args__ = {
        'polymorphic_identity': 'bond',
    }

    id = Column(ForeignKey('asset.id'), primary_key=True)
    # id_bond_category = Column(ForeignKey('bond_category.id'))
    # id_issuer_category = Column(ForeignKey('issuer_category.id'))
    date_issue = Column(DateTime)
    date_maturity = Column(DateTime)
    date_calc_maturity = Column(DateTime)
    # date_workout = Column(DateTime)
    maturity_type = Column(String(50))

    issue_amount = Column(Float(asdecimal=True))
    par_amount = Column(Float, default=100)
    date_first_settlement = Column(DateTime)

    id_rating_sp = Column(Integer, ForeignKey('rating.id'))
    id_rating_moodys = Column(Integer, ForeignKey('rating.id'))
    id_rating_fitch = Column(Integer, ForeignKey('rating.id'))
    id_rating_dbrs = Column(Integer, ForeignKey('rating.id'))
    id_rating_bbg = Column(Integer, ForeignKey('rating.id'))
    id_bond_custom_category = Column(Integer, ForeignKey('bond_custom_category.id'), default=bond_custom_category_default)

    coupon = Column(Float(asdecimal=True))
    # float_spread = Column(Float(asdecimal=True))
    coupon_frequency = Column(String(50))
    coupon_type = Column(String(50))
    id_coupon_currency = Column(ForeignKey('currency.id'))
    day_count = Column(String(50))
    date_first_coupon = Column(DateTime)

    # is_corporate = Column(Boolean)
    is_fixed = Column(Boolean)
    is_callable = Column(Boolean)
    is_convertible = Column(Boolean)
    is_perpetual = Column(Boolean)
    is_subordinated = Column(Boolean)

    green_bond = Column(Boolean)
    payment_rank = Column(String(100))
    normlized_payment_rank = Column(String(100))
    bail_in_bond_designation = Column(String(100))
    basel_iii_designation = Column(String(100))
    capital_initial_trigger = Column(String(100))
    capital_action = Column(String(100))
    capital_trigger_level = Column(Float(asdecimal=True))
    capital_trigger_type = Column(String(100))

    use_of_proceeds = Column(String(500))
    # id_structured_note_coupon = Column(Integer, ForeignKey('structured_note_coupon.id'))

    # asset = relationship('Asset', backref=backref('bond', uselist=False))
    # bond_category = relationship('BondCategory', backref=backref('bonds'))
    coupon_currency = relationship('Currency', backref=backref('bonds'))
    bond_custom_category = relationship('BondCustomCategory', backref=backref('bonds'))
    # issuer_category = relationship('IssuerCategory', backref=backref('bonds'))
    # rating = relationship('Rating', backref=backref('bonds'))
    rating_sp = relationship('Rating', primaryjoin=and_(id_rating_sp== Rating.id, Rating.provider=='sp'))
    rating_moodys = relationship('Rating', primaryjoin=and_(id_rating_moodys== Rating.id, Rating.provider=='moodys'))
    rating_fitch = relationship('Rating',primaryjoin=and_(id_rating_fitch== Rating.id, Rating.provider=='fitch'))
    rating_dbrs = relationship('Rating',  primaryjoin=and_(id_rating_bbg==Rating.id, Rating.provider=='bbg'))
    rating_bbg = relationship('Rating',  primaryjoin=and_(id_rating_dbrs== Rating.id, Rating.provider=='dbrs'))

    structured_note_coupons = relationship('StructuredNoteCoupon', backref=backref('bond'))

    _maturity_buckets = [0, 1.5, 2.5, 4.5, 5.5, 9, 11, 14, 16, 20, 30, np.inf]

    @classmethod
    def _maturity_to_bucket(cls, n):
        i = np.digitize(n, cls._maturity_buckets)
        l = cls._maturity_buckets[i-1]
        r = f"-{cls._maturity_buckets[i]}" if cls._maturity_buckets[i] is not np.inf else '+'
        return f"{l}{r}"

    @hybrid_property
    def maturity_bucket(self):
        today = datetime.today()
        years = (self.date_maturity - today).days / 365.2425
        return self._maturity_to_bucket(years)

    @maturity_bucket.expression
    def maturity_bucket(cls):
        return case(
            [
                (cls.years_to_maturity.between(cls._maturity_buckets[i], cls._maturity_buckets[i+1]),
                 f"{cls._maturity_buckets[i]}-{cls._maturity_buckets[i + 1]}"
                 if cls._maturity_buckets[i + 1] is not np.inf else f"{cls._maturity_buckets[i]}+")
                for i, mb in enumerate(cls._maturity_buckets[:-1])
            ],
            else_='other')

    @hybrid_property
    def years_to_maturity(self):
        return (self.date_maturity - datetime.today()).days / 365.2425

    @years_to_maturity.expression
    def years_to_maturity(cls):
        return (extract('epoch', cls.date_maturity) - extract('epoch', datetime.utcnow())) / 60 / 60 / 24 / 365.2425


class BondCustomCategory(db.Model, TreeMixin):
    id = Column(Integer, primary_key=True)
    name = Column(String(300))
    short_name = Column(String(300))


class StructuredNoteCoupon(db.Model, TreeMixin):
    id = Column(Integer, primary_key=True)
    id_bond = Column(ForeignKey('bond.id'), primary_key=True, nullable=False)
    effective_date = Column(Date)
    coupon_formula = Column(String(200))
    day_count = Column(String(200))
    coupon_frequency = Column(String(200))
    coupon_cap = Column(String(200))
    coupon_floor = Column(String(200))
    # coupon_cap = Column(Float(asdecimal=True))
    # coupon_floor = Column(Float(asdecimal=True))

    @classmethod
    def exists(cls, id=None, **kwargs):
        bond = Bond.exists(**kwargs)
        if not bond:
            return

        return cls.query.filter(
            and_(
                cls.id == id,
                cls.id_bond == bond.id,
            )
        )


class BondHistory(db.Model, TreeMixin):
    id_bond = Column(ForeignKey('bond.id'), primary_key=True, nullable=False)
    date = Column(Date, primary_key=True, default=date.today)
    id_rating_sp = Column(Integer, ForeignKey('rating.id'))
    id_rating_moodys = Column(Integer, ForeignKey('rating.id'))
    id_rating_fitch = Column(Integer, ForeignKey('rating.id'))
    id_rating_dbrs = Column(Integer, ForeignKey('rating.id'))
    id_rating_bbg = Column(Integer, ForeignKey('rating.id'))
    next_coupon_date = Column(DateTime)
    ytm = Column(Float(asdecimal=True))
    duration = Column(Float(asdecimal=True))
    price = Column(Float(asdecimal=True))

    bond = relationship('Bond')
    rating_sp = relationship('Rating', foreign_keys=[id_rating_sp])
    rating_moodys = relationship('Rating', foreign_keys=[id_rating_moodys])
    rating_fitch = relationship('Rating', foreign_keys=[id_rating_fitch])
    rating_dbrs = relationship('Rating', foreign_keys=[id_rating_dbrs])
    rating_bbg = relationship('Rating', foreign_keys=[id_rating_bbg])


# class Equity(Asset):
#     __mapper_args__ = {
#         'polymorphic_identity': 'equity',
#     }
#     id = Column(ForeignKey('asset.id'), primary_key=True)


# class Cash(Asset):
#     __mapper_args__ = {
#         'polymorphic_identity': 'cash',
#     }
#     id = Column(ForeignKey('asset.id'), primary_key=True)
#
#
# class FX(Asset):
#     __mapper_args__ = {
#         'polymorphic_identity': 'fx',
#     }
#     id = Column(ForeignKey('asset.id'), primary_key=True)
#     id_currency_in = Column(ForeignKey('currency.id'), nullable=False, index=True)
#     id_currency_out = Column(ForeignKey('currency.id'), nullable=False, index=True)
#
#     # asset = relationship('Asset', backref=backref('fx', uselist=False))
#     currency_in = relationship('Currency', foreign_keys=[id_currency_in])
#     currency_out = relationship('Currency', foreign_keys=[id_currency_out])
#
#
# class FundCategory(db.Model, TreeMixin):
#     id = Column(Integer, primary_key=True, autoincrement=True)
#     name = Column(String(200), unique=True, index=True)
#
#     @classmethod
#     def exists(cls, name=None, **kwargs):
#         return super().exists(name=name)
#
#
# class Fund(Asset):
#     __mapper_args__ = {
#         'polymorphic_identity': 'fund',
#     }
#
#     id = Column(ForeignKey('asset.id'), primary_key=True)
#     id_fund_category = Column(ForeignKey('fund_category.id'))
#
#     # asset = relationship('Asset', backref=backref('fund', uselist=False))
#     fund_category = relationship('FundCategory', backref=backref('funds'))


# class EquityHistory(db.Model, TreeMixin):
#     id = Column(ForeignKey('equity.id'), primary_key=True, nullable=False)
#     date = Column(Date, primary_key=True, default=date.today)
#     dividend_ex_date = Column(DateTime)
#     dividend_pay_date = Column(DateTime)
#     dividend_type = Column(String(10))
#     dividend_currency = Column(String(10))
#     dividend = Column(Float(asdecimal=True))
#     dividend_yield = Column(Float(asdecimal=True))
#     price = Column(Float(asdecimal=True))
#
#     equity = relationship('Equity')
#
#
# class Portfolio(db.Model, TreeMixin):
#     id = Column(Integer, primary_key=True)
#     code = Column(String(150), unique=True, index=True)
#     name = Column(String(150), unique=True, index=True)
#     id_currency = Column(ForeignKey('currency.id'))
#     id_asset = Column(ForeignKey('asset.id'), index=True)
#     date_start = Column(DateTime)
#     date_end = Column(DateTime)
#     date_last_update = Column(DateTime, onupdate=datetime.utcnow)
#     is_ucits = Column(Boolean, server_default=text("'0'"))
#
#     asset = relationship('Asset', backref='portfolio')
#     currency = relationship('Currency', backref='portfolios')
#
#     @classmethod
#     def exists(cls, code=None, isin=None, ric=None, name=None, **kwargs):
#         l = {**locals()}
#         for k, v in l.items():
#             if v and k not in ['cls', 'kwargs']:
#                 break
#
#         if not v:
#             raise ValueError('no values have been passed')
#
#         cls_ = cls if k in ['name', 'code'] else Asset
#
#         col = getattr(cls_, k if isinstance(k, str) else cls_.id)
#         obj = cls_.query.filter(func.lower(col) == func.lower(v)).first()
#         return obj

#
# class Broker(db.Model, TreeMixin):
#     id = Column(Integer, primary_key=True)
#     name = Column(String(50), primary_key=True)
#     long_name = Column(String(50))
#
#     @classmethod
#     def exists(cls, name=None, **kwargs):
#         # category = kwargs.get('category')
#         obj = cls.query.filter(or_(func.lower(cls.name) == func.lower(name),
#                                    func.lower(cls.long_name) == func.lower(name))).first()
#         return obj
#
#
# class Operation(db.Model, TreeMixin):
#     id = Column(Integer, primary_key=True)
#     name = Column(String(10), primary_key=True)
#     sign = Column(Integer)
#
#     @classmethod
#     def exists(cls, name=None, **kwargs):
#         col = cls.id if isinstance(name, int) else cls.name
#         # category = kwargs.get('category')
#         obj = cls.query.filter(func.lower(col) == func.lower(name)).first()
#         return obj
#
#
# class TradeMixin:
#     pass
#
#
# class Trade(db.Model):
#     id = Column(Integer, primary_key=True, autoincrement=True)  # auto
#     date_trade = Column(DateTime, default=datetime.utcnow)  # auto
#     id_portfolio = Column(ForeignKey('portfolio.id'))  # input
#     id_asset = Column(ForeignKey('asset.id'))  # input
#     id_operation = Column(ForeignKey('operation.id'))  # input
#     id_broker = Column(ForeignKey('broker.id'))  # input
#     price = Column(Float)  # download
#     fx = Column(Float, default=1)  # download
#     quantity = Column(Integer)  # input
#     fee = Column(Float, default=0)  # input
#     other_fees = Column(Float, default=0)  # input
#     taxes = Column(Float, default=0)  # input
#     confirmed = Column(Boolean)
#     category = Column(String(32))  # auto
#     date_settlement = Column(Date)  # input ?
#
#     @hybrid_property  # calculated
#     def signed_quantity(self):
#         return self.quantity * self.operation.sign
#
#     @signed_quantity.expression  # calculated
#     def signed_quantity(cls):
#         return cls.quantity * Operation.sign
#
#     @hybrid_property  # calculated
#     def amount_local_gross(self):
#         return self.quantity * self.price
#
#     @hybrid_property  # calculated
#     def amount_local_net(self):
#         return self.amount_local_gross - self.fee - self.other_fees - self.taxes
#
#     @hybrid_property  # calculated
#     def amount_net(self):
#         return self.amount_local_net / self.fx
#
#     __mapper_args__ = {
#         'polymorphic_identity': 'asset',
#         'polymorphic_on': category
#     }
#
#     portfolio = relationship('Portfolio', backref='trades')
#     asset = relationship('Asset', backref='trades')
#     operation = relationship('Operation', backref='trades')
#     broker = relationship('Broker', backref='trades')
#
#
# class TradeEquity(Trade):
#     __mapper_args__ = {
#         'polymorphic_identity': 'equity',
#     }
#
#     id = Column(ForeignKey('trade.id'), primary_key=True)
#
#
# class TradeFund(Trade):
#     __mapper_args__ = {
#         'polymorphic_identity': 'fund',
#     }
#
#     id = Column(ForeignKey('trade.id'), primary_key=True)
#
#
# class TradeBond(Trade):
#     __mapper_args__ = {
#         'polymorphic_identity': 'bond',
#     }
#
#     id = Column(ForeignKey('trade.id'), primary_key=True)
#     accrued = Column(Float)
#
#     # fx_accrued = Column(Float, default=default_fx_accrued)
#
#     @hybrid_property  # calculated
#     def amount_local_gross(self):
#         return self.quantity * (self.price + self.accrued) / self.asset.nominal
#     # date_settlement = Column(DateTime)  # ? specific to bond?
#     # trade = relationship('Trade', backref=backref('trade_equity', uselist=False))
#
#
# def price_default(context):
#     id_asset = context.get_current_parameters()['id_asset']
#     asset = Asset.query.get(id_asset)
#     return 1 if asset.category == 'cash' else None
#
#
# class PortfolioComposition(db.Model, TreeMixin):
#     id_portfolio = Column(ForeignKey('portfolio.id'), primary_key=True, index=True)  # input
#     id_asset = Column(ForeignKey('asset.id'), primary_key=True, index=True, nullable=False)
#     date = Column(Date, primary_key=True, index=True, default=date.today)
#     price = Column(Float, default=price_default)
#     quantity = Column(Integer)
#     fx = Column(Float)
#     accrued = Column(Float)
#
#     asset = relationship('Asset')
#     portfolio = relationship('Portfolio')
#
#     @hybrid_property  # calculated
#     def amount_local(self):
#         return self.quantity * self.price
#
#     @hybrid_property  # calculated
#     def amount(self):
#         return self.amount_local / self.fx
#     # currency = relationship("Currency", primaryjoin="Asset.idCurrency==Currency.idCurrency")
#
#
# class PortfolioCompositionLive(db.Model, TreeMixin):
#     date = Column(DateTime, index=True, default=datetime.utcnow, onupdate=datetime.utcnow)
#     id_portfolio = Column(ForeignKey('portfolio.id'), primary_key=True, index=True)  # input
#     id_asset = Column(ForeignKey('asset.id'), primary_key=True, index=True, nullable=False)
#     quantity = Column(Float)
#     price = Column(Float, default=price_default)
#     accrued = Column(Float)
#     fx = Column(Float)
#
#     asset = relationship('Asset')
#     portfolio = relationship('Portfolio')
#
#     @hybrid_property  # calculated
#     def amount_local(self):
#         if self.asset.category == 'bond':
#             amount = self.quantity * (self.price + self.accrued) / self.asset.nominal
#         else:
#             amount = self.quantity * self.price
#         return np.round(amount, 5)
#
#     @amount_local.expression
#     def amount_local(cls):
#         return select([func.round(case(
#             [
#                 (Asset.category == 'bond', cls.quantity * (cls.price + cls.accrued) / Bond.nominal)
#             ],
#             else_=cls.quantity * cls.price
#         ), 5)]).where(Asset.id == cls.id_asset).label('amount_local')  # as_scalar should be implied by .label()
#
#     @hybrid_property  # calculated
#     def amount(self):
#         return np.round(self.amount_local / self.fx, 5)
#
#     @amount.expression  # calculated
#     def amount(cls):
#         return func.round(cls.amount_local / cls.fx, 5)
#
#     @hybrid_property  # calculated
#     def weight(self):
#         nav = self.get_total(id_portfolio=self.id_portfolio, attr='amount')
#         return self.amount / nav
#
#     @weight.expression
#     def weight(cls):
#         # for some reason if I dont add the where clause Asset.id == cls.id_asset it fails, meaning it returns
#         # a single element instead of a list of weights. This is probably due to the way the SQL statement is emitted
#         # by SQLAlchemy CORE since.
#         # The rationale is to create a subquery which holds the sums of the the amounts for each portfolio
#         # Then joining the subquery on the original Table. Now I have the cartesian product of the element and I can
#         # filter only on those which have the same portfolio id.
#         # This is a bit involved but it has the advantage that if something changes in terms of quantity, prices etc
#         # I don't need to recalculate anything as all the hybrid properties are dynamic.
#
#         sub_query = select([cls.id_portfolio.label('ptf'), func.sum(cls.amount).label('group_sum')]).group_by(
#             cls.id_portfolio)
#         return select([cls.amount / sub_query.c.group_sum]).where(
#             and_(
#                 cls.id_portfolio == sub_query.c.ptf,
#                 Asset.id == cls.id_asset
#             )
#         ).label('weight')
#
#     @classmethod
#     def exists(cls, id_portfolio=None, id_asset=None, **kwargs):
#         return super().exists(id_portfolio=id_portfolio, id_asset=id_asset)
#
#     # currency = relationship("Currency", primaryjoin="Asset.idCurrency==Currency.idCurrency")
#
#     @classmethod
#     def get_total(cls, id_portfolio=1, attr='amount'):
#         return np.round(db.session.query(func.sum(getattr(cls, attr)))
#                         .filter(cls.id_portfolio == id_portfolio).scalar())
#
#     @classmethod
#     def get_ptf(cls, id_portfolio=1):
#         ptf_components = cls.query.filter_by(id_portfolio=id_portfolio).all()
#
#         return pd.DataFrame(data=[{
#             'portfolio': ptf_component.portfolio.name,
#             'asset': ptf_component.asset.name,
#             'asset_code': ptf_component.asset.code,
#             'asset_category': ptf_component.asset.category,
#             'currency': ptf_component.asset.currency.iso,
#             'quantity': ptf_component.quantity,
#             'price': ptf_component.price,
#             'accrued': ptf_component.accrued,
#             'fx': ptf_component.fx,
#             'amount_local': ptf_component.amount_local,
#             'amount': ptf_component.amount,
#             'weight': ptf_component.weight,
#         } for ptf_component in ptf_components])
#
#
# class StagingTradeEquity(TradeEquity):
#     pass
#
#
# class StagingTrade(Trade):
#     pass
#
#
class DataProvider(db.Model, TreeMixin):
    id = Column(Integer, primary_key=True)
    name = Column(String(150))


class AssetMap(db.Model, TreeMixin):
    id = Column(Integer, primary_key=True)

    id_asset_category = db.Column(ForeignKey('asset_category.id'))
    parent = Column(String(150))
    parent_obj = Column(String(150))
    parent_field = Column(String(150))
    target = Column(String(150))
    target_field = Column(String(150))
    id_provider = db.Column(ForeignKey('data_provider.id'))
    provider_field = Column(String(150))
    provider_bulk_field = Column(String(150))
    provider_column = Column(String(150))
    provider_callable_group = Column(String(150))
    provider_params = Column(String(150))
    provider_callable = Column(String(150))
    provider_callable_params = Column(String(150))

    asset_category = relationship('AssetCategory')
    provider = relationship('DataProvider')

    asset_category_name = association_proxy('asset_category', 'name')
    provider_name = association_proxy('provider', 'name')


# class PriceMap(db.Model, TreeMixin):
#     id = Column(Integer, primary_key=True)
#     id_asset_category = db.Column(ForeignKey('asset_category.id'))
#     target_field = Column(String(150))
#     id_provider = db.Column(ForeignKey('provider.id'))
#     provider_field = Column(String(150))
#     provider_callable = Column(String(150))
#     provider_callable_params = Column(String(150))
#
#     asset_category = relationship('AssetCategory')
#     provider = relationship('Provider')
#
#
# class FXMap(db.Model, TreeMixin):
#     id = Column(Integer, primary_key=True)
#     id_asset_category = db.Column(ForeignKey('asset_category.id'))
#     target_field = Column(String(150))
#     id_provider = db.Column(ForeignKey('provider.id'))
#     provider_field = Column(String(150))
#     provider_callable = Column(String(150))
#     provider_callable_params = Column(String(150))
#
#     asset_category = relationship('AssetCategory')
#     provider = relationship('Provider')
