from enum import Enum
from dataclasses import dataclass, asdict
from collections import UserList
import datetime

# third party
import numpy as np
import pandas as pd
from munch import Munch, munchify

from . import models


__all__ = (
    'Record',
    'Records',
    'InstrumentUI',
    'Instruments',
    'TradeUI',
    'Trades'
)


class EnumMixin:
    @classmethod
    def has(cls, name):
        return name.lower() in cls._member_map_

    @classmethod
    def get(cls, item):
        try:
            return cls(item)
        except ValueError:
            return cls[item]


class Category(EnumMixin, Enum):
    bond = 2
    equity = 3
    fund = 4


class Identifier(EnumMixin, Enum):
    isin = 1
    ric = 2
    ticker = 3


class UserInput:
    pass


@dataclass
class InstrumentUI(UserInput):
    category: str
    identifier: str
    value: str

    def __post_init__(self):
        category = self.category.lower().strip()
        if category not in [ac.name for ac in models.AssetCategory.query.all()]:
            raise ValueError('category not supported')
        self.category = category

        self.identifier = self.identifier.lower().strip()
        self.value = self.value.strip()

    def to_dict(self):
        return asdict(self)

    def __key(self):
        return self.value

    def __hash__(self):
        return hash(self.__key())

    def __eq__(self, other):
        if isinstance(other, InstrumentUI):
            return self.__key() == other.__key()
        return NotImplemented

    @classmethod
    def from_dict(cls, dct):
        return cls(**dct)

    @staticmethod
    def get_record_category(record):
        try:
            return [k for k in Category._member_map_ if k in record][0]
        except IndexError:
            raise AttributeError('record has no asset_category')

    @classmethod
    def from_record(cls, record):
        try:
            category = [k for k in Category._member_map_ if k in record][0]
        except IndexError:
            raise AttributeError('record has no asset_category')
        try:
            identifier = [k for k in record[category] if Identifier.has(k)][0]
        except IndexError:
            raise AttributeError('record has no identifier')

        value = record[category][identifier]
        return cls(category, identifier, value)

    @property
    def record(self):
        params = {
            self.category: {
                self.identifier: self.value
            },
            'asset_category': {
                'name': self.category
            }
        }
        return Record.fromDict(params)

    @classmethod
    def from_pandas(cls, series):
        fields = [*cls.__annotations__.keys()]
        return cls(**series[fields].to_dict())

    def __getitem__(self, item):
        return getattr(self, item)


@dataclass
class TradeUI(UserInput):
    instrument: InstrumentUI
    portfolio: str
    operation: str
    broker: str
    quantity: float
    price: float = None
    fx: float = 1
    fee: float = 0
    other_fees: float = 0
    taxes: float = 0
    accrued: float = None
    date: datetime.datetime = None
    settlement_date: datetime.date = None

    def __post_init__(self):
        portfolio = self.portfolio.upper()
        if not (ptf := models.Portfolio.exists(code=portfolio)):
            raise ValueError('operation not supported')
        self.portfolio = portfolio
        self._id_potfolio = ptf.id
        self._portfolio_obj = ptf

        if not (asset := models.Asset.exists(**{self.instrument.identifier: self.instrument.value})):
            raise ValueError(f'asset {self.instrument.value} not in db. Add it using AssetManager')

        if asset.category != self.instrument.category:
            raise ValueError(f'category mismatch between passed category '
                             f'and category associated to {self.instrument.value} in database')
        self._id_asset = asset.id
        self._asset_obj = asset

        if not (operation := models.Operation.exists(name=self.operation)):
            print(self.operation)
            raise ValueError(f'operation not supported {self.operation}')
        self.operation = operation.name.lower()
        self._id_operation = operation.id
        self._operation_obj = operation

        if not (broker := models.Broker.exists(name=self.broker)):
            print(self.broker)
            raise ValueError(f'broker not authorized {self.broker}')
        self.broker = broker.name.lower()
        self._id_broker = broker.id
        self._broker_obj = broker
        self._trade_model = models.get_model(f'trade_{asset.category}')
        self._trade_id = None

        if isinstance(self.date, str):
            try:
                self.date = pd.to_datetime(self.date).to_pydatetime()
            except:
                print(self.date, 'date failed')

        if isinstance(self.settlement_date, str):
            try:
                self.settlement_date = pd.to_datetime(self.settlement_date).date()
            except:
                print(self.settlement_date,   ' settlement_date failed')

    def to_dict(self):
        return asdict(self)

    # def __key(self):
    #     return self.value
    #
    # def __hash__(self):
    #     return hash(self.__key())

    # def __eq__(self, other):
    #     if isinstance(other, InstrumentUI):
    #         return self.__key() == other.__key()
    #     return NotImplemented

    @classmethod
    def from_dict(cls, dct):
        return cls(**dct)

    # @staticmethod
    # def get_record_category(record):
    #     try:
    #         return [k for k in Category._member_map_ if k in record][0]
    #     except IndexError:
    #         raise AttributeError('record has no asset_category')

    @property
    def record(self):
        params = {
            'id_portfolio': self._id_potfolio,
            'id_asset': self._id_asset,
            'id_operation': self._id_operation,
            'id_broker': self._id_broker,
            'quantity': self.quantity,
            'price': self.price,
            'fx': self.fx,
            'fee': self.fee,
            'other_fees': self.other_fees,
            'taxes': self.taxes,
            'date_trade': self.date,
            'date_settlement': self.settlement_date
        }

        if self._asset_obj.category == 'bond':
            params['accrued'] = self.accrued

        return Record.fromDict(params)

    @classmethod
    def from_pandas(cls, series):
        series.index = series.index.str.lower()
        fields = [key for key in cls.__annotations__.keys() if key != 'instrument']
        instrument = InstrumentUI.from_pandas(series)
        kwargs = series[fields].to_dict()
        kwargs['instrument'] = instrument
        return cls(**kwargs)

    def __getitem__(self, item):
        return getattr(self, item)


class Instruments(UserList):
    _memberclass = InstrumentUI

    def __init__(self, instruments):
        super().__init__(instruments)

    @property
    def instruments(self):
        return self.data

    @classmethod
    def from_pandas(cls, dataframe):
        fields = [*cls._memberclass.__annotations__.keys()]
        instruments = dataframe[fields].to_dict('records')
        return cls(instruments=[cls._memberclass(**instrument) for instrument in instruments])

    @property
    def categories(self):
        return [c.category for c in self]

    @property
    def values(self):
        return [c.value for c in self]

    @property
    def identifiers(self):
        return [c.identifier for c in self]

    @classmethod
    def from_records(cls, records):
        return cls(cls._memberclass.from_record(record) for record in records)

    @property
    def records(self):
        return Records([instrument.record for instrument in self])

    def unique(self):
        return Instruments(set(self))

    @classmethod
    def from_dicts(cls, dicts):
        return cls([cls._memberclass(**instrument) for instrument in dicts])

    def __repr__(self):
        reprs = ',\n\t'.join([m.__repr__() for m in self])
        return f'{self.__class__.__name__}(\n\t{reprs}\n)'


class Trades(UserList):
    _memberclass = TradeUI

    def __init__(self, trades):
        super().__init__(trades)

    @property
    def trades(self):
        return self.data

    # @classmethod
    # def from_pandas(cls, dataframe):
    #     return cls(trades=[cls._memberclass.from_pandas(row) for index, row in dataframe.iterrows()])
    #

    @classmethod
    def from_pandas(cls, dataframe):
        dataframe = dataframe.set_axis(dataframe.columns.str.lower(), axis=1)
        dtypes = {k: v for k, v in TradeUI.__annotations__.items() if
                  k in dataframe and v not in (datetime.datetime, datetime.date)}
        dtypes.update({k: v for k, v in InstrumentUI.__annotations__.items() if k in dataframe})
        dataframe = dataframe.astype(dtypes, errors='ignore').replace({np.nan: None})

        instrument_keys = [*InstrumentUI.__annotations__.keys()]
        # instruments = dataframe[instrument_keys].to_dict('records')

        instruments = Instruments.from_pandas(dataframe)
        dataframe = dataframe[dataframe.columns.difference(instrument_keys)]
        dataframe['instrument'] = instruments
        trades = dataframe.to_dict('records')

        return cls(trades=[t for trade in trades if (t := cls._existing_asset(trade))])

    @classmethod
    def _existing_asset(cls, trade):
        try:
            return cls._memberclass(**trade)
        except Exception as e:
            print(e)
            print(trade)

    @property
    def records(self):
        return Records([instrument.record for instrument in self])

    @classmethod
    def from_dicts(cls, dicts):
        return cls([t for instrument in dicts if (t := cls._existing_asset(instrument))])

    def __repr__(self):
        reprs = ',\n'.join([m.__repr__() for m in self])
        return f'[{self.__class__.__name__}{reprs}]'


class Record(Munch):
    def recursive_find_attrs(self, attrs, _value=None, _key=None, _inputs=None):
        if _inputs is None:
            _inputs = {}
            _value = self

        if items := getattr(_value, 'items', None):
            for k, v in items():
                self.recursive_find_attrs(attrs, _value=v, _key=k, _inputs=_inputs)
        else:
            if _key in attrs:
                _inputs[_key] = _value
        return _inputs


class Records(UserList):
    _memberclass = Record

    def __init__(self, inputs):
        super().__init__(inputs)
        self._inputs = inputs

    @property
    def records(self):
        return self.data

    def __repr__(self):
        reprs = ',\n'.join([m.__repr__() for m in self])
        return f'{self.__class__.__name__}[{reprs}]'
