import sys
from pathlib import Path

import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay

from api.blp import BlpQuery
from api.data.fields import fields_reference
from api.data.processing import post_process
from api.data.base import tables
from api.data.base import root_path, data_path, tables
from api.data.fields import fields_cds_history
from api.data.utils import add_pcs


timestamp = f"{pd.Timestamp.today():%Y%m%d_%H%M%S}"

### Bloomberg Connection
bq = BlpQuery(timeout=20000).start()
bond_ref = tables.bonds_reference.reset_index()
cds_ref = pd.read_csv(data_path / 'cds_reference.csv')

dt_fmt = '%Y%m%d'

start_date = pd.Timestamp(2007, 1, 1)
end_date = pd.Timestamp.today() - BDay(2)
pcs = 'MSG1'
sep = ' '

# bulk_cds = cds_ref.loc[cds_ref['exists'].fillna(False), 'security'].drop_duplicates().to_list()
bulk_cds = cds_ref['cds_ticker'].drop_duplicates()
bulk_cds = add_pcs(bulk_cds, pcs, sep=sep)
if bulk_cds:
    bulk_prices = bq.bdh(
        securities=bulk_cds,
        fields=[field['field'] for field in fields_cds_history],
        # overrides=[('PRICING_SOURCE', 'CMAN')]
        start_date=start_date.strftime(dt_fmt),
        end_date=end_date.strftime(dt_fmt)
    )
    bulk_prices.to_csv(data_path / 'temp' / f"cds_history_{timestamp}.csv", index=False)
    cds_prices = bulk_prices.rename({field['field']: field['name'] for field in fields_cds_history}, axis=1)
    cds_prices = cds_prices.rename({'security': 'cds_ticker'}, axis=1)
    cds_prices['cds_ticker'] = cds_prices['cds_ticker'].str.replace(f'{sep}{pcs}', '')
    cds_prices = cds_prices.merge(cds_ref[['cds_ticker', 'security']], on='cds_ticker', how='left')
    # cds_prices = cds_prices.groupby('security', as_index=False, sort=False, dropna=False)\
    #     .apply(lambda df: df.set_index('date').resample('B').ffill().reset_index())

    cds_prices.to_csv(data_path / 'cds_history.csv', index=False)

