import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd


from api.blp import BlpQuery
from api.data.fields import fields_reference
from api.data.processing import post_process
from api.data.base import tables
from api.data.base import root_path, data_path, tables
from api.data.fields import fields_cds_market
from api.data.utils import add_pcs

timestamp = f"{pd.Timestamp.today():%Y%m%d_%H%M%S}"

### Bloomberg Connection
bq = BlpQuery().start()
bond_ref = tables.bonds_reference.reset_index()
cds_ref = pd.read_csv(data_path / 'cds_reference.csv')

cds_prices = []
cds_na = []
col_names = [field['name'] for field in fields_cds_market]
# bulk_cds = cds_ref.loc[cds_ref['exists'].fillna(False), 'security'].drop_duplicates().to_list()
bulk_cds = cds_ref['cds_ticker'].drop_duplicates()
bulk_cds = add_pcs(bulk_cds, 'MSG1', sep=' ')
if bulk_cds:
    bulk_prices = bq.bdp(
        securities=bulk_cds,
        fields=[field['field'] for field in fields_cds_market],
        # overrides=[('PRICING_SOURCE', 'CMAN')]
    )
    bulk_prices = bulk_prices.set_axis([*bulk_prices.columns[:bulk_prices.shape[1] - len(col_names)], *col_names], axis=1)
    bulk_prices['security'] = bulk_prices['security'].str.replace(' MSG1', '')
    bulk_prices['security'] = bulk_prices['security'].replace(cds_ref[['security', 'cds_ticker']].set_index('cds_ticker').to_dict()['security'])
    cds_prices.append(bulk_prices)

# cds_single = cds_ref.loc[cds_ref['exists'].isna(), 'security'].drop_duplicates()
# for i, sec in enumerate(cds_single):
#     try:
#         res = bq.bdp(
#             securities=[sec],
#             fields=[field['field'] for field in fields_cds_market],
#             # overrides=[('PRICING_SOURCE', 'CMAN')]
#
#         )
#         print(f'{i}/{len(cds_single)} {sec} ---> OK')
#
#         res = res.set_axis([*res.columns[:res.shape[1] - len(col_names)], *col_names], axis=1)
#         cds_prices.append(res)
#     except TypeError:
#         cds_na.append(sec)
#         print(f'{i}/{len(cds_single)} {sec} ---> NA')

cds_prices = pd.concat(cds_prices)
# cds_ref.loc[cds_ref['security'].isin(cds_na), 'exists'] = False
# cds_ref['exists'] = cds_ref['exists'].fillna(True)
#
# cds_ref.to_csv(data_path / 'cds_reference.csv', index=False)
cds_prices.to_csv(data_path / 'temp' / f"cds_market_{timestamp}.csv", index=False)
cds_prices.to_csv(data_path / 'cds_market.csv', index=False)

