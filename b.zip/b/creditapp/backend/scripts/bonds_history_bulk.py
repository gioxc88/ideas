import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay

from api.blp import BlpQuery
from api.data.base import tables, data_path
from api.data.fields import fields_history
from api.data.utils import add_pcs

dt_fmt = '%Y%m%d'
bq = BlpQuery(timeout=20000).start()

bonds_ref = tables.bonds_reference.reset_index()

securities = bonds_ref['security'].drop_duplicates().to_list()
fields = [field['field'] for field in fields_history]

start_date = pd.Timestamp(2007, 1, 1)
end_date = pd.Timestamp.today()

res_cbbt = bq.bdh(
    securities=add_pcs(securities, 'BVAL'),
    fields=fields,
    # overrides=[('PRICING_SOURCE', 'CBBT')],
    start_date=start_date.strftime(dt_fmt),
    end_date=end_date.strftime(dt_fmt)
)
res_cbbt = res_cbbt.rename({field['field']: field['name'] for field in fields_history}, axis=1)
res_cbbt['security'] = res_cbbt['security'].str.replace('@CBBT', '')
res_cbbt['pricing_source'] = 'CBBT'
res_cbbt.to_csv(data_path / 'bonds_history_cbbt.csv', index=False)

no_cbbt = bonds_ref.loc[~bonds_ref['security'].isin(res_cbbt['security'].unique())]

if not no_cbbt.empty:
    to_add = no_cbbt['security'].drop_duplicates().to_list()
    res_bval = bq.bdh(
        securities=add_pcs(to_add, 'BVAL'),
        fields=fields,
        # overrides=[('PRICING_SOURCE', 'CBBT')],
        start_date=start_date.strftime(dt_fmt),
        end_date=end_date.strftime(dt_fmt)
    )

    res_bval = res_bval.rename({field['field']: field['name'] for field in fields_history}, axis=1)
    res_bval['security'] = res_bval['security'].str.replace('@BVAL', '')
    res_bval['pricing_source'] = 'BVAL'
    res_bval.to_csv(data_path / 'bonds_history_bval.csv', index=False)
else:
    res_bval = pd.DataFrame()

res_all = pd.concat([res_cbbt, res_bval])
res_all.groupby('security', as_index=False, sort=False, dropna=False)\
    .apply(lambda df: df.set_index('date').resample('B').ffill().reset_index())

res_all.to_csv(data_path / 'bonds_history_all.csv', index=False)

if 'has_time_series' not in bonds_ref:
    bonds_ref['has_time_series'] = False


bonds_ref.loc[bonds_ref['security'].isin(res_all['security']), 'has_time_series'] = True
bonds_ref.loc[~bonds_ref['security'].isin(res_all['security']), 'has_time_series'] = False
bonds_ref.to_csv(data_path / 'bonds_reference.csv', index=False)

# no_bval = bonds_ref.loc[~bonds_ref['security'].isin(res_all['security'].unique())]



