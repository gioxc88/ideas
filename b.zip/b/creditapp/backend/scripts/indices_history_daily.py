import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay

import config
from loggers import get_default_logger, get_logger

from api.blp import BlpQuery
from api.data.base import root_path, data_path, tables, logs_path
from api.data.fields import fields_indices_history


### Bloomberg Connection
def get_indices_history_daily(
        logger=get_default_logger()
):
    dt_fmt = '%Y%m%d'
    bq = BlpQuery(timeout=20000).start()

    indices_ref = pd.read_csv(data_path / 'indices_reference.csv')
    indices_hist = pd.read_csv(data_path / 'indices_history.csv', parse_dates=['date'], dayfirst=True)
    indices_hist.to_csv(data_path / 'indices_history_backup.csv', index=False)

    # excluding iBoxx for now
    # indices_ref = indices_ref.loc[indices_ref['fields'] != "['CONTRBTD_ZSPREAD']", :]

    end_date = pd.Timestamp.today().date() - BDay()

    g = indices_hist.groupby(['security'])['date'].max()

    res = {}
    for ticker, last_date in g.items():
        if last_date < end_date:
            row = indices_ref.loc[indices_ref['ticker'] == ticker].squeeze()
            logger.info(f"downloading {ticker} ..")
            res_ = bq.bdh(
                securities=[ticker],
                fields=eval(row['fields']),
                start_date=(last_date + BDay()).strftime(dt_fmt),
                end_date=end_date.strftime(dt_fmt)
            )
            res_ = res_.rename({field['field']: field['name'] for field in fields_indices_history}, axis=1)
            res_['z_spread'] = res_['z_spread'] / row['scale']
            res[ticker] = res_

    if res:
        logger.info('new prices for indices found')
        new_hist = pd.concat(res.values())
        indices_hist = pd.concat([indices_hist, new_hist])\
                         .drop_duplicates()\
                         .sort_values(['security', 'date'])
        indices_hist.to_csv(data_path / 'indices_history.csv', index=False)


if __name__ == '__main__':
    logger = get_logger(__name__, file=logs_path / 'indices_history_daily.log', mode='w')
    try:
        get_indices_history_daily(logger=logger)
        logger.info('SUCCESS!')
    except Exception as e:
        logger.error(e)
