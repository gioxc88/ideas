import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd

import config
from loggers import get_default_logger, get_logger

from api.blp import BlpQuery
from api.data.base import tables, data_path, logs_path
from api.data.fields import fields_market
from api.data.utils import add_pcs


def get_bonds_market_data(
        pcs=None,
        sep=None,
        logger=get_default_logger()
):
    tables.bonds_market.to_csv(data_path / 'bonds_market_backup.csv')

    logger.info('starting download')
    sep = sep or '@'

    timestamp = f"{pd.Timestamp.today():%Y%m%d_%H%M%S}"
    bq = BlpQuery(timeout=50000).start()

    bonds_ref = tables.bonds_reference.reset_index()

    bonds_ref = bonds_ref.loc[(bonds_ref['workout_date'] > pd.Timestamp.today()), :]
    securities = bonds_ref['security'].to_list()
    if pcs:
        securities = add_pcs(securities, pcs, sep=sep)
    res = []
    for field in fields_market:
        while True:
            try:
                logger.info(f"downloading {field['field']} ..")
                res_ = bq.bdp(
                    securities=securities,
                    fields=[field["field"]],
                    overrides=field.get("overrides")
                )
            except (TypeError, ConnectionError) as e:
                logger.warning(f"error {e} received for field {field}, retrying")
            else:
                res_ = res_.rename({field['field']: field['name']}, axis=1).set_index('security')
                res.append(res_)
                break
    res = pd.concat(res, axis=1).reset_index()

    if pcs:
        res['security'] = res['security'].str.replace(f'{sep}{pcs}', '')

    logger.info('saving..')
    res.to_csv(data_path / 'temp' / f"bonds_market_{timestamp}.csv", index=False)
    res.to_csv(data_path / f"bonds_market.csv", index=False)


if __name__ == '__main__':
    logger = get_logger(__name__, file=logs_path / 'bonds_market_bulk.log', mode='w')
    try:
        get_bonds_market_data(pcs='BGN', logger=logger)
        logger.info('SUCCESS!')
    except Exception as e:
        logger.error(e)

