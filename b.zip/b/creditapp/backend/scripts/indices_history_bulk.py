import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay

from api.blp import BlpQuery
from api.data.base import root_path, data_path, tables
from api.data.fields import fields_indices_history

### Bloomberg Connection

dt_fmt = '%Y%m%d'
bq = BlpQuery(timeout=20000).start()

indices_ref = pd.read_csv(data_path / 'indices_reference.csv')
indices_hist = pd.read_csv(data_path / 'indices_history.csv', parse_dates=['date'], dayfirst=True)

start_date = pd.Timestamp(2007, 1, 1)
end_date = pd.Timestamp.today()

new_indices = indices_ref.loc[~indices_ref['ticker'].isin(indices_hist['security'].unique())]
# new_indices = new_indices.loc[new_indices['fields'] != "['CONTRBTD_ZSPREAD']", :]


if not new_indices.empty:
    ress = {}

    for index, row in new_indices.iterrows():
        print(f"downloading data for {row['ticker']}")
        res = bq.bdh(
            securities=[row['ticker']],
            fields=eval(row['fields']),
            start_date=start_date.strftime(dt_fmt),
            end_date=end_date.strftime(dt_fmt)
        )
        res = res.rename({field['field']: field['name'] for field in fields_indices_history}, axis=1)
        res['z_spread'] = res['z_spread'] / row['scale']
        ress[row['ticker']] = res
    new_hist = pd.concat(ress.values(), keys=None)
    indices_hist = pd.concat([indices_hist, new_hist]) \
        .sort_values(['security', 'date']) \
        .reset_index(drop=True)
    indices_hist.to_csv(data_path / 'indices_history.csv', index=False)

# indices_hist.loc[indices_hist['security'] == 'BUS3TRUU Index']
