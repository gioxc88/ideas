import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay

from api.blp import BlpQuery
from api.data.base import tables, data_path
from api.data.fields import fields_yas_history
from api.data.utils import add_pcs

dt_fmt = '%Y%m%d'
bq = BlpQuery(timeout=20000).start()

bonds_ref = tables.bonds_reference.reset_index()

start_date = pd.Timestamp(2007, 1, 1)
end_date = pd.Timestamp.today()
data_limit = 10000
securities = None  # securities = bonds_ref['security'].drop_duplicates().to_list()
fields = [field['field'] for field in fields_yas_history]

if securities is not None:
    subset = bonds_ref.loc[bonds_ref['security'].isin(securities)]
else:
    subset = bonds_ref

start_date_ = max(start_date, subset['issue_date'].min())
date_range = pd.date_range(start=start_date_, end=end_date, freq='B')

res = {}
i = 0

for date in date_range[2:]:
    subset_ = subset.loc[(bonds_ref['issue_date'] <= date)]
    if not subset_.empty:
        i += len(subset_) * len(fields)
        print(f'at {date} {i} data points downloaded, limit is {data_limit}')

        res_ = []

        for field in fields_yas_history:
            while True:
                try:
                    res__ = bq.bdp(
                        securities=subset_['security'].to_list(),
                        fields=[field['field']],
                        overrides=[
                            ('USER_LOCAL_TRADE_DATE', date.strftime(dt_fmt)),
                            *field.get('overrides', [])
                        ]
                    )
                except ConnectionError:
                    print('retrying for date {date} because of connection timeout')
                else:
                    res_.append(res__.set_index('security'))
                    break
        res_ = pd.concat(res_, axis=1)

        res[date] = res_
    if data_limit and i >= data_limit:
        print(f'at date {date} data limit reached')
        break
