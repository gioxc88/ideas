import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd


from api.blp import BlpQuery
from api.data.fields import fields_reference
from api.data.processing import post_process
from api.data.base import tables
from api.data.base import root_path, data_path, tables
from api.data.utils import get_cds_tickers

timestamp = f"{pd.Timestamp.today():%Y%m%d_%H%M%S}"

### Bloomberg Connection

bq = BlpQuery().start()
bond_ref = tables.bonds_reference
cds_5y = bond_ref['cds_ticker_5y'].dropna().drop_duplicates().to_list()

field = 'SECURITY_DES'
res = bq.bdp(
    securities=cds_5y,
    fields=[field]
)

cds_ref = []
for index, row in res.iterrows():
    cds_ticker_5y, cds_generic_name = row['security'], row[field]
    cds_tickers = get_cds_tickers(cds_generic_name=cds_generic_name, bq=bq)
    cds_tickers['cds_ticker_5y'] = cds_ticker_5y
    cds_ref.append(cds_tickers)
cds_ref = pd.concat(cds_ref).drop_duplicates(subset='security')


na_cds = []
a_cds = []
for sec in cds_ref['security'].drop_duplicates().to_list():
    try:
        t = bq.bdp(
            securities=[sec],
            fields=['ticker']
        )
        a_cds.append(t)
    except TypeError as e:
        na_cds.append(sec)

cds_real_ref = pd.concat(a_cds).rename({'ticker': 'cds_ticker'}, axis=1)
cds_real_ref = cds_real_ref.merge(cds_ref, on='security')
cds_real_ref['cds_ticker'] = cds_real_ref['cds_ticker'] + ' Curncy'

to_merge = bond_ref[['ticker', 'issuer_equity_ticker', 'issuer_name', 'cds_ticker_5y']].dropna()
cds_real_ref = cds_real_ref.merge(to_merge, how='left', on='cds_ticker_5y').drop_duplicates(subset='security')

cds_real_ref = cds_real_ref.assign(exists=np.nan)
cds_real_ref.to_csv(data_path / 'cds_reference.csv', index=False)

