import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd


from api.blp import BlpQuery
from api.data.fields import fields_reference
from api.data.processing import post_process, apply_function
from api.data.base import tables, root_path, data_path

timestamp = f"{pd.Timestamp.today():%Y%m%d_%H%M%S}"

### Bloomberg Connection

bq = BlpQuery().start()

searches = [
    'at1',
    'lt2',
    'sp',
    'snp'
]

tickers = []
for search in searches:
    tickers.append(bq.bsrch(f"FI:{search}"))

tickers = pd.concat(tickers, keys=searches, sort=False).droplevel(1).rename('security')

tickers.to_csv(data_path / 'temp' / f"searches_{timestamp}.csv" )

res = bq.bdp(
    securities=tickers.to_list(),
    fields=[field['field'] for field in fields_reference],
)

res.to_csv(data_path / 'temp' / f"bonds_reference_{timestamp}.csv" , index=False)

res = post_process(res, tickers)

res.to_csv(data_path / 'bonds_reference.csv', index=False)

### Bugfix

#### 1. Add new fields

# res = pd.read_csv(data_path / 'temp' / 'bonds_reference_20220525_193116.csv')
# tickers = pd.read_csv(data_path / 'temp' / 'searches_20220525_193116.csv', index_col=0).squeeze()
res = pd.read_csv(data_path / 'bonds_reference.csv')
# bonds_ref.loc[(bonds_ref['workout_date'] > pd.Timestamp.today()), :]

res_ = bq.bdp(
    securities=res['security'].to_list(),
    fields=['ISSUER'],
).rename({field['field']: field['name'] for field in fields_reference}, axis=1)

res_ = apply_function(res_)

res = res.merge(res_, on='security', how='left')
res.to_csv(data_path / 'bonds_reference.csv', index=False)

#### 2. Add new Instruments

new_tickers = tickers.loc[~tickers.isin(res['security'])]

res_ = bq.bdp(
    securities=new_tickers.to_list(),
    fields=[field['field'] for field in fields_reference],
).rename({field['field']: field['name'] for field in fields_reference}, axis=1)

res_ = post_process(res_, new_tickers)

res = pd.concat([res, res_])

res.to_csv(data_path / 'bonds_reference.csv', index=False)

