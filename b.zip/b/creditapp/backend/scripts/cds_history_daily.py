import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay

import config
from loggers import get_default_logger, get_logger

from api.blp import BlpQuery
from api.data.fields import fields_reference
from api.data.processing import post_process
from api.data.base import tables
from api.data.base import root_path, data_path, tables, logs_path
from api.data.fields import fields_cds_history
from api.data.utils import add_pcs


def get_cds_history_daily(
        pcs=None,
        sep=None,
        logger=get_default_logger()
):
    sep = sep or ' '
    timestamp = f"{pd.Timestamp.today():%Y%m%d_%H%M%S}"

    ### Bloomberg Connection
    bq = BlpQuery(timeout=50000).start()
    dt_fmt = '%Y%m%d'

    cds_ref = pd.read_csv(data_path / 'cds_reference.csv')
    cds_hist = pd.read_csv(data_path / 'cds_history.csv', parse_dates=['date'])
    cds_hist.to_csv(data_path / 'cds_history_backup.csv', index=False)

    end_date = pd.Timestamp.today().floor('d') - BDay()

    g = cds_hist.groupby(['cds_ticker'])['date'].max()
    # gg = g.groupby(g)

    new_cds_prices = []
    for date, group in g.groupby(g):
        start_date = date + BDay()
        if start_date <= end_date:
            securities = group.index.to_list()
            logger.info(f"downloading prices for {securities}")
            if pcs:
                securities = add_pcs(securities, pcs, sep=sep)
            prices = bq.bdh(
                securities=securities,
                fields=[field['field'] for field in fields_cds_history],
                # overrides=[('PRICING_SOURCE', 'CMAN')]
                start_date=start_date.strftime(dt_fmt),
                end_date=end_date.strftime(dt_fmt)
            )
            if not prices.empty:
                logger.info(f"Prices not empty")
                # prices.to_csv(data_path / 'temp' / f"cds_history_daily_{timestamp}.csv", index=False)
                new_cds_prices.append(prices)

    # start_date = pd.Timestamp(2007, 1, 1).floor('d')
    # bulk_cds = cds_ref.loc[cds_ref['exists'].isna(), 'security'].drop_duplicates().to_list()
    # if bulk_cds:
    #     bulk_prices = bq.bdh(
    #         securities=bulk_cds,
    #         fields=[field['field'] for field in fields_cds_history],
    #         # overrides=[('PRICING_SOURCE', 'CMAN')]
    #         start_date=start_date.strftime(dt_fmt),
    #         end_date=end_date.strftime(dt_fmt)
    #     )
    #     bulk_prices.to_csv(data_path / 'temp' / f"cds_history_daily_bulk_{timestamp}.csv", index=False)
    #     new_cds_prices.append(bulk_prices)

    if new_cds_prices:
        logger.info(f"found some prices to update")
        new_cds_prices = pd.concat(new_cds_prices) \
            .rename({field['field']: field['name'] for field in fields_cds_history}, axis=1)\
            .rename({'security': 'cds_ticker'}, axis=1)
        if pcs:
            new_cds_prices['cds_ticker'] = new_cds_prices['cds_ticker'].str.replace(f'{sep}{pcs}', '')
        new_cds_prices = new_cds_prices.merge(cds_ref[['cds_ticker', 'security']], on='cds_ticker', how='left')

        # new_cds_prices = new_cds_prices.groupby('security', as_index=False, sort=False, dropna=False) \
        #     .apply(lambda df: df.set_index('date').resample('B').ffill().reset_index()).reset_index(drop=True)

        cds_hist = pd.concat([cds_hist, new_cds_prices]).sort_values(['security', 'date'])
        cds_hist.to_csv(data_path / 'temp' / f"cds_history_{timestamp}.csv", index=False)
        cds_hist.to_csv(data_path / 'cds_history.csv', index=False)


if __name__ == '__main__':
    logger = get_logger(__name__, file=logs_path / 'cds_history_daily.log', mode='w')
    try:
        get_cds_history_daily(logger=logger)
        logger.info('SUCCESS!')
    except Exception as e:
        logger.error(e)
