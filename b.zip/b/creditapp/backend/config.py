# import redis
# import redis
#
# redis_url = 'redis://localhost:6379'
import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    """Set Flask config variables."""
    ENV = 'development'

    SECRET_KEY = os.environ.get('SECRET_KEY')
    STATIC_FOLDER = 'static'
    TEMPLATES_FOLDER = 'templates'
    PREFERRED_URL_SCHEME = 'https'

    # DATABASE
    SQLALCHEMY_DATABASE_URI = os.environ.get('SQLALCHEMY_DATABASE_URI')
    SQLALCHEMY_TRACK_MODIFICATIONS = True

    # JWT-EXTENDED
    # JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY')

    # CORS
    CORS_ORIGINS = [r"http://localhost*", "http://127.0.0.1*"]
    CORS_SUPPORTS_CREDENTIALS = True

    # SESSION_TYPE = 'redis'
    # SESSION_REDIS = conn = redis.from_url(redis_url)

    # CUSTOM

