import sys
from pathlib import Path
from itertools import chain, product

import dotenv
import numpy as np
import pandas as pd

from api import db, make_app
from api import models
from api.blp import BlpQuery
from api.manager import InstrumentManager, Clone
from api.inputs import Instruments, InstrumentUI

app = make_app()
app.app_context().push()

bq = BlpQuery().start()

im = InstrumentManager()

root_path = Path('/dev/projects/credit/backend/')
data_path = root_path / 'data'
tickers_csv = data_path / 'tickers_restricted.csv'

tickers = pd.read_csv(tickers_csv, header=None).squeeze().rename(None)


n = 5
test_tickers = tickers.sample(n=n)
# test_tickers = pd.Series(
#     [
#         # 'AZ871246 Corp',
#         # 'AU153783 Corp',
#         'AP419194 Corp', #
#         'BS568342 Corp', #
#         'BR846293 Corp',
#         'EK767337 Corp',
#         'BV694378 Corp'
#     ]
# )

# test_tickers = pd.concat([test_tickers, test_tickers1[:3]])


ii = Instruments([InstrumentUI(category='bond', identifier='ticker', value=tk) for tk in test_tickers])
temp_file = Path('/dev/projects/credit/backend/db/temp') / 'data_2022-04-26 13.33.00.pickle'
d = im.get_data(ii)
im._action(ii)




