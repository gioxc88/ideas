import json
import sys
from pathlib import Path

import ipywidgets as w
import ipyvuetify as v
import pdblp
import numpy as np
import pandas as pd
from IPython.display import display
from ipydatagrid import DataGrid
from sklearn.linear_model import LinearRegression


from api.gui.utils import tables
from api.gui.pairs import tab_ as pairs_tab
from api.gui.details import tab_ as details_tab
from api.gui.regression import tab_ as regression_tab
from api.gui.base import MultiTab


root_path = Path('/dev/projects/credit/backend/')

data_path = root_path / 'data'


with open(data_path / 'pairs.json') as f:
    pairs = json.load(f)

indices = tables.indices
indices_history = tables.indices_history
indices = indices.assign(
    combined_name=indices.drop('ticker', axis=1).apply(lambda x: '_'.join(x.dropna()), axis=1),
)


app = MultiTab(
    tabs=[
        pairs_tab,
        regression_tab,
        details_tab
    ]
)

tp = app.tabs[1]
crncy = tp.tab.children[0].children[0].children[0].children[0]
pair = tp.tab.children[0].children[0].children[1].children[0]
win = tp.tab.children[0].children[0].children[2].children[0]
btn = tp.tab.children[0].children[0].children[-1].children[0]

crncy.v_model = 'eur'
crncy.fire_event('change', None)
pair.v_model = pair.items[0]
btn.fire_event('click', None)


