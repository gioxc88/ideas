

import sys
from pathlib import Path
from itertools import chain, product

import dotenv
import numpy as np
import pandas as pd

from api import db, make_app
from api import models, utils
from api.blp import BlpQuery
from api.manager import InstrumentManager, Clone
from api.inputs import Instruments, InstrumentUI

app = make_app()
app.app_context().push()

bq = BlpQuery().start()

im = InstrumentManager()

root_path = Path('/dev/projects/credit/backend/')
data_path = root_path / 'data'
tickers_csv = data_path / 'tickers_restricted.csv'

tickers = pd.read_csv(tickers_csv, header=None).squeeze().rename(None)
q = models.Bond.query.filter(models.Bond.years_to_maturity <= 15)
q = models.Bond.query.filter(models.Bond.years_to_maturity.between(25, 30))
q = models.Bond.query.filter(models.Bond.maturity_bucket == '30+')
res = q.all()