import sys
from pathlib import Path
from itertools import chain, product

import dotenv
import numpy as np
import pandas as pd

from api import db, make_app
from api import models


app = make_app()
app.app_context().push()

tables_path = path / 'tables'
# path = Path('./db/tables')

encoding = 'ISO-8859-1'
# encoding = 'windows-1252'

db.drop_all()
db.create_all()

'NAME',  # asset
'SECURITY_NAME',  # asset
'TICKER',  # asset
'ID_ISIN',  # asset
'ID_CUSIP',  # asset
'TICKER_AND_EXCH_CODE',  # asset
'EXCH_CODE',  # asset
'MARKET_SECTOR_DES',  # asset (yellow key)
'CRNCY',  # asset currency
'COUNTRY',  # asset country
'CNTRY_OF_RISK',  # asset country
'ISSUER',  # asset issuer
'ISSUER_EQUITY_TICKER',  # issuer

'GICS_SECTOR',  # asset gics
'GICS_INDUSTRY_GROUP',  # asset gics
'GICS_INDUSTRY',  # asset gics
'GICS_SUB_INDUSTRY',  # asset gics
'GICS_SECTOR_NAME',  # asset gics
'GICS_INDUSTRY_GROUP_NAME',  # asset gics
'GICS_INDUSTRY_NAME',  # asset gics
'GICS_SUB_INDUSTRY_NAME',  # asset gics
'BICS_LEVEL_1_SECTOR_CODE',  # asset bics
'BICS_LEVEL_2_INDUSTRY_GROUP_CODE',  # asset bics
'BICS_LEVEL_1_SECTOR_NAME',  # asset bics
'BICS_LEVEL_2_INDUSTRY_GROUP_NAME',  # asset bics

'ISSUE_DT',  # bond
'MATURITY',  # bond
'CALC_MATURITY',  # bond
'MTY_TYP',  # bond

'AMT_ISSUED',  # bond
'PAR_AMT',  # bond
'FIRST_SETTLE_DT',  # bond

'CPN',  # bond
'CPN_FREQ',  # bond
'CPN_TYP',  # bond
'CPN_CRNCY',  # bond
'DAY_CNT',  # bond
'FIRST_CPN_DT',  # bond

'FIXED',  # bond
'CALLABLE',
'IS_PERPETUAL',  # bond
'CONVERTIBLE',  # bond
'IS_SUBORDINATED',  # bond

# 'INT_ACC_DT',
# 'SECURITY_PRICING_DATE',
'GREEN_BOND_LOAN_INDICATOR',  # bond
'PAYMENT_RANK',
'NORMALIZED_PAYMENT_RANK',
'BASEL_III_DESIGNATION',
'CAPITAL_TYP_COCO_INITIAL_TRIGGER',
'CAPITAL_TYPE_COCO_ACTION',
'CAPITAL_TYPE_COCO_TRIGGER_LEVEL',
'CAPITAL_TRIGGER_TYPE',