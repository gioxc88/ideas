import pandas as pd

df = pd.read_clipboard(parse_dates=True, dayfirst=True)
df = df.groupby(df.index.year).apply(lambda df: df.abs() / df.abs().sum())
df = df.assign(year=df.index.year, month=df.index.month)
df.pivot(index='year', columns='month').T.to_clipboard()
