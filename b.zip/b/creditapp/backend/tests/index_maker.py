import sys
from pathlib import Path

import pdblp
import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay

from api.blp import BlpQuery
from api.data.base import tables, data_path
from api.data.fields import fields_history
from api.data.utils import add_pcs

dt_fmt = '%Y%m%d'
bq = BlpQuery(timeout=20000).start()

bonds_ref = tables.bonds_reference.reset_index()
bonds_hist = tables.bonds_history
new_bonds = bonds_ref.loc[bonds_ref['has_time_series'].isna()]
existing_bonds = bonds_ref.loc[bonds_ref['has_time_series']]
bonds_merge = bonds_hist.merge(bonds_ref[['security', 'workout_date']], on='security', how='left')
bonds_merge['workout_years'] = (bonds_merge['workout_date'] - bonds_merge['date']).dt.days / 365.2425

start_date = bonds_hist['date'].min()
end_date = bonds_hist['date'].max()
dates = pd.date_range(start=start_date, end=end_date, freq='B')

memb = []
min_members = 10
base_filters = [
    'workout_years >= 1'
]
for date in dates:
    df_date = bonds_merge.loc[bonds_hist['date'] == date]
    df_filter = df_date.query(' '.join(base_filters))
    if len(df_filter) >= min_members:
        break


