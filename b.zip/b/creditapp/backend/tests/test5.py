import sys
from pathlib import Path
from itertools import chain, product

import dotenv
import numpy as np
import pandas as pd
import sqlalchemy as sa

from api import db, make_app
from api import models
from api.blp import BlpQuery
from api.manager import InstrumentManager, Clone
from api.inputs import Instruments, InstrumentUI

app = make_app()
app.app_context().push()

bq = BlpQuery().start()
im = InstrumentManager()

root_path = Path('/dev/projects/credit/backend/')
data_path = root_path / 'data'
tickers_csv = data_path / 'tickers_restricted.csv'

b = models.Bond.query.get(1)

cls = models.Bond

null_ratings = [
'NR',
'NA',
'SD',
'NM',
'R',

]
sa.case(
    (sa.or_(cls.rating_sp.rating != None)

     ))

{
    'corporates': {
        'fields': {
            'bclass2': {

            }

        },
        'ticker':  'LECPTREU'
    }
}



from dataclasses import dataclass, asdict

@dataclass
class Index:
    name: str = None
    value: str = None
    ticker: str = None
    fields: list = None
    # def __init__(self, name, fields, ticker=None):

# EURO AGGREGATE > EURO CORPORATE
Index(
    name='bclass1',
    value='corporate',
    ticker='LECPTREU',
    fields=[
        Index(
            name='bclass2',
            value='industrials',
            ticker='I02008EU',
            fields=[
                Index(
                    name='maturity',
                    value='1-3y',
                    ticker='I10344EU'
                ),
                Index(
                    name='maturity',
                    value='3-5y',
                    ticker='I10345EU'
                ),
                Index(
                    name='maturity',
                    value='5-7y',
                    ticker='I10346EU'
                ),
                Index(
                    name='maturity',
                    value='7-10y',
                    ticker='I10347EU'
                ),
                Index(
                    name='maturity',
                    value='10y+',
                    ticker='I10348EU'
                ),
                Index(
                    name='quality',
                    value='Aaa',
                    ticker='I10361EU'
                ),
                Index(
                    name='quality',
                    value='Aa',
                    ticker='I10360EU'
                ),
                Index(
                    name='quality',
                    value='A',
                    ticker='I10359EU'
                ),
                Index(
                    name='quality',
                    value='Baa',
                    ticker='I10362EU'
                ),
            ]
        ),
        Index(
            name='bclass2',
            value='utilities',
            ticker='I02009EU',
        ),
        Index(
            name='bclass2',
            value='financials',
            ticker='LEEFTREU',
            fields=[
                Index(
                    name='maturity',
                    value='1-3y',
                    ticker='I10354EU'
                ),
                Index(
                    name='maturity',
                    value='3-5y',
                    ticker='I10355EU'
                ),
                Index(
                    name='maturity',
                    value='5-7y',
                    ticker='I10356EU'
                ),
                Index(
                    name='maturity',
                    value='7-10y',
                    ticker='I10357EU'
                ),
                Index(
                    name='maturity',
                    value='10y+',
                    ticker='I10358EU'
                ),
                Index(
                    name='quality',
                    value='Aaa',
                    ticker='I10369EU'
                ),
                Index(
                    name='quality',
                    value='Aa',
                    ticker='I10368EU'
                ),
                Index(
                    name='quality',
                    value='A',
                    ticker='I10367EU'
                ),
                Index(
                    name='quality',
                    value='Baa',
                    ticker='I10370EU'
                ),
                Index(
                    name='bclass3',
                    value='banking',
                    ticker='I03125EU',
                    fields=[
                        Index(
                            name='subordination',
                            value='senior',
                            ticker='I08154EU',
                            fields=[
                            ]
                        ),
                        Index(
                            name='subordination',
                            value='subordinated',
                            ticker='I26793EU',
                            fields=[
                                Index(
                                    name='subordination',
                                    value='lt2',
                                    ticker='I08153EU',
                                ),
                                Index(
                                    name='subordination',
                                    value='ut2',
                                    ticker='I08152EU',

                                ),
                                Index(
                                    name='subordination',
                                    value='t1',
                                    ticker='I08151EU',

                                ),
                            ]
                        ),
                    ],
                )
            ]
        ),
        Index(
            name='maturity',
            value='1-3y',
            ticker='LEC1TREU'
        ),
        Index(
            name='maturity',
            value='3-5y',
            ticker='LEC3TREU'
        ),
        Index(
            name='maturity',
            value='5-7y',
            ticker='LEC5TREU'
        ),
        Index(
            name='maturity',
            value='7-10y',
            ticker='I02137EU'
        ),
        Index(
            name='maturity',
            value='10y+',
            ticker='I02138EU'
        ),

    ]
)


'TICKER',
'SECURITY_NAME',
'ID_ISIN',
'CRNCY',
'CNTRY_OF_RISK',
'BICS_LEVEL_1_SECTOR_NAME',
'BICS_LEVEL_2_INDUSTRY_GROUP_NAME',
'AMT_OUTSTANDING',
'ISSUE_DT',
'MATURITY',
'CALC_MATURITY',
'WORKOUT_DT_MID',
'MTY_TYP',
'CPN',
'CPN_TYP',
'RTG_SP',
'RTG_MOODY',
'RTG_FITCH',
'BB_COMPOSITE',
'FIXED',
'CALLABLE',
'IS_PERPETUAL',
'CONVERTIBLE',
'IS_SUBORDINATED',
'PAYMENT_RANK',
'BAIL_IN_BOND_DESIGNATION',
'BASEL_III_DESIGNATION',
'GREEN_BOND_LOAN_INDICATOR',

from IPython.display import IFrame, HTML

fields = {
    'TICKER': 'ticker',
    'SECURITY_NAME': 'name',
    'ID_ISIN': 'isin',
    'CRNCY': 'currency',
    'CNTRY_OF_RISK': 'country',
    'BICS_LEVEL_1_SECTOR_NAME': 'bics_sector',
    'BICS_LEVEL_2_INDUSTRY_GROUP_NAME': 'bics_industry',
    'AMT_OUTSTANDING': 'amount_outstanding',
    'ISSUE_DT': 'issue_date',
    'MATURITY': 'maturity',
    'CALC_MATURITY': 'calc_maturity',
    'WORKOUT_DT_MID': 'workout_date',
    'MTY_TYP': 'maturity_type',
    'CPN': 'coupon',
    'CPN_TYP': 'coupon_type',
    'RTG_SP': 'rating_sp',
    'RTG_MOODY': 'rating_moody',
    'RTG_FITCH': 'rating_fitch',
    'BB_COMPOSITE': 'rating_bbg',
    'FIXED': 'is_fixed',
    'CALLABLE': 'is_callable',
    'IS_PERPETUAL': 'is_perpetual',
    'CONVERTIBLE': 'is_convertible',
    'IS_SUBORDINATED': 'is_subordinated',
    'PAYMENT_RANK': 'payment_rank',
    'BAIL_IN_BOND_DESIGNATION': 'bail_in_bond_designation',
    'BASEL_III_DESIGNATION': 'basel_iii_designation',
    'GREEN_BOND_LOAN_INDICATOR': 'is_green',
}


from itables import init_notebook_mode
import ipyvuetify as v




import pdblp
con = pdblp.BCon()
con.start()



from api.pdblp import BCon
import pandas as pd
from api.blp import BlpQuery
cds_hist = pd.read_clipboard(parse_dates=['date'])
bq = BlpQuery(timeout=50000).start()


r = bq.bdph(
    securities=['CCOL1U5 MSG1 Curncy'],
    fields=["CDS_QUOTED_PRICE"],
    id_override=cds_hist['date'].dt.strftime('%Y%m%d').to_list(),
    id_override_field="SW_CURVE_DT",
    CDS_FLAT_SPREAD=cds_hist['cds_spread'].to_list(),
    id_date
)


sprd = [
    250,
    300,
    350,
    400,
    450,
    500,
    550,
    600,
    650,
    700,
    750,
    800,
    850,
    900,
    950,
    1000
]


r = bc2.ref_hist(
    tickers=['CCOL1U5 MSG1 Curncy'],
    flds=["CDS_QUOTED_PRICE"],
    id_override=cds_data['date'].dt.strftime('%Y%m%d').to_list(),
    id_override_field="SW_CURVE_DT",
    CDS_FLAT_SPREAD=cds_data['last_price'].to_list()
)

r = bq.bdph(
    securities=['CCOL1U5 MSG1 Curncy'],
    fields=["CDS_QUOTED_PRICE"],
    id_override=cds_data['date'].dt.strftime('%Y%m%d').to_list(),
    id_override_field="SW_CURVE_DT",
    id_date=True,
    CDS_FLAT_SPREAD=cds_data['cds_spread'].to_list(),
)

r = bq.bdph(
    securities=['CCOL1U5 MSG1 Curncy'],
    fields=["CDS_QUOTED_PRICE"],
    id_override=cds_data['date'].dt.strftime('%Y%m%d').to_list(),
    id_override_field="SW_CURVE_DT",
    id_date=True,
    CDS_FLAT_SPREAD=cds_data['cds_spread'].to_list(),
)

r1 = bq.bdph(
    securities=['CCOL1U5 MSG1 Curncy'],
    fields=["UPFRONT_LAST"],
    id_override=sprd,
    id_override_field="CDS_FLAT_SPREAD",

)


'BN492555@BGN Corp'


r2 = bq.bdph(
    securities=['BN492555@BGN Corp'],
    fields=["YAS_BOND_PX"],
    id_override=sprd,
    id_override_field="YAS_ZSPREAD",
    overrides=[("USER_LOCAL_TRADE_DATE", '20220621')],
)


class CDSStrategy(View):
    def make_widgets(self):
        bond_tf = v.TextField(
            v_model=None,
            dense=True,
            label='bond',
            clearable=True
        )

        cds_tf = v.TextField(
            v_model=None,
            dense=True,
            label='cds',
            clearable=True
        )

        dl_btn = v.Btn(
            fab=True,
            # dark=True,
            small=True,
            plain=True,
            class_='mx-0',
            children=[v.Icon(children=['mdi-download'])]
        )

        start_dp = DatePicker(label='start date')
        end_dp = DatePicker(label='end date', value=pd.Timestamp.today())

        bond_price_tf = v.TextField(
            v_model=None,
            label='bond price',
            clearable=True,
            dense=True,
            type="number",
            outlined=True
        )

        cds_spread_tf = v.TextField(
            v_model=None,
            label='cds spread',
            clearable=True,
            dense=True,
            type="number",
            outlined=True,
        )

        cds_price_tf = v.TextField(
            v_model=None,
            label='cds spread',
            clearable=True,
            dense=True,
            type="number",
            outlined=True,
            disabled=True
        )

        bond_notional_tf = v.TextField(
            v_model=None,
            label='bond notional',
            clearable=True,
            dense=True,
            type="number",
            outlined=True
        )

        cds_notional_tf = v.TextField(
            v_model=None,
            label='cds notional',
            clearable=True,
            dense=True,
            type="number",
            outlined=True,
        )

        out = w.Output()

        self.bond_tf = bond_tf
        self.cds_tf = cds_tf
        self.dl_btn = dl_btn
        self.start_dp = start_dp
        self.end_dp = end_dp
        self.bond_price_tf = bond_price_tf
        self.cds_spread_tf = cds_spread_tf
        self.cds_price_tf = cds_price_tf
        self.bond_notional_tf = bond_notional_tf
        self.cds_notional_tf = cds_notional_tf
        self.out = out

    def make_view(self):
        bond_tf = self.bond_tf
        cds_tf = self.cds_tf
        dl_btn = self.dl_btn
        start_dp = self.start_dp
        end_dp = self.end_dp
        bond_price_tf = self.bond_price_tf
        cds_spread_tf = self.cds_spread_tf
        cds_price_tf = self.cds_price_tf
        bond_notional_tf = self.bond_notional_tf
        cds_notional_tf = self.cds_notional_tf
        out = self.out

        param_box = v.Container(
            children=[
                v.Row(
                    children=[
                        v.Col(
                            cols=2,
                            children=[bond_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[cds_tf],
                            class_="my-0 py-0"
                        ),
                    ],
                    align_content='center',
                ),
                v.Row(
                    children=[
                        v.Col(
                            cols=2,
                            children=[start_dp.menu],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[end_dp.menu],
                            class_="my-0 py-0"
                        ),
                    ],
                    align_content='center',
                ),
                v.Row(
                    children=[
                        v.Col(
                            cols=2,
                            children=[bond_price_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[cds_spread_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[cds_price_tf],
                            class_="my-0 py-0"
                        ),
                    ],
                    align_content='center',
                ),
                v.Row(
                    children=[
                        v.Col(
                            cols=2,
                            children=[bond_notional_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[cds_notional_tf],
                            class_="my-0 py-0"
                        ),
                        v.Col(
                            cols=2,
                            children=[dl_btn],
                            class_="my-0 py-0"
                        ),
                    ],
                    align_content='center',
                )
            ]
        )
        view = w.VBox(
            children=[
                param_box,
                out,
            ]
        )

        self.param_box = param_box
        self.view = view



        {
            'bond_tf': self.bond_tf.v_model,
            'cds_tf': self.cds_tf.v_model,
            'dl_btn': self.dl_btn.v_model,
            'dlh_btn': self.dlh_btn.v_model,
            'start_dp': self.start_dp.dp.v_model,
            'end_dp': self.end_dp.dp.v_model,
            'bond_price_tf': self.bond_price_tf.v_model,
            'cds_spread_tf': self.cds_spread_tf.v_model,
            'cds_price_tf': self.cds_price_tf.v_model,
            'bond_notional_tf': self.bond_notional_tf.v_model,
            'cds_notional_tf': self.cds_notional_tf.v_model,
        }




