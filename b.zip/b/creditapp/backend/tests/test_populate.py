import sys
from pathlib import Path
from itertools import chain, product

import dotenv
import numpy as np
import pandas as pd

from api import db, make_app
from api import models, utils
from api.blp import BlpQuery
from api.manager import InstrumentManager, Clone
from api.inputs import Instruments, InstrumentUI

app = make_app()
app.app_context().push()

bq = BlpQuery().start()

im = InstrumentManager()

root_path = Path('/dev/projects/credit/backend/')
data_path = root_path / 'data'
tickers_csv = data_path / 'tickers_restricted.csv'

tickers = pd.read_csv(tickers_csv, header=None).squeeze().rename(None)

temp_file = Path('/dev/projects/credit/backend/db/temp') / 'data_2022-05-03 12.24.56.pickle'
data = utils.read_pickle(temp_file)
ii = Instruments.from_records(data['bond']['records'])
im._action(ii, fetch=data)


n = 500
start = 500
for i in range(start, len(tickers), n):
    tickers_subset = tickers[i:i + n]
    instruments = Instruments([InstrumentUI(category='bond', identifier='ticker', value=tk) for tk in tickers_subset])
    im._action(instruments)




