cd /c/dev/projects/creditapp/backend && source ./venv/Scripts/activate && voila --enable_nbextensions=True ./notebooks/app_final.ipynb

