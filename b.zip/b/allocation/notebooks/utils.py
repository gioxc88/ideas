from sklearn.tree import export_graphviz
from graphviz import Source

def tree_plot(
    tree,
    max_depth=4, 
    rounded=True, 
    proportion=False, 
    precision=5, 
    filled=True,
    **kwargs
    
):
    dot = export_graphviz(
        tree, 
        max_depth=max_depth, 
        rounded=rounded, 
        proportion=proportion, 
        precision=precision, 
        filled=filled,
        **kwargs
    )
    return Source(dot)