def set_mpl(backend=None, interactive=True, **kwargs):
    import matplotlib as mpl
    if backend:
        mpl.use(backend)
    mpl.interactive(interactive)


set_mpl('Qt5Agg')

import sys
from pathlib import Path

import ipywidgets as w
import numpy as np
import pandas as pd
import seaborn as sns
from dask.distributed import Client
from pandas.tseries.offsets import DateOffset
from scipy.cluster.hierarchy import dendrogram
from scipy import stats
from matplotlib import pyplot as plt

from allocation import *
from allocation.strategies import TestStrategy
from allocation.portfolio import Portfolio
from allocation.risk_managers import ActiveSignalsRiskScaler, VaRLimitScaler
from allocation.estimators import *
from allocation.estimators.misc import EWM

rng = np.random.default_rng(7)

data_path = Path(r'M:\BHAI\Shared\MacroBot\Scrap_Results' if sys.platform == 'win32' else '/mnt/macrobot/Scrap_Results')

assets = pd.read_csv(data_path / 'assets.csv', index_col=0, parse_dates=True, dayfirst=True) \
    .drop(['AUD_Bond_10y_Fut', 'AUD_Equity_Fut'], axis=1) \
    .rename({'AUD_Bond_10y_Fut_shift1': 'AUD_Bond_10y_Fut', 'AUD_Equity_Fut_shift1': 'AUD_Equity_Fut'}, axis=1)
signals = pd.read_csv(data_path / 'Gio_Signals.csv', index_col=0, parse_dates=True, dayfirst=True) \
    .rename({'AUD_Bond_10y_Fut_shift1': 'AUD_Bond_10y_Fut'}, axis=1)

ptf = Portfolio.from_assets_and_signals(assets, signals)

a = MaxRiskAdjusted()
b = BackTest(
    ptf,
    a,
    rebalance=5,
    first_training_size=250
)
b.run(partial=False)

ewm = EWM(SampleStandardDeviation(), alpha=0.05)

als = dict(
    oon=OneOverN(),
    ir_std=InverseRisk(),
    ir_ewm=InverseRisk(measure=ewm),
    ir_cvar=InverseRisk(measure=SampleCVaR()),
    ir_var=InverseRisk(measure=SampleVaR()),
    max_sharpe=MaxRiskAdjusted(),
    hrp=HRP(),
    herc=HERC(),
)

ptf2 = Portfolio.from_assets(assets[['US_Equity_Fut', 'US_Bond_30y_Fut']])
ptf2.get_returns()

concentration_limits = {
    'equity': (0.9, [
        "US_Equity_Fut",
        "EMU_Equity_Fut",
        "CAD_Equity_Fut",
        "UK_Equity_F100_Fut",
        "AUD_Equity_Fut",
        "EM_Equity_Fut",
    ]),
    'bond': (0.9, [
        "EMU_Buxl_Fut",
        "US_Bond_30y_Fut",
        "AUD_Bond_10y_Fut",
    ]),
    'fx': (0.675, [
        "FX_JPY_TR",
        "FX_EUR_TR",
        "FX_EURSEK_TR",
        "FX_EURGBP_TR",
    ]),
    'commodity_fx': (0.72, [
        "FX_CAD_TR",
        "FX_AUD_TR",
        "FX_MXN_TR",
        "FX_NOK_TR",
    ]),
    'risk_on': (0.9, {
        "US_Equity_Fut": 1.0,
        "EMU_Equity_Fut": 1.0,
        "CAD_Equity_Fut": 1.0,
        "UK_Equity_F100_Fut": 1.0,
        "AUD_Equity_Fut": 1.0,
        "EM_Equity_Fut": 1.0,
        "EMU_Buxl_Fut": -1.0,
        "US_Bond_30y_Fut": -1.0,
        "AUD_Bond_10y_Fut": -1.0,
        "FX_CAD_TR": -0.5,
        "FX_JPY_TR": 0.5,
        "FX_AUD_TR": 0.75,
        "FX_EUR_TR": -0.25,
        "FX_NOK_TR": -0.75,
        "FX_EURSEK_TR": -0.5,
        "FX_MXN_TR": -0.75,
        "FX_EURGBP_TR": 0
    })
}
from sklearn.cluster import KMeans


class A:
    def a(selfa, b, v, d, e):
        '''

        Parameters
        ----------
        b
        v
        d
        e

        Returns
        -------

        '''


b = BackTest(ptf2, InverseRisk(SampleVaR())).run()  #

spec = {
    'RollingMean': {
        'B': {
            1: [],
            2: [],
            3: []
        },
        'W': {

        },
    }
}

spec = {
    1: {
        'B': {
            'RollingMean': [{'window': 5}, {'window': 20}, {'window': 60}],
            'RollingZScore': [],
        },
        'W': {
            'RollingMean': [],
            'RollingZScore': [],
        },
    },

    2: {
        'B': {
            'RollingMean': [],
            'RollingZScore': [],
        },
        'W': {
            'RollingMean': [],
            'RollingZScore': [],
        },
    },
}

'''
NOTES
1. The difference is only applied to RollingMean and Raw features 
'''

smooth = {
    'B': {
        1: {
            'smoothers': {
                'RollingMean': [{'window': 5}, {'window': 20}, {'window': 60}],
                'RollingZScore': [{'window': 60}, {'window': 250}, {'window': 500}],
            },
            'differences': {
                'Difference': [{'step': 1}, {'step': 5}, {'step': 20}]
            }
        },
        2: {
            'smoothers': {
                'RollingMean': [{'window': 5}, {'window': 20}, {'window': 60}],
                'RollingEWM': [{'alpha': 0.87}, {'alpha': .93}, {'alpha': .97}],
                'RollingZScore': [{'window': 60}, {'window': 250}, {'window': 500}],
            },
            'differences': {
                'Difference': [{'step': 1}, {'step': 5}, {'step': 20}, {'step': 60}],
                'FracDiff': [{'d': 0.5}, {'d': .9}, ]
            }

        },

    },
    'W': {
        1: {
            'smoothers': {
                'RollingMean': [{'window': 2}, {'window': 4}, {'window': 13}],
                'RollingZScore': [{'window': 13}, {'window': 52}, {'window': 104}],
            },
            'differences': {
                'Difference': [{'step': 1}, {'step': 2}, {'step': 4}]

            },
        },
        2: {
            'smoothers': {
                'RollingMean': [{'window': 2}, {'window': 4}, {'window': 13}],
                'RollingEWM': [{'alpha': .7}, {'alpha': .83}, {'alpha': .94}],
                'RollingZScore': [{'window': 13}, {'window': 52}, {'window': 104}],
            },
            'differences': {
                'Difference': [{'step': 1}, {'step': 2}, {'step': 4}, {'step': 13}],
                'FracDiff': [{'d': .5}, {'d': .9}]
            }

        },

    },

}

assets.__array__()

import ipywidgets as w

w.Output
w.interactive_output()

from sklearn.tree import DecisionTreeClassifier

DecisionTreeClassifier.predict_proba()
from matplotlib.gridspec import GridSpec
from plotly import figure_factory as ff

ff.create_dendrogram()

import scipy
from scipy.cluster import hierarchy

scp = scipy
sch = hierarchy


class Dendrogram(ff._dendrogram._Dendrogram):
    def __init__(self, X, **kwargs):
        self.precalc = kwargs.pop('precalc', False)
        labels = kwargs.pop('labels', None)
        if isinstance(X, pd.DataFrame) and labels is None:
            labels = [*X.columns]
        super().__init__(X, labels=labels, **kwargs)

    def get_dendrogram_traces(
            self, X, colorscale, distfun, linkagefun, hovertext, color_threshold
    ):
        """
        Calculates all the elements needed for plotting a dendrogram.

        :param (ndarray) X: Matrix of observations as array of arrays
        :param (list) colorscale: Color scale for dendrogram tree clusters
        :param (function) distfun: Function to compute the pairwise distance
                                   from the observations
        :param (function) linkagefun: Function to compute the linkage matrix
                                      from the pairwise distances
        :param (list) hovertext: List of hovertext for constituent traces of dendrogram
        :rtype (tuple): Contains all the traces in the following order:
            (a) trace_list: List of Plotly trace objects for dendrogram tree
            (b) icoord: All X points of the dendrogram tree as array of arrays
                with length 4
            (c) dcoord: All Y points of the dendrogram tree as array of arrays
                with length 4
            (d) ordered_labels: leaf labels in the order they are going to
                appear on the plot
            (e) P['leaves']: left-to-right traversal of the leaves

        """
        if self.precalc:
            Z = X
        else:
            d = distfun(X)
            Z = linkagefun(d)

        P = sch.dendrogram(
            Z,
            orientation=self.orientation,
            labels=self.labels,
            no_plot=True,
            color_threshold=color_threshold,
        )

        icoord = scp.array(P["icoord"])
        dcoord = scp.array(P["dcoord"])
        ordered_labels = scp.array(P["ivl"])
        color_list = scp.array(P["color_list"])
        colors = self.get_color_dict(colorscale)

        trace_list = []

        for i in range(len(icoord)):
            # xs and ys are arrays of 4 points that make up the '∩' shapes
            # of the dendrogram tree
            if self.orientation in ["top", "bottom"]:
                xs = icoord[i]
            else:
                xs = dcoord[i]

            if self.orientation in ["top", "bottom"]:
                ys = dcoord[i]
            else:
                ys = icoord[i]
            color_key = color_list[i]
            hovertext_label = None
            if hovertext:
                hovertext_label = hovertext[i]
            trace = dict(
                type="scatter",
                x=np.multiply(self.sign[self.xaxis], xs),
                y=np.multiply(self.sign[self.yaxis], ys),
                mode="lines",
                marker=dict(color=colors[color_key]),
                text=hovertext_label,
                hoverinfo="text",
            )

            try:
                x_index = int(self.xaxis[-1])
            except ValueError:
                x_index = ""

            try:
                y_index = int(self.yaxis[-1])
            except ValueError:
                y_index = ""

            trace["xaxis"] = "x" + x_index
            trace["yaxis"] = "y" + y_index

            trace_list.append(trace)

        return trace_list, icoord, dcoord, ordered_labels, P["leaves"]


r = assets.pct_change().dropna()

from sklearn.ensemble import RandomForestRegressor
from sklearn.tree import DecisionTreeRegressor, plot_tree
from sklearn.model_selection import train_test_split

target_name = 'US_Equity_Fut'
lags = 20
features = pd.concat([r[target_name].shift(i).rename(f'{target_name}_lag{i}') for i in range(1, lags + 1)],
                     axis=1).dropna()
target = r[target_name][lags:]

X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.3, shuffle=False)

reg = RandomForestRegressor().fit(X_train, y_train)

tree = DecisionTreeRegressor().fit(X_train, y_train)
tree.tree_.value

from allocation.allocators.hierarchy import HERC
from allocation.utils import RandomPortfolioGenerator

ptf_gen = RandomPortfolioGenerator(6).make()
ptf = ptf_gen.ptf
ptf.get_returns()

ret = pd.DataFrame(rng)
import requests

base_url = 'https://api.portfoliooptimizer.io/v1'
api_url = f'{base_url}/portfolio/optimization/hierarchical-clustering-based'

headers = {
    'Content-Type': 'application/json',
}
body = {
    'assets': 5,
    'assetsCovarianceMatrix': [[1, 1, 0, 0, 0],
                               [1, 1, 0, 0, 0],
                               [0, 0, 1, 0, 0],
                               [0, 0, 0, 1, 1],
                               [0, 0, 0, 1, 1]],
    'clusters': 3,
    'acrossClusterAllocationMethod': 'equalWeighting',
    'withinClusterAllocationMethod': 'equalWeighting',
}

api_url = f'{base_url}/assets/correlation/matrix'
body = {
  "assets": [
    {
      "assetReturns": [
        0.01,
        0,
        0.02,
        -0.03
      ]
    },
    {
      "assetReturns": [
        0.01,
        0,
        0.02,
        -0.03
      ]
    }
  ]
}


req = requests.post(
    url=api_url,
    data=body,
    headers=headers
)


cov = np.array([[2, 0.8, 0.1, 0.1],
                [0.8, 2, 0.1, 0.1],
                [0.1, 0.1, 1, 0.9],
                [0.1, 0.1, 0.9, 1]])

ret = pd.DataFrame(rng.multivariate_normal(np.zeros(len(cov)), cov=cov, size=1000))
from sklearn.inspection import PartialDependenceDisplay

from sklearn.datasets import make_hastie_10_2
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.inspection import PartialDependenceDisplay

X, y = make_hastie_10_2(random_state=0)
clf = GradientBoostingClassifier(n_estimators=100, learning_rate=1.0, max_depth=1, random_state=0).fit(X, y)
features = [0, 1, (0, 1)]
PartialDependenceDisplay.from_estimator(clf, X, features, method='brute')



np.linalg.cholesky(cov)