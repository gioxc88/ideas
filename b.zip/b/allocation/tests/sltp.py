# Stop Loss / Take Profit
def set_mpl(backend=None, interactive=True, **kwargs):
    import matplotlib as mpl
    if backend:
        mpl.use(backend)
    mpl.interactive(interactive)

set_mpl('Qt5Agg')

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import ipywidgets as widgets
import seaborn as sns
from IPython.display import display
from matplotlib import pyplot as plt

from allocation.strategies import VolStopLossStrategy, ConstantStopLossStrategy, TestStrategy

### 0. Data Loading

mapping_ohlc = {
    'UB1 R:05_0_R Comdty': 'EMU_Buxl_Fut',
    'US1 R:05_0_R Comdty': 'US_Bond_30y_Fut',
    'XM1 R:05_0_R Comdty': 'AUD_Bond_10y_Fut',
    'VG1 R:05_0_R Index': 'EMU_Equity_Fut',
    'MES1 R:05_0_R Index': 'EM_Equity_Fut',
    'XP1 R:05_0_R Index': 'AUD_Equity_Fut',
    'PT1 R:05_0_R Index': 'CAD_Equity_Fut',
    'ES1 R:05_0_R Index': 'US_Equity_Fut',
    'Z 1 R:05_0_R Index': 'UK_Equity_F100_Fut',
    'USDCAD Curncy': 'FX_CAD_TR',
    'USDJPY Curncy': 'FX_JPY_TR',
    'EURUSD Curncy': 'FX_EUR_TR',
    'AUDUSD Curncy': 'FX_AUD_TR',
    'USDNOK Curncy': 'FX_NOK_TR',
    'EURSEK Curncy': 'FX_EURSEK_TR',
    'USDMXN Curncy': 'FX_MXN_TR',
}

mapping_hourly = {
    'AUDUSD': 'FX_AUD_TR',
    'USDCAD': 'FX_CAD_TR',
    'EURUSD': 'FX_EUR_TR',
    'USDMXN': 'FX_MXN_TR',
    'USDNOK': 'FX_NOK_TR',
    'EURSEK': 'FX_EURSEK_TR',
    'USDJPY': 'FX_JPY_TR',
    # 'GBPUSD': 'GBPUSD',
    'UB': 'EMU_Buxl_Fut',
    'US': 'US_Bond_30y_Fut',
    'XP': 'AUD_Equity_Fut',
    'ES': 'US_Equity_Fut',
    'VG': 'EMU_Equity_Fut',
    'Z': 'UK_Equity_F100_Fut',
    'PT': 'CAD_Equity_Fut',
}

data_path = Path('data')
all_ohlc = pd.read_csv(data_path / 'ohlcv.csv', index_col=0, header=[0, 1], parse_dates=True).rename(
    columns=mapping_ohlc)
targets_ohlc = all_ohlc.loc['2005-09-09':, mapping_ohlc.values()]
all_signals = pd.read_csv(data_path / 'signals.csv', index_col=0, parse_dates=True)
targets_hourly = pd.read_csv(data_path / 'hourly.csv', index_col=0, parse_dates=True).rename(columns=mapping_hourly)

### Test

target = 'US_Equity_Fut'

assset_d = targets_ohlc.loc[:, (target, 'close')].dropna()
assset_h = targets_hourly[target].dropna()

strategy = ConstantStopLossStrategy
strategy = VolStopLossStrategy
kwargs = {'stop_loss': 0.02, 'take_profit': 0}
kwargs = {}
s1 = TestStrategy(asset=assset_d.resample('W-FRI').last().pct_change(), signals=all_signals[target])
s2 = strategy(asset=assset_h, signals=all_signals[target], **kwargs)
s2 = strategy(asset=assset_h, signals=all_signals[target], **kwargs)

fig, ax = plt.subplots(figsize=(15, 10))
s1.get_pnl(False).plot(ax=ax)
s2.get_pnl(False).plot(ax=ax)

pl = s2.get_pnl(False)
from functools import partial

widgets.interactive_output()


w = widgets.IntSlider()
w.unobserve()