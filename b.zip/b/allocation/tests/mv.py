# import cvxpy as cp
# import numpy as np
#
# # Problem data.
# m = 30
# n = 20
# np.random.seed(1)
# A = np.random.randn(m, n)
# b = np.random.randn(m)
#
# # Construct the problem.
# x = cp.Variable(n)
# objective = cp.Minimize(cp.sum_squares(A @ x - b))
# constraints = [0 <= x, x <= 1]
# prob = cp.Problem(objective, constraints)
#
# # The optimal objective value is returned by `prob.solve()`.
# result = prob.solve()
# # The optimal value for x is stored in `x.value`.
# print(x.value)
# # The optimal Lagrange multiplier for a constraint is stored in
# # `constraint.dual_value`.
# print(constraints[0].dual_value)
#
# n = r.shape[1]
# r.mean().to_numpy() @ w
#
# n = r.shape[1]
# r.mean().to_numpy() @ (np.ones(shape=n) / n)
#
# config Completer.use_jedi = False
#
# w = cp.Variable(r.shape[1])
#
# w = cp.Variable(n)
# gamma = cp.Parameter(nonneg=True)
# er = r.mean().to_numpy() @ w
# risk = cp.quad_form(w, r.cov().to_numpy())
#
# constraints = [
#     cp.sum(w) == 1,
#     w >= 0
# ]
#
# prob = cp.Problem(
#     objective=cp.Maximize(er - gamma*risk),
#     constraints=constraints
# )
#
# # Compute trade-off curve.
# SAMPLES = 100
# risk_data = np.zeros(SAMPLES)
# er_data = np.zeros(SAMPLES)
# gammas = np.logspace(-2, 3, num=SAMPLES)
# for i in range(SAMPLES):
#     gamma.value = gammas[i]
#     prob.solve()
#     risk_data[i] = cp.sqrt(risk).value
#     er_data[i] = er.value
#
# ef[20:]
#
# ef = pd.DataFrame({'er': er_data, 'vol': risk_data})
# ax = ef.plot.line(x="vol", y="er")
#
# ef = pd.DataFrame({'er': er_data, 'vol': risk_data})
# ax = ef.plot.line(x="vol", y="er")
#
# w = cp.Variable(n)
# ret = cp.Parameter(nonneg=True)
# er = r.mean().to_numpy() @ w
# risk = cp.quad_form(w, r.cov().to_numpy())
#
# constraints = [
#     cp.sum(w) == 1,
#     w >= 0,
#     er == ret,
# ]
#
# prob = cp.Problem(
#     objective=cp.Minimize(risk),
#     constraints=constraints
# )
#
# # Compute trade-off curve.
# SAMPLES = 1000
# risk_data = np.zeros(SAMPLES)
# er_data = np.zeros(SAMPLES)
# rets = np.linspace(r.mean().min(), r.mean().max(), SAMPLES)
# for i in range(SAMPLES):
#     ret.value = rets[i]
#     prob.solve()
#     risk_data[i] = cp.sqrt(risk).value
#     er_data[i] = er.value
#
# ef = pd.DataFrame({'er': er_data, 'vol': risk_data})
# ax = ef.plot.line(x="vol", y="er")
#
# sr = ef['er'] / ef['vol']
# ef.iloc[sr.idxmax()]
#
# y = cp.Variable(n)
# k = cp.Variable()
# rf = 0
# mu = r.mean().to_numpy()
# qf = cp.quad_form(y, r.cov().to_numpy())
# w = y / k
# erp = mu @ w
# risk = cp.quad_form(w, r.cov().to_numpy()) ** 0.5
#
# constraints = [
#     (mu - rf) @ y == 1,
#     # w = y/k and sum(w) == 1 => sum(y/k) == sum(w) => sum(y/k) == 1 => sum(y) == k since k is a constant
#     cp.sum(y) == k,
#     y >= 0,
#     k >= 0,
# ]
#
# prob = cp.Problem(
#     objective=cp.Minimize(qf),
#     constraints=constraints
# )
#
# prob.solve()
#
# w.value
#
# erp.value
#
# risk.value
