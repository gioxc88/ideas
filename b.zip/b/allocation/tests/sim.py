def set_mpl(backend=None, interactive=True, **kwargs):
    import matplotlib as mpl
    if backend:
        mpl.use(backend)
    mpl.interactive(interactive)

set_mpl('Qt5Agg')

import pickle
from pathlib import Path
from typing import Union

import seaborn as sns
from dask.distributed import Client
from pandas.tseries.offsets import DateOffset
from scipy.cluster.hierarchy import dendrogram
from scipy import stats
from sklearn.base import TransformerMixin, BaseEstimator
from matplotlib import pyplot as plt

from macro_tilib import get_all_ti
from macro_tilib.utils import resample, get_returns, drop_na_cols
from allocation.debug import *
from allocation import *
from allocation.estimators.ticc import TICC
from allocation.strategies import ConstantStopLossStrategy
from allocation.app import App


sns.set(style='whitegrid')


mapping_ohlc = {
    'UB1 R:05_0_R Comdty': 'EMU_Buxl_Fut',
    'US1 R:05_0_R Comdty': 'US_Bond_30y_Fut',
    'XM1 R:05_0_R Comdty': 'AUD_Bond_10y_Fut',
    'VG1 R:05_0_R Index': 'EMU_Equity_Fut',
    'MES1 R:05_0_R Index': 'EM_Equity_Fut',
    'XP1 R:05_0_R Index': 'AUD_Equity_Fut',
    'PT1 R:05_0_R Index': 'CAD_Equity_Fut',
    'ES1 R:05_0_R Index': 'US_Equity_Fut',
    'Z 1 R:05_0_R Index': 'UK_Equity_F100_Fut',
    'USDCAD Curncy': 'FX_CAD_TR',
    'USDJPY Curncy': 'FX_JPY_TR',
    'EURUSD Curncy': 'FX_EUR_TR',
    'AUDUSD Curncy': 'FX_AUD_TR',
    'USDNOK Curncy': 'FX_NOK_TR',
    'EURSEK Curncy': 'FX_EURSEK_TR',
    'USDMXN Curncy': 'FX_MXN_TR',
}

mapping_hourly = {
    'AUDUSD': 'FX_AUD_TR',
    'USDCAD': 'FX_CAD_TR',
    'EURUSD': 'FX_EUR_TR',
    'USDMXN': 'FX_MXN_TR',
    'USDNOK': 'FX_NOK_TR',
    'EURSEK': 'FX_EURSEK_TR',
    'USDJPY': 'FX_JPY_TR',
    # 'GBPUSD': 'GBPUSD',
    'UB': 'EMU_Buxl_Fut',
    'US': 'US_Bond_30y_Fut',
    'XP': 'AUD_Equity_Fut',
    'ES': 'US_Equity_Fut',
    'VG': 'EMU_Equity_Fut',
    'Z': 'UK_Equity_F100_Fut',
    'PT': 'CAD_Equity_Fut',
}

mapping_sparks = {
   'US_Bond': 'US_Bond_30y_Fut',
    'EURUSD': 'FX_EUR_TR',
    'AUDUSD': 'FX_AUD_TR',
    'Buxl': 'EMU_Buxl_Fut',
    'SP': 'US_Equity_Fut',
    'Eurostoxx': 'EMU_Equity_Fut',
    'EM': 'EM_Equity_Fut',
    'USDJPY': 'FX_JPY_TR',
}


data_path = Path('data')
all_ohlc = pd.read_csv(data_path / 'ohlcv.csv', index_col=0, header=[0, 1], parse_dates=True, dayfirst=True).rename(columns=mapping_ohlc)
targets_ohlc = all_ohlc.loc['2005-09-09':, mapping_ohlc.values()]
all_signals = pd.read_csv(data_path / 'signals.csv', index_col=0, parse_dates=True, dayfirst=True)
all_signals_sab = pd.read_csv(data_path / 'signalssab.csv', index_col=0, parse_dates=True, dayfirst=True).rename(columns=mapping_sparks)
targets_hourly = pd.read_csv(data_path / 'hourly.csv', index_col=0, parse_dates=True).rename(columns=mapping_hourly)


app = App(
    signals=all_signals_sab, ohlc_prices=targets_ohlc,
    hourly_prices=targets_hourly   # targets_ohlc.loc[:, (slice(None), 'close')].droplevel(axis=1, level=-1) # targets_hourly
         )

app.target_dd.value = 'FX_AUD_TR'
app.date_range_slider.value = ('  19-09-2014  ', '  26-03-2021  ')  # ('  02-08-2019  ', '  26-03-2021  ')
app.strategy_dd.value = 'VolStopLossStrategy'
app.v_stop_loss.value = 1
app.v_take_profit.value = 0



target = 'US_Equity_Fut'
s2 = ConstantStopLossStrategy(asset=targets_ohlc.loc[:, (target, 'close')],
                              signals=signals[target], )



from allocation.app import SLTP

app = SLTP(signals, targets_ohlc, targets_ohlc.loc[:, (slice(None), 'close')].droplevel(axis=1, level=-1))

def resample_dates(df, freq='W-FRI'):
    def fn(df):
        return pd.concat(
            [df.loc[:, (slice(None), 'high')].idxmax(), df.loc[:, (slice(None), 'low')].idxmin()])

    return df.groupby(pd.Grouper(freq=freq)).apply(fn)


dates = resample_dates(targets_prices)
targets_prices_weekly = resample(targets_prices)
high_close_ret = get_returns(targets_prices_weekly, 'high', 'close')
high_close_ret_stacked = high_close_ret.stack().reset_index(level=1)

target_dates = dates[target]

summary_dict = {}
for freq in ['MON', 'TUE', 'WED', 'THU', 'FRI']:
    print(f'{freq} ...')
    dates = resample_dates(targets_prices, freq=f'W-{freq}')
    for target in dates.columns.get_level_values(0).unique():
        target_dates = dates[target]
        high = target_dates['high'].dt.isocalendar().groupby('day')['day'].count()
        low = target_dates['low'].dt.isocalendar().groupby('day')['day'].count()

        summary_dict[(target, 'high', freq)] = high
        summary_dict[(target, 'low', freq)] = low
summary = pd.concat(summary_dict)


def indicators(df):
    return pd.concat([df.idxmax(),
                      df.idxmin()], keys=['max', 'min'])


tmp = all_prices.loc['2006':, target]
tmp_dates = tmp.groupby(pd.Grouper(freq=freq)).apply(indicators).reindex(tmp.index).bfill()
tmp = pd.concat([tmp, tmp.index.isocalendar(), tmp_dates], axis=1)
tmp = tmp.assign(
    high_mask=tmp.index == tmp[('max', 'high')],
    low_mask=tmp.index == tmp[('min', 'low')],
    close_high=tmp[('max', 'high')] == tmp[('max', 'close')],
    close_low=tmp[('min', 'low')] == tmp[('min', 'close')],
)

ti = get_all_ti(all_prices)
ti = drop_na_cols(ti)
fig, ax = plt.subplots()

g = sns.catplot(x='asset', y='value', data=high_close_ret_stacked, kind='box')
g.ax.xaxis.set_tick_params(rotation=90)
g.fig.tight_layout()

dd = tmp.groupby(pd.Grouper(freq=freq)).apply(lambda df: pd.Series([df['high'].idxmax(), df['low'].idxmin()],
                                                                   index=['high', 'low']))

from sklearn.linear_model import LogisticRegression


# # ---------------------------------------------------
# def mpPDF(var, q, pts):
#     # Marcenko-Pastur pdf
#     # q=T/N
#     eMin, eMax = var * (1 - (1. / q) ** .5) ** 2, var * (1 + (1. / q) ** .5) ** 2
#     eVal = np.linspace(eMin, eMax, pts)
#     pdf = q / (2 * np.pi * var * eVal) * ((eMax - eVal) * (eVal - eMin)) ** .5
#     pdf = pd.Series(pdf, index=eVal)
#     return pdf
#
#
# # SNIPPET 2.2 TESTING THE MARCENKO–PASTUR THEOREM
# from sklearn.neighbors import KernelDensity
#
#
# # ---------------------------------------------------
# def getPCA(matrix):
#     # Get eVal,eVec from a Hermitian matrix
#     eVal, eVec = np.linalg.eigh(matrix)
#     indices = eVal.argsort()[::-1]  # arguments for sorting eVal desc
#     eVal, eVec = eVal[indices], eVec[:, indices]
#     eVal = np.diagflat(eVal)
#     return eVal, eVec
#
#
# # ---------------------------------------------------
# def fitKDE(obs, bWidth=.25, kernel='gaussian', x=None):
#     # Fit kernel to a series of obs, and derive the prob of obs
#     # x is the array of values on which the fit KDE will be evaluated
#     if len(obs.shape) == 1:
#         obs = obs.reshape(-1, 1)
#     kde = KernelDensity(kernel=kernel, bandwidth=bWidth).fit(obs)
#     if x is None:
#         x = np.unique(obs).reshape(-1, 1)
#     if len(x.shape) == 1:
#         x = x.reshape(-1, 1)
#     logProb = kde.score_samples(x)  # log(density)
#     pdf = pd.Series(np.exp(logProb), index=x.flatten())
#     return pdf
#
#
# # ---------------------------------------------------
# x = np.random.normal(size=(10000, 1000))
# eVal0, eVec0 = getPCA(np.corrcoef(x, rowvar=0))
# pdf0 = mpPDF(1., q=x.shape[0] / float(x.shape[1]), pts=1000)
# pdf1 = fitKDE(np.diag(eVal0), bWidth=.01)  # empirical pdf


from allocation.strategies import AssetStrategy


class Strategy(AssetStrategy):
    def __init__(self, signals, **kwargs):
        super().__init__(**kwargs)
        self._signlas = signals

    def get_signals(self):
        return self._signlas


s = Strategy(asset=targets_prices.loc[:, (target, 'close')].r(level=True).r, signals=signals[target])
s.get_returns()


from sklearn.linear_model import LinearRegression

n_obs = 1000
n_features = 10

betas = np.random.normal(size=(n_features, 1), scale=50)
alpha = np.random.normal(loc=10, scale=10)
e = np.random.normal(size=(n_obs, 1), scale=0.1)
X = np.random.normal(size=(n_obs, n_features))
y = alpha + X @ betas + e
df = pd.DataFrame(np.concatenate([X, y], axis=1))
df.corr()
reg = LinearRegression()
reg.fit(X, y)
betas
reg.coef_
p1 = reg.predict(X)
eh1 = y - p1

reg2 = LinearRegression()
reg2.fit(X, eh1)

p2 = reg2.predict(X)
eh2 = eh1 - p2

from sklearn.ensemble import AdaBoostRegressor

import ipywidgets as widgets

widgets.interactive_output()


app.date_range_slider.value = ('  02-08-2019  ', '  26-03-2021  ')
app.strategy_dd.value = 'VolStopLossStrategy'
app.v_stop_loss.value = 0.05
import plotly.figure_factory as ff
ff.create_annotated_heatmap()
import plotly.express as px
px.imshow()



target = 'US_Bond_30y_Fut'
target_ss = np.log(targets_ohlc[(target, 'close')])
diff = 10
change_map = {}
for i in range(diff):

    change_ss = target_ss[i:].resample(pd.tseries.offsets.BDay(diff)).last().diff(diff)
    change_map.setdefault(diff, [])
    change_map[diff].append(change_ss)

data = pd.concat(change_map[diff], keys=range(diff)).reset_index(level=0).droplevel(1, axis=1)

g = sns.displot(data=data, x=target, hue='level_0', kind='kde', palette='viridis')
data.groupby('level_0').quantile(.5)


from allocation.strategies import TestStrategy
from allocation.portfolio import Portfolio

target = 'US_Equity_Fut'
assets = all_ohlc.loc[:, (slice(None), 'close')].droplevel(1, axis=1)
asset = assets[target]
signals = all_signals[target]

s = TestStrategy(asset=asset, signals=signals)
p = Portfolio.from_assets_and_signals(assets, all_signals.dropna())