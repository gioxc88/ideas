# %%


import pandas
import numpy
import datetime
import bhutils
import bhutilscommon as bhc

bhutils.bhInit('swap_histories')

import pandas as pd
import numpy as np
from datetime import date
from datetime import timedelta
from pandas.tseries.offsets import BDay

import time

start_datetime = date(2006, 1, 1)
end_datetime = date(2021, 3, 31)

FUT_CONFIG = {'TY': ('US', 2000, 'FixedIncome', {'H': ('-11-25 00:00:00', '-02-24 23:59:01'),
                                                 'M': ('-02-25 00:00:00', '-05-24 23:59:01'),
                                                 'U': ('-05-25 00:00:00', '-08-24 23:59:01'),
                                                 'Z': ('-08-25 00:00:00', '-11-24 23:59:01')}),

              'FV': ('US', 2000, 'FixedIncome', {'H': ('-11-25 00:00:00', '-02-24 23:59:01'),
                                                 'M': ('-02-25 00:00:00', '-05-24 23:59:01'),
                                                 'U': ('-05-25 00:00:00', '-08-24 23:59:01'),
                                                 'Z': ('-08-25 00:00:00', '-11-24 23:59:01')}),

              'TU': ('US', 2000, 'FixedIncome', {'H': ('-11-25 00:00:00', '-02-24 23:59:01'),
                                                 'M': ('-02-25 00:00:00', '-05-24 23:59:01'),
                                                 'U': ('-05-25 00:00:00', '-08-24 23:59:01'),
                                                 'Z': ('-08-25 00:00:00', '-11-24 23:59:01')}),

              'US': ('US', 2000, 'FixedIncome', {'H': ('-11-25 00:00:00', '-02-24 23:59:01'),
                                                 'M': ('-02-25 00:00:00', '-05-24 23:59:01'),
                                                 'U': ('-05-25 00:00:00', '-08-24 23:59:01'),
                                                 'Z': ('-08-25 00:00:00', '-11-24 23:59:01')}),

              'WN': ('US', 2010, 'FixedIncome', {'H': ('-11-25 00:00:00', '-02-24 23:59:01'),
                                                 'M': ('-02-25 00:00:00', '-05-24 23:59:01'),
                                                 'U': ('-05-25 00:00:00', '-08-24 23:59:01'),
                                                 'Z': ('-08-25 00:00:00', '-11-24 23:59:01')}),

              'FLG': ('GB', 2005, 'FixedIncome', {'H': ('-11-25 00:00:00', '-02-24 23:59:01'),
                                                  'M': ('-02-25 00:00:00', '-05-24 23:59:01'),
                                                  'U': ('-05-25 00:00:00', '-08-24 23:59:01'),
                                                  'Z': ('-08-25 00:00:00', '-11-24 23:59:01')}),

              'DU': ('US', 2000, 'FixedIncome', {'H': ('-12-01 00:00:00', '-03-01 23:59:01'),
                                                 'M': ('-03-02 00:00:00', '-05-31 23:59:01'),
                                                 'U': ('-06-01 00:00:00', '-08-31 23:59:01'),
                                                 'Z': ('-09-01 00:00:00', '-11-30 23:59:01')}),

              'OE': ('US', 2000, 'FixedIncome', {'H': ('-12-01 00:00:00', '-03-01 23:59:01'),
                                                 'M': ('-03-02 00:00:00', '-05-31 23:59:01'),
                                                 'U': ('-06-01 00:00:00', '-08-31 23:59:01'),
                                                 'Z': ('-09-01 00:00:00', '-11-30 23:59:01')}),

              # Late Roll:
              # 'OE': ('US', 2000, 'FixedIncome', {'H': ('-12-03 00:00:00', '-03-02 23:59:01'),
              #                                    'M': ('-03-03 00:00:00', '-06-02 23:59:01'),
              #                                    'U': ('-06-03 00:00:00', '-09-02 23:59:01'),
              #                                    'Z': ('-09-03 00:00:00', '-12-02 23:59:01')}),

              # 'RX':('US', 2000, 'FixedIncome',{'H':('-12-01 00:00:00', '-03-01 23:59:01'),
              #                                  'M':('-03-02 00:00:00', '-05-31 23:59:01'),
              #                                  'U':('-06-01 00:00:00', '-08-31 23:59:01'),
              #                                  'Z':('-09-01 00:00:00', '-11-30 23:59:01')}),

              # Early Roll:
              'RX': ('US', 2000, 'FixedIncome', {'H': ('-11-25 00:00:00', '-02-24 23:59:01'),
                                                 'M': ('-02-25 00:00:00', '-05-24 23:59:01'),
                                                 'U': ('-05-25 00:00:00', '-08-24 23:59:01'),
                                                 'Z': ('-08-25 00:00:00', '-11-24 23:59:01')}),
              # Late Roll:
              # 'RX':('US', 2000, 'FixedIncome',{'H':('-12-03 00:00:00', '-03-02 23:59:01'),
              #                                  'M':('-03-03 00:00:00', '-06-02 23:59:01'),
              #                                  'U':('-06-03 00:00:00', '-09-02 23:59:01'),
              #                                  'Z':('-09-03 00:00:00', '-12-02 23:59:01')}),

              # 'UB':('US', 2010, 'FixedIncome',{'H':('-12-01 00:00:00', '-03-01 23:59:01'),
              #                                  'M':('-03-02 00:00:00', '-05-31 23:59:01'),
              #                                  'U':('-06-01 00:00:00', '-08-31 23:59:01'),
              #                                  'Z':('-09-01 00:00:00', '-11-30 23:59:01')}),
              # Late Roll:
              'UB': ('US', 2010, 'FixedIncome', {'H': ('-12-09 00:00:00', '-03-08 23:59:01'),
                                                 'M': ('-03-09 00:00:00', '-06-08 23:59:01'),
                                                 'U': ('-06-09 00:00:00', '-09-08 23:59:01'),
                                                 'Z': ('-09-09 00:00:00', '-12-08 23:59:01')}),

              'OA': ('AU', 2012, 'FixedIncome', {'H': ('-12-16 00:00:00', '-03-15 23:59:01'),
                                                 'M': ('-03-09 00:00:00', '-06-15 23:59:01'),
                                                 'U': ('-06-09 00:00:00', '-09-15 23:59:01'),
                                                 'Z': ('-09-09 00:00:00', '-12-15 23:59:01')}),
              'XP': ('AU', 2010, 'Index', {'H': ('-12-18 00:00:00', '-03-17 23:59:01'),
                                           'M': ('-03-18 00:00:00', '-06-17 23:59:01'),
                                           'U': ('-06-18 00:00:00', '-09-17 23:59:01'),
                                           'Z': ('-09-18 00:00:00', '-12-17 23:59:01')}),
              'MES': ('ASIA', 2010, 'Index', {'H': ('-12-22 00:00:00', '-03-21 23:59:01'),
                                              'M': ('-03-22 00:00:00', '-06-21 23:59:01'),
                                              'U': ('-06-22 00:00:00', '-09-21 23:59:01'),
                                              'Z': ('-09-22 00:00:00', '-12-21 23:59:01')}),

              'CN': ('CA', 2005, 'FixedIncome', {'H': ('-11-25 00:00:00', '-02-24 23:59:01'),
                                                 'M': ('-02-25 00:00:00', '-05-24 23:59:01'),
                                                 'U': ('-05-25 00:00:00', '-08-24 23:59:01'),
                                                 'Z': ('-08-25 00:00:00', '-11-24 23:59:01')}),

              'JB': ('JP', 2005, 'FixedIncome', {'H': ('-12-10 00:00:00', '-03-09 23:59:01'),
                                                 'M': ('-03-10 00:00:00', '-06-09 23:59:01'),
                                                 'U': ('-06-10 00:00:00', '-09-09 23:59:01'),
                                                 'Z': ('-09-10 00:00:00', '-12-09 23:59:01')}),

              'PT': ('CA', 2005, 'Index', {'H': ('-12-16 00:00:00', '-03-15 23:59:01'),
                                           'M': ('-03-16 00:00:00', '-06-15 23:59:01'),
                                           'U': ('-06-16 00:00:00', '-09-15 23:59:01'),
                                           'Z': ('-09-16 00:00:00', '-12-15 23:59:01')}),

              'GX': ('DE', 2005, 'Index', {'H': ('-12-17 00:00:00', '-03-16 23:59:01'),
                                           'M': ('-03-17 00:00:00', '-06-16 23:59:01'),
                                           'U': ('-06-17 00:00:00', '-09-16 23:59:01'),
                                           'Z': ('-09-17 00:00:00', '-12-16 23:59:01')}),

              'VG': ('EURO', 2005, 'Index', {'H': ('-12-15 00:00:00', '-03-14 23:59:01'),
                                             'M': ('-03-15 00:00:00', '-06-14 23:59:01'),
                                             'U': ('-06-15 00:00:00', '-09-14 23:59:01'),
                                             'Z': ('-09-15 00:00:00', '-12-14 23:59:01')}),

              'CF': ('FR', 2000, 'Index', {'F': ('-12-17 00:00:00', '-01-15 23:59:01'),
                                           'G': ('-01-16 00:00:00', '-02-18 23:59:01'),
                                           'H': ('-02-19 00:00:00', '-03-17 23:59:01'),
                                           'J': ('-03-18 00:00:00', '-04-15 23:59:01'),
                                           'K': ('-04-16 00:00:00', '-05-12 23:59:01'),
                                           'M': ('-05-13 00:00:00', '-06-16 23:59:01'),
                                           'N': ('-06-17 00:00:00', '-07-14 23:59:01'),
                                           'Q': ('-07-15 00:00:00', '-08-19 23:59:01'),
                                           'U': ('-08-20 00:00:00', '-09-17 23:59:01'),
                                           'V': ('-09-18 00:00:00', '-10-17 23:59:01'),
                                           'X': ('-10-18 00:00:00', '-11-18 23:59:01'),
                                           'Z': ('-11-19 00:00:00', '-12-16 23:59:01')}),

              'Z ': ('GB', 2005, 'Index', {'H': ('-12-14 00:00:00', '-03-13 23:59:01'),
                                           'M': ('-03-14 00:00:00', '-06-13 23:59:01'),
                                           'U': ('-06-14 00:00:00', '-09-13 23:59:01'),
                                           'Z': ('-09-14 00:00:00', '-12-13 23:59:01')}),

              'NK': ('JP', 2005, 'Index', {'H': ('-12-10 00:00:00', '-03-10 23:59:01'),
                                           'M': ('-03-11 00:00:00', '-06-10 23:59:01'),
                                           'U': ('-06-11 00:00:00', '-09-08 23:59:01'),
                                           'Z': ('-09-09 00:00:00', '-12-09 23:59:01')}),

              'ES': ('US', 2000, 'Index', {'H': ('-12-13 00:00:00', '-03-13 23:59:01'),
                                           'M': ('-03-14 00:00:00', '-06-14 23:59:01'),
                                           'U': ('-06-15 00:00:00', '-09-13 23:59:01'),
                                           'Z': ('-09-14 00:00:00', '-12-12 23:59:01')})
              }

CODE = ['H', 'M', 'U', 'Z']  # [March, June, Sep, Dec]
FREQ = 'Minutes'  #


def import_intraday_histo(fut_name, start_year=2000, freq='1H', tz='UTC'):
    if fut_name == 'G':
        fut_name = 'FLG'
    df = {}
    raw_prices_full_table = {}
    returns_full_table = {}
    t_costs_full_table = {}

    name = fut_name
    region = FUT_CONFIG[fut_name][0]
    asset_class = FUT_CONFIG[fut_name][2]
    next_start_date = None
    for year in range(np.max([FUT_CONFIG[fut_name][1], start_year]), 2022):  # 2000
        calendar = {'H': (pd.Timestamp(str(year - 1) + FUT_CONFIG[fut_name][3]['H'][0], tz='UTC'),
                          pd.Timestamp(str(year) + FUT_CONFIG[fut_name][3]['H'][1], tz='UTC')),
                    'M': (pd.Timestamp(str(year) + FUT_CONFIG[fut_name][3]['M'][0], tz='UTC'),
                          pd.Timestamp(str(year) + FUT_CONFIG[fut_name][3]['M'][1], tz='UTC')),
                    'U': (pd.Timestamp(str(year) + FUT_CONFIG[fut_name][3]['U'][0], tz='UTC'),
                          pd.Timestamp(str(year) + FUT_CONFIG[fut_name][3]['U'][1], tz='UTC')),
                    'Z': (pd.Timestamp(str(year) + FUT_CONFIG[fut_name][3]['Z'][0], tz='UTC'),
                          pd.Timestamp(str(year) + FUT_CONFIG[fut_name][3]['Z'][1], tz='UTC')),
                    }
        for c in CODE:
            start_datetime = calendar[c][0] if next_start_date is None else next_start_date
            end_datetime = calendar[c][1]

            instrument = name + c + str(year)[-1:]
            print('instrument:', instrument)
            print('start date:', start_datetime)
            print('end date:', end_datetime)

            print(asset_class, region, instrument, start_datetime, end_datetime)
            dates, prices, dates_t_costs, prices_t_costs = import_prices(asset_class, region, instrument,
                                                                         start_datetime, end_datetime)
            if dates is None:
                break

            while (next_start_date is not None) and (pd.isnull(dates) is False) and (dates[0][0] != start_datetime):
                print('  ** * * * * * old next_start_date:', next_start_date, start_datetime + timedelta(minutes=-5))
                next_start_date = start_datetime + timedelta(minutes=-5)
                start_datetime = next_start_date
                dates, prices, dates_t_costs, prices_t_costs = import_prices(asset_class, region, instrument,
                                                                             start_datetime, end_datetime)

            try:
                df[name + c + str(year)[-2:]] = pd.Series(index=dates.flatten(), data=prices.flatten())
                next_start_date = df[name + c + str(year)[-2:]].last_valid_index()
                # print(next_start_date)
                df[name + c + str(year)[-2:]] = df[name + c + str(year)[-2:]].tz_localize('UTC').tz_convert(
                    tz).tz_localize(None)

                t_costs = pd.Series(index=dates_t_costs.flatten(), data=prices_t_costs.flatten()).tz_localize(
                    'UTC').tz_convert(tz).tz_localize(None)

                raw_prices_full_table[name + c + str(year)[-2:]] = df[name + c + str(year)[-2:]].resample(
                    freq).ffill().dropna()
                raw_prices_full_table[name + c + str(year)[-2:]] = raw_prices_full_table[
                    name + c + str(year)[-2:]].drop(
                    [k for k in raw_prices_full_table[name + c + str(year)[-2:]].index if k.weekday() in [5, 6]])
                returns_full_table[name + c + str(year)[-2:]] = (
                        raw_prices_full_table[name + c + str(year)[-2:]] - raw_prices_full_table[
                    name + c + str(year)[-2:]].shift(1).ffill())  # .loc[calendar[c][0]:]  # .iloc[1:]

                t_costs_full_table[name + c + str(year)[-2:]] = t_costs.resample(freq).ffill()
                t_costs_full_table[name + c + str(year)[-2:]] = t_costs_full_table[name + c + str(year)[-2:]].drop(
                    [k for k in t_costs_full_table[name + c + str(year)[-2:]].index if k.weekday() in [5, 6]])

            except:
                print(' ** ** ** *not possible')

    prices_fut = pd.concat(raw_prices_full_table, axis=0).droplevel(0, axis=0).sort_index()
    returns_fut = pd.concat(returns_full_table, axis=0).droplevel(0, axis=0).sort_index()
    t_costs_fut = pd.concat(t_costs_full_table, axis=0).droplevel(0, axis=0).sort_index()

    prices_fut = prices_fut[~prices_fut.index.duplicated(keep='first')]
    returns_fut = returns_fut[~returns_fut.index.duplicated(keep='first')]
    t_costs_fut = t_costs_fut[~t_costs_fut.index.duplicated(keep='first')]

    if (fut_name in ['RX', 'OE']) and (start_year <= 2009) and (freq == '1H'):
        prices_fut.loc['2009-02-09 08:00:00'] = 121.995
        returns_fut.loc['2009-02-09 08:00:00'] = 0.
        returns_fut.loc['2009-02-09 09:00:00'] = 0.

    if (fut_name == 'TU') and (start_year <= 2004) and (freq == '1H'):
        returns_fut.loc['2001-01-19 13:00:00'] = 0
        returns_fut.loc['2001-01-22 03:00:00'] = 0
        returns_fut.loc['2001-02-01 10:00:00'] = 0
        returns_fut.loc['2001-02-01 11:00:00'] = 0
        returns_fut.loc['2001-02-02 06:00:00'] = 0
        returns_fut.loc['2001-02-02 07:00:00'] = 0
        returns_fut.loc['2001-08-01 08:00:00'] = 0
        returns_fut.loc['2001-08-01 09:00:00'] = 0
        returns_fut.loc['2001-09-19 18:00:00'] = 0
        returns_fut.loc['2001-09-20 01:00:00'] = 0
        returns_fut.loc['2001-10-01 16:00:00'] = 0
        returns_fut.loc['2001-10-02 05:00:00'] = 0
        returns_fut.loc['2003-03-21 02:00:00'] = 0
        returns_fut.loc['2003-03-21 03:00:00'] = 0
        returns_fut.loc['2004-01-02 01:00:00'] = 0
        returns_fut.loc['2004-01-02 04:00:00'] = 0
        returns_fut.loc['2000-10-19 14:00:00'] = 0
        returns_fut.loc['2000-10-19 19:00:00'] = 0
        returns_fut.loc['2001-02-01 19:00:00'] = 0
        returns_fut.loc['2001-02-01 21:00:00'] = 0
        returns_fut.loc['2001-09-24 20:00:00'] = 0
        returns_fut.loc['2001-09-25 08:00:00'] = 0
        returns_fut.loc['2001-10-03 02:00:00'] = 0
        returns_fut.loc['2001-10-05 17:00:00'] = 0
        returns_fut.loc['2001-10-05 18:00:00'] = 0
        returns_fut.loc['2001-11-02 21:00:00'] = 0
        returns_fut.loc['2001-11-05 02:00:00'] = 0
        returns_fut.loc['2000-09-20 06:00:00'] = 0
        returns_fut.loc['2000-09-20 09:00:00'] = 0
        returns_fut.loc['2001-01-24 15:00:00'] = 0
        returns_fut.loc['2001-01-24 21:00:00'] = 0
        returns_fut.loc['2001-10-02 19:00:00'] = 0
        returns_fut.loc['2002-10-30 06:00:00'] = 0
        returns_fut.loc['2002-10-30 08:00:00'] = 0

    if fut_name in ['ES']:
        new_values_tab = pd.read_pickle(
            r'M:\BHAI\Shared\MacroBot\data\ES_new_values.pkl')
        tmp = pd.Series(index=returns_fut.index, data=returns_fut.index)
        for dt in new_values_tab.index.intersection(returns_fut.index):
            prices_fut.loc[dt] = new_values_tab.loc[dt, 'new value']
            returns_fut.loc[dt] = 0
            returns_fut.loc[tmp.shift(-1).loc[dt]] = 0  # prices_fut.loc[tmp.shift(-1).loc[dt]] - prices_fut.loc[dt]

    return prices_fut, returns_fut, t_costs_fut


def import_volumes(fut_name, start_year=2000, freq='1H'):
    df = {}
    volumes_full_table = {}
    name = fut_name
    region = FUT_CONFIG[fut_name][0]
    asset_class = FUT_CONFIG[fut_name][2]

    for year in range(np.max([FUT_CONFIG[fut_name][1], start_year]), 2022):  # 2000
        calendar = {'H': (pd.Timestamp(str(year - 1) + FUT_CONFIG[fut_name][3]['H'][0], tz='UTC'),
                          pd.Timestamp(str(year) + FUT_CONFIG[fut_name][3]['H'][1], tz='UTC')),
                    'M': (pd.Timestamp(str(year) + FUT_CONFIG[fut_name][3]['M'][0], tz='UTC'),
                          pd.Timestamp(str(year) + FUT_CONFIG[fut_name][3]['M'][1], tz='UTC')),
                    'U': (pd.Timestamp(str(year) + FUT_CONFIG[fut_name][3]['U'][0], tz='UTC'),
                          pd.Timestamp(str(year) + FUT_CONFIG[fut_name][3]['U'][1], tz='UTC')),
                    'Z': (pd.Timestamp(str(year) + FUT_CONFIG[fut_name][3]['Z'][0], tz='UTC'),
                          pd.Timestamp(str(year) + FUT_CONFIG[fut_name][3]['Z'][1], tz='UTC')),
                    }
        for c in CODE:
            start_datetime = calendar[c][0]
            end_datetime = calendar[c][1]

            instrument = name + c + str(year)[-1:]
            print('instrument:', instrument)
            print('start date:', start_datetime)
            print('end date:', end_datetime)

            print(asset_class, region, instrument, start_datetime, end_datetime)
            dates, volumes = import_volumes(asset_class, region, instrument, start_datetime, end_datetime)

            try:
                df[name + c + str(year)[-2:]] = pd.Series(index=dates.flatten(), data=volumes.flatten())

                volumes_full_table[name + c + str(year)[-2:]] = df[name + c + str(year)[-2:]].resample(freq,
                                                                                                       label='right').sum().dropna()
                volumes_full_table[name + c + str(year)[-2:]] = volumes_full_table[name + c + str(year)[-2:]].drop(
                    [k for k in raw_prices_full_table[name + c + str(year)[-2:]].index if k.weekday() in [5, 6]])
            except:
                print(' ** ** ** *not possible')

    volumes_fut = pd.concat(volumes_full_table, axis=0).droplevel(0, axis=0).sort_index()
    volumes_fut = volumes_fut[~volumes_fut.index.duplicated(keep='first')]

    return volumes_fut


def import_prices(asset_class, region, instrument, start_datetime, end_datetime):
    ask_handle = bhutils.bhTsTicksRead(_tsid='_ask', _assetclass=asset_class, _source='trth_',
                                       _region=region,
                                       _instrument=instrument, _field='ASK', _frequency=FREQ,
                                       _startdatetime=start_datetime, _enddatetime=end_datetime,
                                       _servername='SQLP-B', _databasename='Ticks')

    bid_handle = bhutils.bhTsTicksRead(_tsid='_bid', _assetclass=asset_class, _source='trth_',
                                       _region=region,
                                       _instrument=instrument, _field='BID', _frequency=FREQ,
                                       _startdatetime=start_datetime, _enddatetime=end_datetime,
                                       _servername='SQLP-B', _databasename='Ticks')

    handle = bhutils.bhTsCalcExpression('mid', "(a+b)/2", ["a", "b"], [ask_handle, bid_handle])
    handle_t_costs = bhutils.bhTsCalcExpression('bid_ask', "(a-b)/2", ["a", "b"], [ask_handle, bid_handle])

    # Get dates and prices.
    try:
        dates = bhutils.bhTsGet(_tsid=handle, _outputtype="d", _start=start_datetime, _end=end_datetime)
        prices = bhutils.bhTsGet(_tsid=handle, _outputtype="v", _start=start_datetime, _end=end_datetime)

        dates_t_costs = bhutils.bhTsGet(_tsid=handle_t_costs, _outputtype="d", _start=start_datetime, _end=end_datetime)
        prices_t_costs = bhutils.bhTsGet(_tsid=handle_t_costs, _outputtype="v", _start=start_datetime,
                                         _end=end_datetime)
    except:
        dates = None
        prices = None
        dates_t_costs = None
        prices_t_costs = None

    return dates, prices, dates_t_costs, prices_t_costs


# %%

prices = []
for i in ['UB', 'US', 'XP', 'ES', 'VG', 'Z ', 'PT']:
    prices_fut, returns_fut, t_costs_fut = import_intraday_histo(i, start_year=start_datetime.year)
    prices.append(prices_fut.rename(i.strip()))

futures_df = pd.concat(prices, axis=1)

# %%

import bhutilscommon
import bhutils
from datetime import date

bhutils.bhInit('macrobot')
frequency = 'Hours'

results = []
for region, ticker in [('AU', 'AUDUSD'), ('CA', 'USDCAD'), ('EURO', 'EURUSD'), ('MX', 'USDMXN'),
                       ('NO', 'USDNOK'), ('SE', 'USDSEK'), ('ASIA', 'USDJPY'), ('GB', 'GBPUSD')]:
    ask_handle = bhutils.bhTsTicksRead(_tsid='_ask', _assetclass='Currency', _source='trth_',
                                       _region=region,
                                       _instrument=ticker, _field='ASK', _frequency='Minutes',
                                       _startdatetime=start_datetime, _enddatetime=end_datetime,
                                       _servername='SQLP-B', _databasename='Ticks')
    bid_handle = bhutils.bhTsTicksRead(_tsid='_ask', _assetclass='Currency', _source='trth_',
                                       _region=region,
                                       _instrument=ticker, _field='BID', _frequency='Minutes',
                                       _startdatetime=start_datetime, _enddatetime=end_datetime,
                                       _servername='SQLP-B', _databasename='Ticks')
    ask = bhutilscommon.ts_to_series(ask_handle)
    bid = bhutilscommon.ts_to_series(bid_handle)
    mid = (ask + bid) / 2
    results.append(mid.rename(ticker))

fx_df = pd.concat(results, axis=1)
fx_df = fx_df.assign(EURSEK=fx_df['USDSEK'] * fx_df['EURUSD'])

futures_resampled = futures_df.dropna(how='all').bfill().resample('H').last()
fx_resampled = fx_df.dropna(how='all').bfill().resample('H').last()

merged = pd.concat([futures_resampled, fx_resampled], axis=1).dropna(how='all')
merged.to_csv('data/hourly.csv')

mapping = {
    'AUDUSD': 'FX_AUD_TR',
    'USDCAD': 'FX_CAD_TR',
    'EURUSD': 'FX_EUR_TR',
    'USDMXN': 'FX_MXN_TR',
    'USDNOK': 'FX_NOK_TR',
    'EURSEK': 'FX_EURSEK_TR',
    'USDJPY': 'FX_JPY_TR',
    # 'GBPUSD': 'GBPUSD',
    'UB': 'EMU_Buxl_Fut',
    'US': 'US_Bond_30y_Fut',
    'XP': 'AUD_Equity_Fut',
    'ES': 'US_Equity_Fut',
    'VG': 'EMU_Equity_Fut',
    'Z': 'UK_Equity_F100_Fut',
    'PT': 'CAD_Equity_Fut',
}

merged.to_csv('data/hourly.csv')