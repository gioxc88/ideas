import numpy as np
import pandas as pd
from copy import deepcopy
import multiprocessing as mp


def check_array(x):
    return np.array(x).reshape(-1, 1)


def ptf_tail(w, X, prob):
    w = check_array(w)
    y = (X @ w)  # portfolio returns
    Xy = np.concatenate([X, y], axis=1)
    VaR = np.quantile(y, prob)  # subset tail only
    return Xy[(y <= VaR).squeeze()]


def marginal_CVaR_contrib(w, X, prob):
    # marginal risk contribution = partial derivative
    w = check_array(w)

    # subset tail only
    Xy_tail = ptf_tail(w, X, prob)

    # extracting VaR scenario
    Xy_CVaR_approx = Xy_tail.mean(axis=0)
    CVaR_approx = Xy_CVaR_approx[-1]

    mrc_approx = Xy_CVaR_approx[:-1].reshape(-1, 1)
    return mrc_approx, CVaR_approx


def total_CVaR_contrib(w, X, prob):
    mrc_approx, CVaR_approx = marginal_CVaR_contrib(w, X, prob)
    return mrc_approx * w, CVaR_approx


def relative_CVaR_contrib(w, X, prob):
    w = check_array(w)
    trc_approx, CVaR_approx = total_CVaR_contrib(w, X, prob)
    return trc_approx / CVaR_approx


def loss_function(w_asset, w_risk, fun, *args):
    return np.sum((fun(w_asset, *args) - w_risk) ** 2)


def long_only_constraint(x):
    return x


def total_weight_constraint(x):
    return np.sum(x) - 1.0


def calculate_portfolio_var(w, V):
    # function that calculates portfolio risk
    w = np.array(w)
    return w.dot((V.dot(w)))


def relative_covar_contrib(w, V):
    # function that calculates asset contribution to total risk
    w = np.array(w)
    sigma = np.sqrt(calculate_portfolio_var(w, V))
    # Marginal Risk Contribution
    MRC = V.dot(w)
    # Risk Contribution

    RC = np.multiply(MRC, w.T) / (sigma ** 2)
    return RC


def asset_risk_parity(assets, window=60, rebalance_skip=60):
    from .risk_parity_vol_allocator import RiskParityVolAllocator
    #setting up allocator
    config = DotDict(dict(portfolio_capital=None, var_limit=None, money_var_limit=None, signal_scale=False,
                          money_based=False, var_window=window, window=window, var_percent=5, vol_constr=0, cvar=False,
                          mean='hist', covariance='hist', weights_share=False, conc_limit={}))
    allocator = RiskParityVolAllocator(assets=assets, config=config)
    #Calculating rebalance dates
    date_range = pd.date_range(start=assets.index[window+6], end=assets.index[-1], freq='B')
    rebal_dates = list(date_range)[::rebalance_skip]
    #setting up tables for results
    results = pd.DataFrame(columns=assets.columns, index=rebal_dates)
    errors = pd.Series(index=rebal_dates, name='Allocation_Errors')
    #Setting up input to multiprocessor
    signal= pd.Series(index=assets.columns, data=np.ones(len(assets.columns)))
    args = []
    for i in rebal_dates:
        args.append((i, deepcopy(allocator), signal.copy()))
    with mp.Pool(mp.cpu_count()) as process_pool:
        results_list = process_pool.starmap(rp_allocator_helper, args)
    for date, weight, error in results_list:
        results.loc[date] = weight
        errors.loc[date] = error
    results = results.reindex(assets.index)
    results = results.ffill(0)
    asset_returns = (np.exp(assets)).pct_change()
    asset_returns = asset_returns.reindex(results.index)
    return (results*asset_returns).sum(axis=1), results


def rp_allocator_helper(date, allocator, signal):
    weight, error = allocator.get_allocation(signal, date, forecast=None, rf=0.02)
    return date, weight, error



