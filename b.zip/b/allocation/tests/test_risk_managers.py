import numpy as np
import pandas as pd

from allocation import *
from allocation.strategies import TestStrategy
from allocation.portfolio import Portfolio
from allocation.risk_managers import VaRLimitScaler
from allocation.estimators import *
from allocation.estimators.misc import EWM, GerberCovariance, SharpeRatio
from allocation.backtest import BTInspector

assets = pd.read_csv('data/prices.csv', index_col=0, parse_dates=True)
signals = pd.read_csv('data/signals_strats.csv', index_col=0, parse_dates=True)

from dask.distributed import Client
client = Client()
print(client)

ptf = Portfolio.from_assets_and_signals(assets, signals)

ewm = EWM('std', alpha=0.05)

als = dict(
    oon=OneOverN(),
    ir_std=InverseRisk(),
    ir_ewm=InverseRisk(measure=ewm),
    ir_cvar=InverseRisk(measure=SampleCVaR()),
    ir_var=InverseRisk(measure=SampleVaR()),
    # risk_budget=RiskBudgeting(),
    max_sharpe=MaxRiskAdjusted(SharpeRatio(cov=GerberCovariance())),
    # hrp=HRP(),
    # herc=HERC(),
)


bts = {}
for key, allocator in als.items():
    b = BackTest(
        ptf,
        allocator,
        n_jobs=-1,
        # risk_managers = [VaRLimitScaler()]  #, ActiveSignalsRiskScaler()]
    )
    b.run(partial=True).adjust()
    bts[key] = b


for key, bt in bts.items():
    bt.risk_managers = [VaRLimitScaler()]
    bt.adjust()


from allocation.utils import slice_and_switch


for key, bt in bts.items():
    break



comonotonic = True
backtest = bt
weights = backtest.risk_weights_
signals = backtest.portfolio.get_signals()
asset_returns = backtest.portfolio.get_asset_returns()
weights_ = []
scales_ = []

class A:
    window = 250
    expanding = False
    q = 0.05
    limit = 0.015

self = A()

for loc in weights.index:
    b = False
    current_assets = slice_and_switch(asset_returns, signals, loc, switch=True).dropna(how='all', axis=1)
    current_weights = weights.loc[loc, current_assets.columns].dropna()
    if current_weights.any():  # .astype(bool).sum() >= 2:  # checking if it makes sense to do the calculation in the first place
        b = True

        for key, (mult, group) in concentration_limits.items():
            group = pd.Series(group)
            mask = current_assets.columns.str.replace('_shift1', '').isin(group.index)

            asset_subset = current_assets.loc[:, mask]
            weight_subset = current_weights[mask]
            group_subset = group[weight_subset.index]
            ptf_returns = (asset_subset * weight_subset)
            if comonotonic:
                ptf_returns = ptf_returns[-self.window:] if self.expanding else ptf_returns
                var = (ptf_returns.quantile(self.q) * group_subset).sum()
                scale = - self.limit / var if var < (mult * self.limit) else 1.0
                weights.loc[loc, group_subset.index] = weight_subset * scale
            else:
                pass

            break
    if b:
        print('ok')
        break

    scale = self._scale(ptf_returns)


    def _scale(self, ptf_returns):
        '''
        this function returns the scaling factors for the weights based on portfolio returns
        Parameters
        ----------
        ptf_returns

        Returns
        -------

        '''

        ptf_returns = ptf_returns[-self.window:] if self.expanding else ptf_returns
        var = ptf_returns.quantile(self.q)

        #         P(X < q) = 5%
        #         q = limit/ c
        #         c = limit/q

        return - self.limit / var
