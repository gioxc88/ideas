def set_mpl(backend=None, interactive=True, **kwargs):
    import matplotlib as mpl
    if backend:
        mpl.use(backend)
    mpl.interactive(interactive)


set_mpl('Qt5Agg')

from typing import Union

import seaborn as sns
from dask.distributed import Client
from pandas.tseries.offsets import DateOffset
from scipy.cluster.hierarchy import dendrogram
from matplotlib import pyplot as plt

from allocation.debug import *
from allocation import *
from allocation.estimators.ticc import TICC

sns.set(style='whitegrid')
p = pd.read_csv('data/ohlcv.csv', index_col=0, header=[0, 1], parse_dates=True)


def resample(data, freq='W-FRI'):
    high = data.loc[:, (slice(None), 'high')].resample(freq).max()
    low = data.loc[:, (slice(None), 'low')].resample(freq).min()
    open = data.loc[:, (slice(None), 'open')].resample(freq).last()
    close = data.loc[:, (slice(None), 'close')].resample(freq).last()

    try:
        volume = data.loc[:, (slice(None), 'volume')].resample(freq).sum()
    except:
        return pd.concat([open, high, low, close], axis=1).sort_index(axis=1, level=0)
    else:
        return pd.concat([open, high, low, close, volume], axis=1).sort_index(axis=1, level=0)


def get_returns(data, num='close', den='close'):
    return (data.loc[:, (slice(None), num)] / data.loc[:, (slice(None), den)].shift().to_numpy() - 1) \
        .dropna() \
        .droplevel(level=1, axis=1)


pw = resample(p)
hcr = get_returns(pw, 'high', 'close')

mapping = {
    'UB1 R:05_0_R Comdty': 'EMU_Buxl_Fut',
    'US1 R:05_0_R Comdty': 'US_Bond_30y_Fut',
    'XM1 R:05_0_R Comdty': 'AUD_Bond_10y_Fut',

    'VG1 R:05_0_R Index': 'EMU_Equity_Fut',
    'MES1 R:05_0_R Index': 'EM_Equity_Fut',
    'XP1 R:05_0_R Index': 'AUD_Equity_Fut',
    'PT1 R:05_0_R Index': 'CAD_Equity_Fut',
    'ES1 R:05_0_R Index': 'US_Equity_Fut',
    'Z 1 R:05_0_R Index': 'UK_Equity_F100_Fut',

    'USDCAD Curncy': 'FX_CAD_TR',
    'USDJPY Curncy': 'FX_JPY_TR',
    'EURUSD Curncy': 'FX_EUR_TR',
    'AUDUSD Curncy': 'FX_AUD_TR',
    'USDNOK Curncy': 'FX_NOK_TR',
    'EURSEK Curncy': 'FX_EURSEK_TR',
    'USDMXN Curncy': 'FX_MXN_TR',
}

client = Client()

print(client.dashboard_link)


def aud_bond_contract_value(price):
    i = (100 - price) / 200
    v = 1 / (1 + i)
    c = 3
    return c * (1 - v ** 20) / i + 100 * v ** 20

assets['AUD_Bond_10y_Fut'] = assets['AUD_Bond_10y_Fut'].apply(aud_bond_contract_value)
rng = np.random.default_rng(7)

assets = pd.read_csv('data/assets.csv', index_col=0, parse_dates=True, dayfirst=True)
assets['AUD_Bond_10y_Fut'] = assets['AUD_Bond_10y_Fut'].apply(aud_bond_contract_value)
r = assets.pct_change().dropna()
rr = r[:250]
w = pd.Series(rng.uniform(size=r.shape[1]), index=r.columns)

ptf = Portfolio.from_assets(assets=r)

allocator = InverseRisk()
bt = BackTest(
    portfolio=ptf,
    allocator=allocator,
    expanding=False,
    rebalance=DateOffset(months=1),
    first_training_size=250,
    n_jobs=-1
)
bt.run(n_jobs=-1)
weights = bt.weights_

(1 + (r.loc[bt.weights_.index[0]:] * bt.weights_).sum(axis=1)).cumprod()

r.r.ptf(weights, compound=True)


def seriation(Z, N, cur_index):
    """Returns the order implied by a hierarchical tree (dendrogram).

       :param Z: A hierarchical tree (dendrogram).
       :param N: The number of points given to the clustering process.
       :param cur_index: The position in the tree for the recursive traversal.

       :return: The order implied by the hierarchical tree Z.
    """
    if cur_index < N:
        return [cur_index]
    else:
        left = int(Z[cur_index - N, 0])
        right = int(Z[cur_index - N, 1])
        return (seriation(Z, N, left) + seriation(Z, N, right))


def compute_serial_matrix(dist_mat, method="ward"):
    """Returns a sorted distance matrix.

       :param dist_mat: A distance matrix.
       :param method: A string in ["ward", "single", "average", "complete"].

        output:
            - seriated_dist is the input dist_mat,
              but with re-ordered rows and columns
              according to the seriation, i.e. the
              order implied by the hierarchical tree
            - res_order is the order implied by
              the hierarhical tree
            - res_linkage is the hierarhical tree (dendrogram)

        compute_serial_matrix transforms a distance matrix into
        a sorted distance matrix according to the order implied
        by the hierarchical tree (dendrogram)
    """
    N = len(dist_mat)
    flat_dist_mat = squareform(dist_mat)
    res_linkage = linkage(flat_dist_mat, method=method)
    res_order = seriation(res_linkage, N, N + N - 2)
    seriated_dist = np.zeros((N, N))
    a, b = np.triu_indices(N, k=1)
    seriated_dist[a, b] = dist_mat[[res_order[i] for i in a], [res_order[j] for j in b]]
    seriated_dist[b, a] = seriated_dist[a, b]

    return seriated_dist, res_order, res_linkage


def compute_HRP_weights(covariances, res_order):
    weights = pd.Series(1, index=res_order)
    clustered_alphas = [res_order]

    while len(clustered_alphas) > 0:
        clustered_alphas = [cluster[start:end] for cluster in clustered_alphas
                            for start, end in ((0, len(cluster) // 2),
                                               (len(cluster) // 2, len(cluster)))
                            if len(cluster) > 1]
        for subcluster in range(0, len(clustered_alphas), 2):
            left_cluster = clustered_alphas[subcluster]
            right_cluster = clustered_alphas[subcluster + 1]

            left_subcovar = covariances[left_cluster].loc[left_cluster]
            inv_diag = 1 / np.diag(left_subcovar.values)
            parity_w = inv_diag * (1 / np.sum(inv_diag))
            left_cluster_var = np.dot(parity_w, np.dot(left_subcovar, parity_w))

            right_subcovar = covariances[right_cluster].loc[right_cluster]
            inv_diag = 1 / np.diag(right_subcovar.values)
            parity_w = inv_diag * (1 / np.sum(inv_diag))
            right_cluster_var = np.dot(parity_w, np.dot(right_subcovar, parity_w))

            alloc_factor = 1 - left_cluster_var / (left_cluster_var + right_cluster_var)

            weights[left_cluster] *= alloc_factor
            weights[right_cluster] *= 1 - alloc_factor

    return weights


def compute_MV_weights(covariances):
    inv_covar = np.linalg.inv(covariances)
    u = np.ones(len(covariances))

    return np.dot(inv_covar, u) / np.dot(u, np.dot(inv_covar, u))


def compute_RP_weights(covariances):
    weights = (1 / np.diag(covariances))

    return weights / sum(weights)


def compute_unif_weights(covariances):
    return [1 / len(covariances) for i in range(len(covariances))]


rr = r[:250].set_axis(range(r.shape[1]), axis=1)

estimate_correl = rr.corr()
estimate_covar = rr.cov()

distances = np.sqrt((1 - estimate_correl) / 2)
ordered_dist_mat, res_order, res_linkage = compute_serial_matrix(distances.values, method='single')

HRP_weights = compute_HRP_weights(estimate_covar, res_order)

from allocation.strategies import AssetStrategy


class SameAsLast(AssetStrategy):
    def __init__(self, asset, resample=None):
        super().__init__(asset=asset)
        self.resample = resample

    def get_signals(self):
        returns = np.expm1(np.log1p(self.asset).resample(rule=self.resample).sum()) if self.resample else self.asset
        signals = np.sign(returns.shift())
        return signals.reindex(self.asset.index.join(signals.index, how='outer')).bfill()


from macro_tilib import get_all_ti
from sklearn.base import BaseEstimator
