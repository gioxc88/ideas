import pandas as pd

from .utils import slice_and_switch


class SignalsRuleScaler:
    def run(self, backtest=None, weights=None, **kwargs):
        weights = weights if weights is not None else backtest.risk_weights_
        signals = kwargs.get('signals', backtest.portfolio.get_signals())
        scale = self.rule(signals)
        if isinstance(scale, pd.DataFrame):
            scale = scale.reindex(weights.index)
        self.weights_ = weights.multiply(scale, axis=0)
        if backtest:
            backtest.risk_weights_ = self.weights_
        return self

    def rule(self, signals):
        '''
        this function should return the scaling factors solely based on the signals dataframe
        Parameters
        ----------
        signals

        Returns
        -------

        '''
        pass


class ActiveSignalsRisk(SignalsRuleScaler):
    def __init(self, n_assets=None, threshold=False):
        self.n_assets = n_assets
        self.threshold = threshold

    def rule(self, signals):
        active_signals = (signals.fillna(0) != 0).sum(axis=1)
        n_assets = self.n_asset if self.n_assets else signals.shape[1]
        scale = active_signals / n_assets
        if self.threshold:
            scale[scale > 1] = 1
        return scale


class VaRLimitScaler:
    def __init__(self, q=0.05, limit=0.015, window=250, expanding=False):
        self.q = q
        self.limit = limit
        self.window = window
        self.expanding = expanding

    def run(self, backtest=None, weights=None, **kwargs):
        weights = weights if weights is not None else backtest.risk_weights_
        signals = kwargs.get('signals', backtest.portfolio.get_signals())
        asset_returns = backtest.portfolio.get_asset_returns()

        weights_ = []
        scales_ = []
        for loc in weights.index:
            current_assets = slice_and_switch(asset_returns, signals, loc, switch=True)
            current_weights = weights.loc[loc].dropna()
            ptf_returns = (current_weights * current_assets[current_weights.index]).sum(axis=1).dropna()
            scale = self._scale(ptf_returns)

            scales_.append(scale)
            weights_.append(current_weights * scale)

        weights_ = pd.concat(weights_, axis=1).T

        self.weights_ = weights_
        self.scales_ = scales_
        if backtest:
            backtest.risk_weights_ = self.weights_
        return self

    def _scale(self, ptf_returns):
        '''
        this function returns the scaling factors for the weights based on portfolio returns
        Parameters
        ----------
        ptf_returns

        Returns
        -------

        '''

        ptf_returns = ptf_returns[-self.window:] if self.expanding else ptf_returns
        var = ptf_returns.quantile(self.q)

        #         P(X < q) = 5%
        #         q = limit/ c
        #         c = limit/q

        return - self.limit / var


concentration_limits = {
    'equity': (0.9, {
        "US_Equity_Fut": 1.0,
        "EMU_Equity_Fut": 1.0,
        "CAD_Equity_Fut": 1.0,
        "UK_Equity_F100_Fut": 1.0,
        "AUD_Equity_Fut": 1.0,
        "EM_Equity_Fut": 1.0,
    }),
    'bond': (0.9, {
        "EMU_Buxl_Fut": 1.0,
        "US_Bond_30y_Fut": 1.0,
        "AUD_Bond_10y_Fut": 1.0,
    }),
    'fx': (0.675, {
        "FX_JPY_TR": 1.0,
        "FX_EUR_TR": 1.0,
        "FX_EURSEK_TR": 1.0,
        "FX_EURGBP_TR": 1.0,
        "FX_CAD_TR": 1.0,
        "FX_AUD_TR": 1.0,
        "FX_MXN_TR": 1.0,
        "FX_NOK_TR": 1.0,
    }),
    'commodity_fx': (0.72, {
        "FX_CAD_TR": 1.0,
        "FX_AUD_TR": 1.0,
        "FX_MXN_TR": 1.0,
        "FX_NOK_TR": 1.0,
    }),
    'risk_on': (0.9, {
        "US_Equity_Fut": 1.0,
        "EMU_Equity_Fut": 1.0,
        "CAD_Equity_Fut": 1.0,
        "UK_Equity_F100_Fut": 1.0,
        "AUD_Equity_Fut": 1.0,
        "EM_Equity_Fut": 1.0,
        "EMU_Buxl_Fut": -1.0,
        "US_Bond_30y_Fut": -1.0,
        "AUD_Bond_10y_Fut": -1.0,
        "FX_CAD_TR": -0.5,
        "FX_JPY_TR": 0.5,
        "FX_AUD_TR": 0.75,
        "FX_EUR_TR": -0.25,
        "FX_NOK_TR": -0.75,
        "FX_EURSEK_TR": -0.5,
        "FX_MXN_TR": -0.75,
        "FX_EURGBP_TR": 0
    })
}


class ConcentrationRiskScaler:
    def __init(self, limits, use_weights=True):
        self.limits = limits
        self.use_weights = use_weights

    def run(self, backtest=None, weights=None, **kwargs):
        weights = weights if weights is not None else backtest.risk_weights_
        signals = kwargs.get('signals', backtest.portfolio.get_signals())
        asset_returns = backtest.portfolio.get_asset_returns()
        weights_ = []
        scales_ = []
        for loc in weights.index:
            current_assets = slice_and_switch(asset_returns, signals, loc, switch=True)
            current_weights = weights.loc[loc].dropna()
            ptf_returns = (current_weights * current_assets[current_weights.index]).sum(axis=1).dropna()

            for key, (mult, group) in concentration_limits.items():
                group = pd.Series(group)
                break

            scale = self._scale(ptf_returns)


