import random
from itertools import chain

import numpy as np
import pandas as pd
import matplotlib.pyplot as mpl
from matplotlib import pyplot as plt
from scipy.linalg import block_diag
from scipy.cluster import hierarchy as sch
from scipy.cluster.hierarchy import linkage, optimal_leaf_ordering, fcluster, leaves_list
from scipy.spatial.distance import pdist, squareform
from sklearn import datasets
# from fastcluster import linkage


def seriation(Z, N, cur_index):
    """Returns the order implied by a hierarchical tree (dendrogram).

       :param Z: A hierarchical tree (dendrogram).
       :param N: The number of points given to the clustering process.
       :param cur_index: The position in the tree for the recursive traversal.

       :return: The order implied by the hierarchical tree Z.
    """
    if cur_index < N:
        return [cur_index]
    else:
        left = int(Z[cur_index - N, 0])
        right = int(Z[cur_index - N, 1])
        return (seriation(Z, N, left) + seriation(Z, N, right))


def compute_serial_matrix(dist_mat, method="ward"):
    """Returns a sorted distance matrix.

       :param dist_mat: A distance matrix.
       :param method: A string in ["ward", "single", "average", "complete"].

        output:
            - seriated_dist is the input dist_mat,
              but with re-ordered rows and columns
              according to the seriation, i.e. the
              order implied by the hierarchical tree
            - res_order is the order implied by
              the hierarhical tree
            - res_linkage is the hierarhical tree (dendrogram)

        compute_serial_matrix transforms a distance matrix into
        a sorted distance matrix according to the order implied
        by the hierarchical tree (dendrogram)
    """
    N = len(dist_mat)
    flat_dist_mat = squareform(dist_mat)
    res_linkage = linkage(flat_dist_mat, method=method)
    res_order = seriation(res_linkage, N, N + N - 2)
    seriated_dist = np.zeros((N, N))
    a, b = np.triu_indices(N, k=1)
    seriated_dist[a, b] = dist_mat[[res_order[i] for i in a], [res_order[j] for j in b]]
    seriated_dist[b, a] = seriated_dist[a, b]

    return seriated_dist, res_order, res_linkage


def compute_HRP_weights(covariances, res_order):
    weights = pd.Series(1, index=res_order)
    clustered_alphas = [res_order]

    while len(clustered_alphas) > 0:
        clustered_alphas = [cluster[start:end] for cluster in clustered_alphas
                            for start, end in ((0, len(cluster) // 2),
                                               (len(cluster) // 2, len(cluster)))
                            if len(cluster) > 1]
        for subcluster in range(0, len(clustered_alphas), 2):
            left_cluster = clustered_alphas[subcluster]
            right_cluster = clustered_alphas[subcluster + 1]

            left_subcovar = covariances[left_cluster].loc[left_cluster]
            inv_diag = 1 / np.diag(left_subcovar.values)
            parity_w = inv_diag * (1 / np.sum(inv_diag))
            left_cluster_var = np.dot(parity_w, np.dot(left_subcovar, parity_w))

            right_subcovar = covariances[right_cluster].loc[right_cluster]
            inv_diag = 1 / np.diag(right_subcovar.values)
            parity_w = inv_diag * (1 / np.sum(inv_diag))
            right_cluster_var = np.dot(parity_w, np.dot(right_subcovar, parity_w))

            alloc_factor = 1 - left_cluster_var / (left_cluster_var + right_cluster_var)

            weights[left_cluster] *= alloc_factor
            weights[right_cluster] *= 1 - alloc_factor

    return weights


def compute_MV_weights(covariances):
    inv_covar = np.linalg.inv(covariances)
    u = np.ones(len(covariances))

    return np.dot(inv_covar, u) / np.dot(u, np.dot(inv_covar, u))


def compute_RP_weights(covariances):
    weights = (1 / np.diag(covariances))

    return weights / sum(weights)


def compute_unif_weights(covariances):
    return [1 / len(covariances) for i in range(len(covariances))]


def compute_MV_weights(covariances):
    inv_covar = np.linalg.inv(covariances)
    u = np.ones(len(covariances))

    return np.dot(inv_covar, u) / np.dot(u, np.dot(inv_covar, u))


def compute_RP_weights(covariances):
    weights = (1 / np.diag(covariances))

    return weights / sum(weights)


def compute_unif_weights(covariances):
    return [1 / len(covariances) for i in range(len(covariances))]


def getIVP(cov, **kargs):
    # Compute the inverse-variance portfolio
    ivp = 1. / np.diag(cov)
    ivp /= ivp.sum()
    return ivp


def getClusterVar(cov, cItems):
    # Compute variance per cluster
    cov_ = cov.loc[cItems, cItems]  # matrix slice
    w_ = getIVP(cov_).reshape(-1, 1)
    cVar = np.dot(np.dot(w_.T, cov_), w_)[0, 0]
    return cVar


def getQuasiDiag(link):
    # Sort clustered items by distance
    link = link.astype(int)
    sortIx = pd.Series([link[-1, 0], link[-1, 1]])
    numItems = link[-1, 3]  # number of original items
    while sortIx.max() >= numItems:
        sortIx.index = range(0, sortIx.shape[0] * 2, 2)  # make space
        df0 = sortIx[sortIx >= numItems]  # find clusters
        # Electronic copy available at: https://ssrn.com/abstract=270867815
        i = df0.index;
        j = df0.values - numItems
        sortIx[i] = link[j, 0]  # item 1
        df0 = pd.Series(link[j, 1], index=i + 1)
        sortIx = sortIx.append(df0)  # item 2
        sortIx = sortIx.sort_index()  # re-sort
    sortIx.index = range(sortIx.shape[0])  # re-index
    return sortIx.tolist()


def getRecBipart(cov, sortIx):
    # Compute HRP alloc
    w = pd.Series(1, index=sortIx)
    cItems = [sortIx]  # initialize all items in one cluster
    while len(cItems) > 0:
        cItems = [i[j:k] for i in cItems for j, k in ((0, len(i) / 2), (len(i) / 2, len(i))) if
                  len(i) > 1]  # bi-section
        for i in range(0, len(cItems), 2):  # parse in pairs
            cItems0 = cItems[i]  # cluster 1
            cItems1 = cItems[i + 1]  # cluster 2
            cVar0 = getClusterVar(cov, cItems0)
            cVar1 = getClusterVar(cov, cItems1)
            alpha = 1 - cVar0 / (cVar0 + cVar1)
            w[cItems0] *= alpha  # weight 1
            w[cItems1] *= 1 - alpha  # weight 2
    return w


def correlDist(corr):
    # A distance matrix based on correlation, where 0<=d[i,j]<=1
    # This is a proper distance metric
    dist = ((1 - corr) / 2.) ** .5  # distance matrix
    return dist


def plotCorrMatrix(path, corr, labels=None):
    # Heatmap of the correlation matrix
    if labels is None: labels = []
    mpl.pcolor(corr)
    mpl.colorbar()
    mpl.yticks(np.arange(.5, corr.shape[0] + .5), labels)
    mpl.xticks(np.arange(.5, corr.shape[0] + .5), labels)
    mpl.savefig(path)
    mpl.clf();
    mpl.close()  # reset pylab
    return


def generateData(nObs, size0, size1, sigma1):
    # Time series of correlated variables
    # 1) generating some uncorrelated data
    np.random.seed(seed=12345)
    random.seed(12345)
    # Electronic copy available at: https://ssrn.com/abstract=270867816
    x = np.random.normal(0, 1, size=(nObs, size0))  # each row is a variable
    # 2) creating correlation between the variables
    cols = [random.randint(0, size0 - 1) for i in range(size1)]
    y = x[:, cols] + np.random.normal(0, sigma1, size=(nObs, len(cols)))
    x = np.append(x, y, axis=1)
    x = pd.DataFrame(x)
    return x, cols


def main():
    # 1) Generate correlated data
    nObs, size0, size1, sigma1 = 10000, 5, 5, .25
    x, cols = generateData(nObs, size0, size1, sigma1)

    # 2) compute and plot correl matrix
    cov, corr = x.cov(), x.corr()
    plotCorrMatrix('HRP3_corr0.png', corr, labels=corr.columns)
    # 3) cluster
    dist = correlDist(corr)
    link = sch.linkage(dist, 'single')
    sortIx = getQuasiDiag(link)
    sortIx = corr.index[sortIx].tolist()  # recover labels
    df0 = corr.loc[sortIx, sortIx]  # reorder
    plotCorrMatrix('HRP3_corr1.png', df0, labels=df0.columns)
    # 4) Capital allocation
    hrp = getRecBipart(cov, sortIx)

    return


def intersection(lst1, lst2):
    return list(set(lst1) & set(lst2))


def seriate(linkage_matrix, value=None, index=-1, n=None):
    """
    Returns the order implied by a hierarchical tree (dendrogram)
       :param linkage_matrix: A hierarchical tree (dendrogram) calculated using scipy.cluster.hierarchy.linkage
              The linkage_matrix is (n - 1) by 4 matrix. At the i-th iteration,
              clusters with indices Z[i, 0] and Z[i, 1] are combined to form cluster n + i.
              A cluster with an index less than n corresponds to one of the n original observations.
              The distance between clusters Z[i, 0] and Z[i, 1] is given by Z[i, 2].
              The fourth value Z[i, 3] represents the number of original observations in the newly formed cluster
       :return: The order implied by the hierarchical tree Z.
    """
    if not n:  # not necessary to specify n in the parameters, but this is to avoid repeating the calculation
        n = len(linkage_matrix) + 1
    if value is not None and value < n:
        return [value]
    else:
        left, right = linkage_matrix[index, :2].astype(np.int32)
        return [*seriate(linkage_matrix, value=left, index=left - n, n=n),
                *seriate(linkage_matrix, value=right, index=right - n, n=n)]


def compute_allocation(Z, covar, clusters):
    dim = len(covar)
    try:
        covar = covar.to_numpy()
    except:
        pass

    nb_clusters = len(clusters)
    assets_weights = np.array([1.] * len(covar))
    clusters_weights = np.array([1.] * nb_clusters)
    clusters_var = np.array([0.] * nb_clusters)

    for id_cluster, cluster in clusters.items():
        cluster_covar = covar[cluster, :][:, cluster]
        inv_diag = 1 / np.diag(cluster_covar)
        assets_weights[cluster] = inv_diag / np.sum(inv_diag)

    for id_cluster, cluster in clusters.items():
        weights = assets_weights[cluster]
        clusters_var[id_cluster - 1] = np.dot(weights, np.dot(covar[cluster, :][:, cluster], weights))

    for merge in range(nb_clusters - 1):
        print('id merge:', merge)
        left = int(Z[dim - 2 - merge, 0])
        right = int(Z[dim - 2 - merge, 1])
        left_cluster = seriation(Z, dim, left)
        right_cluster = seriation(Z, dim, right)

        print(len(left_cluster),
              len(right_cluster))

        ids_left_cluster = []
        ids_right_cluster = []
        for id_cluster, cluster in clusters.items():
            if sorted(intersection(left_cluster, cluster)) == sorted(cluster):
                ids_left_cluster.append(id_cluster)
            if sorted(intersection(right_cluster, cluster)) == sorted(cluster):
                ids_right_cluster.append(id_cluster)

        ids_left_cluster = np.array(ids_left_cluster) - 1
        ids_right_cluster = np.array(ids_right_cluster) - 1
        print(ids_left_cluster)
        print(ids_right_cluster)
        print()

        alpha = 0
        left_cluster_var = np.sum(clusters_var[ids_left_cluster])
        right_cluster_var = np.sum(clusters_var[ids_right_cluster])
        alpha = left_cluster_var / (left_cluster_var + right_cluster_var)

        clusters_weights[ids_left_cluster] = clusters_weights[
                                                 ids_left_cluster] * alpha
        clusters_weights[ids_right_cluster] = clusters_weights[
                                                  ids_right_cluster] * (1 - alpha)

    for id_cluster, cluster in clusters.items():
        assets_weights[cluster] = assets_weights[cluster] * clusters_weights[
            id_cluster - 1]

    return assets_weights


def get_cluster_indices(labels):
    clusters = np.unique(labels)
    return {cluster: np.flatnonzero([labels == cluster]) for cluster in clusters}


def compute_allocation2(Z, cov, clusters):
    try:
        cov = cov.to_numpy()
    except AttributeError:
        pass

    n = len(cov)
    n_clusters = len(clusters)
    assets_weights = np.ones(shape=n)
    clusters_weights = np.ones(shape=n_clusters)
    clusters_var = np.empty(shape=n_clusters)

    # calculate the asset weights in each cluster
    # according to 1 / risk and the variance of the cluster
    for i, cluster in enumerate(clusters.values()):
        cluster_cov = cov[np.ix_(cluster, cluster)]
        inv_diag = 1 / np.diag(cluster_cov)
        weights = inv_diag / np.sum(inv_diag)
        clusters_var[i] = weights @ cluster_cov @ weights
        assets_weights[cluster] = weights

    for merge in range(1, n_clusters):  # recursive divide in clusters following the dendrogram
        print('id merge:', merge)
        left, right = Z[-merge, :2].astype(np.int32)
        left_cluster = seriate(Z, value=left, index=left - n)
        right_cluster = seriate(Z, value=right, index=right - n)

        ids_left_cluster = []
        ids_right_cluster = []
        for id_cluster, cluster in clusters.items():
            if sorted(intersection(left_cluster, cluster)) == sorted(cluster):
                ids_left_cluster.append(id_cluster)
            if sorted(intersection(right_cluster, cluster)) == sorted(cluster):
                ids_right_cluster.append(id_cluster)

        ids_left_cluster = np.array(ids_left_cluster) - 1
        ids_right_cluster = np.array(ids_right_cluster) - 1
        print(ids_left_cluster)
        print(ids_right_cluster)
        print()

        alpha = 0
        left_cluster_var = np.sum(clusters_var[ids_left_cluster])
        right_cluster_var = np.sum(clusters_var[ids_right_cluster])
        alpha = left_cluster_var / (left_cluster_var + right_cluster_var)

        clusters_weights[ids_left_cluster] = clusters_weights[
                                                 ids_left_cluster] * alpha
        clusters_weights[ids_right_cluster] = clusters_weights[
                                                  ids_right_cluster] * (1 - alpha)

    for id_cluster, cluster in clusters.items():
        assets_weights[cluster] = assets_weights[cluster] * clusters_weights[
            id_cluster - 1]

    return assets_weights

from allocation.allocators import InverseRisk, RiskBudgeting
from allocation.estimators import SampleStandardDeviation

class HierarchicalEqualRiskContribution:
    def __init__(
            self,
            n_clusters=3,
            metric=None,
            method='single',
            within=None,
            across=None,
            clustering=None
    ):
        '''
        :param n_clusters: int or None.
            If None clustering must be specified as a callable. See below
        :param within: allocator.
            allocation strategy within clusters
        :param across: allocator
            allocation strategy across clusters
        :param clustering: callable
            If n_clusters is None then this parameter must be specified
            It takes as input the linkage matrix Z and the assets time series and returns the labels for each assets
        '''

        self.n_clusters = n_clusters
        self.within = within or InverseRisk()
        self.across = across or RiskBudgeting()
        self.clustering = clustering

    def allocate(self, assets, **kwargs):
        pass

    def compute_allocation3(Z, assets, clusters):

        n = len(cov)
        n_clusters = len(clusters)
        assets_weights = np.ones(shape=n)
        clusters_weights = np.ones(shape=n_clusters)
        clusters_var = np.empty(shape=n_clusters)

        # calculate the asset weights in each cluster
        # according to 1 / risk and the variance of the cluster
        for i, cluster in enumerate(clusters.values()):
            cluster_cov = cov[np.ix_(cluster, cluster)]
            inv_diag = 1 / np.diag(cluster_cov)
            weights = inv_diag / np.sum(inv_diag)
            clusters_var[i] = weights @ cluster_cov @ weights
            assets_weights[cluster] = weights

        for merge in range(1, n_clusters):  # recursive divide in clusters following the dendrogram
            print('id merge:', merge)
            left, right = Z[-merge, :2].astype(np.int32)
            left_cluster = seriate(Z, value=left, index=left - n)
            right_cluster = seriate(Z, value=right, index=right - n)

            ids_left_cluster = []
            ids_right_cluster = []
            for id_cluster, cluster in clusters.items():
                if sorted(intersection(left_cluster, cluster)) == sorted(cluster):
                    ids_left_cluster.append(id_cluster)
                if sorted(intersection(right_cluster, cluster)) == sorted(cluster):
                    ids_right_cluster.append(id_cluster)

            ids_left_cluster = np.array(ids_left_cluster) - 1
            ids_right_cluster = np.array(ids_right_cluster) - 1
            print(ids_left_cluster)
            print(ids_right_cluster)
            print()

            alpha = 0
            left_cluster_var = np.sum(clusters_var[ids_left_cluster])
            right_cluster_var = np.sum(clusters_var[ids_right_cluster])
            alpha = left_cluster_var / (left_cluster_var + right_cluster_var)

            clusters_weights[ids_left_cluster] = clusters_weights[
                                                     ids_left_cluster] * alpha
            clusters_weights[ids_right_cluster] = clusters_weights[
                                                      ids_right_cluster] * (1 - alpha)

        for id_cluster, cluster in clusters.items():
            assets_weights[cluster] = assets_weights[cluster] * clusters_weights[
                id_cluster - 1]

        return assets_weights


