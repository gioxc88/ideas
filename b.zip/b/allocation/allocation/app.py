from functools import partial

import ipywidgets as widgets
import numpy as np
import pandas as pd
import seaborn as sns
from IPython.display import display
from matplotlib import pyplot as plt

from . import strategies


class App:
    def __init__(self, signals, ohlc_prices, hourly_prices):

        self.signals = signals
        self.ohlc_prices = ohlc_prices
        self.hourly_prices = hourly_prices
        self.i = 0

        self.boxes = {}

        self._init_components()
        self._build()

    @staticmethod
    def _build_date_range_slider(x, datetime_format='%d-%m-%Y'):
        lbound = x.first_valid_index().strftime(f'  {datetime_format}  ')

        ubound = x.index[-1].strftime(f'  {datetime_format}  ')
        value = (lbound, ubound)
        options = x.loc[x.first_valid_index():].index.strftime(f'  {datetime_format}  ')
        return widgets.SelectionRangeSlider(options=options, value=value, layout=widgets.Layout(width='50%'),
                                            continuous_update=False)

    def _init_components(self):
        self.target_dd = widgets.Dropdown(options=self.signals)
        self.strategy_dd = widgets.Dropdown(options=['ConstantStopLossStrategy', 'VolStopLossStrategy'],
                                            description='strategy')

        self.target_check = widgets.Checkbox(description='target')
        self.progress_bar = widgets.IntProgress(
            value=0,
            min=0,
            max=10,
            description='',
            bar_style='success',  # , 'info', 'warning', 'danger' or ''
            orientation='horizontal'
        )
        self.date_range_slider = self._build_date_range_slider(self.signals)

        self.common_param_box = widgets.VBox([
            widgets.HBox([self.target_dd, self.strategy_dd, self.target_check]),
            self.date_range_slider,
            self.progress_bar
        ])

        # constant
        self.c_stop_loss = widgets.FloatSlider(
            value=None,
            min=0,
            max=0.1,
            step=0.001,
            readout_format='.2p',
            description='stop_loss:',
            continuous_update=False
        )
        self.c_take_profit = widgets.FloatSlider(
            value=None,
            min=0,
            max=0.1,
            step=0.001,
            readout_format='.2p',
            description='take_profit:',
            continuous_update=False
        )

        # vol
        self.v_stop_loss = widgets.FloatSlider(
            value=1.5,
            min=0,
            max=10,
            step=0.1,
            readout_format='.2f',
            description='stop_loss:',
            continuous_update=False
        )
        self.v_take_profit = widgets.FloatSlider(
            value=2,
            min=0,
            max=10,
            step=0.1,
            readout_format='.2f',
            description='take_profit:',
            continuous_update=False
        )
        self.v_vol = widgets.SelectionSlider(options=['std', 'ewm'], description='vol:')
        self.v_periods = widgets.IntText(value=50, description='periods:')
        self.v_resample = widgets.Text(value='W-FRI', description='resample')
        self.v_expanding = widgets.Checkbox(description='expanding', value=False, continuous_update=False)
        self.v_alpha = widgets.FloatSlider(
            value=0.1,
            min=0,
            max=0.5,
            step=0.01,
            readout_format='.2f',
            description='alpha:',
            continuous_update=False
        )
        self.c_param_box = widgets.HBox([self.c_stop_loss, self.c_take_profit])
        self.v_param_box = widgets.VBox(
            [
                widgets.HBox([self.v_stop_loss, self.v_take_profit]),
                widgets.HBox([self.v_vol, self.v_periods]),
                widgets.HBox([self.v_resample, self.v_expanding, self.v_alpha])
            ]
        )

    def run_strategy(self, target, strategy, dates, target_check, **kwargs):

        d1 = dates[0].strip()
        d2 = dates[1].strip()
        signals = self.signals[target].loc[d1:d2]

        self.progress_bar.value = 0
        s1 = strategies.TestStrategy(
            # asset=self.ohlc_prices.loc[:, (target, 'close')].dropna().resample('W-FRI').last().pct_change(),
            asset=self.hourly_prices[target].dropna().resample('W-FRI').last().pct_change(),
            signals=signals
        )

        s2 = getattr(strategies, strategy)(asset=self.hourly_prices[target], signals=signals, **kwargs)

        ret2 = s2.get_returns().dropna()
        ret1 = s1.get_returns().dropna().loc[ret2.index[0]:]
        pnl1 = ret1.r.prices(compound=False, start_value=1)
        pnl2 = ret2.r.prices(compound=False, start_value=1)

        self.pnl1 = pnl1
        self.pnl2 = pnl2
        self.s1 = s1
        self.s2 = s2

        asset_prices = s1.get_asset().loc[pnl1.index[0]:pnl1.index[-1]].r.prices(compound=False)

        summary_df = pd.concat([ret1, ret2], axis=1).agg([
            'mean',
            'std',
            lambda x: x.mean() / x.std(),
            lambda x: x.quantile(0.05),
            lambda x: x[x <= x.quantile(0.05)].mean()]
        ).set_axis(['mean', 'std', 'ir', 'var5', 'es5']).set_axis(['plain', 'sl-tp'], axis=1)

        # if pd.to_datetime(d1) < pnl2.index[0]:
        #     self.date_range_slider.value =

        if strategy == 'ConstantStopLossStrategy':
            vol = asset_prices.resample('W-FRI').last().diff().rolling(50).std().loc[pnl2.index[0]:pnl2.index[-1]]
        else:
            vol = s2._vol.loc[pnl2.index[0]:pnl2.index[-1]]

        fig = make_fig(pnl1, pnl2, vol, summary_df, asset_prices if target_check else None)
        display(fig)

        # fig, axs = plt.subplots(figsize=(20, 7), ncols=2)
        # pnl1.plot(ax=axs[0])
        # pnl2.plot(ax=axs[0])
        # # s1.get_asset().loc[pnl1.index[0]:pnl1.index[-1]].r.prices().plot(ax=axs[0])
        # axs[0].legend(['plain', 'sl-tp', 'target'])
        # if strategy == 'ConstantStopLossStrategy':
        #     pnl1.pct_change().plot(ax=axs[1])
        # else:
        #     s2._vol.loc[pnl2.index[0]:pnl2.index[-1]].plot(ax=axs[1])
        # display(summary_df)

        self.i += 1
        print(f'called {self.i}')
        self.progress_bar.value = 10

    def build_strategy(self, strategy):
        if strategy == 'ConstantStopLossStrategy':
            param_box = self.c_param_box
            kwargs = {
                'stop_loss': self.c_stop_loss,
                'take_profit': self.c_take_profit
            }
        else:
            param_box = self.v_param_box
            kwargs = {
                'stop_loss': self.v_stop_loss,
                'take_profit': self.v_take_profit,
                'vol': self.v_vol,
                'periods': self.v_periods,
                'resample': self.v_resample,
                'expanding': self.v_expanding,
                'alpha': self.v_alpha,
            }

        for w in [self.target_dd, self.date_range_slider, self.target_check]:
            key = 'value' if 'value' in w._trait_notifiers else 'comm'
            if len(w._trait_notifiers[key]['change']) == 2:
                w.unobserve(w._trait_notifiers[key]['change'][-1], names='value')

        # if not (box := self.boxes.get(strategy)):
        run_fn = partial(self.run_strategy, strategy=strategy)
        kwargs.update({
            'target': self.target_dd,
            'dates': self.date_range_slider,
            'target_check': self.target_check
        })

        out = widgets.interactive_output(run_fn, kwargs)
        box = widgets.VBox([param_box, out])
        # self.boxes[strategy] = box

        display(box)

    def _build(self):
        self.app_out = widgets.interactive_output(self.build_strategy, {'strategy': self.strategy_dd})
        self.app = widgets.VBox(
            [
                self.common_param_box,
                self.app_out
            ]
        )

    @property
    def freq(self):
        # try:
        #     return self._freq
        # except AttributeError:
        #     pass
        labels = ['MON', 'TUE', 'WED', 'THU', 'FRI']

        def fn(target, freq, dates, pct):
            d1 = dates[0].strip()
            d2 = dates[1].strip()
            df = self.ohlc_prices.loc[d1:d2, target].dropna()

            freq = f'W-{freq}'
            target_dates = df.groupby(pd.Grouper(freq=freq)).apply(
                lambda df: pd.Series([df.loc[:, 'high'].idxmax(), df.loc[:, 'low'].idxmin()], index=['high', 'low']))
            high = target_dates['high'].dt.isocalendar().groupby('day')['day'].count()
            low = target_dates['low'].dt.isocalendar().groupby('day')['day'].count()

            high_ser = target_dates['high'].dt.isocalendar()['day']
            low_ser = target_dates['low'].dt.isocalendar()['day']

            mat = np.zeros(shape=(5, 5))
            for i, j in zip(high_ser, low_ser):
                mat[i - 1, j - 1] += 1

            df_freq = pd.DataFrame(
                mat,
                index=pd.Index(labels, name='HIGH'),
                columns=pd.Index(labels, name='LOW')
            )

            if pct:
                fmt = '.1%'
                df_freq = df_freq / len(target_dates)
            else:
                fmt = '.3g'

            fig, axs = plt.subplots(nrows=2, ncols=2, figsize=(20, 10))
            high.plot.bar(ax=axs[0, 0], title='high')
            axs[0, 0].set_xticklabels(labels)
            axs[0, 0].xaxis.set_tick_params(rotation=0)
            low.plot.bar(ax=axs[0, 1], title='low')
            axs[0, 1].set_xticklabels(labels)
            axs[0, 1].xaxis.set_tick_params(rotation=0)
            sns.heatmap(data=df_freq, annot=True, cmap='YlOrRd', fmt=fmt, ax=axs[1, 0])
            df['close'].plot(ax=axs[1, 1])

        date_range_slider = self._build_date_range_slider(self.signals)
        resample_dd = widgets.Dropdown(options=labels, value='FRI')
        target2_dd = widgets.Dropdown(options=self.ohlc_prices.columns.get_level_values(0).unique())
        pct = widgets.Checkbox(description='pct')
        out = widgets.interactive_output(fn, {'target': target2_dd, 'freq': resample_dd, 'dates': date_range_slider,
                                              'pct': pct})
        return widgets.VBox([widgets.HBox([target2_dd, resample_dd, date_range_slider, pct]), out])
        return self._freq

    def _ipython_display_(self):
        return display(self.app)


from plotly import graph_objects as go
from plotly.subplots import make_subplots


def bold(string):
    # using + instead of f'{}' as it works with pandas too
    return '<b>' + string + '</b>'


def make_table(df):
    return go.Table(
        header=dict(
            values=[bold('measure'), *df.columns],
            # fill_color='paleturquoise',
            align='left'
        ),
        cells=dict(
            values=[bold(df.index), *df.applymap("{:.4%}".format).to_numpy().T],
            align='left'
        )
    )


def make_trace(series, name=None):
    scatter = go.Scatter(x=series.index, y=series)
    if name:
        scatter.name = name
    return scatter


def make_fig(pnl1, pnl2, vol, summary, target=None):
    # fig = make_subplots(
    #     rows=3,
    #     cols=3,
    #     specs=[
    #         [{"type": "xy", 'colspan': 2, 'rowspan': 2}, None, {"type": "table", 'rowspan': 3}],
    #         [None, None, None],
    #         [{"type": "xy", 'colspan': 2, 'rowspan': 1}, None, None]
    #     ]
    # )

    fig = make_subplots(
        rows=3,
        cols=2,
        specs=[
            [{"type": "xy",  'rowspan': 2}, {"type": "table", 'rowspan': 3}],
            [None, None],
            [{"type": "xy", 'rowspan': 1}, None]
        ]
    )

    table = make_table(summary)

    trace1 = make_trace(pnl1, 'plain')
    trace2 = make_trace(pnl2, 'sl-tp')
    trace3 = make_trace(vol, 'vol')

    if target is not None:
        trace0 = make_trace(target, 'target')
        fig.add_trace(trace0, row=1, col=1)
    #
    # fig.add_trace(trace1, row=1, col=1)
    # fig.add_trace(trace2, row=1, col=1)
    # fig.add_trace(trace3, row=3, col=1)
    # fig.add_trace(table, row=1, col=3)

    fig.add_trace(trace1, row=1, col=1)
    fig.add_trace(trace2, row=1, col=1)
    fig.add_trace(trace3, row=3, col=1)
    fig.add_trace(table, row=1, col=2)
    fig.update_layout(
        height=700,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0
        ),
    )

    return fig
