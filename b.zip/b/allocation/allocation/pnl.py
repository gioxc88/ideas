import math
from enum import Enum, IntEnum
from functools import wraps
from copy import deepcopy

import numpy as np
import pandas as pd
from pandas.tseries.frequencies import to_offset


class AssetType:
    def __init__(self, level=False, log=True, **kwargs):
        self.level = level
        self.log = log
        vars(self).update(**kwargs)


class PNL:
    def __init__(
            self,
            signals,
            assets=None,
            asset_type=None,
            compound=False,
            t_cost=0
    ):
        self.signals = signals
        self.compound = compound
        self.t_cost = t_cost

        self.asset = signals.get_asset() if assets is None else assets
        assert self.asset is not None, "asset should either be passed explicitly or " \
                                       "extracted from the signal using signal.get_asset"

        asset_type = asset_type or AssetType()
        self.asset.r(level=asset_type.level, log=asset_type.log)
        self.asset_type = asset_type

    def get_t_cost(self, signals):

        t_cost = signals.diff().abs()
        t_cost.iloc[0] = np.abs(signals.iloc[0])

        return t_cost * self.t_cost

    def get_returns(self):

        signals = self.signals.get_signals().dropna()
        t_cost = self.get_t_cost(signals)
        asset_returns = self.asset.r.simple().reindex(signals.index)

        return (signals.multiply(asset_returns, axis=0) - t_cost).astype(np.float32)

    def get_pnl(self, compound=False, p0=1, weight=1):
        # since we get the returns by using self.r.simple in the get_returns function
        # those returns will always be simple. This means that for calculating the
        # pnl I don't have to use self.r but Returns(compounding=Compounding.SIMPLE)
        compound = compound if compound is not None else self.compound
        ret = self.get_returns() * weight
        first_index_loc = self.asset.index.get_loc(ret.index[0])
        first_index = self.asset.index[first_index_loc - 1] if first_index_loc else None
        return ret.r.prices(compound=compound, p0=p0, first_index=first_index)




