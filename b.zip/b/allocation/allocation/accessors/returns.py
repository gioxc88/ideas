from enum import IntEnum
from functools import wraps
from typing import Union

import numpy as np
import pandas as pd
from pandas.tseries.frequencies import to_offset


def clone(fn):
    @wraps(fn)
    def wrapper(self, *args, **kwargs):
        result = fn(self, *args, **kwargs)
        self._set_params(result)
        return result
    return wrapper


class Compounding(IntEnum):
    SIMPLE = 0
    COMPOUNDED = 1
    CONTINUOUS = 2


@pd.api.extensions.register_series_accessor('r')
@pd.api.extensions.register_dataframe_accessor('r')
class ReturnsAccessor:
    def __init__(self, obj):
        self._obj = obj
        self.level = False
        self.log = False
        self.compound = True
        self.m = 1
        self.r = self._to_simple(self._obj, self.level, self.log).dropna()

    def _set_params(self, new):
        new.r.compound = self.compound

    def __call__(
            self,
            level=False,
            log=False,
            compound=True,

    ):
        self.level = level
        self.log = log
        self.compound = compound
        self.r = self._to_simple(self._obj, level, log, compound)
        self._type = 'simple'
        return self

    @staticmethod
    def _to_simple(obj, level=False, log=False, compound=True, m=1):
        if log:
            if level:
                r = np.exp(obj).pct_change()
            else:
                r = np.exp(obj) - 1
        else:
            if level:
                if compound:
                    r = obj.pct_change()
                else:
                    r = obj.diff()
            else:
                if m == 1:
                    r = obj
                else:
                    r = (1 + obj / m) ** m - 1
        return r

    @clone
    def simple(self):
        return self.r

    @clone
    def compounded(self, m=1):
        r = self.r
        r = m * ((1 + r) ** (1 / m) - 1)
        r.r(m=m)
        return r

    @clone
    def continuous(self):
        r = self.r
        r = np.log(1 + r)
        r.r(log=True)
        return r

    @clone
    def prices(self, start_value=1, start_index=None, compound=None):
        '''

        :param compound:
        :param start_value: int, float or pd.Series
            The first value of the price time series
        :param start_index: datetime
        :return:
        '''

        r = self.r
        if isinstance(r, pd.Series):
            r = r.to_frame()
        compound = compound if compound is not None else self.compound
        if start_index:
            if isinstance(start_index, (int, np.int32, np.int64)):
                r = r[start_index:]
            else:
                r = r.loc[start_index:]

        r = (1 + r).cumprod() if compound else 1 + r.cumsum()

        if isinstance(start_value, pd.Series):
            first_index = start_value.index[0]
        else:
            if self.level:
                first_index = self._obj.index[self._obj.index.get_loc(r.index[0]) - 1]
            else:
                first_index = self.get_index(r)
            start_value = pd.Series(start_value, index=r.columns, name=first_index)

        r = r.reindex(index=r.index.insert(0, first_index))
        r.iloc[0, :] = 1

        prices = r * start_value
        prices.r(level=True)
        return prices.squeeze()

    def total(self, compound=None):
        r = self.r
        compound = compound if compound is not None else self.compound
        return (1 + r).prod() - 1 if compound else r.sum()

    @staticmethod
    def get_index(r):
        freq = r.index.inferred_freq
        first_index = r.index[0]
        offset = to_offset(freq) if freq else pd.to_timedelta(r.index[1] - r.index[0])
        return first_index - offset

    @clone
    def drawdown(self, compound=None):
        compound = compound if compound is not None else self.compound
        p = self.prices(compound=compound)
        if compound:
            return p / p.cummax() - 1
        else:
            return p - p.cummax()

    @clone
    def ptf(self, weights, rebalance=False):
        if isinstance(weights, pd.Series):
            weights = weights.rename(self.r.index[0]).to_frame().T
            r = self.r
        else:
            r = self.r.loc[weights.index[0]:]

        if rebalance:  # rebalance implies compounding
            if len(weights) < len(r):
                prices = r.r.prices(compound=True)
                units = weights / prices.shift().reindex(weights.index)
                units = pd.concat([prices[:1], units]).shift(-1)

                ret = []
                for i, start in enumerate(units.index[:-1]):
                    group_units = units.loc[start]
                    end = units.index[i + 1] if i < len(units) - 2 else prices.index[-1]
                    group_prices = prices.loc[start:end]
                    nav = (group_prices * group_units).sum(axis=1)
                    ret.append(nav.pct_change()[1:])
                return pd.concat(ret)
            else:
                return (r * weights).sum(axis=1)
        else:
            if len(weights) == 1:
                return r @ weights.squeeze()
            else:
                return (weights.reindex(r.index).bfill() * r).sum(axis=1)

    def __repr__(self):
        return f'{self.__class__.__name__}(level={self.level}, log={self.log})'


