from .base import BaseAccessors, BaseAccessor

__all__ = (
    'Accessors',
    'TrainingAccessors',
    'PredictionsAccessor',
    'ActiveSignalsRiskScaler',
    'ConcentrationRiskScaler'
)


class Accessors(BaseAccessors):
    def collect_all(self, *args, **kwargs):
        for accessor in self.accessors.values():
            accessor.collect_all(*args, **kwargs)
        return self


class TrainingAccessors(BaseAccessors):
    def collect_all(self, *args, **kwargs):
        self.kwargs = {}
        for accessor in self.accessors.values():
            accessor.collect_all(*args, **kwargs)
            self.kwargs.update(getattr(accessor, 'kwargs', {}))
        return self


class RiskManagers(BaseAccessors):
    def run_all(self, *args, **kwargs):
        for accessor in self.accessors.values():
            accessor.run(*args, **kwargs)
        return self


class PredictionsAccessor(BaseAccessor):
    def collect_predictions(self, assets=None, idx=None, **kwargs):
        mask = kwargs.get('mask', slice(None))
        predictions = self.obj.portfolio.get_predictions()
        self.kwargs = {'mean': predictions.loc[idx, mask]}


class ActiveSignalsRiskScaler(BaseAccessor):
    def run(self, weights=None, signals=None, **kwargs):
        signals = signals if signals is not None else self.obj.portfolio.get_signals()
        weights = weights if weights is not None else self.obj.risk_weights_
        scale = ((signals != 0).sum(axis=1) / signals.shape[1]).reindex(weights.index)
        self.weights_ = weights.multiply(scale, axis=0)
        self.obj.risk_weights_ = self.weights_
        return self


class ConcentrationRiskScaler(BaseAccessor):
    def __init__(
            self,
            obj=None,
            asset_categories=None,
            category_limits=None
    ):
        super().__init__(obj)
        self.asset_categories = asset_categories
        self.category_limits = category_limits

    def run(self, weights=None, signals=None, **kwargs):
        pass
