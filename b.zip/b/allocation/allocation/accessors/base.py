import inspect

from functools import wraps
from typing import Iterable

__all__ = (
    'BaseAccessors',
    'collector',
    'BaseAccessor',
)


def collector(fn):
    @wraps(fn)
    def wrapper(self, *args, **kwargs):
        name = fn.__name__
        prefix = name.split('_', 1)[0]

        methods = [
            collect_[1] for collect_ in inspect.getmembers(self, inspect.ismethod)
            if (collect_[0].startswith(prefix) and collect_[0] != name)
        ]

        for method in methods:
            method(*args, **kwargs)

        return self
    wrapper._collector = True
    return wrapper


class BaseAccessors:
    def __init__(self, obj, accessors=None):
        self.obj = obj
        self.accessors = {}
        self.register(accessors)

    def register(self, accessors):
        if not accessors:
            return

        accessors = self.to_dict(accessors)
        for key, accessor in accessors.items():
            accessor = accessor(self.obj)
            self.accessors[key] = accessor
            setattr(self, key, accessor)

    @staticmethod
    def to_dict(accessors):
        def _get_name(accessor):
            return accessor.__class__.__name__.lower()

        if isinstance(accessors, dict):
            pass
        if not isinstance(accessors, Iterable):
            name = getattr(accessors, 'name', _get_name(accessors))
            accessors = {name: accessors}
        elif isinstance(accessors, (list, tuple)):
            accessors = {getattr(accessor, 'name', _get_name(accessor)): accessor for accessor in accessors}
        else:
            raise ValueError(f'Wrong accessors type {type(accessors)}')
        return accessors

    def __repr__(self):
        strings = [f'{accessor.__class__.__name__}' for accessor in self.accessors.values()]

        if len(strings) > 1:
            strings[0] = f'\n\t{strings[0]}'
            strings[-1] = f'{strings[-1]}\n)'
            sep = ',\n\t'
        else:
            strings[-1] = f'{strings[-1]})'
            sep = ''
        string = sep.join(strings)

        return f'{self.__class__.__name__}({string}'

    def __getitem__(self, item):
        return self.accessors[item]


class BaseAccessor:

    def __init__(self, obj=None, *args, **kwargs):
        self.obj = obj

    @collector
    def collect_all(self, *args, **kwargs):
        pass

    def __call__(self, obj):
        self.obj = obj
        return self
