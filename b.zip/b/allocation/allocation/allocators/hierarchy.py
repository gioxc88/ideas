from itertools import chain

import numpy as np
import pandas as pd
from scipy.cluster.hierarchy import linkage, leaves_list, fcluster, to_tree
from scipy.spatial.distance import pdist, squareform

from .base import BaseAllocator
from .risk import InverseRisk, RiskBudgeting
from ..estimators import SampleCovariance, DistanceCorrelation

__all__ = (
    'HRP',
    'HERC'
)


def seriate(linkage_matrix, value=None, index=-1, n=None):
    """
    Returns the order implied by a hierarchical tree (dendrogram)
       :param linkage_matrix: A hierarchical tree (dendrogram) calculated using scipy.cluster.hierarchy.linkage
              The linkage_matrix is (n - 1) by 4 matrix. At the i-th iteration,
              clusters with indices Z[i, 0] and Z[i, 1] are combined to form cluster n + i.
              A cluster with an index less than n corresponds to one of the n original observations.
              The distance between clusters Z[i, 0] and Z[i, 1] is given by Z[i, 2].
              The fourth value Z[i, 3] represents the number of original observations in the newly formed cluster
       :return: The order implied by the hierarchical tree Z.
    """
    if not n:  # not necessary to specify n in the parameters, but this is to avoid repeating the calculation
        n = len(linkage_matrix) + 1
    if value is not None and value < n:
        return [value]
    else:
        left, right = linkage_matrix[index, :2].astype(np.int32)
        return [*seriate(linkage_matrix, value=left, index=left - n, n=n),
                *seriate(linkage_matrix, value=right, index=right - n, n=n)]


class HRP(BaseAllocator):
    '''
    ref: Marcos López de Prado, 2016, Building Diversified Portfolios that Outperform Out-of-Sample
    https://poseidon01.ssrn.com/delivery.php?ID=448116089123103086096073122118105081056087054032028010066007099074002100073008123030002122118022114055124102030127094100112070014010033010014104099078093065077019021062065099071065098005071015008087004119020099072014016024008099105120076004102091&EXT=pdf&INDEX=TRUE
    '''

    def __init__(
            self,
            cov=None,
            metric=None,
            method='single',
            cluster=True
    ):
        '''

        Parameters
        ----------
        cov: estimator, the covariance matrix estimator
        metric
        method
        cluster
        '''
        '''
        :param cov: ,
        :param metric: estimator, the metric used for calculating distances between assets
        :param method: str, the method for calculating the distances between clusters
        :param cluster: bool, if True runs hierarchical clustering and seriation before the recursive bisection
        '''

        self.cov = cov or SampleCovariance()
        self.metric = metric or DistanceCorrelation()
        self.method = method
        self.cluster = cluster

    def allocate(self, returns, **kwargs):

        if self.cluster:
            # step 1: chose a distance metric (this is chosen in the __init__)
            distance = self.metric.fit(returns, **kwargs).param_

            # step 2: calculate the dendogram which is presented as a linkage_matrix as explained in:
            # https://docs.scipy.org/doc/scipy/reference/generated/scipy.cluster.hierarchy.linkage.html or
            # https://www.mathworks.com/help/stats/linkage.html
            linkage_matrix = linkage(squareform(distance), method=self.method)

            # step 3: seriate the distance matrix (quasi-diagonalization)
            # leaves_list is same as seriate
            order = leaves_list(linkage_matrix)
        else:
            order = linkage_matrix = None

        # step 4: estimate the covariance and using recursive bisection calculate the weights for each asset
        cov = self.cov.fit(returns, **kwargs).param_
        weights = self.recursive_bisect(cov.to_numpy(), order)

        self.weights_ = pd.Series(weights, index=returns.columns)
        self.linkage_matrix_ = linkage_matrix
        self.order_ = order

        return self

    @staticmethod
    def bisect(x):
        split = len(x) // 2
        return x[:split], x[split:]

    def recursive_bisect(self, cov, order=None):

        order = order if order is not None else [*range(len(cov))]
        weights = np.ones(len(order))
        clusters = [(order,)]

        while clusters:
            clusters = [*chain.from_iterable(clusters)]
            clusters = [self.bisect(cluster) for cluster in clusters if len(cluster) > 1]
            for left_cluster, right_cluster in clusters:  # iterate every 2
                vars = []
                for cluster in [left_cluster, right_cluster]:
                    cluster_cov = cov[np.ix_(cluster, cluster)]
                    inv_diag = 1 / np.diag(cluster_cov)
                    parity_w = inv_diag / np.sum(inv_diag)
                    vars.append(parity_w @ cluster_cov @ parity_w)
                alloc_factor = 1 - vars[0] / sum(vars)
                weights[left_cluster] *= alloc_factor
                weights[right_cluster] *= 1 - alloc_factor
        return weights


def get_cluster_indices(labels):
    clusters = np.unique(labels)
    return {cluster: np.flatnonzero([labels == cluster]) for cluster in clusters}


class HERC:
    def __init__(
            self,
            n_clusters=3,
            metric=None,
            method='single',
            within=None,
            across=None,
            clustering=None
    ):
        '''
        :param n_clusters: int or None.
            If None clustering must be specified as a callable. See below
        :param within: allocator.
            allocation strategy within clusters
        :param across: allocator
            allocation strategy across clusters
        :param clustering: callable
            If n_clusters is None then this parameter must be specified
            It takes as input the linkage matrix Z and the assets time series and returns the labels for each assets
        '''

        self.n_clusters = n_clusters
        self.metric = metric or DistanceCorrelation()
        self.method = method
        self.within = within or InverseRisk()
        self.across = across or RiskBudgeting()
        self.clustering = clustering

    def allocate(self, returns, **kwargs):

        # step 1: chose a distance metric (this is chosen in the __init__)
        distance = self.metric.fit(returns, **kwargs).param_

        # step 2: calculate the dendogram which is presented as a linkage_matrix as explained in:
        # https://docs.scipy.org/doc/scipy/reference/generated/scipy.cluster.hierarchy.linkage.html or
        # https://www.mathworks.com/help/stats/linkage.html
        Z = linkage(squareform(distance), method=self.method)

        # step 3: get the labels of each asset
        if self.clustering:
            labels = self.clustering(returns, Z)
        else:
            labels = fcluster(Z, self.n_clusters, criterion='maxclust')

        # step 4: perform within allocation and recursive across allocation based on the clusters
        clusters = get_cluster_indices(labels)
        n_clusters = len(clusters)
        n = returns.shape[1]

        asset_weights = np.ones(shape=n)
        cluster_weights = np.ones(shape=(n, n_clusters))

        # calculate the asset weights in each cluster
        # according to the within allocator
        for i, cluster_indices in enumerate(clusters.values()):
            w = self.within.allocate(returns.iloc[:, cluster_indices], refit=True).weights_.to_numpy()
            asset_weights[cluster_indices] = w

        weighted_assets = returns * asset_weights
        # recursive divide in clusters following the dendrogram
        for merge in range(1, n_clusters):

            # 4.1 split into left and right cluster
            left, right = Z[-merge, :2].astype(np.int32)
            left_cluster = seriate(Z, value=left, index=left - n)
            right_cluster = seriate(Z, value=right, index=right - n)

            # 4.2 calculate the returns of the sub-portfolio in each cluster using the asset_weights
            left_ptf = weighted_assets.iloc[:, left_cluster].sum(axis=1).rename('left')
            right_ptf = weighted_assets.iloc[:, right_cluster].sum(axis=1).rename('right')
            ptf = pd.concat([left_ptf, right_ptf], axis=1)

            # 4.3 calculate the allocation between left and right cluster using self.across allocator
            self.across.allocate(ptf, refit=True)

            cluster_weights[left_cluster, merge] *= self.across.weights_['left']
            cluster_weights[right_cluster, merge] *= self.across.weights_['right']

        self.cluster_weights_ = cluster_weights
        self.weights_ = pd.Series(cluster_weights.prod(axis=1) * asset_weights, index=returns.columns)

        return self


