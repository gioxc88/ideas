import numpy as np
import pandas as pd

from .base import BaseAllocator
from .risk import MaxRiskAdjusted
from ..estimators.ticc import TICC


__all__ = (
    'LastRegime',
)


class LastRegime(BaseAllocator):
    def __init__(self, allocator=None, estimator=None):
        self.allocator = allocator or MaxRiskAdjusted()
        self.estimator = estimator or TICC(
            window_size=1,
            n_clusters=3,
            lambda_parameter=0.02,
            switch_penalty=28,
            max_iters=100,
            threshold=2e-5,
            cluster_reassignment=10,
            verbose=1
        )

    def allocate(self, returns, **kwargs):

        X = kwargs.get('X', returns)
        self.estimator.fit(X=X)

        labels = pd.Series(data=self.estimator.labels_, index=X.index).reindex(returns.index).bfill().ffill()
        # subset = returns[-len(self.estimator.labels_):]
        subset = returns.loc[labels == labels[-1], :]
        self.allocator.allocate(returns=subset, **kwargs)
        self.weights_ = self.allocator.weights_
        return self

