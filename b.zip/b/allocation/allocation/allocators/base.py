from abc import abstractmethod, ABC


class BaseAllocator(ABC):
    @abstractmethod
    def allocate(self, returns, **kwargs):
        '''

        Parameters
        ----------
        returns: pandas series of simple returns
        **kwargs: any additional parameter
        kwargs

        Returns
        -------
        self: the instance of the allocator
        '''

        return self