from copy import deepcopy

# import cvxpy as cvx
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy import stats
from dask import compute, delayed

from ..allocators.base import BaseAllocator
from ..estimators import SampleMean
from allocation.estimators.misc import SampleCovariance, SampleStandardDeviation, SharpeRatio

__all__ = (
    'OneOverN',
    'InverseRisk',
    'MaxRiskAdjusted',
    'MinRisk',
    'RiskBudgeting',
    'GaussianResampling'
)


class OneOverN(BaseAllocator):
    def allocate(self, returns, **kwargs):
        n = returns.shape[1]
        self.weights_ = pd.Series(np.ones(n)/n, index=returns.columns)
        return self


class InverseRisk(BaseAllocator):
    def __init__(self, measure=None):
        self.measure = measure or SampleStandardDeviation()

    def allocate(self, returns, **kwargs):
        risk = self.measure.fit(returns, **kwargs).risk_
        one_over = 1 / risk
        self.weights_ = one_over / one_over.sum()
        return self


# class MaxSharpe(BaseAllocator):
#     def __init__(
#             self,
#             mean=None,
#             cov=None,
#             risk_free=0,
#             long_only=True
#     ):
#         self.mean = mean or SampleMean()
#         self.cov = cov or SampleCovariance()
#         self.risk_free = risk_free
#         self.long_only = long_only
#
#     def allocate(self, returns, **kwargs):
#         n = returns.shape[1]
#         y = cvx.Variable(n)
#         k = cvx.Variable()
#         rf = kwargs.get('risk_free', self.risk_free)
#         mu = self.mean.fit(returns, **kwargs).param_.to_numpy()
#         cov = self.cov.fit(returns, **kwargs).param_.to_numpy()
#         quadratic_form = cvx.quad_form(y, cov)  # ** 0.5
#         x = y / k
#         ptf_mean = mu @ x
#         ptf_var = cvx.quad_form(x, cov)
#
#         constraints = [
#             (mu - rf) @ y == 1,
#             # w = y/k and sum(w) == 1 => sum(y/k) == sum(w) => sum(y/k) == 1 => sum(y) == k since k is a constant
#             cvx.sum(y) == k,
#             k >= 0,
#         ]
#
#         if self.long_only:
#             constraints.append(y >= 0)
#
#         prob = cvx.Problem(
#             objective=cvx.Minimize(quadratic_form),
#             constraints=constraints
#         )
#
#         prob.solve()
#         self.weights_ = pd.Series(x.value, index=returns.columns)
#
#         self.more_params_ = {
#             'n': n,
#             'y': y,
#             'k': k,
#             'rf': rf,
#             'mu': mu,
#             'cov': cov,
#             'quadratic_form': quadratic_form,
#             'x': x,
#             'ptf_mean': ptf_mean,
#             'ptf_var': ptf_var,
#             'prob': prob
#         }
#
#         return self

class SLSQPMixin:
    def __init__(self,  weights_sum=1.0,  bounds=None,  constraints=None):
        self.weights_sum = weights_sum
        self.bounds = bounds or (0.0, 1.0)
        self.constraints = [
            {'type': 'eq', 'fun': Constraints.weight_sum(weights_sum)}
        ]

        if constraints:
            self.constraints.append(constraints)

    def minimize(self, returns, loss, **kwargs):
        # starting point
        x0 = self.get_x0(returns, **kwargs)
        # bounds
        bounds = self.get_bounds(returns, **kwargs)
        return minimize(loss, x0=x0, constraints=self.constraints, bounds=bounds)

    def get_bounds(self, returns, **kwargs):
        bounds = self.bounds
        if bounds is None:
            bounds = [(0.0, 1.0)] * returns.shape[1]
        elif isinstance(bounds, tuple):
            bounds = [bounds] * returns.shape[1]
        return bounds

    def get_x0(self, returns, **kwargs):
        return OneOverN().allocate(returns, **kwargs).weights_


class MaxRiskAdjusted(SLSQPMixin, BaseAllocator):
    def __init__(
            self,
            measure=None,
            risk_free=0,
            weights_sum=1.0,
            bounds=None,
            constraints=None,
    ):
        super().__init__(
            weights_sum=weights_sum,
            bounds=bounds,
            constraints=constraints,
        )
        self.measure = measure or SharpeRatio()
        self.risk_free = risk_free

    def allocate(self, returns, **kwargs):
        loss = self.get_loss(returns, **kwargs)
        opt = super().minimize(returns, loss, **kwargs)

        self.opt_ = opt
        self.weights_ = pd.Series(self.opt_.x, index=returns.columns)
        return self

    def get_loss(self, returns, **kwargs):
        def loss(weights):
            return - self.measure.ptf(returns=returns, weights=weights, **kwargs)
        return loss


class MinRisk(MaxRiskAdjusted):

    def __init__(
            self,
            measure=None,
            weights_sum=1.0,
            bounds=None,
            constraints=None,
    ):
        super().__init__(
            measure=measure or SampleCovariance(),
            weights_sum=weights_sum,
            bounds=bounds,
            constraints=constraints,
        )

    def get_loss(self, returns, **kwargs):
        def loss(weights):
            return self.measure.ptf(returns=returns, weights=weights, **kwargs)

        return loss


class RiskBudgeting(SLSQPMixin, BaseAllocator):
    def __init__(
            self,
            measure=None,
            budget=None,
            weights_sum=1.0,
            bounds=None,
            constraints=None
    ):
        '''
        If the budget is not specified it defaults to RiskParity (1 / n)
        :param risk: estimator
        :param budget: pd.Series.
            The target percentage risk contribution.The index should same as assets columns
            For instance if you want that asset1 contributes to 30% and asset2 contribute to 70%
            of the total risk this array would be [.3, .7]
        :param constraints: dict
            Example:
                cons = [
                  {'type': 'eq', 'fun': fn},
                  {'type': 'ineq', 'fun': fn}
                ]
                fn is a function of weights only
        '''

        self.measure = measure or SampleCovariance()
        self.budget = budget
        super().__init__(
            weights_sum=weights_sum,
            bounds=bounds,
            constraints=constraints,
        )

    def allocate(self, returns, **kwargs):
        n_assets = returns.shape[1]
        budget = pd.Series(np.full(n_assets, 1 / n_assets), index=returns.columns) if self.budget is None else self.budget

        def loss(weights):
            relative_risk_contribution = self.measure.rc(returns, weights, **kwargs).rrc_
            return np.sum((relative_risk_contribution - budget) ** 2)

        opt = super().minimize(returns, loss, **kwargs)

        self.opt_ = opt
        self.weights_ = pd.Series(self.opt_.x, index=returns.columns)
        return self

    def get_x0(self, returns, **kwargs):
        self.measure.fit(returns, **kwargs)
        one_over = 1 / self.measure.risk_
        return one_over / one_over.sum()


class Constraints:
    @staticmethod
    def long_only(weights):
        # because you need an inequality where the right side is zero and the function only need to
        # return the left side, hence w > 0 => w
        return weights

    @staticmethod
    def weight_sum(value=1.0):
        def fn(weights):
            return np.sum(weights) - value
        return fn


class Resampling:
    def __init__(
            self,
            base_allocator=None,
            n_sim=100,
            n_samples=500,
            n_jobs=None
    ):
        self.base_allocator = base_allocator or MaxRiskAdjusted()
        self.n_sim = n_sim
        self.n_samples = n_samples
        self.n_jobs = n_jobs

    def allocate(self, assets, **kawrgs):
        rvs = self.simulate(assets)
        # allocators = []
        # weights = []
        # for i in range(self.n_sim):
        #     allocator = deepcopy(self.base_allocator)
        #     sim_assets = pd.DataFrame(rvs[i], columns=assets.columns)
        #     allocator.allocate(sim_assets)
        #     allocators.append(allocator)
        #     weights.append(allocator.weights_)

        if not self.n_jobs or self.n_jobs == 1:
            copy = True
            fn = allocate_one
            parallel_kwargs = {}

            def comp(*x, **parallel_kwargs):
                return [*x]
        else:
            copy = False
            fn = delayed(allocate_one)
            parallel_kwargs = {'num_workers': None if self.n_jobs == -1 else self.n_jobs}
            comp = compute

        res = [
            fn(
                self.base_allocator,
                pd.DataFrame(rvs[i], columns=assets.columns),
                copy=copy
            ) for i in range(self.n_sim)
        ]

        res = comp(*res, **parallel_kwargs)

        self.allocators_ = res
        self.all_weights_ = pd.concat([allocator.weights_ for allocator in res], axis=1)
        self.weights_ = self.all_weights_.mean(axis=1)
        return self

    def simulate(self, assets, **kwargs):
        pass


class GaussianResampling(Resampling):

    def __init__(
            self,
            base_allocator=None,
            n_sim=100,
            n_samples=500,
            mean=None,
            cov=None,
            n_jobs=None
    ):

        super().__init__(
            base_allocator=base_allocator,
            n_sim=n_sim,
            n_samples=n_samples,
            n_jobs=n_jobs
        )

        self.mean = mean or SampleMean()
        self.cov = cov or SampleCovariance()

    def simulate(self, assets, **kwargs):
        mean = self.mean.fit(assets).param_
        cov = self.cov.fit(assets).param_
        rvs = np.random.multivariate_normal(mean, cov, size=(self.n_sim, self.n_samples))
        return rvs


def allocate_one(allocator, assets, copy=True):
    if copy:
        allocator = deepcopy(allocator)
    sim_assets = pd.DataFrame(assets, columns=assets.columns)
    allocator.allocate(sim_assets)
    return allocator
