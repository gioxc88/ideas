# built in

from abc import ABC, abstractmethod
from datetime import datetime
from numbers import Number

# third party
import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay, DateOffset

rng = np.random.default_rng(7)


class BaseStrategy(ABC):
    '''

    '''

    def __init__(self, t_costs=0):
        self.t_costs = t_costs

    @abstractmethod
    def get_signals(self):
        '''
        Returns the signals which represent the position (not the trade).
        '''
        pass

    @abstractmethod
    def get_asset_returns(self):
        '''
        It must return the simple returns of the asset which the strategy is based on
        '''
        pass

    @abstractmethod
    def get_asset_prices(self):
        pass

    def get_t_costs(self, signals):
        '''

        '''
        if isinstance(self.t_costs, Number) and not self.t_costs:
            return self.t_costs
        t_costs = signals.diff().abs()
        t_costs.iloc[0] = np.abs(signals.iloc[0])
        return t_costs * self.t_costs

    def get_returns(self):
        '''
        It must return the simple returns of the strategy
        This function implies that asset_returns can have a higher granularity than the signals
        but not the opposite. For example asset time series can be daily but the signals are weekly
        '''
        signals = self.get_signals().dropna()
        t_cost = self.get_t_costs(signals)
        # I cannot reindex the asset otherwise I loose the granularity of the pnl

        asset = self.get_asset_prices()

        first_index = np.argmin((asset.index < signals.index[0]))
        first_date = asset.index[first_index - 1 if first_index else first_index]  # .reindex(signals.index)
        asset = asset.loc[first_date:]
        # not sure why I added this, maybe is because I want to change the structure and
        # not to force the asset to be in the returns space
        asset_returns = asset.r(level=True).simple()

        signals = signals.reindex(asset_returns.index).bfill()
        if isinstance(t_cost, pd.Series):
            t_cost = t_cost.reindex(asset_returns.index).fillna(0)

        return (signals.multiply(asset_returns, axis=0) - t_cost).astype(np.float32)[1:].dropna(how='all')

    def get_pnl(self, compound=True, p0=1, start_index=None):
        returns = self.get_returns()
        return returns.r.prices(compound=compound, start_value=p0, start_index=start_index)


class RandomStrategy(BaseStrategy):
    '''
    This is an abstract class, used as base for AutoStrategy and SimpleStrategy
    '''

    def get_signals(self):
        return pd.Series(
            data=rng.integers(low=-1, high=2, size=self.asset.shape),
            index=self.asset_returns.index,
            name=self.asset_returns.name
        )

    def get_asset_returns(self):
        return self.asset_returns

    def get_asset_prices(self):
        return self.asset_returns.r.prices()

    def get_predictions(self):
        return self.asset_returns


class SimpleRandomStrategy(RandomStrategy):

    def __init__(self, asset_returns, **kwargs):
        self.asset_returns = asset_returns
        super().__init__(**kwargs)




class AutoStrategy(RandomStrategy):
    def __init__(
            self,
            dist='normal',
            size=1000,
            freq='B',
            start=datetime(2000, 1, 1),
            **kwargs
    ):
        t_costs = kwargs.pop('t_costs', 0)
        super().__init__(t_costs=t_costs)
        if dist == 'normal':
            kwargs.setdefault('loc', 0)
            kwargs.setdefault('scale', 0.01)

        self.asset = pd.Series(
            data=getattr(rng, dist)(size=(size,), **kwargs),
            index=pd.date_range(start=start, periods=size, freq=freq),
        )


class AssetStrategy(BaseStrategy):
    '''
    Abstract class, do not use directly.
    Inherit from it and implement the get_signals method
    '''

    def __init__(self, asset, **kwargs):
        '''
        :param asset: the asset prices
        :param kwargs:
        '''
        self.asset = asset
        super().__init__(**kwargs)

    def get_asset_prices(self):
        return self.asset

    def get_asset_returns(self):
        attr = '_asset_returns'
        if (returns := getattr(self, attr, None)) is not None:
            return returns
        returns = self.get_asset_prices().r(level=True).simple()
        setattr(self, attr, returns)
        return returns


class LongStrategy(AssetStrategy):
    def __init__(self, asset, **kwargs):
        '''

        :param asset: the asset prices
        :param kwargs:
        '''
        super().__init__(asset=asset, **kwargs)
        self._signals = pd.Series(data=np.ones(len(self.asset)), index=self.asset.index, name=self.asset.name)

    def get_signals(self):
        return self._signals


class TestStrategy(AssetStrategy):
    def __init__(self, signals, **kwargs):
        super().__init__(**kwargs)
        self._signals = signals

    def get_signals(self):
        return self._signals


def _is_intraday(index):
    return (index.hour != 0).any()


def _get_intraday_prices(asset, date0, date1):
    # start = (asset.index < (date0 + BDay())).sum() - 1  # being 0 indexed I need to subtract 1
    # end = (asset.index < (date1 + BDay())).sum()
    # return asset.iloc[start:end]
    return asset.loc[date0+pd.tseries.offsets.Hour(23):date1 + pd.tseries.offsets.Hour(23)]


def _get_daily_prices(asset, date0, date1):
    return asset.loc[date0:date1]



class BaseStopLossStrategy(ABC):
    def __init__(self, use_thresholds=False, **kwargs):
        super().__init__(**kwargs)
        self.use_thresholds = use_thresholds

    @abstractmethod
    def stop_loss(self, date=None):
        pass

    @abstractmethod
    def take_profit(self, date=None):
        pass

    def get_returns(self):
        signals = self.get_signals().dropna()
        t_costs = self.get_t_costs(signals)
        asset = self.get_asset()

        self._precalc(signals, asset, t_costs)

        asset = asset.loc[signals.index[0]:].dropna()
        get_prices_fn = _get_intraday_prices if _is_intraday(asset.index) else _get_daily_prices

        max_common_index = (np.argmax(signals.index > asset.index[-1]) - 1) or (len(signals) - 1)
        final_iter = min(len(signals) - 1, max_common_index)

        self.exit_dates = []
        returns = {}
        for i in range(final_iter):
            # for i, (date0, _) in enumerate(signals.iteritems()):

            date0, date1 = signals.index[i:i + 2]
            signal = signals[i + 1]

            stop_loss = self.stop_loss(date=date0)
            take_profit = self.take_profit(date=date0)

            # Note for hourly prices:
            # say the signals 1 is for friday 8-Jan. This means that we are long between 1-Jan and 8-Jan.
            # The return for the week MUST be calculated using close to close prices meaning 1-Jan 23:00 and 8-Jan 23:00
            # The signal though refers to 8-Jan 00:00 which is before the closing price of 8-Jan 17:00 (or 23:00)
            # This means that when I slice the prices for the period related to the signal period I need to
            # 1. take the signal date (date1) and the date of the previous signal (date0)
            #    date1 would be in the example 8-Jan 00:00. Now I want to retrieve the last price of the day.
            # 2. Offset date0 and date1 by 1 BDay (in this case I would get a date on the next monday) and take
            #    the first price before that (assuming no NaN in the series)

            prices = get_prices_fn(asset, date0, date1)
            period_returns = (prices / prices[0] - 1)[1:] * signal

            if not any((take_profit, stop_loss)):  # if I don't have stop loss or take profit return the last pnl
                returns[date1] = period_returns[-1]
                continue
            elif not take_profit:
                take_profit = np.inf
            elif not stop_loss:
                stop_loss = - np.inf

            stop_loss_mask = period_returns <= stop_loss
            take_profit_mask = period_returns >= take_profit

            # If stop loss or take profit are not reached take the return of the whole period
            for mask in [stop_loss_mask, take_profit_mask]:
                if (~ mask).all():  # meaning if stop_loss or take profit are never reached
                    mask[-1] = True

            take_profit_date = take_profit_mask.idxmax()
            stop_loss_date = stop_loss_mask.idxmax()
            exit_date = min(take_profit_date, stop_loss_date)

            # this means if stop loss or take profit are reached what is my actual return for the period?
            # I can either use the stop_loss and take_profit directly (use thresholds) or use the price corresponding
            # to the date when the barrier has been hit
            if self.use_thresholds:
                returns[date1] = period_returns[-1] if take_profit_date == stop_loss_date else \
                    take_profit if take_profit_date < stop_loss_date else stop_loss
            else:
                returns[date1] = period_returns[exit_date]
            self.exit_dates.append(exit_date)

        returns = (pd.Series(returns) - t_costs).astype(np.float32).dropna()
        self._returns = returns
        return returns

    def _precalc(self, signals, asset, t_costs):
        return self


class ConstantStopLossStrategy(BaseStopLossStrategy, AssetStrategy):
    def __init__(self, signals, stop_loss=None, take_profit=None, **kwargs):
        super().__init__(**kwargs)
        self._signals = signals
        self._stop_loss = - stop_loss if stop_loss else stop_loss
        self._take_profit = take_profit

    def get_signals(self):
        return self._signals

    def stop_loss(self, date=None):
        return self._stop_loss

    def take_profit(self, date=None):
        return self._take_profit


class VolStopLossStrategy(BaseStopLossStrategy, AssetStrategy):
    def __init__(
            self,
            signals,
            stop_loss=1.5,
            take_profit=2,
            vol='std',
            periods=50,
            resample='W-FRI',
            expanding=False,
            alpha=0.1,
            **kwargs):
        super().__init__(**kwargs)
        self._signals = signals

        self._stop_loss = stop_loss
        self._take_profit = take_profit

        self.vol = vol
        self.periods = periods
        self.resample = resample
        self.expanding = expanding
        self.alpha = alpha

    def get_signals(self):
        return self._signals

    def stop_loss(self, date=None):
        return self._dynamic_stop_loss.loc[:date][-1]

    def take_profit(self, date=None):
        return self._dynamic_take_profit.loc[:date][-1]

    def _precalc(self, signals, asset, t_costs):
        asset = asset.resample(self.resample).last().pct_change()

        if self.vol == 'ewm':
            handler = asset.ewm(alpha=self.alpha)
        else:
            handler = asset.expanding(self.periods) if self.expanding else asset.rolling(self.periods)

        vol = handler.std()
        self._vol = vol
        self._dynamic_stop_loss = - vol * self._stop_loss
        self._dynamic_take_profit = vol * self._take_profit
        return self


