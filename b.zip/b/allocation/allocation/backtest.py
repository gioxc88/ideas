from typing import Union
from copy import deepcopy

import ipywidgets as w
import numpy as np
import pandas as pd
import plotly.io as pio

pio.templates.default = "plotly_white"

from IPython.display import display
from dask import compute, delayed
from pandas.tseries.offsets import DateOffset

from .accessors.backtest import Accessors, TrainingAccessors, RiskManagers
from allocation.estimators import SampleCovariance, SampleMean

__all__ = (
    'BackTest',
)

default_training_accessors = []
default_risk_accessors = []
default_risk_managers = []


def get_rebalance_index(
        index: pd.DatetimeIndex,
        rebalance: Union[int, DateOffset] = 1,
        start: Union[int, pd.Timestamp] = 0,
):
    if start:
        if not isinstance(start, (int, np.int32, np.int64)):
            start = index.get_loc(start)
        index = index[start:]

    if isinstance(rebalance, (int, np.int32, np.int64)):
        if rebalance == 1:
            return index
        else:
            return pd.DatetimeIndex([index[i] for i in range(0, len(index), rebalance)])

    else:  # assumes rebalance is a DateOffset
        temp = pd.date_range(start=index[0], end=index[-1], freq=rebalance)
        temp = pd.concat([index.to_series(name='index'), temp.to_series(name='rebalance')], axis=1)
        temp = temp.assign(filled=temp.iloc[:, 0].fillna(method='bfill'))
        mask = temp['index'].isna()
        temp.loc[mask, 'rebalance'] = temp.loc[mask, 'filled']

        return pd.DatetimeIndex(temp['rebalance'].dropna())


class BackTest:
    def __init__(
            self,
            portfolio,
            allocator,
            expanding=False,
            rebalance=1,
            switch=True,
            training_accessors=None,
            risk_accessors=None,
            risk_managers=None,
            first_training_size=250,
            n_jobs=None,
    ):

        # if first_training_size is None and expanding == True uses all data available from start to
        # the first rebalance date. This implies that the signals have more NaN compared to the assets

        if not any((first_training_size, expanding)):
            raise ValueError('if expanding is False then first training size must be specified')

        self.portfolio = portfolio
        self.allocator = allocator
        self.first_training_size = first_training_size
        self.expanding = expanding
        self.rebalance = rebalance
        self.switch = switch
        self.n_jobs = n_jobs
        self.risk_managers = risk_managers
        # self.init_accessors(training_accessors, risk_accessors, risk_managers)

    def reset_weights(self):
        self.risk_weights_ = self.weights_

    def init_accessors(self, training_accessors, risk_accessors, risk_managers):
        if default_training_accessors or training_accessors:
            self.training_accessors = TrainingAccessors(self, default_training_accessors)
            self.training_accessors.register(training_accessors)
        else:
            self.training_accessors = None

        if default_risk_accessors or risk_accessors:
            self.risk_accessors = Accessors(self, default_risk_accessors)
            self.risk_accessors.register(risk_accessors)
        else:
            self.risk_accessors = None

        if default_risk_managers or risk_managers:
            self.risk_managers = RiskManagers(self, default_risk_managers)
            self.risk_managers.register(risk_managers)
        else:
            self.risk_managers = None

    def run(self, **kwargs):
        '''
        first_training_size is used both if the strategy is expanding or rolling.
        :return:
        '''

        partial = kwargs.pop('partial', False)
        portfolio = self.portfolio
        all_assets = portfolio.get_asset_returns()  # assuming that the strategies are initialized using asset prices
        signals = portfolio.get_signals()  # .reindex(index=all_assets.index)
        end = min(signals.index[-1], all_assets.index[-1])

        if not partial:
            all_assets = all_assets.dropna()
            signals = signals.dropna()
        elif isinstance(partial, (int, np.int)):
            start = np.argmax(signals.notna().sum(axis=1) >= partial)
            signals = signals[start:]

        all_assets = all_assets.loc[:end]
        signals = signals.loc[:end]

        # 1. find all the rebalance dates taking into account first_training_size and NaN in assets and signals
        # assumes no trailing nan

        if self.first_training_size:
            # first_valid_index = pd.concat([self.first_training_size + all_assets.isna().sum(),
            #                                signals.isna().sum()], axis=1).max(axis=1).min()

            first_valid_index = pd.concat([
                pd.Series(all_assets.index[self.first_training_size + all_assets.isna().sum() - 1],
                          index=all_assets.columns),
                signals.apply(pd.Series.first_valid_index)
            ], axis=1).max(axis=1).min()

        else:
            first_valid_index = signals.first_valid_index()

        rebalance_index = get_rebalance_index(index=signals.index, rebalance=self.rebalance, start=first_valid_index)

        # 2. collect the arguments for each rebalance date
        run_kwargs = self.make_kwargs(all_assets, signals, rebalance_index, **kwargs)

        # 3. perform allocation for each date
        if n_jobs := kwargs.get('n_jobs', self.n_jobs):
            futures = [delayed(run_one)(**idx_kwargs) for idx_kwargs in run_kwargs]
            parallel_kwargs = {} if n_jobs == - 1 else \
                {'scheduler': 'single-threaded'} if n_jobs == 1 else \
                    {'num_workers': n_jobs}
            results = compute(*futures, **parallel_kwargs)
        else:
            results = [run_one(**idx_kwargs) for idx_kwargs in run_kwargs]

        # for i, idx in enumerate(rebalance_index):
        #
        #     # try:
        #     #     assets = self.switch(assets=all_assets, signals=signals, loc=idx, active=True, existing=True)
        #     # except IndexError:
        #     #     e = 1
        #     assets = self.slice(assets=all_assets, signals=signals, loc=idx, active=True, existing=True)
        #
        #     if assets.empty:
        #         weights = pd.Series(index=all_assets.columns)
        #     else:
        #         # assets = assets.dropna()
        #         if self.first_training_size:
        #             assets = assets.loc[:, (assets.shape[0] - assets.isna().sum()) >= self.first_training_size]
        #
        #         if (one_asset := assets.squeeze()).ndim == 1:
        #             weights = pd.Series(1, index=[one_asset.name])
        #         else:
        #             mask = all_assets.columns.isin(assets.columns)
        #             if not self.expanding:
        #                 assets = assets[-self.first_training_size:]
        #
        #             if self.switch:
        #                 assets = assets * signals
        #
        #             kwargs = self.make_kwargs(assets, idx, mask)
        #
        #             weights = self.allocator.allocate(assets, **kwargs).weights_
        #     all_weights.append(weights)

        weights, allocators = [*zip(*results)]

        self.weights_ = pd.concat(weights, axis=1).T.set_axis(rebalance_index, axis=0)
        self.allocators_ = {idx: allocator for idx, allocator in zip(allocators, rebalance_index)}
        self.risk_weights_ = self.weights_
        return self

    def make_kwargs(self, all_assets, signals, rebalance_index, **kwargs):

        to_slice = (pd.Series, pd.DataFrame)
        all_kwargs = []
        for idx in rebalance_index:
            assets = self.slice_and_switch(
                assets=all_assets,
                signals=signals,
                loc=idx,
                active=True,
                existing=True,
                switch=self.switch,
            )
            idx_kwargs = {
                'assets': assets,
                'allocator': deepcopy(self.allocator),
                'index': idx,
                'all_columns': all_assets.columns
            }

            # the kwargs are created if
            # 1. assets is not empty
            # 2. assets contains more than 1 column
            if not assets.empty:  # assets can be empty because the signals are all inactive, i.e. 0
                # assets = assets.dropna()

                # if first_training_size is None and expanding == True uses all data available from start to
                # the first rebalance date. This implies that the signals have more NaN compared to the assets
                # I don't care if the window is expanding or rolling here because the weights are not calculated but are
                # either 0 or 1 depending if the assets dataframe is empty or contains only  one asset
                if self.first_training_size:
                    # assets = assets.loc[:, (assets.shape[0] - assets.isna().sum()) >= self.first_training_size]
                    idx_kwargs['assets'] = assets

                # this is the case where I actually collect the kwargs because condition 1 and 2 are met
                if not assets.squeeze().ndim == 1:
                    mask = all_assets.columns.isin(assets.columns)
                    if not self.expanding:
                        assets = assets[-self.first_training_size:]
                        idx_kwargs['assets'] = assets

                    start = assets.index[0]
                    end = assets.index[-1]

                    for k, v in kwargs.items():
                        if isinstance(v, to_slice):
                            try:
                                v = v.loc[start:end]
                            except KeyError:
                                pass
                            finally:
                                idx_kwargs[k] = v

                    # if training_accessors := self.training_accessors:
                    #     training_accessors.collect_all(assets=assets, idx=idx, mask=mask)
                    #     idx_kwargs.update(training_accessors.kwargs)
            all_kwargs.append(idx_kwargs)
        return all_kwargs

    @staticmethod
    def slice_and_switch(assets, signals, loc, active=False, existing=False, switch=False):
        '''
        :param assets:
        :param signals:
        :param loc:
        :param active: bool
            if the signal was not 0
        :param existing: bool
            if the signal was already present. It can be not present because it's only available at a later date
        :param switch: if to change the sign of the assets based on the specific signal
        :return:
        '''

        signals_iloc = signals.index.get_loc(loc)
        if not signals_iloc:  # meaning is zero for first iteration
            asset_loc = signals.index[0] - (signals.index[1:] - signals.index[:-1]).median()
        else:
            asset_loc = signals.index[signals_iloc - 1]
        assets_iloc = assets.index.get_loc(asset_loc)
        current_signals = signals.iloc[signals_iloc].to_numpy()

        if active:
            mask = current_signals != 0
        if existing:
            existing_mask = ~np.isnan(current_signals)
            try:
                mask = mask & existing_mask
            except NameError:
                mask = existing_mask

            current_signals = current_signals[mask]
            assets = assets.loc[:, mask]

        assets = assets[:assets_iloc + 1]
        if switch:
            assets = assets * current_signals
        return assets

    def adjust(self, **kwargs):
        if not self.risk_managers:
            return self

        self.reset_weights()
        for manager in self.risk_managers:
            manager.run(self)
        return self

    def get_returns(
            self,
            rebalance=False,
            exclude=None,
            weights=None,
    ):
        exclude = exclude or []
        strategy_returns = self.portfolio.get_returns().drop(exclude, axis=1).fillna(0)
        if weights is None:
            weights = self.risk_weights_.drop(exclude, axis=1).fillna(0)
        elif isinstance(weights, (int, np.int)):
            if weights == -1:
                weights = self.weights_
            else:
                weights = self.risk_managers[weights].weights_
        return strategy_returns.r.ptf(weights, rebalance=rebalance)

    def get_pnl(
            self,
            compound=True,
            rebalance=False,
            exclude=None,
            weights=None,
            **kwargs
    ):
        return self.get_returns(rebalance, exclude, weights).r.prices(compound=compound, **kwargs)


def run_one(assets, allocator, index, all_columns, **kwargs):
    if assets.empty:  # assets can be empty because the signals are all inactive, i.e. 0
        weights = pd.Series(0, index=all_columns)
    elif (one_asset := assets.squeeze()).ndim == 1:
        weights = pd.Series(1, index=[one_asset.name])
    else:
        weights = allocator.allocate(assets, **kwargs).weights_
    return weights, allocator


class BTInspector:
    def __init__(self, bts):
        if not isinstance(bts, dict):  # assume its Backtest
            self.bt = bts
            self._bt_key = 'backtest'
            self.bts = {self._bt_key: self.bt}
        else:  # assume its dictionary
            self.bts = bts
            self._bt_key = next(iter(bts.keys()))
            self.bt = self.bts[self._bt_key]

        bt = self.bt

        self.signals = self.bt.portfolio.get_signals()
        strategy_ret = self.bt.portfolio.get_returns().loc[self.bt.risk_weights_.index[0]:]
        self.contrib = (self.bt.risk_weights_.reindex(strategy_ret.index).bfill() * strategy_ret).fillna(0)
        self.pnls = pd.concat({k: v.get_pnl(False) for k, v in self.bts.items()}, axis=1)
        self.returns = pd.concat({k: v.get_returns() for k, v in self.bts.items()}, axis=1)

        self.bts_dd1 = w.Dropdown(options=[*self.bts, None], description='allocator')
        self.mask_weights = w.Checkbox(description='mask')
        self.dates_dd1 = w.Dropdown(options=[None, *bt.weights_.index], description='date')
        self.assets_dd1 = w.Dropdown(options=[None, *bt.weights_.columns], description='asset')
        self.out1 = w.interactive_output(self._plot_weights,
                                         dict(key=self.bts_dd1, index=self.dates_dd1,
                                              col=self.assets_dd1, mask=self.mask_weights))
        self.tab1 = w.VBox(
            [
                w.HBox([w.VBox([self.bts_dd1, self.dates_dd1]), w.VBox([self.assets_dd1, self.mask_weights])]),
                self.out1
            ]
        )

        self.bts_dd2 = w.Dropdown(options=self.bts.keys(), description='allocator')
        self.dates_dd2 = w.Dropdown(options=[None, *bt.weights_.index], description='date')
        self.assets_dd2 = w.Dropdown(options=[None, *bt.weights_.columns], description='asset')
        self.out2 = w.interactive_output(self._plot_contrib,
                                         dict(key=self.bts_dd2, index=self.dates_dd2, col=self.assets_dd2))
        self.tab2 = w.VBox(
            [
                w.HBox([self.bts_dd2, self.dates_dd2, self.assets_dd2]),
                self.out2
            ]
        )

        self.exclude = w.SelectMultiple(options=self.contrib.columns, description='exclude')
        self.dates_range = self._build_date_range_slider(self.pnls)
        # self.out3 = w.interactive_output(self._plot_pnls, {'dates': self.dates_range})
        self.out3 = w.Output()

        def onclick(change=None):

            self.pnls = pd.concat({k: v.get_pnl(False, exclude=[*self.exclude.value]) for k, v in self.bts.items()},
                                  axis=1)

            d1 = pd.to_datetime(self.dates_range.value[0].strip(), dayfirst=True)
            d2 = pd.to_datetime(self.dates_range.value[1].strip(), dayfirst=True)
            with self.out3:
                self.out3.clear_output()
                display(((self.pnls.loc[d1:d2].diff().cumsum()).fillna(0) + 1).plot())

        self.calc = w.Button(
            description='run',
            button_style='',  # 'success', 'info', 'warning', 'danger' or ''
            icon='check'
        )
        self.calc.on_click(onclick)

        self.clear = w.Button(
            description='clear',
            button_style='',  # 'success', 'info', 'warning', 'danger' or ''
            icon='timess'
        )

        def onclick_clear(change):
            self.exclude.value = ([])

        self.clear.on_click(onclick_clear)

        self.tab3 = w.VBox([
            w.HBox([
                self.exclude, w.VBox([
                    self.dates_range,
                    w.HBox([self.clear, self.calc])
                ], layout=dict(width='500px'))
            ]),
            self.out3,
        ])
        onclick()

        self.mask = w.Checkbox(description='mask')
        self.out4 = w.interactive_output(self._plot_signals, {'mask': self.mask})
        self.tab4 = w.VBox([self.mask, self.out4])

        self.dates_range5 = self._build_date_range_slider(self.returns)
        self.out5 = w.interactive_output(self._get_measures, {'dates': self.dates_range5})
        self.tab5 = w.VBox([self.dates_range5, self.out5])

        self.app = w.Tab()
        self.app.children = [self.tab3, self.tab4, self.tab1, self.tab2, self.tab5]
        for i, title in enumerate(['pnl', 'signals', 'weights', 'contribution', 'measures']):
            self.app.set_title(i, title)

    def _plot_weights(self, key, index, col, mask):

        if not key:
            if not index:
                index = self.dates_dd1.options[1]

            all_weights = pd.concat([
                bt.weights_.loc[index].rename(name) if not mask else
                (bt.weights_.loc[index] * self.signals.loc[index]).rename(name)
                for name, bt in self.bts.items()], axis=1)

            display(all_weights.T.plot.bar())

            return

        self._set_data(key)

        mult = 1 if not mask else self.signals.loc[self.bt.risk_weights_.index[0]:]
        weights = self.bt.risk_weights_ * mult

        if index and col:
            fig = weights.loc[[index], [col]]
        elif index:
            fig = weights.loc[index, :].plot.bar()
        elif col:
            fig = weights.loc[:, col].plot(kind='scatter')
            fig.update_xaxes(
                rangebreaks=[dict(bounds=["sat", "mon"])]
            )
            fig.update_layout(bargap=0)
        else:
            fig = weights.plot.bar()
            fig.update_xaxes(
                rangebreaks=[dict(bounds=["sat", "mon"])]
            )
            fig.update_layout(bargap=0)

        display(fig)

    def _plot_contrib(self, key, index, col):
        self._set_data(key)
        if index and col:
            display(self.contrib.loc[[index], [col]])

        elif index:
            display(self.contrib.loc[index, :].plot.bar())
        elif col:
            display(self.contrib.cumsum().loc[:, col].plot())
        else:
            display(self.contrib.cumsum().plot.area())

    def _plot_pnls(self, dates):
        d1 = pd.to_datetime(dates[0].strip(), dayfirst=True)
        d2 = pd.to_datetime(dates[1].strip(), dayfirst=True)
        display(((self.pnls.loc[d1:d2].diff().cumsum()).fillna(0) + 1).plot())

    def _plot_signals(self, mask=False):
        signals = self.signals.dropna(how='all') if not mask else self.signals.dropna(how='all').notna().astype(int)
        fig = signals.plot.bar()
        fig.update_xaxes(
            rangebreaks=[dict(bounds=["sat", "mon"])]
        )
        fig.update_layout(bargap=0)
        display(fig)

    def _get_measures(self, dates):
        d1 = dates[0].strip()
        d2 = dates[1].strip()
        r = self.returns.loc[d1:d2]
        mean = r.mean()
        std = r.std()
        var = r.quantile(0.05)
        dd_dev = r[r < 0].std()
        df = pd.DataFrame(dict(
            ann_ret=r.sum() / len(r) * 252,
            std=std,
            var5=var,
            cvar5=r[r <= var].mean(),
            sharpe_ratio=mean / std * (252 ** 0.5),
            sortino_ratio=mean / dd_dev,
            max_dd=drawdowns(r).min(),

        )).T

        def highlight_max(s):
            '''
            highlight the maximum in a Series yellow.
            '''
            is_max = s == s.max()
            return ['background-color: palegreen' if v else '' for v in is_max]

        def highlight_min(s):
            '''
            highlight the maximum in a Series yellow.
            '''
            is_min = s == s.min()
            return ['background-color: tomato' if v else '' for v in is_min]

        display(df.style.apply(highlight_max, axis=1).apply(highlight_min, axis=1))
        return df

    def _set_data(self, key):
        if self._bt_key != key:
            self.bt = self.bts[key]
            self._bt_key = key

            strategy_ret = self.bt.portfolio.get_returns().loc[self.bt.risk_weights_.index[0:]]
            self.contrib = self.bt.risk_weights_.reindex(strategy_ret.index).bfill() * strategy_ret

    @staticmethod
    def _build_date_range_slider(x, datetime_format='%d-%m-%Y'):
        lbound = x.first_valid_index().strftime(f'  {datetime_format}  ')

        ubound = x.index[-1].strftime(f'  {datetime_format}  ')
        value = (lbound, ubound)
        options = x.loc[x.first_valid_index():].index.strftime(f'  {datetime_format}  ')
        return w.SelectionRangeSlider(options=options, value=value, layout=w.Layout(width='80%'),
                                      continuous_update=False)

    def _ipython_display_(self):
        return display(self.app)


def drawdowns(returns, compound=False):
    levels = 1 + returns.cumsum() if compound else (1 + returns).cumprod()
    return (levels / levels.cummax() - 1) if compound else levels - levels.cummax()


