from functools import wraps
from itertools import chain

import numpy as np
import pandas as pd

__all__ = (
    'sklearn_one_param_mixin',
    'refit',
    'BaseEstimator',
    'OneParamMixin',
    'PandasMixin',
    'StandardDeviation',
    'Mean',
    'Covariance',
    'VaR',
    'CVaR',
)


class Ptf:
    def __call__(self, returns, weights):
        return returns @ weights


def to_pandas(pd_obj, array):
    array = array.squeeze()
    if array.ndim <= 1:
        return pd.Series(array, index=pd_obj.columns)
    else:
        return pd.DataFrame(array, index=pd_obj.columns, columns=pd_obj.columns)


def sklearn_one_param_mixin(param, bases=None):

    default_bases = (OneParamMixin, BaseEstimator)

    if bases:
        new_bases = [*bases]
        mro = set([*chain.from_iterable([base.__mro__ for base in new_bases])])

        for default_base in default_bases:
            if default_base not in mro:
                new_bases.append(default_base)
    else:
        new_bases = default_bases

    def decorator(cls):
        class Wrapper(*new_bases):
            _param = param

            @wraps(cls.__init__)
            def __init__(self, *args, **kwargs):
                # cls.__init__(self)
                self.obj = cls(*args, **kwargs)

            def fit(self, returns, **kwargs):
                if not self.obj._get_tags().get('allow_nan', True):
                    returns = returns.dropna()
                y = kwargs.pop('y', None)
                self.obj.fit(X=returns, y=y)
                setattr(self, param, to_pandas(pd_obj=returns, array=getattr(self.obj, param)))
                self._fitted = True
                return self

        Wrapper.__name__ = cls.__name__
        Wrapper.__qualname__ = cls.__qualname__
        return Wrapper
    return decorator


def refit(fn):
    @wraps(fn)
    def wrapper(self, returns, **kwargs):
        if kwargs.get('refit', True) or not self.fitted:
            return fn(self, returns, **kwargs)
        return self
    return wrapper


# def fitted(fn):
#     @wraps(fn)
#     def wrapper(self, returns, **kwargs):
#         fn(self, returns, kwargs)
#         self.fitted = True
#         return self
#     return wrapper

# def check_fitted(fn):
#     @wraps(fn)
#     def wrapper(self, *args, **kwargs):
#         try:
#             check_is_fitted(self)
#         except NotFittedError:
#             self.fit(*args, **kwargs)
#
#         return fn(self, *args, **kwargs)
#     return wrapper


class BaseEstimator:
    @property
    def fitted(self):
        try:
            fitted = self._fitted
        except AttributeError:
            return False
        else:
            return True

    def __repr__(self):
        strings = [f'{k}={v}' for k, v in vars(self).items()
                   if (not k.startswith('_') and not k.endswith('_'))]
        sep = ', ' if len(strings) > 1 else ''
        string = sep.join(strings)

        return f'{self.__class__.__name__}({string})'


class OneParamMixin:
    @property
    def param_(self):
        return getattr(self, self._param)

    @property
    def risk_(self):
        return self.param_


class PandasMixin:
    def __init__(self, **kwargs):
        self.kwargs = kwargs

    @refit
    def fit(self, returns, **kwargs):
        fn = getattr(returns, self._fn)
        setattr(self, self._param, fn(**self.kwargs))
        self._fitted = True
        return self


class StandardDeviation(OneParamMixin, BaseEstimator):
    _param = 'std_'


class Mean(OneParamMixin, BaseEstimator):
    _param = 'mean_'

    def ptf(self, returns=None, weights=None, **kwargs):
        self.fit(returns=returns, **kwargs)
        return self.param_ @ weights


class Covariance(OneParamMixin, BaseEstimator):
    _param = 'cov_'

    @property
    def risk_(self):
        # it returns the standard deviation for each asset
        return pd.Series(np.diag(self.param_) ** 0.5, index=self.param_.index)

    def ptf(self, returns=None, weights=None, **kwargs):
        '''
        Parameters
        ----------
        returns: pandas dataframe
        weights: pandas series
        kwargs: additional parameters

        Returns
        -------

        '''
        # it returns the standard deviation of the portfolio
        self.fit(returns=returns, **kwargs)
        return (weights @ self.param_ @ weights) ** 0.5

    def rc(self, returns=None, weights=None, **kwargs):
        '''

        Parameters
        ----------
        returns: pandas dataframe
        weights: pandas series
        kwargs: additional parameters

        Returns
        -------

        Notes
        -----
        #     - marginal: partial derivative
        #     - total: marginal * weights
        #     - relative: total / risk
        '''

        cov = self.fit(returns, **kwargs).param_
        sigma = (weights @ cov @ weights) ** 0.5
        mrc = (cov @ weights) / sigma

        total = weights * mrc
        relative = total / sigma

        self.trc_ = total
        self.mrc_ = mrc
        self.rrc_ = relative

        # self.rc_ = {
        #     'total': total,
        #     'marginal': mrc,
        #     'relative': relative
        # }

        return self

    @property
    def corr_(self):

        try:
            cov = self.param_
        except AttributeError:
            raise AttributeError('Estimator instance not yet fitted')
        v = np.sqrt(np.diag(cov))
        outer_v = np.outer(v, v)
        corr = cov / outer_v
        corr[cov == 0] = 0
        np.fill_diagonal(corr.values, 1)
        return corr


class VaR(OneParamMixin, BaseEstimator):
    _param = 'q_'

    def ptf(self, returns=None, weights=None, **kwargs):
        '''
        Parameters
        ----------
        returns: pandas dataframe
        weights: pandas series
        kwargs: additional parameters

        Returns
        -------

        '''
        # it returns the standard deviation of the portfolio
        ptf_returns = returns @ weights
        self.fit(returns=ptf_returns, **kwargs)
        return self.param_


class CVaR(OneParamMixin, BaseEstimator):
    _param = 'cvar_'

    def rc(self, returns=None, weights=None, **kwargs):
        '''
        :param returns:
        :param weights:
        # :param method: str.
        #     - marginal: partial derivative
        #     - total: marginal * weights
        #     - relative: total / risk
        :param kwargs:
        :return:
        '''

        # 1. calculate ptf returns
        ptf = returns @ weights
        # 2. calculate ptf VaR
        self.fit(ptf, **kwargs)

        var = self.var.param_
        cvar = self.param_

        # 3. filter assets rows <= ptf VaR, calculate mrc
        mrc = returns[ptf <= var].mean()

        total = weights * mrc
        relative = total / cvar

        self.trc_ = total
        self.mrc_ = mrc
        self.rrc_ = relative

        return self
