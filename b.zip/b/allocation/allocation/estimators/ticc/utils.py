import numpy as np
from scipy import stats

