from functools import wraps

import numpy as np
import pandas as pd
from scipy.spatial.distance import pdist, squareform

from .base import *

__all__ = (
    'SampleStandardDeviation',
    'SampleMean',
    'SampleCovariance',
    'SampleVaR',
    'SampleCVaR',
    'DistanceCorrelation',
    'GerberCovariance',
    'SharpeRatio',
    'EWM'
)


class SampleStandardDeviation(PandasMixin, StandardDeviation):
    _fn = 'std'


class SampleMean(PandasMixin, Mean):
    _fn = 'mean'


class FixedMean(Mean):
    def fit(self, returns=None, mean=None, **kwargs):
        self.mean_ = mean
        self._fitted = True
        return self


class SampleCovariance(PandasMixin, Covariance):
    _fn = 'cov'


class SampleVaR(PandasMixin, VaR):
    _fn = 'quantile'

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.kwargs.setdefault('q', 0.05)


class SampleCVaR(CVaR):

    def __init__(self, q=0.05):
        self.q = q
        self.var = SampleVaR(q=q)

    @refit
    def fit(self, returns, **kwargs):
        var = self.var.fit(returns, **kwargs).param_

        # the slicing based on boolean on pandas works differently than in numpy
        # assets < var returns a boolean matrix which is then used to slice assets.
        # In numpy this results in a flat array since clearly different columns will have
        # a different number of elements. In pandas instead this returns still an DataFrame
        # with same dimension as assets where all False are replaced with NaN.
        # Finally when you take the mean by default pandas ignore NaN and this is why the code below works.
        # Assuming now that assets and var are numpy arrays instead of a DataFrame, to achieve the same in numpy we do
        # np.mean(assets, axis=0, where=assets <= var)

        self.cvar_ = returns[returns <= var].mean()
        self._fitted = True
        return self


class EWM(OneParamMixin, BaseEstimator):

    def __init__(self, fn, **kwargs):
        self.fn = fn
        self.kwargs = kwargs
        self._param = f'{fn}_'

    def fit(self, returns, **kwargs):
        ewm = returns.ewm(**self.kwargs)
        fn = getattr(ewm, self.fn)
        res = fn()
        setattr(self, self._param, res.loc[returns.index[-1]])
        return self

    _ptf_fn = {
        'mean': Mean.ptf
    }

    def __getattr__(self, item):
        if item == 'ptf':
            try:
                return self._ptf_fn[self.fn].__get__(self)
            except KeyError:
                raise AttributeError(f'{self} object has no attribute ptf')
        else:
            raise AttributeError(f'{self} object has no attribute {item}')


class FixedEstimator:
    def __init__(self, estimator):
        self.estimator = estimator

    def fit(self, returns, **kwargs):
        return self.estimator[returns.index[-1]]


class DistanceCorrelation(OneParamMixin, BaseEstimator):
    _param = 'distance_'

    def __init__(self, cov=None, metric=None):
        '''
        :param cov: estimator
            The estimator for the covariance matrix
        :param metric: str
            If not None, after calculating the distance correlation it calculates the pairwise distances between columns
        '''
        self.cov = cov or SampleCovariance()
        self.metric = metric

    def fit(self, returns, **kwargs):

        self.cov.fit(returns, **kwargs)
        corr = self.corr_from_cov(self.cov.param_)
        dist_corr = ((1 - corr) / 2) ** 0.5

        if metric := self.metric:
            dist_corr = pd.DataFrame(
                data=squareform(pdist(dist_corr.to_numpy(), metric=metric)),
                index=dist_corr.index,
                columns=dist_corr.columns
            )
        self.distance_ = dist_corr
        return self

    def corr_from_cov(self, cov):
        v = np.sqrt(np.diag(cov))
        outer_v = np.outer(v, v)
        corr = cov / outer_v
        corr[cov == 0] = 0
        np.fill_diagonal(corr.values, 1)
        return corr


class SharpeRatio(OneParamMixin, BaseEstimator):
    _param = 'sr_'

    def __init__(self, mean=None, cov=None, risk_free=0):
        self.mean = mean or SampleMean()
        self.cov = cov or SampleCovariance()
        self.risk_free = risk_free

    def fit(self, returns, **kwargs):
        mean = self.mean.fit(returns=returns, **kwargs).param_
        self.cov.fit(returns=returns, **kwargs)
        self.sr_ = (mean - self.risk_free) / (self.cov.risk_ ** 0.5)
        return self

    def ptf(self, returns=None, weights=None, **kwargs):
        mean = self.mean.ptf(returns=returns, weights=weights, **kwargs)
        std = self.cov.ptf(returns=returns, weights=weights, **kwargs)
        return (mean - self.risk_free) / std


class GerberCovariance(Covariance):
    def __init__(
            self,
            threshold=None,
            c=0.5,
            diagonal=None,
            adjust=True
    ):
        self.threshold = threshold
        self.c = c
        self.diagonal = diagonal
        self.adjust = adjust

    def fit(self, returns, **kwargs):
        X = returns
        H = self.get_threshold(X)
        diagonal = np.diag(self.get_diagonal(X))
        cols = getattr(X, "columns", None)
        X = np.asarray(X)

        U = (X >= np.asarray(H[1])[None, :]).astype(int)
        D = (X <= np.asarray(H[0])[None, :]).astype(int)

        N_uu = U.T @ U
        N_dd = D.T @ D

        N_conc = N_uu + N_dd
        N_disc = U.T @ D + D.T @ U

        if self.adjust:
            N = ((~ U.astype(bool)) & (~ D.astype(bool))).astype(int)
            N_nn = N.T @ N
            denominator = len(X) - N_nn
        else:
            denominator = (N_conc + N_disc)

        self.G_ = pd.DataFrame((N_conc - N_disc) / denominator, index=cols, columns=cols)
        self.cov_ = pd.DataFrame(diagonal @ self.G_ @ diagonal, index=cols, columns=cols)
        return self

    @property
    def corr_(self):
        return self.G_

    def get_threshold(self, X):
        # must return a tuple with upper and lower threshold

        threshold = self.threshold
        if threshold is None:
            H = self.c * X.std()
            return (-H, H)
        elif callable(threshold):
            return threshold(X)
        else:
            return threshold

    def get_diagonal(self, X):
        diagonal = self.diagonal
        if diagonal is None:
            return np.diag(X.std())
        elif callable(diagonal):
            return np.diag(diagonal(X))
        else:
            return np.diag(diagonal)
