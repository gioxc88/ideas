import sys

import numpy as np
import pandas as pd
from sklearn import covariance

from .base import sklearn_one_param_mixin, Covariance

this_module = sys.modules[__name__]

__all__ = (
    'GraphicalLasso',
    'ShrunkCovariance',
    'LedoitWolf'
)

covariance_estimators = [
    covariance.GraphicalLasso,
    covariance.ShrunkCovariance,
    covariance.LedoitWolf
]


param_ = 'covariance_'
for estimator in covariance_estimators:
    estimator = sklearn_one_param_mixin(param_, bases=[Covariance])(estimator)

    # @property
    # def risk_(self):
    #     return pd.Series(np.diag(self.param_) ** 0.5, index=self.param_.index)
    #
    # @property
    # def corr_(self):
    #     try:
    #         cov = self.param_
    #     except AttributeError:
    #         raise AttributeError('Estimator instance not yet fitted')
    #     v = np.sqrt(np.diag(cov))
    #     outer_v = np.outer(v, v)
    #     corr = cov / outer_v
    #     corr[cov == 0] = 0
    #     np.fill_diagonal(corr.values, 1)
    #     return corr
    #
    # def ptf(self, returns=None, weights=None, **kwargs):
    #     '''
    #     Parameters
    #     ----------
    #     returns: pandas dataframe
    #     weights: pandas series
    #     kwargs: additional parameters
    #
    #     Returns
    #     -------
    #
    #     '''
    #     # it returns the standard deviation of the portfolio
    #     self.fit(returns=returns, **kwargs)
    #     return (weights @ self.param_ @ weights) ** 0.5
    #
    # def rc(self, returns=None, weights=None, **kwargs):
    #     '''
    #
    #     Parameters
    #     ----------
    #     returns: pandas dataframe
    #     weights: pandas series
    #     kwargs: additional parameters
    #
    #     Returns
    #     -------
    #
    #     Notes
    #     -----
    #     #     - marginal: partial derivative
    #     #     - total: marginal * weights
    #     #     - relative: total / risk
    #     '''
    #
    #     cov = self.fit(returns, **kwargs).param_
    #     sigma = (weights @ cov @ weights) ** 0.5
    #     mrc = (cov @ weights) / sigma
    #
    #     total = weights * mrc
    #     relative = total / sigma
    #
    #     self.trc_ = total
    #     self.mrc_ = mrc
    #     self.rrc_ = relative
    #
    #     # self.rc_ = {
    #     #     'total': total,
    #     #     'marginal': mrc,
    #     #     'relative': relative
    #     # }
    #
    #     return self
    #
    # estimator.risk_ = risk_
    # estimator.corr_ = corr_
    estimator.__module__ = __name__
    setattr(this_module, estimator.__name__, estimator)


