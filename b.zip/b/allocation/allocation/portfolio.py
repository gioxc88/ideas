import pandas as pd
from .strategies import LongStrategy, TestStrategy


__all__ = (
    'Portfolio',
)


class Portfolio:

    def __init__(self, strategies):

        '''

        Parameters
        ----------
        strategies
        '''
        '''
        :param strategies: a list of strategy instances
        '''
        self.strategies = strategies
        self._asset_prices_df = None
        self._asset_returns_df = None
        self._signals_df = None
        self._returns_df = None
        self._pnl_df = None

    def get_signals(self):
        if self._signals_df is None:
            self._signals_df = pd.concat([strategy.get_signals() for strategy in self.strategies], axis=1)
        return self._signals_df

    def get_returns(self):
        '''
        Returns: the strategies returns
        '''
        if self._returns_df is None:
            self._returns_df = pd.concat([strategy.get_returns() for strategy in self.strategies], axis=1)
        return self._returns_df

    def get_pnl(self, compound=True, p0=1, start_index=None, dropna=False):
        '''
        Returns: the strategies returns
        '''

        returns = self.get_returns()
        if dropna:
            returns = returns.dropna()
            return returns.r.prices(compound=compound, start_value=p0, start_index=start_index)
        if self._pnl_df is None:
            self._pnl_df = pd.concat([strategy.get_pnl(compound=compound, p0=p0) for strategy in self.strategies], axis=1)
        return self._pnl_df

    def get_asset_prices(self):
        '''
        Returns: the asset prices
        '''

        if self._asset_prices_df is None:
            self._asset_prices_df = pd.concat([strategy.get_asset_prices() for strategy in self.strategies], axis=1)
        return self._asset_prices_df

    def get_asset_returns(self):
        '''
        Returns: the returns of the underlying asset
        '''
        if self._asset_returns_df is None:
            self._asset_returns_df = pd.concat([strategy.get_asset_returns() for strategy in self.strategies], axis=1)
        return self._asset_returns_df

    def get_predictions(self):
        if getattr(self, '_predictions_df', None) is None:
            self._predictions_df = pd.concat([strategy.get_predictions() for strategy in self.strategies], axis=1)
        return self._predictions_df

    @classmethod
    def from_assets(cls, assets):
        strategies = [LongStrategy(asset) for col, asset in assets.iteritems()]
        self = cls(strategies)
        return self

    @classmethod
    def from_assets_and_signals(cls, assets, signals):

        cols = assets.columns.intersection(signals.columns)
        strategies = [TestStrategy(asset=assets[col], signals=signals[col]) for col in cols]
        self = cls(strategies)
        return self

    # def switch(self, loc, active=False):
    #     # it is possible that signals df has shorter index
    #     # than assets dataframe
    #     signals = self.get_signals()
    #     assets = self.get_assets().reindex(signals.index)
    #     iloc = loc if isinstance(loc, int) else assets.index.get_loc(loc)
    #     signals = signals.iloc[iloc].to_numpy()
    #
    #     if active:
    #         active_mask = signals != 0
    #         signals = signals[active_mask]
    #         assets = assets.loc[:, active_mask]
    #
    #     assets = assets[:iloc]
    #     return assets * signals

    def __getitem__(self, item):
        return self.strategies[item]

    def __len__(self):
        return len(self.strategies)

    def __repr__(self):
        return f'{self.__class__.__name__}(n_assets={len(self)})'
