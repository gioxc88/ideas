# built in

from datetime import datetime

# third party
import numpy as np
import pandas as pd

from scipy import stats

# internal
from .portfolio import Portfolio
from .strategies import SimpleRandomStrategy


rng = np.random.default_rng(7)


__all__ = (
    'RandomPortfolioGenerator',
)


def random_cor(
        eig=None,
        n=10,
        eig_dist='uniform',
        **kwargs
):
    # the method for generating random correlation matrix relies on random eigenvalues generation
    # the sum of the eigenvalues must equal n (the size of the correlation matrix)
    # we must rescale eigenvalues to sum up to n
    # sum(x_i) = s
    # we want a constant k such that:
    # k * sum(x_i) = n
    # k = n / sum(x_i) = n / s

    if eig is None:
        eig_dist = getattr(rng, eig_dist)
        eig = abs(eig_dist(size=n, **kwargs))

    eig *= n / eig.sum()
    return stats.random_correlation.rvs(eig)


def random_cov(
        sigma=None,
        n=None,
        sigma_dist='uniform',
        sigma_params: dict = None,
        return_cor=False,
        **kwargs
):
    # square matrix where the ij-th element is sigma_i * sigma_j
    if sigma is None:
        sigma_params = sigma_params or {}
        if sigma_dist == 'uniform':
            sigma_params.setdefault('high', 0.05)
            sigma_params.setdefault('low', 0.005)
        sigma_dist = getattr(rng, sigma_dist)
        sigma = abs(sigma_dist(size=n, **sigma_params))
    else:
        sigma = np.array(sigma)
    var = sigma.reshape(-1, 1) @ sigma.reshape(1, -1)

    cor = random_cor(n=n, **kwargs)
    cov = cor * var
    out = (cov, cor) if return_cor else cov

    return out


class RandomPortfolioGenerator:
    def __init__(
            self,
            n_assets=10,
            n_obs=1000,
            mu=None,
            cov=None,
            mu_dist='uniform',
            mu_params=None,
            freq='B',
            columns=None,
            start=datetime(2000, 1, 1),
            **kwargs
    ):
        self.n_assets = n_assets
        self.n_obs = n_obs
        self.mu = mu
        self.cov = cov
        self.mu_dist = mu_dist
        self.mu_params = mu_params
        self.columns = columns
        self.freq = freq
        self.start = start
        self.kwargs = kwargs

    def make(self):

        if self.cov is None:
            cov = random_cov(n=self.n_assets, **self.kwargs)
            self.cov = pd.DataFrame(cov, index=self.columns, columns=self.columns)
        if self.mu is None:
            mu_params = self.mu_params or {}
            if self.mu_dist == 'uniform':
                mu_params.setdefault('low', -0.01)
                mu_params.setdefault('high', 0.02)
            mu_dist = getattr(rng, self.mu_dist)
            mu = mu_dist(size=self.n_assets, **mu_params)
            self.mu = pd.Series(mu, index=self.columns)

        self.X = pd.DataFrame(
            data=rng.multivariate_normal(self.mu, self.cov, size=(self.n_obs,)),
            index=pd.date_range(start=self.start, periods=self.n_obs, freq=self.freq),
            columns=self.columns,
        )

        self.ptf = Portfolio([SimpleRandomStrategy(x) for i, x in self.X.iteritems()])
        return self


def slice_and_switch(assets, signals, loc, active=False, existing=False, switch=False):
        '''
        :param assets:
        :param signals:
        :param loc:
        :param active: bool
            if the signal was not 0
        :param existing: bool
            if the signal was already present. It can be not present because it's only available at a later date
        :param switch: if to change the sign of the assets based on the specific signal
        :return:
        '''
        assets_iloc = loc if isinstance(loc, int) else assets.index.get_loc(loc)
        signals_iloc = loc if isinstance(loc, int) else signals.index.get_loc(loc)
        current_signals = signals.iloc[signals_iloc].to_numpy()

        if active:
            mask = current_signals != 0
        if existing:
            existing_mask = ~np.isnan(current_signals)
            try:
                mask = mask & existing_mask
            except NameError:
                mask = existing_mask

            current_signals = current_signals[mask]
            assets = assets.loc[:, mask]

        assets = assets[:assets_iloc]
        if switch:
            assets = assets * current_signals
        return assets


def corr_from_cov(cov):
    v = np.sqrt(np.diag(cov))
    outer_v = np.outer(v, v)
    corr = cov / outer_v
    corr[cov == 0] = 0
    np.fill_diagonal(corr.values, 1)
    return corr

# def set_mpl(backend=None, interactive=True, **kwargs):
#     import matplotlib as mpl
#     if backend:
#         mpl.use(backend)
#     mpl.interactive(interactive)

