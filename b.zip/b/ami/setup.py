import setuptools
import pathlib
from pathlib import Path

file = pathlib.Path(__file__).parent / 'requirements.txt'
req = [line.strip() for line in file.read_text().splitlines()]

def package_data(patterns):
    # this assumes setup.py lives in the folder that contains the package
    package_root = Path(__file__).parent / 'ami'
    file_list = [str(path.relative_to(package_root))
                     for p in patterns
                     for path in package_root.glob(p)]
    print(file_list)
    return {'ami': file_list}


setuptools.setup(
    name="Ami",
    version="0.0.20",
    author="BH Macrobot Team",
    description="Artificial Macro Intelligence",
    packages=setuptools.find_packages(),
    include_package_data=True,
    package_data=package_data(['**/*.json', '**/*.jinja2']),
    classifiers=[
        "Programming Language :: Python :: 3.8",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.8',
    install_requires=req
)
