# WofoMaker

A project that can generate Symawofo models and source code, from the simplified json spec. It can also loads and save the production model

