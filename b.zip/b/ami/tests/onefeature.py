import os
import sys

from datetime import datetime
from pathlib import Path

import pandas as pd
import numpy as np

from macro_utils import DotDict
from symawofo.ensemble import BaggingRegressor, FeatureEnsemble
from symawofo import FeatureFrame, WindowFrame, model_selection
from symawofo.signals.wf import ThresholdSignSignal
from symawofo.pnl import PNL, AssetType
from symawofo.transformers import (
    Clipper,
    Difference,
    make_column_transformer,
    make_pipeline,
    StandardScaler,
    TransformedTargetRegressor
)
from ami.build.common import (
    make_pca_column_transformer,
    make_pca_diff_column_transformer,
    make_local_data_passthrough,
    FeatureCallable,
    make_data_splitter,
    make_preprocessing,
    set_output_path
)
from ami.macrobot.models import GRURegressor, CNNRegressor
from ami.build.loss import SampleWeightDecay

import warnings

warnings.filterwarnings("ignore")

import tensorflow as tf

tf.get_logger().setLevel('ERROR')

from symawofo import get_client

client = get_client(silence_logs=50)

# Tensorflow Model definition

from typing import Iterable

from symawofo.models.base import model
from symawofo.models.tf import BaseTFRegressor3d
from tensorflow.keras import regularizers
from tensorflow.keras.layers import (BatchNormalization, Dense, Dropout, GRU)
from ami.macrobot.models import GRURegressor

# @model(BaseTFRegressor3d)
# class GRURegressor:
#     def __init__(
#             self,
#             nodes=15,
#             lookback_periods=13,
#             activation="selu",
#             kernel_initializer='random_uniform',
#             regularizer_l1=0.05,
#             regularizer_l2=0.0,
#             recurrent_dropout=0.0,
#             dropout=0.0,
#             dense_units: Iterable = tuple(),
#             batchnorm=True,
#             batchnorm_trainable=True,
#             batchnorm_training=False,
#             epochs=100,
#             batch_size=None,
#             use_bias=False,
#             recurrent_activation='hard_sigmoid',
#             reset_after=False,
#             implementation=1,
#             **kwargs
#     ):
#         super().__init__(**kwargs)

#         # for param in inspect.signature(self).parameters.values():
#         #     setattr(self, param.name, param.default if param.name != 'dense_layers_list' else [])

#         self.nodes = nodes
#         self.lookback_periods = lookback_periods
#         self.activation = activation
#         self.kernel_initializer = kernel_initializer
#         self.regularizer_l1 = regularizer_l1
#         self.regularizer_l2 = regularizer_l2
#         self.recurrent_dropout = recurrent_dropout
#         self.dropout = dropout
#         self.dense_units = dense_units
#         self.batchnorm = batchnorm
#         self.batchnorm_training = batchnorm_training
#         self.batchnorm_trainable = batchnorm_trainable
#         self.batch_size = batch_size
#         self.epochs = epochs
#         self.use_bias = use_bias
#         self.recurrent_activation = recurrent_activation
#         self.reset_after = reset_after
#         self.implementation = implementation

#     def _hidden_layers(self, x):
#         if self.dropout:
#             x = Dropout(self.dropout)(x)

#         x = GRU(
#             self.nodes,
#             activation=self.activation,
#             recurrent_dropout=self.recurrent_dropout,
#             return_sequences=False,
#             kernel_initializer=self.kernel_initializer,
#             kernel_regularizer=regularizers.l1_l2(self.regularizer_l1, self.regularizer_l2),
#             activity_regularizer=regularizers.l2(0.0),
#             use_bias=self.use_bias,
#             recurrent_activation=self.recurrent_activation,
#             reset_after=self.reset_after,
#             implementation=self.implementation
#         )(x)

#         dense_units = self.dense_units or []
#         for n in dense_units:
#             x = Dense(
#                 n,
#                 activation=self.activation,
#                 name=f'extra_dense{n}',
#                 kernel_regularizer=regularizers.l1_l2(0.01, 0.01)
#             )(x)

#         if self.batchnorm:
#             x = BatchNormalization(trainable=self.batchnorm_trainable)(x, training=self.batchnorm_training)

#         x = Dense(
#             1,
#             activation='linear',
#             use_bias=self.use_bias,
#             kernel_initializer='random_uniform',
#             name='prediction'
#         )(x)

#         return x


from symawofo.models.xgboost import XGBRegressor

# Feature transformation and Embeded models

from symawofo.models.sk import LassoCV, LinearRegression
from itertools import chain


def make_feature_transform(config: DotDict):
    tr_pca_levels = make_pca_column_transformer(config.PCA)
    tr_pca_diffs = make_pca_diff_column_transformer(config.PCA_diff)
    tr_level_features = [('passthrough', config.pass_through)]
    tr_diffs = [(Difference(1), config.diff)]
    tr_local = make_local_data_passthrough(config)
    ct = tr_level_features + tr_diffs + tr_local  # tr_pca_levels + tr_pca_diffs +

    main_transform = make_pipeline(
        make_column_transformer(*ct, remainder='drop'),
        StandardScaler(),
        Clipper(-config.clip_level, config.clip_level)
    )

    if config.get('on_the_fly', []):
        p1 = [(main_transform, list(chain(*[i[1] for i in ct])))]
        print(p1[0][1])
        p2 = [('passthrough', tuples[0]) for tuples in config.get('on_the_fly', [])]
        ct2 = make_column_transformer(*(p1 + p2), remainder='drop')
        return ct2
    else:
        return main_transform


def make_model(**kwargs):
    kwargs.pop('loss')
    return LinearRegression(**kwargs)
    sample_weights_fn = SampleWeightDecay(kwargs.get('decay')) if kwargs.get('decay') else None
    if kwargs.pop('type') == 'GruModel':
        return GRURegressor(_sample_weight_fn=sample_weights_fn, **kwargs)
    else:
        return CNNRegressor(_sample_weight_fn=sample_weights_fn, **kwargs)


def get_FeatureEnsemble_params(spec):
    testing_features = spec.pop('features')
    feature_type = spec.pop('type')
    group = spec.pop('group')
    ignore_pca = spec.pop('ignore_pca')
    faulty_cond = (feature_type == ('core_features') and (group == 'combine'))
    warning = "feature_testing parameter 'group' cannot be 'combine' if feature_type is 'core_features' \nSet 'group' to 'separate' or False"
    assert not faulty_cond, warning
    if testing_features:
        features_callable = FeatureCallable(testing_features, group=group, ignore_pca=ignore_pca)
        spec[feature_type] = features_callable
    return spec


def make_ensemble_model(jobspec: DotDict):
    model = make_model(**jobspec.model)
    feature_transform = make_feature_transform(jobspec.features_transform)

    if ensemble := dict(jobspec.get('ensemble', {})):
        if ensemble.pop('type') == 'bagging':
            model = BaggingRegressor(model, **ensemble)

    if feature_testing := jobspec.get('feature_testing', None):
        feature_params = get_FeatureEnsemble_params(dict(feature_testing))
        model = FeatureEnsemble(model, **feature_params)

    estimator = make_pipeline(
        feature_transform,
        model
    )
    return estimator  # TransformedTargetRegressor(estimator, jobspec.target.transform)


def make_window_frame(jobspec: DotDict, data, output_path=None, experiment=None):
    target = data[jobspec.target.name]
    modeling_features = FeatureFrame(data=data)
    modeling_target = make_preprocessing(target, **jobspec.target)
    splitter = make_data_splitter(jobspec)
    targetRegressor = make_ensemble_model(jobspec)
    accessors = jobspec.get('accessors', None)
    wf = WindowFrame(
        features=modeling_features,
        target=modeling_target,
        splitter=splitter,
        estimator=targetRegressor,
        output_path=output_path,
        accessors=accessors,
        experiment=experiment,
        **jobspec.windowframe,
    )
    return wf


def make_signal(jobspec: DotDict, window_frame: WindowFrame):
    return ThresholdSignSignal(window_frame, **jobspec.signal)


def make_pnl(jobspec: DotDict, signal, target):
    return PNL(signal,
               asset_type=AssetType(log=True, level=True),
               asset=target,
               **jobspec.trade)


from ami.macrobot.jobspec import MBJobspec
from ami.macrobot.runner import MacrobotRunner

spec = MBJobspec({
    "accessors": None,
    "data_splitter": {
        "expanding": 1,
        "initial_training_size": 325,
        "test_size": 13
    },
    #     "ensemble": {
    #         "agg_fn": None,
    #         "max_samples": None,
    #         "n_estimators": 1,
    #         "n_jobs": -1,
    # #         "parallel_backend": 'multiprocessing',
    #         "type": "bagging"
    #     },
    "features_transform": {
        "PCA": [
            #             "GLOB_Risk",
            #             "GLOB_Growth"
        ],
        "PCA_diff": [
            #             "AUD_Growth",
            "AUD_Inflation",
            #             "GLOB_Risk",
            #             "GLOB_Growth",
            #             "CH_Growth"
        ],
        "clip_level": 8,
        "data_startsfrom": "2005-06-17",
        "diff": [
            #             "CH_PMI_Man",
            #             "GLOB_Equity",
            #             "US_Bond_10y",
            #             "US_CECI",
            #             "US_eps_upgrade_ratio",
            #             "AUD_Bond_10ySp",
            #             "AUD_RBA_Cmdty",
            #             "US_Swap30y",
            #             "AUD_Swap_30y",
            #             "AUD_Swap_OIS_2y",
            #             "US_Swap_OIS_2y",
            #             "AUD_Breakeven10",
            #             "AUD_House_Prices",
            #             "AUD_CPI_Core",
            #             "GLOB_JPPMI_NO"
            #             "AUD_Bond_10y"
        ],
        "pass_through": [
            #             "AUD_Bond_10y_Fut_MASignal",
            #             "AUD_Bond_10y_Fut_RSI"
        ],

        "on_the_fly": [
            #              ('Iron_Ore_diff', ['Iron_Ore'], "ser.shift(1).diff(5)"),
            #             ('AUD_Bond_Sp2_diff', ['AUD_Bond_10y', 'US_Bond_10y'], "(df['AUD_Bond_10y']-df['US_Bond_10y'].shift(1)).diff(5)"),
            #             ('GLOB_Ind_metals_chg13', ['GLOB_Ind_metals'], "(ser.shift(1).diff(65)<0).astype(int)"),
            #             ('Glob_Oil_chg13', ['GLOB_Oil'], "(ser.shift(1).diff(45)<0).astype(int)"),
            ('AUD_Bond_10y_bin', ['AUD_Bond_10y'], "(ser.diff(5)>0).astype(int)")
        ]
    },
    #     "model": {
    #         "activation": "selu",
    #         "batch_size": 1000,
    #         "batchnorm": True,
    #         "batchnorm_trainable": True,
    #         "batchnorm_training": False,
    #         "dropout": 0.0,
    #         "epochs": 100,
    #         "lookback_periods": 1,
    #         "loss": "mse",
    #         "nodes": 29,
    #         "optimizer": "adam",
    #         "recurrent_dropout": 0.0,
    #         "regularizer_l1": 0.01,
    #         "regularizer_l2": 0.0005,
    #         "type": "GruModel",
    #         "use_bias": False,
    #     },
    "model": {
        "lags": 1,
        "loss": 'mse'
    },
    "signal": {
        "c": 0.1,
        "threshold": 0.0015,
    },
    "target": {
        "logreturn": True,
        "name": "AUD_Bond_10y_Fut",
        "prediction_lag": 1,
        "transform": "make_pipeline(StandardScaler(with_mean=True), Clipper(-1, 1))"
    },
    "trade": {
        "t_cost": 0.0005
    },
    "type": "MB_training",
    "windowframe": {
        "n_jobs": -1
    }
}).parse()

runner = MacrobotRunner(spec)

data = runner.get_data()

##  build the model

output_path = None
output_path = set_output_path(output_path, runner.jobspec)
start_time = datetime.now()
target = data[spec.target.name]
wf = make_window_frame(runner.jobspec, data, output_path=output_path)

w = wf[0]
w.fit()
w.estimator
