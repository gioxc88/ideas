import argparse
from ami.macrobot.MBPortfolio import MBPortfolio
from symawofo import get_client
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

def run(input_args):

    client = get_client(silence_logs=50)

    try:
        port = MBPortfolio(name=input_args.name, spec=input_args.spec,
                            mode=input_args.mode)
        port.run(runs=input_args.runs)
    except Exception as e:
        import traceback
        traceback.print_exc()
    finally:
        if input_args.shutdown_server:
            from ami.common.data_fetcher import DataFetcher
            DataFetcher().shutdown_this_server()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='run portfolio')
    parser.add_argument('--name', type=str,
                        help='name of portfolio to be written or used')
    parser.add_argument('--spec', type=str,
                        help='name of portfolio sepc')
    parser.add_argument('--runs', type=int, default=None, help='optional: only used to specify training runs')
    parser.add_argument('--mode', type=str, choices=['backtest', 'single_fit_forecast', 'forecast'],
                        default='single_fit_forecast')
    parser.add_argument('--shutdown-server', default=False, action='store_true',
                        help='shuts down the current running server after the job is finished')
    commandline_args = parser.parse_args()
    run(commandline_args)


