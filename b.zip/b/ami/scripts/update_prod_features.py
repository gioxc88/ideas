import requests

from ami.macrobot.MBPortfolio import MBPortfolio


def update_prod_ticker():
    port = MBPortfolio(name='test', spec='production', mode='backtest')
    for name, spec in port.asset_specs.items():
        print(name)
        features = spec.features_transform

        pass_throught = features.pass_through.names
        diff = features.diff.names
        pca = features.PCA
        pca_diff = features.PCA_diff

        res = requests.post(f'http://awsmbdev02.idm.rivagecapital.com/api/data/update_prod_groups/{name}', json=dict(
            features=pass_throught+diff,
            pca=pca+pca_diff
        ))
        print(res.text)


if __name__ == '__main__':
    update_prod_ticker()

    # notify server to generate the dump json-tree
    requests.get('http://awsmbdev02.idm.rivagecapital.com/api/data/dump_prod_tickers')
