import sys
sys.path.append(r'C:\SyMAWoFlo\Symawofo')
from pathlib import Path
from copy import deepcopy

from symawofo import FeatureFrame
from ami.build.macrobot import make_window_frame, make_preprocessing, make_strat
from ami.common.pickler import dump, load
from ami.macrobot.runner import MacrobotRunner
from ami.macrobot.jobspec import MBJobspec
import ami.macrobot.charting as charting_module
from symawofo.shared.utils import to_cpickle


class MBAsset:
    def __init__(self, asset_spec, port_path=None):
        self.asset_spec = asset_spec
        self.port_path = port_path
        self.asset_path = port_path / self.asset_name if port_path else Path('.') / self.asset_name
        self.asset_path.mkdir(parents=True, exist_ok=True)
        self.runner = MacrobotRunner(MBJobspec.load(asset_spec, 'training'))

    @staticmethod
    def update_spec(orig_spec, runs=None):
        spec = deepcopy(orig_spec)
        if hasattr(spec, 'ensemble'):
            spec.ensemble.n_estimators = runs or spec.ensemble.n_estimators
        # if hasattr(spec, 'windowframe'):
        #     spec.windowframe.n_jobs = None
        return spec

    def fit(self, runs=None, single_window=True, data=None):
        spec = self.update_spec(self.runner.jobspec, runs)
        data = data if data is not None else self.runner.get_data()
        target = data[spec.target.name]
        wf = make_window_frame(spec, data, output_path=self.asset_path, experiment='')
        if single_window:
            strat = make_strat(wf, spec, target)
            strat.update_data(data, target)
            wf.fitted = True
            dump(locals(), folder=self.asset_path)

        else:
            wf.fit_predict()
            strat = make_strat(wf, spec, target)
            strat.get_pnl()

            # refit and save the last windows
            wf[-1].fit()

            dump(locals(), folder=self.asset_path)

            for charter in self.runner.jobspec.charting:
                CharterClass = getattr(charting_module, charter)
                charter = CharterClass(strat, target, accessors_data=wf.data_)
                charter.save_charts(self.asset_path)

            to_cpickle(wf.data_, self.asset_path / 'accessor_data.h5')
        to_cpickle(self, self.asset_path / 'MBAsset.h5')

        return wf

    def forecast(self, save_path=None):
        spec = self.update_spec(self.runner.jobspec)
        data = self.runner.get_data(all='True', dropna=False).ffill()
        target = make_preprocessing(data[spec.target.name], **spec.target)
        strat = self.get_strat(data, target)

        if save_path:
            forecast_asset_path = save_path / spec.name
            forecast_asset_path.mkdir(parents=True, exist_ok=True)

            accessor_data = strat.wf.data_
            dump(locals(), folder=forecast_asset_path,
                 obj_to_save = ['spec', 'data', 'target', 'strat', 'accessor_data'])

        print(spec.name, 'forecasted')
        return strat

    @property
    def asset_name(self):
        if isinstance(self.asset_spec, Path):
            return self.asset_spec.name[:-5]
        elif isinstance(self.asset_spec, MBJobspec):
            return self.asset_spec.name


    def get_strat(self, X_predict, target):
        strat = load(self.asset_path / 'strat.h5')
        strat.update_data(features=X_predict, target=target)
        return strat
