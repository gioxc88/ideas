import inspect
from datetime import datetime
from pathlib import Path

from ami.common.nb_builder import NotebookBuilder
from ami.macrobot.research_data import on_the_fly_features


class MBNotebookBuilder(NotebookBuilder):

    def __init__(self, jobspec, module, type='training'):

        if type == 'training':
            template_path = 'macrobot/ipynb_gen/training.jinja2'
        elif type == 'feature_testing':
            template_path = 'macrobot/ipynb_gen/feature_testing.jinja2'
        elif type == 'hyptesting':
            template_path = 'macrobot/ipynb_gen/hyptesting.jinja2'
        elif type == 'forecast':
            template_path = 'macrobot/ipynb_gen/forecast_prod.jinja2'
        elif type == 'linear':
            template_path = 'macrobot/ipynb_gen/linear.jinja2'

        name = f'MB_{jobspec.name}_{type}_{datetime.now():%Y-%m-%d}'

        super().__init__(jobspec, module, template_path, name=name)
        if type == 'hyptesting':
            self.hyper_testing_modification()
        elif type == 'training' and hasattr(self.jobspec, 'ensemble'):
            self.jobspec.ensemble.n_estimators = 6

        self.type = type  # can be 'training' or 'feature_testing'
        self.on_the_fly_features = on_the_fly_features.get(jobspec.name, '')


    def hyper_testing_modification(self):
        self.script.make_ensemble_model = '''
            def make_ensemble_model(jobspec):
                model = make_model(**jobspec.model)
                feature_transform = make_feature_transform(jobspec.features_transform)
                model = make_pipeline(feature_transform, model)
                model = TransformedTargetRegressor(model, jobspec.target.transform)

                if hyperparam_testing := jobspec.get('hyptesting', None):
                    Hyptest_Model = eval(hyperparam_testing.pop('type', 'BayesSearchCV'), model_selection.__dict__)
                    model = Hyptest_Model(model, **hyperparam_testing)

                if ensemble := dict(jobspec.ensemble):
                    if ensemble.pop('type') == 'bagging':
                        model = BaggingRegressor(model, **ensemble)
                return model
            '''

    def get_model_code(self):
        model_class = self.script.make_model(**self.jobspec.model).__class__
        file_path = inspect.getfile(model_class)
        model_source = Path(file_path).read_text()

        return f'''
# %% [markdown]
## Tensorflow Model definition

# %%
{model_source}
    '''

