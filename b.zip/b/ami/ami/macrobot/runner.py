from itertools import chain

import pandas as pd
from IPython.core.display import display, HTML

from ami import build
from ami.common.base_runner import baseRunner
from ami.macrobot.jobspec import MBJobspec
from ami.macrobot.nb_builder import MBNotebookBuilder


class MacrobotRunner(baseRunner):

    def __init__(self, asset):
        super().__init__(None)
        self.orig_jobspec = MBJobspec.load(asset)
        self.jobspec = self.orig_jobspec.clone().parse()

    def get_pca(self):
        pca = self.jobspec.features_transform.PCA + self.jobspec.features_transform.PCA_diff
        if len(pca):
            return self.fetcher.get_pca(pca)
        else:
            return pd.DataFrame()

    def get_jobspec_feature(self, **kwargs):
        all_features = [group['names'] for name, group in self.jobspec.features_transform.items()
                            if isinstance(group, dict) and not 'PCA' in name]
        onthefly_names = {i[0] for i in getattr(self.jobspec, 'on_the_fly', [])}
        features = set(chain(*all_features)) - onthefly_names
        features.add(self.jobspec.target.name)

        print(f'requesting: {features}' )
        df = self.fetcher.get_features_by_names(names=list(features),
                                       data_startsfrom=self.jobspec.features_transform.data_startsfrom,
                                       **kwargs)
        return df

    def get_on_the_fly_data(self):
        on_the_fly_names = self.jobspec.get('on_the_fly', [])
        if len(on_the_fly_names):
            return self.fetcher.get_on_the_fly_transform(
                    self.jobspec.on_the_fly,
                    data_startsfrom=self.jobspec.features_transform.data_startsfrom
            )
        else:
            return pd.DataFrame()


    def get_data(self, dropna=True, drop_duplicate=True, **kwargs):
        server_data = self.get_jobspec_feature(**kwargs).dropna(axis=1, how='all')
        pca = self.get_pca().reindex(server_data.index)
        on_the_fly = self.get_on_the_fly_data().reindex(server_data.index)

        df = pd.concat([pca, on_the_fly], axis=1).ffill()
        for c in server_data:
            df[c] = server_data[c]       # overwrite any duplicates in pca data

        if dropna:
            df = df.dropna()

        if drop_duplicate:
            reversed = df.T
            if reversed.duplicated().any():
                duplicated_columns = list(reversed.duplicated(keep=False).loc[lambda x: x == True].index)
                dropped_columns = list(reversed.duplicated(keep='first').loc[lambda x: x == True].index)

                display(HTML(f'''
                <div style="background-color: LemonChiffon;">
                <h4>found columns with same values: </h4>
                <p>{duplicated_columns=}<br/><b>{dropped_columns=}</b><br/>
                If you want to keep these columns, please use runner.get_data(drop_duplicate=False).
                </p>
                </div>
                '''))
            return reversed.drop_duplicates().T  # drop duplicate columns
        else:
            return df


    def get_models(self):
        wf_fn = self.script.make_window_frame
        return wf_fn(self.jobspec, self.get_data())



    @classmethod
    def save_notebook(cls, asset, type='training', folder=None, **kwargs):
        '''
        :param type:  value be 'training' or 'feature_testing'
        :type type: str
        '''
        jobspec = MBJobspec.load(asset, type)
        MBNotebookBuilder(jobspec=jobspec,
                          module=build.macrobot,
                          type=type).save(folder, **kwargs)

