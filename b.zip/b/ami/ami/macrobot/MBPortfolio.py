from datetime import datetime
from itertools import chain
import numpy as np
import pandas as pd
import requests
import symawofo.strategies.ensemble as ensemble_module
from macro_utils import MACROBOT_PATH
from symawofo.shared.parallel import ParallelBackend
from symawofo.shared.utils import to_cpickle
from symawofo.allocation import MovingAllocator, Portfolio

from ami.common.pickler import dump, load
from ami.macrobot.jobspec import MBJobspec, MBPortSpec
from ami.macrobot.MBAsset import MBAsset

from symawofo import get_client


class MBPortfolio:
    def __init__(self, name, spec=None, mode='backtest', portfolio_dir=None,
                 backtest_dir=None, save_path=None):
        self.mode = mode
        self.init_path(name, portfolio_dir, backtest_dir, save_path)
        self.portspec = MBPortSpec.load(spec)
        self.asset_specs = self.get_asset_specs()

    def init_path(self, portfolio_name, portfolio_dir, backtest_dir, save_path):
        self.portfolio_name = portfolio_name
        self.portfolio_dir = portfolio_dir or (MACROBOT_PATH / 'AMI_Models' / portfolio_name)
        self.portfolio_dir.mkdir(parents=True, exist_ok=True)

        self.backtest_dir = backtest_dir or (self.portfolio_dir / 'backtest')
        self.backtest_dir.mkdir(parents=True, exist_ok=True)

        self.save_path = save_path
        if not save_path:
            if self.mode == 'forecast':
                now = datetime.now()
                self.save_path = self.portfolio_dir / f'forecast_{now:%Y%m%d_%H%M%S}'

            else:
                self.save_path = self.backtest_dir
        self.save_path.mkdir(parents=True, exist_ok=True)

    def get_asset_specs(self):
        if self.mode == 'forecast':
            # we load the spec from backtest, just incase the spec changed.
            return self.load_pickled_files('spec.h5', filter_assets=list(self.portspec.all_assets))
        else:
            return {asset: MBJobspec.load(asset, 'training') for asset in self.portspec.all_assets}

    def get_ensemble_port(self):
        return [MBPortfolio(name=sub.name, spec=sub, mode=self.mode, portfolio_dir=self.portfolio_dir,
                            backtest_dir=self.backtest_dir, save_path=self.save_path / sub.name)
                for sub in self.portspec.all_ensemble_specs]

    def load_pickled_files(self, file, from_folder=None, filter_assets=None):
        from_folder = from_folder or self.backtest_dir
        if filter_assets:
            paths = [p for p in from_folder.glob(f'**/{file}') if p.parent.name in filter_assets]
        else:
            paths = [p for p in from_folder.glob(f'**/{file}')]

        results = ParallelBackend(-1, 'threadpool').starmap(
            load,
            ((p,) for p in paths)
        )
        return {p.parent.name: r for p, r in zip(paths, results)}

    def load_csv_files(self, file, from_folder=None, filter_assets=None):
        from_folder = from_folder or self.save_path
        if filter_assets:
            paths = [p for p in from_folder.glob(f'**/{file}') if p.parent.name in filter_assets]
        else:
            paths = [p for p in from_folder.glob(f'**/{file}')]

        return {p.parent.name: pd.read_csv(p, index_col=0, parse_dates=True) for p in paths}

    def run(self, runs=None):
        if self.mode == 'backtest':
            # fit all assets
            [_fit_asset_in_chunk(group, self.backtest_dir, runs) for group in chunker(self.asset_specs.items(), 5)]
            self.generate_all_ensemble()

            # generate pnls
            for port in (self.get_ensemble_port() + [self]):
                port.cal_portfolio_pnl()

        elif self.mode == 'single_fit_forecast':

            with get_client(silence_logs=50) as client:
                ParallelBackend(-1, 'dask').starmap(
                    _fit_one_asset_on_last_windows,
                    ((spec, self.backtest_dir, runs) for name, spec in self.asset_specs.items())
                )
            self.generate_all_ensemble()

            print('------ Forecasting Done -----------')
            self.send_forecast_email()
            self.send_shaps_email()

        elif self.mode == 'forecast':
            print(self.asset_specs.keys())

            # collect forecast and send out the email first
            ParallelBackend(-1, 'dask').starmap(
                    _forecast_one_asset,
                    ((spec, self.backtest_dir, self.save_path) for name, spec in self.asset_specs.items())
            )
            self.generate_all_ensemble()

            print('------ Forecasting Done -----------')
            self.send_forecast_email()
            self.send_shaps_email()

        # save MB_portfolio to disk, it contains list of MBAssets and wf
        to_cpickle(self, self.save_path / 'MB_portfolio.h5')

    def generate_all_ensemble(self):
        # generate strategy for ensembles
        ParallelBackend(-1, 'dask').starmap(
                lambda p: p.save_ensemble_strategy(from_folder=self.save_path),
                ((p,) for p in self.get_ensemble_port())
        )

    def save_ensemble_strategy(self, from_folder):
        '''
        Note: the self here is the MBPortfolio instance with the ensemble spec.
        '''
        import ami.macrobot.charting as charting_module

        signals_names = self.portspec.assets + self.portspec.ensembles
        strat_dict = self.load_pickled_files('strat.h5',
                                             from_folder=from_folder,
                                             filter_assets=signals_names)

        spec = self.portspec

        cls = self.portspec.strategy.pop('type')
        strat = getattr(ensemble_module, cls)(strat_dict, **self.portspec.strategy)
        dump(locals(), folder=self.save_path)

        # adding charts for ensemble
        target = np.log(list(strat.strategies.values())[0].get_asset_prices())
        charting_module.BaseTrainChart(strat, target).save_charts(self.save_path,
                                                                  charts_to_save=['chart_ensemble_strategies'])

    def get_weights(self, signals):
        ma = MovingAllocator(
                ptf=Portfolio(signals),
                **self.portspec.allocator_params
        ).run()

        to_cpickle(ma, self.save_path / 'allocator.h5')
        ma.weights_.to_csv(self.save_path / 'weights.csv')
        return ma.weights_

    def cal_portfolio_pnl(self):
        signals_names = self.portspec.assets + self.portspec.ensembles
        strat_dict = self.load_pickled_files('strat.h5',
                                             from_folder=self.backtest_dir,
                                             filter_assets=signals_names)

        # for each assets, we aggregated 30 runs signals into one,
        # and changes the signal inplace, so pnl object is also modified with a
        # aggregated signal
        df_signals = pd.concat([s.get_signals().rename(name)
                                for name, s in strat_dict.items()], axis=1)

        # allocation and weights
        if hasattr(self.portspec, 'allocation'):
            weights = self.get_weights(strat_dict.values())
            df = pd.concat([p.get_pnl(weight=weights[p.get_asset_prices().name]).rename(name)
                            for name, p in strat_dict.items()], axis=1)
        else:
            df = pd.concat([p.get_pnl().rename(name) for name, p in strat_dict.items()], axis=1)

        df.to_csv(self.save_path / 'portfolio_pnl.csv')
        df_signals.to_csv(self.save_path / 'portfolio_signals.csv')

        return df


    @staticmethod
    def get_category(asset_name):
        if any(x in asset_name for x in ['Bond', 'Buxl']):
            print(asset_name)
            return 'Bond'
        elif 'FX' in asset_name:
            return 'FX'
        elif 'Equity' in asset_name:
            return 'Equity'
        else:
            return 'Other'


    def send_forecast_email(self, recipients=None):
        from macro_utils import set_default_style
        from datetime import datetime

        signals_dict = self.load_csv_files('signal.csv')
        threshold_dict = self.load_csv_files('threshold.csv')
        pred_dict = self.load_csv_files('prediction.csv')
        signals_names = self.portspec.assets + self.portspec.ensembles

        all_signals = pd.concat([
            pd.concat([v.squeeze().rename(k) for k, v in signals_dict.items()], axis=1).iloc[-1].rename('signal'),
            pd.concat([v.squeeze().rename(k) for k, v in pred_dict.items() if len(v.columns) == 1], axis=1).iloc[
                -1].rename('pred'),
            pd.concat([v.squeeze().rename(k) for k, v in threshold_dict.items()], axis=1).iloc[-1].rename('threshold'),
        ], axis=1)
        all_signals['diff'] = all_signals['pred'].abs() - all_signals['threshold']
        all_signals['Category'] = all_signals.index.map(self.get_category)
        all_signals = all_signals.rename_axis('assets').fillna(0)
        summary = all_signals.loc[signals_names].reset_index().set_index(['Category', 'assets']).sort_index()
        summary.to_csv(self.save_path / 'forecast_summary.csv')

        breakdown = pd.concat(
                [pd.concat([
                    pd.Series(data=p.name, index=p.all_assets, name='Ensemble'),
                    all_signals.loc[p.all_assets]
                ], axis=1) for p in self.portspec.all_ensemble_specs])
        breakdown = breakdown.reset_index().set_index(['Category', 'Ensemble', 'index']).sort_index()
        breakdown.to_csv(self.save_path / 'forecast_breakdown.csv')


        ######   Email styling
        recipients = recipients or ['#BHSystematicJG@brevanhoward.com']
        subject = 'Ami Forecast signal'

        summary_style = set_default_style(summary,
                                  color_columns=['signal', 'pred'],
                                  format=dict(
                                          signal='{:,.0f}',
                                          pred='{:,.5f}',
                                          threshold='{:,.5f}',
                                  ))
        breakdown_style = set_default_style(breakdown,
                                  color_columns=['signal', 'pred'],
                                  format=dict(
                                          signal='{:,.0f}',
                                          pred='{:,.5f}',
                                          threshold='{:,.5f}',
                                  ))

        requests.post('http://awsmbdev02.idm.rivagecapital.com/api/pnl/send_email', json=dict(
                subject=f"{subject} -- {self.portfolio_name}",
                display_from='Ami Forecast',
                recipients=recipients,
                header=subject,
                content_htmls=[
                    f"{self.save_path.name}",
                    f'Model: {self.portfolio_name}'
                    '<br/><br/>',
                    summary_style.render(),
                    f'<h5> Ensemble Breakdown </h5>',
                    breakdown_style.render()
                ],
                priority=4
        ))

    def send_shaps_email(self):
        from ami.macrobot.charting.shap_charting import ShapCompare

        data_dict = self.load_pickled_files('accessor_data.h5', from_folder=self.save_path)
        sc = ShapCompare(data_dict, self.save_path)
        sc.save_html()

def chunker(seq, size):
    seq = list(seq)
    return (seq[pos:pos + size] for pos in range(0, len(seq), size))

def _fit_asset_in_chunk(chunk_group, *args):
    # we fit one chunk group(5 assets) in dask parallelization and then restart dask workers

    with get_client(silence_logs=50) as client:
        ParallelBackend(-1, 'dask').starmap(
                _fit_one_asset,
                ((spec, *args) for name, spec in chunk_group)
        )

def _fit_one_asset(spec, port_path, runs):
    asset = MBAsset(spec, port_path=port_path)
    asset.fit(runs=runs, single_window=False)


def _fit_one_asset_on_last_windows(spec, port_path, runs):
    asset = MBAsset(spec, port_path=port_path)
    asset.fit(runs=runs, single_window=True)


def _forecast_one_asset(spec, port_path, save_path):
    asset = MBAsset(spec, port_path=port_path)
    asset.forecast(save_path)


def rename_ami(x):
    if '_Fut_' in x:
        return f"{x.split('_Fut_')[0]}_Fut"
    elif '_TR_' in x:
        return f"{x.split('_TR_')[0]}_TR"
