import pandas as pd
from shap import Explainer, GradientExplainer
from sklearn.linear_model._base import LinearModel
from symawofo.accessors.mixin import recursive_hierarchy, register
from symawofo.ensemble import BaggingRegressor, FeatureEnsemble
from symawofo.model_selection.skopt import BayesSearchCV
from symawofo.models.base import BaseModel2d, BaseModel
from symawofo.models.tf import BaseTFRegressor3d
from symawofo.windows import Window, WindowFrame


@register(BaseTFRegressor3d)
def collect_loss(self, **kwargs):
    return self.history_['loss']


@register(BaseTFRegressor3d)
def collect_val_loss(self, **kwargs):
    return self.history_['val_loss']


@register(LinearModel)
def collect_betas(self, **kwargs):
    return self.coef_


@register(Window)
def collect_date(self, **kwargs):
    return f'{self.training_end:%Y-%m-%d}'


@register(Window)
def collect_test_samples(self, **kwargs):
    if self.predictable:
        return self.get_samples(subset='test')


@register(WindowFrame, key='test_samples')
def finalize_test_samples(self, data):
    Xs, ys = zip(*recursive_hierarchy(data, 'collect_test_samples'))
    return pd.concat(Xs), pd.concat(ys)


@register(WindowFrame, key='loss')
def finalize_loss(self, data):
    losses = {}
    windows = recursive_hierarchy(data, 'window')
    if len(self.windows) == 1:
        windows = [windows]

    for window in windows:
        loss = recursive_hierarchy(window, 'collect_loss')
        val_loss = recursive_hierarchy(window, 'collect_val_loss')
        date = window['collect_date']

        losses[date] = pd.DataFrame(loss).T, pd.DataFrame(val_loss).T

    return losses


@register(BaseModel)
def collect_shap_value(self, **kwargs):
    X_train = self.get_samples(kwargs['X_fit'])
    X_test = self.get_samples(kwargs['X_predict'])

    if isinstance(self, BaseTFRegressor3d):
        explainer = GradientExplainer(self.model_, X_train)
        array = explainer.shap_values(X_test)[0]
        return pd.DataFrame(array.reshape(array.shape[0], -1),
                            index=kwargs['X_predict'].index[-array.shape[0]:],
                            columns=pd.MultiIndex.from_product([range(array.shape[1]),
                                                                list(kwargs['X_predict'].columns)],
                                                               names=['timestep', 'features'])
                            ).reorder_levels([1, 0], axis=1)
        # mean_values = array.mean(axis=1)
        # # if we need to return timestep diamension, return as a multiindex dataframe
        # return pd.DataFrame(
        #     mean_values,
        #     index=kwargs['X_predict'].index[-len(mean_values):],
        #    columns=kwargs['X_predict'].columns
        # )
    else:
        explainer = Explainer(self, X_train)
        array = explainer.shap_values(X_test)

        return pd.DataFrame(
            array,
            index=kwargs['X_predict'].index[-len(array):],
            columns=kwargs['X_predict'].columns
        ).rename_axis('features', axis=1)


@register(BaggingRegressor, BaseModel2d)
def collect_X_trans(self, **kwargs):
   diff_dates = set(kwargs['X_predict'].index) - set(kwargs['X_fit'].index)
   predict_dates = sorted([x for x in diff_dates
                            if x > kwargs['X_fit'].index[-1]])
   index = pd.DatetimeIndex(sorted(predict_dates))
   return kwargs['X_predict'].data.reindex(index)


@register(WindowFrame, key='shap_series')
def finalize_shap_series(self, data):

    shap = recursive_hierarchy(data, 'collect_shap_value')

    if isinstance(shap[0], list):
        levels = list(shap[0][0].columns.names)
        shap_series = pd.concat([

            # now a multiindex dataframe with levels ( bagging, timestep, features)
            pd.concat(window_data, axis=1, keys=range(len(window_data)),
                      names=['bagging'] + levels)
            for window_data in shap
        ])
        return shap_series.mean(level=levels, axis=1)
    else:
        return pd.concat(shap)






@register(WindowFrame, key='X_trans')
def finalize_X_trans(self, data):
    return pd.concat([
        window_data for window_data in recursive_hierarchy(data, 'collect_X_trans')
    ])


@register(FeatureEnsemble)
def collect_estimator_names(self, **kwargs):
    estimator_names = [key if isinstance(key, str) else ','.join(value) for key, value in
                       self.estimators_varying_features_.items()]
    if self.baseline:
        estimator_names.append('Baseline')
    return estimator_names


@register(WindowFrame, key='multiindex')
def finalize_multiindex(self, data):
    names = recursive_hierarchy(data, 'collect_estimator_names')[0]
    n = self[0].get_estimator(2).n_estimators
    return pd.MultiIndex.from_product([names, range(n)])


@register(BayesSearchCV)
def collect_bestparam(self, **kwargs):
    return self.best_params_


@register(WindowFrame, key='bestparams')
def finalize_bestparam(self, data):
    space = self.estimator.base_estimator.search_spaces
    collected_data = recursive_hierarchy(data, 'collect_bestparam')
    dates = recursive_hierarchy(data, 'collect_date')
    df = pd.DataFrame(collected_data, index=dates)

    return {param: df.applymap(lambda x: x[param]) for param in space.keys()}


@register(WindowFrame, key='paramspace')
def finalize_paramspace(self, data):
    return self.estimator.base_estimator.search_spaces


@register(WindowFrame, key='betas')
def finalize_betas(self, data):
    dates = recursive_hierarchy(data, 'collect_date')
    feature_names = self[0].get_samples()[0].columns
    return pd.DataFrame(recursive_hierarchy(data, key='collect_betas'), index=dates, columns=feature_names)


@register(WindowFrame, key='contributions')
def finalize_contributions(self, data):
    betas = finalize_betas.fn(self, data)
    test_data = finalize_test_samples.fn(self, data)[0]
    betas.index = pd.to_datetime(betas.index)
    betas = betas.reindex([self[0].training_end] + list(test_data.index)).shift(1).fillna(
        method='ffill').dropna()
    return (betas * test_data).rename_axis('features', axis=1)


base_accessors = [collect_date] + [collect_X_trans, finalize_X_trans]
train_accessors = [collect_loss, collect_val_loss, finalize_loss]
feature_accessors = [collect_estimator_names, finalize_multiindex]
shap_accesssors = [collect_shap_value, finalize_shap_series]

xgboost_accessors = base_accessors + shap_accesssors
train_and_shap = base_accessors+ train_accessors + shap_accesssors
hypertest_accessors = base_accessors + [collect_bestparam, finalize_bestparam, finalize_paramspace]
contribution_accessors = base_accessors + [collect_test_samples,
                    collect_betas, finalize_betas, finalize_contributions]
linreg_accessors = contribution_accessors + shap_accesssors
