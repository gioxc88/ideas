import numpy as np
from ami.common.base_jobspec import Jobspec
import sklearn
from itertools import chain

class MBJobspec(Jobspec):
    spec_folder = 'macrobot/specs'

    @classmethod
    def load(cls, asset, type=None):
        spec = super().load(asset)
        if type:
            spec.update_spec_to_type(type)
        return spec

    def update_spec_to_type(self, type='training'):
        if hasattr(self, 'ensemble'):
            self.ensemble.n_jobs = -1
        self.windowframe.n_jobs = -1

        if type == 'feature_testing':
            self.feature_testing = {
                "strategy": 'drop_one',
                "group": False,     #False, separate or combine
                "type": 'core_features',       #varying_features or core_features
                "ignore_pca": True,
                "features": [
                ],
                "n_jobs": -1, # no of workers for parallelisation
            }
            # training and others/forecast
            self.type = 'MB_feature_testing'
            self.accessors_fn = 'feature_accessors'
        elif type == 'hyptesting':
            self.hyptesting = {
                "type": 'BayesSearchCV',
                "automod_keys": True,
                "n_iter": 2,
                "scoring": None,
                "param_space": {
                    'nodes': 'range(5, 25, 5)',
                    'lookback_periods': 'range(4, 20, 4)',
                    'regularizer_l1': 'np.logspace(-4, -1, 8)',
                    'regularizer_l2': 'np.logspace(-4, -1, 8)',
                    'recurrent_dropout': 'np.arange(0, 0.6, 0.1)',
                    'dropout': 'np.arange(0, 0.6, 0.1)',
                    'decay': '[None]+list(np.arange(0.5, 0.9, 0.1))',
                    'loss': "['mse', 'mae']",
                    'batchnorm': '[True, False]',
                    'batchnorm_training': '[True, False]',
                    'batchnorm_trainable': '[True, False]',
                    'use_bias': '[True, False]',
                    'optimizer': None,
                    'metrics': None,
                    'batch_size': None,
                    'epochs': None,
                    'activation': None,
                    'kernel_initializer': None,
                    'dense_units': None,
                    'recurrent_activation': None,
                    'kernel_size': None
                }
            }
            self.type = 'MB_hyptesting'
            self.accessors_fn = 'hypertest_accessors'
            self.windowframe = {
                'validate_on_test' : False
            }

        else:
            # training and others/forecast
            self.type = f'MB_{type}'
            self.accessors_fn = self.accessor_from_model()

        return self

    def accessor_from_model(self):
        if self.model.type in ['GruModel', 'CNNModel']:
            return 'train_and_shap'
        elif self.model.type in sklearn.linear_model.__all__:
            return 'linreg_accessors'
        elif self.model.type == 'Rule':
            return 'contribution_accessors'
        # elif self.model.type in ['XGBRegressor']:
        #     return 'xgboost_accessors'
        else:
            return 'base_accessors'




    def parse(self):
        from ami.macrobot import accessors as ami_accessors

        if hasattr(self.strategy, 'signal_agg_fn'):
            if isinstance(self.strategy.signal_agg_fn, str) and 'lambda' in self.strategy.signal_agg_fn:
                self.strategy.signal_agg_fn = self.parse_string(self.strategy.signal_agg_fn)

        if hasattr(self.strategy, 'pred_agg_fn'):
            if isinstance(self.strategy.pred_agg_fn, str) and 'lambda' in self.strategy.pred_agg_fn:
                self.strategy.pred_agg_fn = self.parse_string(self.strategy.pred_agg_fn )

        if hasattr(self.model, 'loss'):
            if isinstance(self.model.loss, str):
                self.model.loss = self.parse_string(self.model.loss)
                if isinstance(self.model.loss, type):
                    loss_kwargs = self.model.pop('loss_kwargs', {})
                    self.model.loss = (self.model.loss)(**loss_kwargs)

        if hasattr(self, 'accessors_fn') and isinstance(self.accessors_fn, str):
            self.accessors_fn = self.parse_string(self.accessors_fn, [ami_accessors])

        for k, v in self.features_transform.items():
            if isinstance(v, dict) and 'transform' in v and v['transform'] != 'passthrough':
                self.features_transform[k]['transform'] = self.parse_string(v['transform'])

        self.target.transform = self.parse_string(self.target.transform)

        if hasattr(self, 'hyptesting'):
            self.hyptesting.param_space = self.convert_paramspace_fromjson()
            if hasattr(self.hyptesting, 'scoring') and isinstance(self.hyptesting.scoring, str):
                self.hyptesting.scoring = self.parse_string(self.hyptesting.scoring)()
        return self


    def convert_paramspace_fromjson(self):
        params = {k: self.parse_string(v) for k, v in self.hyptesting.param_space.items()}
        return self.get_hyptertesting_params(params)


    def get_hyptertesting_params(self, params):
        from ami.build.loss import SampleWeightDecay
        def to_list(v):
            return v if isinstance(v, (list, tuple)) else list(v)
        params = {k: to_list(v) for k, v in params.items() if v is not None}

        if params_with_decay := [i for i in params.keys() if 'decay' in i]:
            decay_params = params.pop(params_with_decay[0], None)
            params['_sample_weight_fn'] = [SampleWeightDecay(i) if i is not None else None for i in decay_params]
        return params

class MBPortSpec(Jobspec):
    spec_folder = 'macrobot/specs_portfolio'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        if not hasattr(self, 'ensembles'):
            self.ensembles = []
        self.ensemble_specs = [MBEnsembleSpec.load(name) for name in self.ensembles]

    @property
    def all_assets(self):
        '''
        return all assets models from the portfolio struture.
        '''
        assets_from_en = chain.from_iterable(en.all_assets for en in self.ensemble_specs)
        return chain(self.assets, assets_from_en)

    @property
    def all_ensembles(self):
        ensemble_from_en = chain.from_iterable(en.all_ensembles for en in self.ensemble_specs)

        # the ordering maters! we put most inner level ensemble on the first
        return chain(ensemble_from_en, self.ensembles)

    @property
    def all_asset_specs(self):
        return [MBJobspec.load(name) for name in self.all_assets]

    @property
    def all_ensemble_specs(self):
        return [MBEnsembleSpec.load(name) for name in self.all_ensembles]

    @property
    def allocator_params(self):
        from symawofo import allocation as alloc_module

        if hasattr(self, 'allocation'):
            return {k: self.parse_string(v, alloc_module) for k, v in self.allocation.items()}
        else:
            return {}

class MBEnsembleSpec(MBPortSpec):
    spec_folder = 'macrobot/specs_ensemble'

    def parse(self):
        import symawofo.strategies.ensemble as ensemble_module
        cls = self.strategy.pop('type')
        self.strategy = getattr(ensemble_module, cls)(**self.strategy)

