import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from ami.common.base_charting import Chart


class HypTestingChart(Chart):


    def hyper_param_plot(self, parameter, chart_count=False, logscale=False):
        param_space = self.data.paramspace[parameter]
        df = self.data.bestparams[parameter]

        if '_sample_weight_fn' in parameter:
            conversion_fn = lambda x: x.decay if x is not None else 1
            df = df.applymap(conversion_fn)
            df = df.replace(0, 1)
            param_space = list(map(conversion_fn, param_space))

        fig, ax = plt.subplots(1, 1, figsize=(12, 7))
        title = f'Distribution of {parameter} Parameters \n runs={df.shape[1]}'
        if all([type(i) in (float, int, np.float64) for i in param_space]) and not chart_count:
            df_display = df.median(axis=1).rename('Median').to_frame()
            df_display['pot_max'] = max(param_space)
            df_display['pot_min'] = min(param_space)
            df_display['eff_max'] = df.max(axis=1)
            df_display['eff_min'] = df.min(axis=1)
            df_display['Median'].plot(ax=ax, title=title, linewidth=2, marker='o', markersize=5)
            fill_between = ax.fill_between(df_display.index, df_display['eff_min'], df_display['eff_max'],
                                           facecolor='blue',
                                           alpha=0.1)
            df_display[['pot_max', 'pot_min']].plot(ax=ax, color='k')
            for k in param_space:
                df_display[str(k)] = k
                df_display[str(k)].plot(ax=ax, linestyle='--', color='grey')

            fill_between_lines = [fill_between]
            fill_between_legend = ['Effective Range']

            if df.shape[1] >= 4:
                df_display['q1'] = df.quantile(0.25, axis=1)
                df_display['q3'] = df.quantile(0.75, axis=1)
                fill_between2 = ax.fill_between(df_display.index, df_display['q1'], df_display['q3'], facecolor='blue',
                                                alpha=0.3)
                fill_between_lines.append(fill_between2)
                fill_between_legend.append('Interquartile Range')

            lines = ax.get_lines()[:2] + fill_between_lines + ax.get_lines()[-1:]
            ax.legend(lines,
                      ['Median', 'Param Space Limit'] + fill_between_legend + ['Effective Range', 'Possible Params'])
        else:
            to_plot = df.T.apply(pd.Series.value_counts).fillna(0).T
            to_plot.set_axis(to_plot.index.astype(str)).plot.bar(ax=ax, title=title)

        if logscale:
            plt.yscale('log')
        return df