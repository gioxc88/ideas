import numpy as np
import shap
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from macro_utils import DotDict
from scipy.stats import ks_2samp
import requests
import io
import base64
from macro_utils import MACROBOT_PATH
from macro_utils import Mail, set_default_style
from pathlib import Path
from ami.common.pickler import load
from ami.common.base_charting import ContChart
from matplotlib.colors import TwoSlopeNorm
from itertools import chain




class ShapChart(ContChart):
    charts_to_save = ['chart_cont_pnls', 'chart_cont_ensemble_strategy']

    def __init__(self, strat, target, accessors_data, **kwargs):
        self.target = target
        self.data = DotDict(accessors_data)
        ContChart.__init__(self, strat, self.data.shap_series, **kwargs)

    def save_charts(self, dir=None, charts_to_save=None):
        super().save_charts(dir=dir, charts_to_save=charts_to_save)
        self.save_shap_charts(dir)

    def save_shap_charts(self, path):
        for chart_fn in ['summary', 'chart_feature_contributions']:
            getattr(self, chart_fn)(to_file=path)

    def summary(self, to_file=None):
        ss = self.cont
        data = self.data.X_trans.reindex(ss.index)

        if not to_file:
            shap.summary_plot(ss.values, data, plot_type='violin')
            shap.summary_plot(ss.values, data, plot_type='bar')
        else:
            shap.summary_plot(ss.values, data, plot_type='violin', show=False)
            f = plt.gcf()
            html = self.get_image_html(f)
            plt.close()
            self.generate_html(html, to_file / 'shap_summary.html')

    def dependency(self, feature, coloring_feature=None, window=52):

        fig = plt.figure(figsize=(15, 12))
        ax1 = plt.subplot2grid((3, 2), (0, 0))
        ax2 = plt.subplot2grid((3, 2), (0, 1))
        ax3 = plt.subplot2grid((3, 2), (1, 0), colspan=2)
        ax4 = plt.subplot2grid((3, 2), (2, 0), colspan=2)

        ss = self.cont
        data = self.data.X_trans

        assert feature in data.columns
        if not coloring_feature or coloring_feature == feature:
            coloring_feature = "auto"

        shap.dependence_plot(feature, ss.values, data,
                             interaction_index=coloring_feature, show=False, ax=ax1)

        sns.regplot(ss[feature].shift(1), self.strat.target.diff().reindex(ss.shift(1).index), ax=ax2,
                    line_kws={'linewidth': 1}, scatter_kws={'s': 4, 'alpha': 0.5})
        ax2.axhline(0, color='k', linewidth=1)
        ax2.axvline(0, color='k', linewidth=1)

        ss[feature].shift(1).rolling(window=window).corr(self.strat.target.diff()).dropna()\
            .plot(ax=ax3, title=f'Rolling {window}W Correlation of {feature} with target')
        ax3.axhline(0, color='k')
        ax3.axhline()

        ss[feature].shift(1).rolling(window=window).corr(data[feature]).dropna() \
            .plot(ax=ax4, title=f'Rolling {window}W Correlation between shap and feature: {feature}')
        ax4.axhline(0, color='k')
        ax4.axhline()

        plt.tight_layout()

    def chart_feature_contributions(self, date_start=None, date_end=None,
                                    to_file=None):
        ss = self.cont
        x_trans = self.data.X_trans

        if date_start or date_end:
            date_start = pd.Timestamp(date_start or ss.index[0])
            date_end = pd.Timestamp(date_end or ss.index[-1])
            ss = ss[date_start:date_end]
            x_trans = x_trans[date_start:date_end]

        add_html = []
        for i in ss:
            ss[i].plot(title=f'Feature_contributions - {i}',
                       figsize=(10, 7))
            ss.sum(axis=1).plot(alpha=0.5)

            ax = x_trans[i].plot(secondary_y=True, color='grey', alpha=0.25)
            ax.left_ax.axhline(y=0, xmin=0, xmax=1, color='r', linestyle='-')
            if not to_file:
                plt.show()
            else:
                f = plt.gcf()
                html = self.get_image_html(f)
                plt.close()
                add_html.append(html)
        if to_file:
            self.generate_html(add_html, to_file / 'shap_contribution.html')



    @staticmethod
    def get_image_html(f, size=(10, 6)):
        plt.tight_layout()
        my_stringIObytes = io.BytesIO()
        f.set_size_inches(size)
        f.savefig(my_stringIObytes, format='jpg')
        my_stringIObytes.seek(0)
        b64data = base64.b64encode(my_stringIObytes.read())
        html_image = f'<img src="data:image/gif;base64,{b64data.decode()}">'
        return html_image

    @staticmethod
    def generate_html(html, file):
        if isinstance(html, list):
            use_html = ''.join(html)
        else:
            use_html = html

        html = f'''
        <html>
            <body>
                                {use_html}
            </body>
        </html>
        '''
        (file).write_text(html)


class ShapCompare:

    def __init__(self, data, save_path):

        self.shap_series = {k: v.get('contributions', v['shap_series']) for k, v in data.items()}
        self.X_trans = {k: v['X_trans'] for k, v in data.items()}

        self.last_week_name = self.read_db_config('last_week')
        self.save_path = save_path

    @staticmethod
    def read_db_config(field):
        res = requests.get('http://awsmbdev02.idm.rivagecapital.com/api/pnl/setting/read',
                           params=dict(name=field))
        return res.json()['data']

    @staticmethod
    def load_shap_series(forecast, asset):
        base = Path(MACROBOT_PATH / 'Ami_Models' / forecast / asset / 'accessor_data.h5')
        return load(base)['shap_series']

    @property
    def html(self):
        save_path = self.save_path
        current_model = f'{save_path.parents[0].name}/{save_path.name}'

        mail = Mail(subject=f'Shap reports - {save_path.parents[0].name}',
                    content_htmls=[
                        f'''
                        {current_model} <br>
                        --<br>
                        next_week: current forecast, for next week data point <br>
                        current_last_week: current forecast, for this week data point  <br>
                        prev_last_week: {self.last_week_name}<br>


                        --<br>
                        Diverage color heat map: red -- white -- blue <br>
                        directional color heat map: green
                        ''',
                        *list(chain.from_iterable(
                            (self.generate_shap_report(asset),
                             self.generate_decision_plot(asset))
                            for asset in self.shap_series))
                    ]
                    )
        return mail.html

    def save_html(self):
        (self.save_path / 'shap_report.html').write_text(self.html)

    def compare_shap(self, asset):
        shap_series = self.shap_series[asset].copy()
        feature = self.X_trans[asset].copy()

        shap_series['Total'] = shap_series.sum(axis=1)
        shap_zscore = shap_series.rank(pct=True)
        shap_zscore_cont = (shap_series - shap_series.mean()) / shap_series['Total'].std()
        feature_zscore = feature.rank(pct=True)

        try:
            last_week = self.load_shap_series(self.last_week_name, asset)
            last_week['Total'] = last_week.sum(axis=1)
        except:
            last_week = shap_series.fillna(0).isna().astype(float)

        results = pd.concat([
            shap_series.iloc[-1].rename('next_week'),
            (shap_series.iloc[-1] - shap_series.iloc[-2]).rename('diff_current_last_week'),
            (shap_series.iloc[-1] - last_week.iloc[-1]).rename('diff_prev_last_week'),
            shap_zscore.iloc[-1].rename('pctile'),
            shap_zscore_cont.iloc[-1].rename('zscore_cont'),
            feature_zscore.iloc[-1].rename('feature_pctile'),
            feature.iloc[-1].rename('feature'),
            shap_series.mean().rename('Mean'),
            shap_series.std().rename('std'),
            self.KS(shap_series, 26).round(2)
        ], axis=1).fillna(0)

        pick_index = results['next_week'].drop('Total').abs().sort_values(ascending=False).index[:10]
        return results.loc[list(pick_index) + ['Total']]

    @staticmethod
    def KS(shap_series, n):
        results = pd.Series(name='KS_pvalue')
        for i in shap_series.columns:
            prev_distr = shap_series[i][:-n]
            new_distr = shap_series[i][-n:]
            stat, pval = ks_2samp(new_distr, prev_distr)
            results.loc[i] = pval
        return results

    def generate_decision_plot(self, asset):

        shap.decision_plot(self.shap_series[asset].sum(axis=1).mean(), self.shap_series[asset].iloc[-1].values,
                           feature_names=list(self.shap_series[asset]), show=False)
        f = plt.gcf()
        f.suptitle(asset, fontsize=16)
        plt.tight_layout()
        my_stringIObytes = io.BytesIO()
        f.set_size_inches(11, 7)
        f.savefig(my_stringIObytes, format='jpg')
        plt.close()
        my_stringIObytes.seek(0)
        b64data = base64.b64encode(my_stringIObytes.read())
        return f'<img src="data:image/gif;base64,{b64data.decode()}">'

    def generate_shap_report(self, asset):
        cm_value = sns.light_palette("green", as_cmap=True)
        cm_signs = sns.diverging_palette(20, 220, center='light', as_cmap=True)

        df = self.compare_shap(asset).sort_values(by='next_week', ascending=False)
        df = pd.concat([df.loc[['Total'], :], df.drop('Total').sort_values(by='next_week', ascending=False)], axis=0)

        style = set_default_style(df).format('{:.4f}')

        for i in ['std']:
            style = style.background_gradient(cmap=cm_value,
                                              subset=pd.IndexSlice[df.drop(labels='Total').index, i],
                                              gmap=df[i].abs())

        for i in ['next_week', 'pctile', 'feature_pctile']:
            vcenter = 0 if i == 'next_week' else 0.5
            norm = TwoSlopeNorm(vmin=min(df[i].min(), vcenter-1e-9), vmax=max(df[i].max(), vcenter+1e-9), vcenter=vcenter)

            style = style.background_gradient(cmap=cm_signs,
                                              subset=pd.IndexSlice[df.drop(labels='Total').index, i],
                                              gmap=norm(df[i].drop(labels='Total'))
                                              )

        for i in ['diff_current_last_week', 'diff_prev_last_week']:
            norm = TwoSlopeNorm(vmin=min(df[i].min(), -1e-9), vmax=max(df[i].max(), 1e-9), vcenter=0)
            style = style.text_gradient(cmap=cm_signs,
                                        subset=pd.IndexSlice[df.drop(labels='Total').index, i],
                                        gmap=norm(df[i].drop(labels='Total'))
                                        )

        return f'<div align="center"><h5>{asset}</h5></div> {style.render()}'


def shap_boxplots(data, sort_by_diff=False, showfliers=False, whis=5, n=10, to_file=None):
    fig, axs = plt.subplots(1, 2, sharey=True, figsize=(16, 13))
    shap_series = data.get('contributions', data['shap_series']).copy()
    features = data.get('X_trans').copy()

    index = shap_series.diff().iloc[-1].sort_values().index if sort_by_diff else shap_series.iloc[
        -1].sort_values().index

    shap_series['Total'] = shap_series.sum(axis=1)
    features['Total'] = np.nan
    index = list(index) + ['Total']

    dropped_last = shap_series[index].diff().iloc[-1, :-1] if sort_by_diff else shap_series[index].iloc[-1, :-1]
    hlines = [len(dropped_last[dropped_last < 0]) - 0.5,
              len(dropped_last) - (len(dropped_last[dropped_last > 0]) + 0.5)]

    boxplot_and_points(shap_series[index], ax=axs[0], showfliers=showfliers, whis=whis, n=n, add_flag=hlines)
    boxplot_and_points(features[index], ax=axs[1], showfliers=showfliers, whis=whis, n=n, add_flag=hlines)

    value_counts = np.sign(shap_series[index].iloc[-1, :-1]).value_counts()
    for i, (k, v) in enumerate(value_counts.items()):
        axs[1].text(0, shap_series[index].shape[1] - 1.25 + (i * 0.25), f'{k} signals: {v}', fontsize=16)

    if to_file:
        fig.savefig(to_file / f'shap_boxplot.png')
        plt.close()


def boxplot_and_points(df, ax, showfliers=False, whis=5, n=10, add_flag=None):
    add_flag = [add_flag] if isinstance(add_flag, (float, int)) else (add_flag or [])
    bplot = {'alpha': 1, 'color': 'lightblue'}
    whis = [whis, 100 - whis] if whis else None
    ax.boxplot(x=df, positions=range(df.shape[1]),
               flierprops={'marker': 'o', 'markersize': 2, 'markeredgecolor': 'lightblue', 'alpha': 0.7},
               vert=False, showfliers=showfliers,
               boxprops=bplot,
               whiskerprops={'alpha': 0},
               capprops=bplot,
               medianprops=bplot,
               whis=whis
               )

    ax.scatter(x=df.iloc[-1], y=df.columns, s=75, color='red')
    ax.scatter(x=df.iloc[-2], y=df.columns, s=25, color='green')
    ax.axhline(df.shape[1] - 1.5, color='k', linewidth=2)
    ax.axvline(0, color='black', linewidth=1, alpha=0.2)
    for i in add_flag:
        ax.axhline(i, color='grey', linewidth=2)

    for i in df.columns:
        ax.scatter(x=df[i].iloc[-n - 2:-2], y=[i] * (n), s=20, color='pink', alpha=1)