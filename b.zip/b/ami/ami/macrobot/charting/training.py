import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from IPython.display import display
from macro_utils import MACROBOT_PATH
import symawofo.strategies.ensemble as ensemble_module
from symawofo.strategies import pred, wf, AssetType
from ami.common.base_charting import Chart
from ami.common.plsummary import PLSummary
from ami.common.pickler import load
from ami.common.base_charting import ContChart

class BaseTrainChart(Chart):

    charts_to_save = ['chart_strategy', 'chart_runs', 'chart_scatter']

    def chart_ensemble_strategies(self):
        signals = self.strat.get_all_signals()
        strat_pls = []
        for name, st in self.strat.strategies.items():
            strat_pls.append(st.get_pnl(start_index=signals.first_valid_index()))
        legend = list(self.strat.strategies.keys())

        pnls = pd.concat(strat_pls, axis=1, keys=legend)
        pnls[type(self.strat).__name__] = self.strat.get_pnl(start_index=signals.first_valid_index())
        pnls['Asset'] = self.hold_pnl.get_pnl(start_index=signals.first_valid_index())
        ax = pnls.plot(figsize=(15, 10))
        return ax

    def chart_pnl(self):
        if type(self.strat)==wf.ThresholdSignStrategy:
            self.chart_runs()
        else:
            self.chart_strategy()


    def chart_strategy(self):
        strat = self.strat
        ax = strat.get_pnl().plot(figsize=(15, 10), color='red', legend=False, alpha=0.5)
        ax.yaxis.set_ticks_position('both')
        self.hold_pnl.get_pnl().plot(ax=ax, color='blue', legend=False)
        return ax

    def chart_runs(self):
        if hasattr(self.strat, 'change_agg'):
            strat = self.strat.change_agg(pred_agg_fn=None, signal_agg_fn=None)
        else:
            strat = self.strat

        ax = strat.get_pnl().plot(figsize=(15, 10), color='grey', legend=False, alpha=0.5)
        ax.yaxis.set_ticks_position('both')
        self.hold_pnl.get_pnl().plot(ax=ax, color='blue', legend=False)
        return ax


    def display_stats(self, base_line_strats=None):

        signals = self.strat.change_agg(pred_agg_fn='mean', keep_cache=True).get_signals().to_frame()
        signals['Market'] = 1

        if base_line_strats is not None:
            strat_signals = []
            for bls, st in base_line_strats.items():
                if isinstance(st.get_pnl(), pd.Series):
                    strat_signals.append(st.get_signals())
                else:
                    strat_signals.append(st.change_agg(pred_agg_fn='mean').get_signals())
            strat_signals = pd.concat(strat_signals, axis=1, keys=list(base_line_strats.keys()))
            signals = pd.concat([signals, strat_signals], axis=1)

        pls = PLSummary(signals, (1+self.returns).cumprod())
        return pls.report


    @staticmethod
    def calculate_hitrate(strat):

        en_pnl = strat.get_pnl().diff().dropna()
        signal = strat.get_signals()

        signal = signal.reindex_like(en_pnl)

        results = pd.DataFrame(columns=['Right/Signal_Up', 'Wrong/Signal_Up', 'Right/Signal_Down', 'Wrong/Signal_Down'],
                               index=['Hitrate', 'Mean', 'Median', 'Share of Observations', 'Share of Active Signals'])

        right = en_pnl.apply(lambda x: 1 if x > 0 else 0)
        wrong = en_pnl.apply(lambda x: 1 if x < 0 else 0)

        up_right = right[signal > 0] * en_pnl[signal > 0]
        up_wrong = wrong[signal > 0] * en_pnl[signal > 0]
        down_right = right[signal < 0] * en_pnl[signal < 0]
        down_wrong = wrong[signal < 0] * en_pnl[signal < 0]

        n_up_right = len(right[(right == 1) & (signal > 0)])
        n_up_wrong = len(wrong[(wrong == 1) & (signal > 0)])
        n_down_right = len(right[(right == 1) & (signal < 0)])
        n_down_wrong = len(wrong[(wrong == 1) & (signal < 0)])

        results['Right/Signal_Up'] = np.round(right[signal > 0].mean(), 4), up_right[up_right != 0].mean(), up_right[
            up_right != 0].median(), n_up_right / len(en_pnl), n_up_right / len(signal[signal != 0])
        results['Wrong/Signal_Up'] = np.round(wrong[signal > 0].mean(), 4), up_wrong[up_wrong != 0].mean(), up_wrong[
            up_wrong != 0].median(), n_up_wrong / len(en_pnl), n_up_wrong / len(signal[signal != 0])
        results['Right/Signal_Down'] = np.round(right[signal < 0].mean(), 4), down_right[down_right != 0].mean(), \
                                       down_right[down_right != 0].median(), n_down_right / len(en_pnl), \
                                       n_down_right / len(signal[signal != 0])
        results['Wrong/Signal_Down'] = np.round(wrong[signal < 0].mean(), 4), down_wrong[down_wrong != 0].mean(), \
                                       down_wrong[down_wrong != 0].median(), n_down_wrong / len(en_pnl), \
                                       n_down_wrong / len(signal[signal != 0])

        return results.T


    def create_hitrate(self, pred_agg_fn='mean', threshold='0'):

        threshold = float(threshold) if isinstance(threshold, str) else threshold

        strat = self.strat.change_agg(pred_agg_fn=pred_agg_fn, keep_cache=True)
        results = self.calculate_hitrate(strat)
        pl = strat.get_pnl().diff().mean()*52*100
        std = strat.get_pnl().diff().std()*np.sqrt(52)*100
        sharpe = pl/std

        strat0 = self.strat.change_agg(pred_agg_fn=pred_agg_fn, threshold=threshold, keep_cache=True)
        results0 = self.calculate_hitrate(strat0)
        pl0 = strat0.get_pnl().diff().mean() * 52*100
        std0 = strat0.get_pnl().diff().std() * np.sqrt(52)*100
        sharpe0 = pl0 / std0

        df1 = pd.DataFrame(columns=results.columns, index=[f'Threshold = {strat.threshold}', f'R_ann = {pl:.2f} / sharpe = {sharpe:.2f}'])
        df2 = pd.DataFrame(columns=results.columns, index=[f'Threshold = {threshold}', f'R_ann = {pl0:.2f} / sharpe = {sharpe0:.2f}'])
        display_df = pd.concat([df1, results, df2, results0], axis=0).fillna('')
        display(display_df)
        return  display_df


    def chart_scatter(self, pred_threshold='', outside=False):
        threshold = pred_threshold if pred_threshold else 0
        predictions = self.strat.get_predictions()
        predictions = predictions if isinstance(predictions, pd.Series) else predictions.mean(axis=1)
        target = self.hold_pnl.get_pnl().diff().reindex(predictions.index)
        sns.set_style('ticks')
        fig, ax = plt.subplots()
        ax.yaxis.set_ticks_position('both')
        fig.set_size_inches(18.5, 10.5)
        sns.regplot(predictions, target, ax=ax)
        if threshold:
            threshold = float(threshold) if isinstance(threshold, str) else threshold
            cond = predictions.abs() > threshold if outside else predictions.abs() < threshold
            predictions2 = predictions[cond]
            target2 = target.reindex(predictions2.index)
            sns.regplot(predictions2, target2, ax=ax, color='r')
            plt.axvline(x=-threshold, color='k', linestyle='--')
            plt.axvline(x=threshold, color='k', linestyle='--')
        sns.despine()
        plt.axvline(x=0, color='k')
        plt.axhline(y=0, color='k')
        return ax


    def chart_by_threshold(self, threshold, force_sign=True):
        threshold = float(threshold) if isinstance(threshold, str) else threshold
        if type(self.strat)==wf.ThresholdSignStrategy:
            strat = self.strat.change_agg(pred_agg_fn='mean', threshold=threshold, keep_cache=True)
        else:
            fn = lambda x: np.sign(x.mean(axis=1)).mask(x.mean(axis=1).abs() < threshold, 0) if force_sign else \
                lambda x: x.mean(axis=1).mask(x.mean(axis=1).abs() < threshold, 0)
            strat = self.strat.change_agg(signal_agg_fn=fn)
        ax = strat.get_pnl().plot(figsize=(15, 10))
        ax.yaxis.set_ticks_position('both')
        self.hold_pnl.get_pnl().plot()
        ax2 = ax.twinx()
        strat.get_signals().plot(ax=ax2, alpha=0.5, color='grey')
        ax.legend(['Strategy', 'Asset'])
        signals = pd.concat([self.strat.get_signals(), strat.get_signals()], axis=1, keys=['Strat', 'Adj. Strat'])
        signals['Asset'] = 1
        pls = PLSummary(signals, (1+self.returns).cumprod())
        plt.show()
        display(pls.report)
        return pls

    def chart_signal_strength(self, n_bins=7):
        if type(self.strat) == wf.ThresholdSignStrategy:
            pred = self.strat.get_predictions().dropna()
        else:
            # This currently won't work if we try to do a median signal from shap; that's because no contribution; we would need to inherit contribution, or merge the shap/training charts
            pred = self.cont_signals.mean(axis=1).dropna()
        unique_values = pd.qcut(pred, n_bins).value_counts().sort_index().to_frame()

        # Generating data
        signal_list = []
        signal_list2 = []
        for i in unique_values.index:
            s = self.strat.get_signals()
            signal_list.append(
                s[pred.reindex(s.index).between(i.left, i.right, inclusive='right')].reindex(s.index).fillna(0))
            signal_list2.append(
                pd.Series(1, index=s.index)[pred.reindex(s.index).between(i.left, i.right, inclusive='right')].reindex(
                    s.index).fillna(0))

        # Collecting Data
        column_names = [f'({round(a.left, 4)},{round(a.right, 4)})' for a in unique_values.index]
        signals = pd.concat(signal_list, axis=1, keys=column_names)
        signals2 = pd.concat(signal_list2, axis=1, keys=column_names)
        pls = PLSummary(signals, (1 + self.returns).cumprod())
        pls2 = PLSummary(signals2, (1 + self.returns).cumprod())
        r1 = pls.report.loc[['CumPL', 'Average_PL_X0', 'Median_PL_X0', 'Sharpe_X0', 'MDD', 'CDD', 'Hit_Rate_X0']]
        r2 = pls2.report.loc[['1.0_asset_mean', '1.0_asset_median']]
        r2.loc['Observations'] = pls2.report.loc['% Active'] * pls2.report.loc['Possible']
        result = pd.concat([r1, r2])

        # Charting
        ax = result.loc['1.0_asset_mean'].plot.bar(alpha=0.5, figsize=(15, 10))
        result.loc['1.0_asset_median'].plot(marker='_', color='blue', linewidth=0)
        for i, (x, v) in enumerate(result.loc['Observations'].items()):
            ax.text(i - 0.2, max(result.loc['1.0_asset_mean', x], 0), str(int(v)), fontsize=12)
        ax2 = ax.twinx()
        result.loc['Hit_Rate_X0'].plot(ax=ax2, linewidth=0, marker='o', color='red')
        ax2.axhline(0.5, color='k', linestyle='-', linewidth=0.5)
        handles = [plt.Rectangle((0, 0), 1, 1, color='lightblue', alpha=0.5)]
        ax.legend(handles + ax.get_lines() + ax2.get_lines(), ['Mean', 'Median', 'Hitrate (RHS)'])
        ax.set_xticklabels(ax.get_xticklabels(), rotation=30)
        return ax



class TrainChart(BaseTrainChart):

    charts_to_save = ['chart_strategy', 'chart_runs', 'chart_signals', 'chart_scatter', 'chart_signal_strength']

    def chart_loss(self, date):
        loss_dict = self.data.loss
        self.chart_loss_helper(*loss_dict[date], title=date)


    @staticmethod
    def chart_loss_helper(training_loss, val_loss, title=None):
        train_mean = training_loss.mean(axis=1)
        train_min = training_loss.min(axis=1)
        train_max = training_loss.max(axis=1)

        val_mean = val_loss.mean(axis=1)
        val_min = val_loss.min(axis=1)
        val_max = val_loss.max(axis=1)

        ax = train_mean.plot(figsize=(15, 10), title=title)
        ax.yaxis.set_ticks_position('both')
        val_mean.plot()

        ax.fill_between(train_mean.index, train_min, train_max, facecolor='blue', alpha=0.2)
        ax.fill_between(val_mean.index, val_min, val_max, facecolor='orange', alpha=0.2)
        ax.legend(['Training_Loss', 'Validation_Loss'])

    def chart_baseline_strats(self, base_line_strats):
        strat_pls = []
        for bls, st in base_line_strats.items():
            if isinstance(st.get_pnl(), pd.Series):
                strat_pls.append(st.get_pnl())
            else:
                strat_pls.append(st.change_agg(pred_agg_fn='mean').get_pnl())
        strat_pls.append(self.strat.change_agg(pred_agg_fn='mean').get_pnl())
        pnls = pd.concat(strat_pls, axis=1, keys=list(base_line_strats.keys())+['Strat'])
        pnls['Asset'] = self.hold_pnl.get_pnl()
        ax = pnls.plot(figsize=(15, 10))
        return ax

    def chart_signals(self):

        def mode_mean(x):
            return x.mode(axis=1).mean(axis=1)

        avg_pred_pnl = self.strat.change_agg(pred_agg_fn='mean', keep_cache=True).get_pnl()
        med_pred_pnl = self.strat.change_agg(pred_agg_fn='median', keep_cache=True).get_pnl()
        avg_sign_pnl = self.strat.change_agg(signal_agg_fn='mean', keep_cache=True).get_pnl()
        med_sign_pnl = self.strat.change_agg(signal_agg_fn='median', keep_cache=True).get_pnl()
        mode_sign_pnl = self.strat.change_agg(signal_agg_fn=mode_mean, keep_cache=True).get_pnl()

        ax = self.hold_pnl.get_pnl().plot(figsize=(15, 10))
        ax.yaxis.set_ticks_position('both')
        avg_pred_pnl.plot()
        med_pred_pnl.plot()
        avg_sign_pnl.plot()
        med_sign_pnl.plot()
        mode_sign_pnl.plot()
        ax.legend(['Asset', 'Avg_Pred', 'Med_Pred', 'Avg_Sig', 'Med_Sig', 'Mode_Sig'])

        return ax



class LinRegChart(BaseTrainChart, ContChart):

    charts_to_save = ['chart_strategy', 'chart_runs', 'chart_scatter', 'chart_betas', 'chart_cont_pnls',
                      'chart_cont_ensemble_strategy',  'chart_signal_strength']


    def __init__(self, strat, target, **kwargs):
        BaseTrainChart.__init__(self, strat, target, **kwargs)
        ContChart.__init__(self, strat, self.data.contributions, **kwargs)


    def chart_betas(self):
        data = self.data['betas'].sort_values(by=self.data['betas'].index[-1], ascending=False, axis=1)
        ax = data.plot(figsize=(15, 10))
        ax.legend(bbox_to_anchor=(1, 1))
        return ax


    def chart_contribution(self, start=None, end=None):
        data = self.cont[start:end].sort_values(by=self.cont[start:end].index[-1], ascending=False, axis=1)
        ax = data.plot(figsize=(10, 7))
        ax.legend(bbox_to_anchor=(1, 1))
        return ax


class EnsembleCharter:

    def __init__(self, strats, ensemble_methods):
        self.strats = strats
        self.ensemble_methods = ensemble_methods
        self.ensemble_strats = self.create_ensemble_strats()
        self.single_strat = self.strats[next(iter(self.strats))]
        self.target = (1 + self.single_strat.get_asset_returns()).cumprod()
        self.hold_pnl = pred.ThresholdSignStrategy(target=self.target,
                                                   predictions=pd.Series(1, index=self.single_strat.get_signals().index),
                                                   threshold=0,
                                                   asset_type=AssetType(level=True, log=False),
                                                   t_costs=self.single_strat.t_costs
                                                   ).get_pnl()
        self.signals = self.get_signals()

    def create_ensemble_strats(self):
        ensemble_strats = {}
        for method, (cl, fn) in self.ensemble_methods.items():
            Method = getattr(ensemble_module, cl)
            ensemble_strats[method] = Method(self.strats, fn)
        return ensemble_strats

    def plot_strats(self):
        strat_pls = []
        for name, st in self.ensemble_strats.items():
            strat_pls.append(st.get_pnl(start_index=self.signals.first_valid_index()))
        legend = list(self.ensemble_strats.keys())

        for name, st in self.strats.items():
            strat_pls.append(st.get_pnl(start_index=self.signals.first_valid_index()))
        legend = legend + list(self.strats.keys())

        pnls = pd.concat(strat_pls, axis=1, keys=legend)
        pnls['Asset'] = self.hold_pnl
        index = pnls.iloc[-1].sort_values(ascending=False).index
        ax = pnls[index].plot(figsize=(15, 10))
        return ax

    def get_signals(self):
        signals = []
        for name, st in self.ensemble_strats.items():
            signals.append(st.get_signals())
        legend = list(self.ensemble_strats.keys())

        for name, st in self.strats.items():
            signals.append(st.get_signals())
        legend = legend + list(self.strats.keys())
        signals = pd.concat(signals, axis=1, keys=legend).dropna()
        return signals


    def summary(self):
        signals = self.signals.copy()
        signals['Asset'] = 1
        pls = PLSummary(signals, self.target)
        return pls


    @classmethod
    def interactive_ensemble(cls, strats, methods, sub_strats, sub_methods):
        new_strats = {i: j for i, j in strats.items() if i in sub_strats}
        new_methods = {i: j for i, j in methods.items() if i in sub_methods}
        ens = cls(new_strats, new_methods)
        ens.plot_strats()
        plt.show()
        display(ens.summary().report)



def collect_strats(paths=None, ami_model=None, asset=None):
    if isinstance(paths, list):
        return {p.name: load(p/ 'strat.h5') for p in paths}
    else:
        root_path = MACROBOT_PATH / 'AMI_Models' / ami_model / 'backtest'
        return {p.name: load(root_path /p/ 'strat.h5') for p in root_path.iterdir() if asset in p.name and 'Ensemble' not in p.name}