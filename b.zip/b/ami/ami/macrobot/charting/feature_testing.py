import pandas as pd
from symawofo.strategies import pred, AssetType

from ami.common.base_charting import Chart


class FeatureTestingChart(Chart):

    charts_to_save = ['chart_fe_averages']

    def __init__(self, signal_spec, *args, **kwargs):
        self.signal_spec = signal_spec
        super().__init__(*args, **kwargs)
        self.averaged_pnl = self.calc_averaged_pnl()

    def calc_averaged_pnl(self):
        predictions = self.strat.get_predictions()
        predictions.columns = self.data.multiindex
        predictions = predictions.groupby(level=0, axis=1, sort=False).mean()

        averaged_strat = pred.ThresholdSignStrategy(self.strat.target, predictions=predictions,
                                                    asset_type=AssetType(level=True, log=True),
                                                    **self.signal_spec)
        pnl = averaged_strat.get_pnl()
        return pnl


    def chart_fe_averages(self):
        ax = self.hold_pnl.get_pnl().plot(figsize=(15, 10), color='k', linewidth=2)
        ax.yaxis.set_ticks_position('both')
        self.averaged_pnl.iloc[:, :-1].plot(ax=ax, alpha=0.8)  # non baseline plot
        self.averaged_pnl.iloc[:, -1].plot(ax=ax, linewidth=3)  # baseline plot
        ax.legend(ax.get_lines(), ['Target'] + list(self.averaged_pnl.columns), bbox_to_anchor=(1.05, 1), loc='upper left')
        return ax


    def fe_summary(self):
        pnl_to_plot = self.strat.get_pnl()
        pnl_to_plot.columns = self.data.multiindex
        avg_return = (pnl_to_plot - 1).iloc[-1] / pnl_to_plot.shape[0] * 52
        stdev = avg_return.groupby(level=0, sort=False).std()
        group_return = (self.averaged_pnl - 1).iloc[-1] / self.averaged_pnl.shape[0] * 52
        results = pd.concat([group_return, stdev], axis=1)
        results.columns = ['Group ann. return', 'ann. return variance']
        return results


    def plot_each_feature(self, feature_group):
        pnl_to_plot = self.strat.get_pnl()
        pnl_to_plot.columns = self.data.multiindex
        ax = pnl_to_plot[feature_group].plot(figsize=(15, 10), color='grey', alpha=0.5, legend=False)
        ax.yaxis.set_ticks_position('both')
        self.averaged_pnl[feature_group].plot(ax=ax, color='blue')
        self.hold_pnl.get_pnl().plot(ax=ax, color='k')
        ax.legend(ax.get_lines()[-2:], ['Average_Prediction', 'Target'])


