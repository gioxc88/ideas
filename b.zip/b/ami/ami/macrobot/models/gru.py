from typing import Iterable

from symawofo.models.base import model
from symawofo.models.tf import BaseTFRegressor3d
from tensorflow.keras import regularizers
from tensorflow.keras.layers import (BatchNormalization, Dense, Dropout, GRU)


@model(BaseTFRegressor3d)
class GRURegressor:
    def __init__(
            self,
            nodes=15,
            lookback_periods=13,
            activation="selu",
            kernel_initializer='random_uniform',
            regularizer_l1=0.05,
            regularizer_l2=0.0,
            recurrent_dropout=0.0,
            dropout=0.0,
            dense_units: Iterable = tuple(),
            batchnorm=True,
            batchnorm_trainable=True,
            batchnorm_training=False,
            epochs=100,
            batch_size=None,
            use_bias=False,
            recurrent_activation='hard_sigmoid',
            reset_after=False,
            implementation=1,
            **kwargs
    ):
        super().__init__(**kwargs)

        # for param in inspect.signature(self).parameters.values():
        #     setattr(self, param.name, param.default if param.name != 'dense_layers_list' else [])

        self.nodes = nodes
        self.lookback_periods = lookback_periods
        self.activation = activation
        self.kernel_initializer = kernel_initializer
        self.regularizer_l1 = regularizer_l1
        self.regularizer_l2 = regularizer_l2
        self.recurrent_dropout = recurrent_dropout
        self.dropout = dropout
        self.dense_units = dense_units
        self.batchnorm = batchnorm
        self.batchnorm_training = batchnorm_training
        self.batchnorm_trainable = batchnorm_trainable
        self.batch_size = batch_size
        self.epochs = epochs
        self.use_bias = use_bias
        self.recurrent_activation = recurrent_activation
        self.reset_after = reset_after
        self.implementation = implementation

    def _hidden_layers(self, x):
        if self.dropout:
            x = Dropout(self.dropout)(x)

        x = GRU(
            self.nodes,
            activation=self.activation,
            recurrent_dropout=self.recurrent_dropout,
            return_sequences=False,
            kernel_initializer=self.kernel_initializer,
            kernel_regularizer=regularizers.l1_l2(self.regularizer_l1, self.regularizer_l2),
            activity_regularizer=regularizers.l2(0.0),
            use_bias=self.use_bias,
            recurrent_activation=self.recurrent_activation,
            reset_after=self.reset_after,
            implementation=self.implementation
        )(x)

        dense_units = self.dense_units or []
        for n in dense_units:
            x = Dense(
                n,
                activation=self.activation,
                # name=f'extra_dense{n}',
                kernel_regularizer=regularizers.l1_l2(0.01, 0.01)
            )(x)

        if self.batchnorm:
            x = BatchNormalization(trainable=self.batchnorm_trainable)(x, training=self.batchnorm_training)

        x = Dense(
            1,
            activation='linear',
            use_bias=self.use_bias,
            kernel_initializer='random_uniform',
            # name='prediction'
        )(x)

        return x

