from symawofo.models.base import model
from symawofo.models.tf import BaseTFRegressor3d
from tensorflow.keras import regularizers
from tensorflow.keras.layers import (BatchNormalization, Conv1D, Dense, Dropout, Flatten)


@model(BaseTFRegressor3d)
class CNNRegressor:
    def __init__(
            self,
            nodes=15,
            lookback_periods=10,
            kernel_size=5,
            activation="selu",
            kernel_initializer='random_uniform',
            regularizer_l1=0.05,
            regularizer_l2=0.0,
            dropout=0.0,
            batchnorm=True,
            batchnorm_trainable=True,
            batchnorm_training=False,
            epochs=100,
            batch_size=None,
            use_bias=False,
            **kwargs
    ):

        assert lookback_periods > kernel_size, 'lookback_periods cannot be smaller than kernel size'
        super().__init__(**kwargs)

        # for param in inspect.signature(self).parameters.values():
        #     setattr(self, param.name, param.default if param.name != 'dense_layers_list' else [])

        self.nodes = nodes
        self.lookback_periods = lookback_periods
        self.kernel_size = kernel_size
        self.activation = activation
        self.kernel_initializer = kernel_initializer
        self.regularizer_l1 = regularizer_l1
        self.regularizer_l2 = regularizer_l2
        self.dropout = dropout
        self.batchnorm = batchnorm
        self.batchnorm_training = batchnorm_training
        self.batchnorm_trainable = batchnorm_trainable
        self.epochs = epochs
        self.batch_size = batch_size
        self.use_bias = use_bias

    def _hidden_layers(self, x):
        if self.dropout:
            x = Dropout(self.dropout)(x)

        x = Conv1D(
            self.nodes,
            self.kernel_size,
            activation=self.activation,
            use_bias=self.use_bias,
            kernel_initializer=self.kernel_initializer,
            kernel_regularizer=regularizers.l1_l2(self.regularizer_l1, self.regularizer_l2)
        )(x)

        if self.batchnorm:
            x = BatchNormalization(trainable=self.batchnorm_trainable)(x, training=self.batchnorm_training)

        x = Flatten()(x)

        x = Dense(
            1,
            activation='linear',
            use_bias=self.use_bias,
            kernel_initializer='random_uniform',
            # name='prediction'
        )(x)

        return x