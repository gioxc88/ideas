from .cnn import CNNRegressor
from .gru import GRURegressor