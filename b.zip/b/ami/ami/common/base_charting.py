import numpy as np
import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt
from symawofo.strategies import pred, AssetType
from macro_utils import DotDict
from ami.common.plsummary import PLSummary
plt.style.use('fivethirtyeight')

class Chart:

    charts_to_save = []

    def __init__(self, strat, target, accessors_data=None, isinputlog=True, **kwargs):
        self.strat = strat
        self.data = DotDict(accessors_data) if accessors_data else dict()
        self.target = target
        self.hold_pnl = pred.ThresholdSignStrategy(target=target,
                                                   predictions=pd.Series(1, index=self.strat.get_signals().index),
                                                   threshold=0,
                                                   asset_type=AssetType(level=True, log=isinputlog),
                                                   t_costs=strat.t_costs
                                                   )
        self.returns = self.target.diff() if kwargs.get('isinputlog', True) else self.target.pct_change()

    def save_charts(self, dir=None, charts_to_save=None):
        dir = dir or Path('../macrobot/charting')
        charts_to_save = charts_to_save or self.charts_to_save or []
        for chart_fn in charts_to_save:
            ax = getattr(self, chart_fn)()
            fig = ax.get_figure()
            fig.savefig(dir / f'{chart_fn}.png')
            plt.close()



class ContChart(Chart):
    def __init__(self, strat, cont, **kwargs):
        self.strat = strat
        self.raw_cont = cont
        self.cont = cont.sum(level='features', axis=1)
        self.returns = self.strat.target.diff() if kwargs.get('isinputlog', True) else self.strat.target.pct_change()

        if kwargs.get('weighted', None):
            divisor = self.cont.abs().sum(axis=1)
            signed_weights = self.cont.abs().divide(divisor.abs(), axis=0) * np.sign(self.cont)
            self.cont_signals = signed_weights.shift(1)
        else:
            self.cont_signals = np.sign(self.cont).shift(1)


    def chart_cont_pnls(self):
        results = self.cont_signals.multiply(self.returns, axis=0).dropna().cumsum()
        index = results.iloc[-1].sort_values(ascending=False).index
        ax = results[index].plot(figsize=(15, 10))
        ax.legend(bbox_to_anchor=(1, 1))
        return ax

    def cont_strat_summary(self):
        pls = PLSummary(self.cont_signals, (self.returns+1).cumprod())
        return pls.report

    def chart_signal_comparisons(self, feature):
        signal_0threshold = self.strat.change_agg(pred_agg_fn='mean', threshold=0).get_signals()
        sigs_to_plot = pd.concat([self.cont_signals[feature], signal_0threshold.rename('Prediction')], axis=1)
        sigs_to_plot['Difference'] = sigs_to_plot[feature]-sigs_to_plot['Prediction']
        ax = sigs_to_plot[[feature, 'Prediction']].plot(figsize=(15, 10))
        sigs_to_plot['Difference'].plot(ax=ax, alpha=0.5, color='grey')
        return ax

    def most_similar_signals(self):
        signal_0threshold = self.strat.change_agg(pred_agg_fn='mean', threshold=0).get_signals()
        return self.cont_signals.subtract(signal_0threshold, axis=0).abs().mean().sort_values()

    def get_group_signals(self):
        median_signal = self.cont_signals.median(axis=1)
        mean_signal = self.cont_signals.mean(axis=1)
        strat = self.strat
        signals = pd.concat([median_signal, mean_signal, strat.get_signals()], axis=1, keys=['Median', 'Mean', 'Strat'])
        signals['Asset'] = 1
        return signals.dropna()

    def chart_cont_ensemble_strategy(self):
        signals = self.get_group_signals()
        ax = (signals.multiply(self.returns.reindex(signals.index), axis=0)).dropna().cumsum().plot(figsize=(15, 10))
        return ax

    def group_strategy_summary(self):
        signals = self.get_group_signals()
        return PLSummary(signals, (self.returns + 1).cumprod())



