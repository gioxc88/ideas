import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

plt.style.use('fivethirtyeight')


class PLSummary():
    def __init__(self, sigs, assets, start=None, end=None):

        self.start = start or sigs.index[0]
        self.end = end or sigs.index[-1]

        self.sigs = sigs.loc[self.start:self.end]
        self.sigs_start_dates = sigs.apply(pd.Series.first_valid_index)
        self.sigs = self.signal_mask_datedict(self.sigs, self.sigs_start_dates)
        self.sigs_X0 = self.sigs.replace(0, np.nan)
        self.assets = self.check_in_assets(assets)
        self.asset_returns = self.assets.pct_change().reindex(self.sigs.index)
        self.strat = self.sigs.multiply(self.asset_returns, axis=0).dropna(how='all', axis=0)
        self.strat_X0 = self.sigs_X0.multiply(self.asset_returns, axis=0).dropna(how='all', axis=0)
        self.asset_sign = np.sign(self.asset_returns)

        self.report = self.run_report()

    def check_in_assets(self, assets):
        if isinstance(assets, pd.Series):
            return pd.DataFrame(1, index=assets.index, columns=self.sigs.columns).multiply(assets, axis=0)
        elif (assets.shape[1]==1 and self.sigs.shape[1]>1):
            return pd.DataFrame(1, index=assets.index, columns=self.sigs.columns).multiply(assets.iloc[:, 0], axis=0)
        else:
            return assets[self.sigs.columns]


    @staticmethod
    def drawdown(df_pl):
        cum = df_pl.cumsum()
        temp_cum = cum.copy()
        temp_cum.iloc[0] = temp_cum.iloc[0].apply(lambda x: max(x, 0))
        mx = temp_cum.expanding().max()
        return cum - mx

    @staticmethod
    def hit_rate_helper(pred, actual, X0=True):
        if X0:
            hr = pred.multiply(actual, axis=0)
            return hr.replace(-1, 0)
        else:
            return (((pred.multiply(actual, axis=0)) + 1) / 2)

    def hit_rate(self, X0=True, replace='', value=''):
        return self.hit_rate_helper(self.sigs_X0.replace(replace, value), self.asset_sign, X0)

    def signal_shares(self, X0=True, norm=True):
        sigs = self.sigs_X0 if X0 else self.sigs
        results = sigs.apply(pd.Series.value_counts)
        if norm:
            results = results / results.sum()
            word = 'Share'
        else:
            word = 'Number'
        results.index = [f'{word} of {x}' for x in results.index]
        return results

    def count_signal(self, X0=True):
        return self.sigs.abs().sum() if X0 else (1 - self.sigs.isna().astype(int)).sum()

    def average_pnl(self, X0=True):
        return self.sigs.abs().sum() if X0 else (1 - self.sigs.isna().astype(int)).sum()

    def cond_stat(self, sig, attr='mean', asset=True):
        ref = self.asset_returns if asset else self.strat
        return getattr(ref[self.sigs == sig], attr)()

    def cond_stat_multsig(self, attr='mean', asset=True):
        typ = 'asset' if asset else 'strat'
        return pd.concat([self.cond_stat(i, attr, asset).rename(f'{i}_{typ}_{attr}') for i in
                          self.sigs.apply(pd.Series.value_counts).index], axis=1)

    def right_sigs(self):
        return (self.strat > 0).astype(int).sum()

    @property
    def cumpnl(self):
        return self.strat.cumsum()

    @staticmethod
    def signal_mask_count(sigs, n):
        count = sigs.sort_index(ascending=False).abs().cumsum().sort_index()
        return sigs[count <= n]

    @staticmethod
    def signal_mask_datedict(sigs, dates):
        new_sigs = pd.DataFrame().reindex_like(sigs)
        for a, d in dates.iteritems():
            new_sigs[a].loc[d:] = sigs[a].loc[d:]
        return new_sigs.reindex_like(sigs)

    def chart_strat(self, asset, ax=None):
        self.strat[asset].dropna().cumsum().plot(ax=ax)
        self.asset_returns[asset].cumsum().plot(title='Cumulative returns', ax=ax, fontsize=9)
        plt_use = ax or plt
        plt_use.legend(['Strategy', 'Asset'])

    def chart_strat_rel_benchmark(self, asset, benchmark=None, ax=None):
        benchmark = benchmark if benchmark is not None else self.asset_returns[asset]
        (self.strat[asset].reindex(benchmark.index).fillna(0) - benchmark).cumsum().plot(ax=ax,
                                                                                         title='Performance Relative to Benchmark')

    def chart_drawdown(self, pl, ax=None, **kwargs):
        self.drawdown(pl).plot(ax=ax, **kwargs)

    def chart_sigs(self, asset, ax=None, figsize=(5, 0.5), color0=True, marker='.', title='Sigs'):
        ax = ax or plt.gca()
        hr = self.hit_rate(X0=True)
        self.sigs[asset][hr[asset] > 0].astype(int).plot(ax=ax, title=title, figsize=figsize, linestyle='None',
                                                         marker=marker, color='green', markersize=11)
        self.sigs[asset][hr[asset] < 1].astype(int).plot(ax=ax, linestyle='None', marker=marker, color='red',
                                                         markersize=11)

        color0_1, color0_2 = ('green', 'red') if color0 else ('k', 'k')
        cond1 = (self.sigs[asset] == 0) & (self.asset_returns[asset] < 0)
        cond2 = (self.sigs[asset] == 0) & (self.asset_returns[asset] > 0)
        if cond1.sum() > 0:
            self.sigs[asset][(self.sigs[asset] == 0) & (self.asset_returns[asset] < 0)].astype(int).plot(ax=ax,
                                                                                                         linestyle='None',
                                                                                                         marker=marker,
                                                                                                         color=color0_1,
                                                                                                         markersize=11)

        if cond2.sum() > 0:
            self.sigs[asset][(self.sigs[asset] == 0) & (self.asset_returns[asset] > 0)].astype(int).plot(ax=ax,
                                                                                                         linestyle='None',
                                                                                                         marker=marker,
                                                                                                         color=color0_2,
                                                                                                         markersize=11)

        ya = ax.get_yaxis()
        ya.set_major_locator(MaxNLocator(integer=True))
        ya.set_ticks([-1, 0, 1])
        ax.set_ylim(-1.5, 1.5)

    def run_report(self):
        return pd.concat([
            self.cumpnl.iloc[-1].rename('CumPL') * 100,
            self.strat_X0.mean().rename('Average_PL_X0') * 100,
            self.strat.mean().rename('Average_PL') * 100,
            self.strat_X0.median().rename('Median_PL_X0') * 100,
            (self.strat_X0.mean() / self.strat_X0.std()).rename('Sharpe_X0') * np.sqrt(52),
            (self.strat.mean() / self.strat.std()).rename('Sharpe') * np.sqrt(52),
            self.drawdown(self.strat).min().rename('MDD') * 100,
            self.drawdown(self.strat).iloc[-1].rename('CDD') * 100,
            self.count_signal(False).rename('Possible'),
            (self.count_signal(True) / self.count_signal(False)).rename('% Active'),
            self.hit_rate(X0=True).mean().rename('Hit_Rate_X0'),
            self.hit_rate(X0=True, replace=-1, value=np.nan).mean().rename('1_Hit_Rate_X0'),
            self.hit_rate(X0=True, replace=1, value=np.nan).mean().rename('-1_Hit_Rate_X0'),
            self.cond_stat_multsig('mean', asset=True) * 100,
            self.cond_stat_multsig('median', asset=True) * 100,
            self.signal_shares(X0=True, norm=True).T
        ], axis=1).round(2).T

    def plot_all(self, asset, benchmark=None, color0=True):
        f, ax = plt.subplots(2, 2, figsize=(11, 5), gridspec_kw={'height_ratios': [6, 4]})
        f.suptitle(asset)
        self.chart_strat(asset, ax=ax[0][0])
        self.chart_strat_rel_benchmark(asset, benchmark=benchmark, ax=ax[0][1])
        self.chart_drawdown(self.strat[[asset]], ax=ax[1][1], title='Drawdown')
        self.chart_sigs(asset, ax=ax[1][0], figsize=None, color0=color0)
        plt.tight_layout()

