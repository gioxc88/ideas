from requests import Session, Response
from io import StringIO
import inspect
import pandas as pd
from macro_utils import API_BASE, DotDict
from IPython.core.display import display, HTML


class ServerSession(Session):
    def __init__(self, path=''):
        super().__init__()
        self.prefix_url = API_BASE + path

    def request(self, method, url, *args, **kwargs):
        url = self.prefix_url + url
        return super().request(method, url, *args, **kwargs)


class DataFetcher():

    def __init__(self):
        self.data_session = ServerSession('/data')
        self.ctl_session = ServerSession('/pnl')

    def to_frame(self, res: Response):
        try:
            data = res.json()
        except:
            curframe = inspect.currentframe()
            calframe = inspect.getouterframes(curframe, 2)
            caller_name = calframe[1][3]

            display(HTML(f'''
            <div style="background-color: LightCoral;">
            <h4>Error when calling { caller_name } api: </h4>
            <p>There is an error when exectuting the request: server response is not json. </p>
            </div>
            '''))
            return pd.DataFrame()

        if res.status_code == 200 and data['data']:
            data = StringIO(data['data'])
            return pd.read_csv(data, index_col=0, parse_dates=True)
        else:
            curframe = inspect.currentframe()
            calframe = inspect.getouterframes(curframe, 2)
            caller_name = calframe[1][3]

            display(HTML(f'''
            <div style="background-color: LightCoral;">
            <h4>{data['type']} when calling { caller_name } api: </h4>
            <p>{data['error']}</p>
            </div>
            '''))

            return pd.DataFrame()


    def get_pca_components(self, pca_groups):
        res = self.data_session.get('/PCA_components', params=dict(groups=pca_groups))
        return res.json()['data']

    def get_pca(self, pca_groups):
        res = self.data_session.get('/PCA', params=dict(groups=pca_groups))
        return self.to_frame(res)

    def get_features_by_names(self, names, **kwargs):
        res = self.data_session.get(f'/features/names', params=dict(
            names=names,
            **kwargs
        ))
        return self.to_frame(res)

    def get_features_by_name(self, name):
        res = self.data_session.get(f'/features/name/{name}', params=dict(
        ))
        return self.to_frame(res)

    def search_features_by_pattern(self, name):
        res = self.data_session.get(f'/features/search/{name}', params=dict(
        ))
        return res.json()['data']

    def get_on_the_fly_transform(self, transforms, data_startsfrom:str=None):
        '''
        params transforms: list of tuples ( new_name, feature_name, transform_express )
            eg: [ ('US_SSR_diff13', 'US_SSR', 'ser.diff(13)') ]
        '''
        res = self.data_session.post(f'/on_the_fly_transform', json=dict(
            transforms=transforms,
            data_startsfrom=data_startsfrom
        ))
        return self.to_frame(res)

    def shutdown_this_server(self):
        import socket
        host = socket.gethostname().split('.')[0][-5:]
        if host:
            res = self.ctl_session.get(f'/ec2/{host}/stop')
            return res.json()

    def clear_cache(self):
        res = self.data_session.get(f'/clear_cache')
        return res.json()