import inspect
import json
import re
import types
from pathlib import Path
from textwrap import dedent
from types import FunctionType

import numpy as np
from macro_utils import DotDict
from pandas import DataFrame, Series

from ami.setting import PROJECT_PATH


class Script():

    def __init__(self, intial_module):
        self.__dict__ = {k:v for k,v in intial_module.__dict__.items()
                                if not k.startswith('__')}
        self.modified = {}
        self.source_code = inspect.getsource(intial_module)

    def update_source_code(self, old_fn_name, new_fn_source):
        new_fn_source = dedent(new_fn_source)

        if source := self.modified.get(old_fn_name, None) == None:
            source = inspect.getsource(getattr(self, old_fn_name))

        self.modified[old_fn_name] = new_fn_source
        self.source_code = self.source_code.replace(source, new_fn_source)

    def __setattr__(self, name, fn):
        if type(fn) == types.FunctionType:
            fn_source = inspect.getsource(fn).replace(fn.__name__, name)
            self.update_source_code(name, fn_source)
        elif name != 'source_code' and isinstance(fn, str):
            self.update_source_code(name, fn)
        super().__setattr__(name, fn)



class AmiEncoder(json.JSONEncoder):
    def default(self, obj):
        from symawofo.transformers import Pipeline

        if isinstance(obj, FunctionType):
            return f'<Function: {obj.__name__} >'
        if isinstance(obj, DataFrame):
            return f'<DataFrame: {list(obj.columns)} >'
        if isinstance(obj, Series):
            return f'<Series: {obj.name} >'
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, Pipeline):
            names = ','.join([name for (name, _) in obj.steps])
            return f'<Pipeline: {names}>'

        return str(type(obj))   # will not throw error, but returning object type


class Jobspec(DotDict):
    spec_folder = ''

    @classmethod
    def load(cls, asset):
        if isinstance(asset, str):
            asset = PROJECT_PATH / f'ami/{cls.spec_folder}/{asset}.json'

        if isinstance(asset, Path):
            return cls.load_from_path(asset)
        elif isinstance(asset, cls):
            return asset

    @classmethod
    def load_from_path(cls, path:str):
        json_text = json.loads(Path(path).read_text())
        return cls(json_text)

    def clone(self):
        from copy import deepcopy
        return deepcopy(self)

    @staticmethod
    def parse_string(value, modules=None):
        '''
        params models: list of modules that we can use to parse the string into
                objects or class

        return: parsed objects, or the original strings
        '''
        from symawofo import transformers
        from ami.build import loss

        modules = modules or [transformers, loss]
        if not isinstance(modules, list):
            modules = [modules]

        modules_dict =  {k:v for mod in modules for k,v in vars(mod).items()}
        modules_dict.update({'np': np})

        if value and isinstance(value, str):
            try:
                return eval(value, modules_dict )
            except NameError:
                return value
        return value


    def __repr__(self):
        spec_string = json.dumps(self, indent=4, sort_keys=True, cls=AmiEncoder)
        spec_string = re.sub(r'(\s)true[,]?\n', r'\1True,\n', spec_string)
        spec_string = re.sub(r'(\s)false[,]?\n', r'\1False,\n', spec_string)
        spec_string = re.sub(r'(\s)null[,]?\n', r'\1None,\n', spec_string)
        return spec_string


class Pyspec(DotDict):

    def __init__(self, spec, keys_path):
        self.keys_path = keys_path

    @staticmethod
    def parse_string(value, modules=None):
        '''
        params models: list of modules that we can use to parse the string into
                objects or class

        return: parsed objects, or the original strings
        '''
        from symawofo import transformers
        from ami.build import loss

        modules = modules or [transformers, loss]
        if not isinstance(modules, list):
            modules = [modules]

        modules_dict =  {k:v for mod in modules for k,v in vars(mod).items()}
        modules_dict.update({'np': np})

        if value and isinstance(value, str):
            try:
                return eval(value, modules_dict )
            except NameError:
                return value
        return value



