import numpy as np
import mlflow


def log_portfolio_run():
    pass


def get_env_versions():
    from importlib.metadata import version
    nl = '\n'
    try:
        sw_version = version('symawofo')
        ami_version = version('ami')
    except:
        sw_version = 'dev'
        ami_version = 'dev'

    return dict(
        ami=ami_version,
        symawofo=sw_version,
        tensorflow=version('tensorflow'),
        sklearn=version('scikit-learn'),
        pandas=version('pandas'),
        dask=version('dask')
    )

def mark_notebook_start(notebook_name, asset):
    from pathlib import Path

    folder = str(Path.cwd()).replace('/home/svc_macrobot/notebooks/', '').replace('/', '_')

    mlflow.set_tracking_uri("http://awsmbdev02.idm.rivagecapital.com:15000/")
    mlflow.set_experiment(f'{folder}_{asset}')

    #
    mlflow.start_run(run_name=notebook_name.replace(asset, ''),
                     tags=get_env_versions()).__enter__()


def get_sharp(strat, threashold=None):
    import numpy as np
    from ami.macrobot.charting.training import BaseTrainChart

    threashold = strat.threshold if threashold is None else threashold

    strat = strat.change_agg(pred_agg_fn='mean', keep_cache=True, threashold=threashold)
    results = BaseTrainChart.calculate_hitrate(strat)
    pl = strat.get_pnl().diff().mean() * 52 * 100
    std = strat.get_pnl().diff().std() * np.sqrt(52) * 100
    sharpe = pl / std

    return {
        f'R_ann_{threashold}': pl,
        f'sharpe_{threashold}': sharpe,
    }


def log_notebook_result(env):
    from datetime import datetime
    from pathlib import Path
    from ami.common.pickler import dump


    with mlflow.start_run(run_name=f'notebook run', nested=True, tags=get_env_versions()) as run:

        # params
        spec = env['raw_spec']
        mlflow.log_params(dict(
                expanding=spec.data_splitter.expanding,
                initial_training_size=spec.data_splitter.initial_training_size,
                pca=spec.features_transform.PCA,
                pca_diff=spec.features_transform.PCA_diff,
                pass_throught=spec.features_transform.pass_through.names,
                diff=spec.features_transform.diff.names,
                **spec.model,
        ))

        # metrics
        mlflow.log_metrics(dict(
            **get_sharp(env['strat']),
            **get_sharp(env['strat'], threashold=0),
            run_time=(env['end_time'] - env['start_time']).seconds / 60,
        ))

        # artifacts
        p = Path(f'/tmp/{datetime.now():%s}')
        p.mkdir()

        dump(env, folder=p)
        if charter := env.get('charter'):
            charter.save_charts(p)
        if shap_chart := env.get('shap_chart'):
            shap_chart.save_charts(p)
        mlflow.log_artifacts(p)

