import inspect
import json
from datetime import datetime
from pathlib import Path
from types import ModuleType
from ami.common.base_jobspec import Script
from ami.setting import SRC_PATH

class NotebookBuilder:
    def __init__(self, jobspec, module, template_path, name=None):

        if isinstance(module, ModuleType):
            self.script = Script(module)
        elif isinstance(module, Script):
            self.script = module

        self.jobspec = jobspec
        self.template_path = template_path
        self.name = name or f'{self.jobspec.target.name}_{datetime.now():%Y-%m-%d}'

    def get_built_module_import_statements(self):
        return self.get_built_module().split('### Import ###')[0]

    def get_built_module_body(self):
        return self.get_built_module().split('### Import ###')[1]

    def get_built_module(self):
        return self.script.source_code


    def get_env_versions(self):
        import sys
        from importlib.metadata import version
        nl = '\n'
        try:
            sw_version = version('symawofo')
            ami_version = version('ami')
        except:
            sw_version = 'dev'
            ami_version = 'dev'

        return f'''
# %% [markdown]
### Env versions (date {datetime.now():%Y-%m-%d})
    - Python:  {sys.version.replace(nl, ' ')}
    - Symawofo: {sw_version}
    - Ami: {ami_version}

    - Tensorflow: {version('tensorflow')}
    - sklearn: {version('scikit-learn')}
    - xgboost: {version('xgboost')}

    - Pandas: {version('pandas')}
    - Dask: {version('dask')}
    '''

    def save(self, folder=None, format='notebook'):
        from jupytext import reads

        filepath = Path(folder) if folder else Path().absolute()

        if format == 'notebook':
            filepath = filepath / f'{self.name}.ipynb'

            print(f'saving notebook to: {filepath}')
            content = reads(self.built(), fmt='py:percent')
            content = json.dumps(content)
        else:
            filepath = filepath / f'{self.name}.py'
            print(f'saving python file to: {filepath}')
            content = self.built()

        filepath.write_text(content)

    def built(self):
        from jinja2 import Template

        path = SRC_PATH / self.template_path
        template = Template(path.read_text())
        notebook_text = template.render(builder=self, jobspec=self.jobspec,
                                        notebook_name=self.name)

        return notebook_text
