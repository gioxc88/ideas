import gc
from pathlib import Path
import pandas as pd
import symawofo
from ami.common.base_runner import baseRunner
from datetime import datetime
from symawofo.shared.utils import to_cpickle, read_cpickle

def create_folder(spec, folder):
    folder = folder or f'results/{spec.type}/{spec.target.name}_{datetime.now():%Y-%m-%d_%H%M}'
    path = Path(folder)
    path.mkdir(parents=True, exist_ok=True)
    return path


def dump(env: dict, folder=None, obj_to_save=None):
    obj_to_save = obj_to_save or ['data', 'wf', 'spec', 'strat', 'runner']
    path = create_folder(env['spec'], folder)

    for name in obj_to_save:
        if (obj := env.get(name, None)) is None:
            continue

        print(f'saving obj {name} to file')

        if isinstance(obj, baseRunner):
            (path / f'orig_spec.py').write_text(str(obj.orig_jobspec))

        if name == 'spec':
            (path / f'spec.py').write_text(str(obj))

        if name == 'data':
            obj.to_csv(path / f'{name}.csv')

        if name == 'wf':
            to_cpickle(obj.data_, path / f'accessor_data.h5')

        if isinstance(obj, symawofo.strategies.base.BaseStrategy):
            obj.get_signals().to_csv(path / 'signal.csv')
            if hasattr(obj, 'get_predictions'):
                obj.get_predictions().to_csv(path / 'prediction.csv')
            if hasattr(obj, 'get_threshold'):
                index = obj.get_predictions().index
                obj.get_threshold().reindex(index).ffill().to_csv(path / 'threshold.csv')

        to_cpickle(obj, path / f'{name}.h5')

def load(path):

    # disable garbage collector
    gc.disable()

    obj = read_cpickle(Path(path))

    # enable garbage collector again
    gc.enable()
    return obj
