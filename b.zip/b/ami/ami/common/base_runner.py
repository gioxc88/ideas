import types

from ami.common.data_fetcher import DataFetcher


class baseRunner:

    def __init__(self, jobspec):
        self.jobspec = jobspec
        self.fetcher = DataFetcher()

    def get_data(self):
        pass

    def get_models(self):
        pass


    def get_features_by_name(self, names):
        if isinstance(names, str):
            names = [names]

        jobspec_features = self.jobspec.features_transform.pass_through + self.jobspec.features_transform.diff
        diff = list( set(names) - set(jobspec_features) )
        return self.fetcher.get_features_by_names(diff)

    def search_feature(self, pattern):
        return self.fetcher.search_features_by_pattern(pattern)


    def shutdown(self):
        return self.fetcher.shutdown_this_server()

    def clear_cache(self):
        return self.fetcher.clear_cache()