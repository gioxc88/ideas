import numpy as np
import pandas as pd


def sharpe(PL, freq=52):
    return PL.mean() * np.sqrt(freq) / PL.std()


def sharpe_whenactive(PL, sig, freq=52):
    PL = PL.reindex(sig[sig != 0].index)
    return sharpe(PL, freq)


def get_sharpe_whenactive(df_PL, df_sig, freq=52):
    series = pd.Series()
    for i, j in zip(df_PL.columns, df_sig.columns):
        series.loc[i] = sharpe_whenactive(df_PL[i], df_sig[j], freq)
    return series


def drawdown(cumPL, compound=False):
    if compound:
        cumPL = (cumPL / 100) + 1
        return (cumPL / cumPL.cummax() - 1) * 100
    else:
        return cumPL - cumPL.cummax()


def percentile_return_when_active(sig, target_return, percentile):
    temp = (sig[sig != 0] * target_return).dropna()
    if percentile == 'mean':
        return temp.mean()
    else:
        return temp.quantile(percentile)


def mean_ex_extremes(sig, target_return, cutoff):
    cutoff = 1 - cutoff if cutoff > 0.5 else cutoff
    temp = (sig[sig != 0] * target_return).dropna()
    thresh_1 = temp.quantile(cutoff)
    thresh_2 = temp.quantile(1 - cutoff)
    return temp.loc[(temp > thresh_1) & (temp < thresh_2)].mean()


def right_when_active(sig1, perfect_sig):
    temp = (sig1.loc[sig1 != 0] * perfect_sig).dropna()
    return len(temp[temp > 0]) / len(temp)


def check_in(df):
    if isinstance(df, pd.Series):
        df = df.to_frame()
    return df