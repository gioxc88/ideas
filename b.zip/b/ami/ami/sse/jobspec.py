from ami.common.base_jobspec import Jobspec
from copy import deepcopy
from ami.sse.models import condition_fns
from ami.sse.models import scoring_fns


class SSEJobspec(Jobspec):
    spec_folder = 'sse/job_spec'

    @staticmethod
    def convert_correlation(value):
        if value in ['pearson', 'kendall', 'spearman']:
            return value
        else:
            from sklearn import metrics
            return getattr(metrics, value, value)


    def convert_strat_from_json(self, strat_dict):
        result = deepcopy(strat_dict)
        result['param_grid']['thresh'] = self.parse_string(strat_dict['param_grid']['thresh'])
        result['param_grid']['func'] = self.parse_string(strat_dict['param_grid']['func'], condition_fns)
        result['feature_preprocessing'] = self.parse_string(strat_dict['feature_preprocessing'])
        result['scoring_func'] = self.parse_string(strat_dict['scoring_func'], scoring_fns)
        return result

    def convert_clustering_from_json(self):
        result = deepcopy(self['clustering'])
        result['corr'] = self.convert_correlation(result['corr'])
        return result

    def convert_jobspec_from_json(self):
        result = self.clone()
        result['substrats'] = list(map(self.convert_strat_from_json, result['substrats']))
        result['clustering'] = self.convert_clustering_from_json()
        return result

