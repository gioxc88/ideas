import numpy as np
import pandas as pd
from sklearn.metrics import pairwise_distances, euclidean_distances
from sklearn.cluster import AgglomerativeClustering
from scipy.cluster.hierarchy import dendrogram


def plot_dendrogram(model, **kwargs):
    # Create linkage matrix and then plot the dendrogram

    # create the counts of samples under each node
    counts = np.zeros(model.children_.shape[0])
    n_samples = len(model.labels_)
    for i, merge in enumerate(model.children_):
        current_count = 0
        for child_idx in merge:
            if child_idx < n_samples:
                current_count += 1  # leaf node
            else:
                current_count += counts[child_idx - n_samples]
        counts[i] = current_count

    linkage_matrix = np.column_stack([model.children_, model.distances_,
                                      counts]).astype(float)

    # Plot the corresponding dendrogram
    R = dendrogram(linkage_matrix, leaf_rotation=90, **kwargs)
    return



def get_d_mat(strats, correlation_method, to_score=True):
    if correlation_method is euclidean_distances:
        return euclidean_distances(strats.T)
    elif isinstance(correlation_method, str):
        result = strats.dropna().corr(method=correlation_method)
    else:
        result = pairwise_distances(strats.T, metric=correlation_method)
    return np.sqrt(1-result) if to_score else result



def effective_weight_2by2(strats, plot=True, correlation_method='pearson'):
    cl = AgglomerativeClustering(linkage='complete', affinity='precomputed',
                                 distance_threshold=0, n_clusters=None)
    d_mat = get_d_mat(strats, correlation_method)
    cl.fit(d_mat)

    if plot: plot_dendrogram(cl, labels=strats.columns)

    def find_ancestor(model, target):
        for ind, pair in enumerate(model.children_):
            if target in pair:
                return [target] + find_ancestor(model, model.n_leaves_ + ind)
        return [ind + model.n_leaves_]

    output = pd.Series(index=strats.columns, dtype='float64')
    for i, col in enumerate(strats):
        depth = len(find_ancestor(cl, i)) - 1
        output[col] = 0.5 ** depth
    return output


def effective_weight_even(strats, n_clusters=2, correlation_method='pearson'):
    cl = AgglomerativeClustering(linkage='complete', affinity='precomputed', n_clusters=n_clusters)
    d_mat = get_d_mat(strats, correlation_method)
    labels = cl.fit_predict(d_mat)
    unique_labels = np.unique(labels)

    output = pd.Series(data=np.ones(len(strats.columns)), index=strats.columns, dtype='float64')
    for label in unique_labels:
        idx = np.where(labels == label)[0]
        output.iloc[idx] = 1 / (len(idx) * len(unique_labels))
    return output