import numpy as np
import sklearn as sk
from sklearn.model_selection import ParameterGrid
from symawofo.models.base import model as model_dec, RegressorMixin2d, BaseModel

@model_dec(RegressorMixin2d)
class SubStrat(sk.base.BaseEstimator):
    def __init__(self, param_grid, scorer, dynamic_threshold=None):
        self.param_grid = param_grid
        self.dynamic_threshold = dynamic_threshold

        self.func = None
        self.thresh = None

        self.best_params_ = {'func': None, 'thresh': None, 'score': -np.inf}

        self.scorer = scorer

    def fit(self, X, y):

        if self.dynamic_threshold:
            self.param_grid['thresh'] = self.update_threshold(X)  # updates param_grid if

        for params in ParameterGrid(self.param_grid):
            self.func = params['func']
            self.thresh = params['thresh']
            score = self.scorer(y, self.predict(X).data)
            if score > self.best_params_['score']:
                self.best_params_['func'] = self.func
                self.best_params_['thresh'] = self.thresh
                self.best_params_['score'] = score

        self.func = self.best_params_['func']
        self.thresh = self.best_params_['thresh']

        return self

    def predict(self, X):
        return self.func(X, self.thresh)

    def update_threshold(self, X):
        percentile = self.dynamic_threshold['percentile'] if self.dynamic_threshold['percentile' ] <0.5 else \
                    (1 - self.dynamic_threshold['percentile'])
        percentile_lower = X.iloc[:, 0].quantile(percentile)
        percentile_higher = X.iloc[:, 0].quantile(1 - percentile)
        left_limit = 0 if self.dynamic_threshold['tail'] == 'right' else percentile_lower
        right_limit = 0 if self.dynamic_threshold['tail'] == 'left' else percentile_higher
        return np.linspace(left_limit, right_limit, num=20)
