import numpy as np

def long_only_relative_mean_score(y, y_pred):
    return np.mean(y_pred*y) - np.mean((1-y_pred)*y)

def mean_score(y, y_pred):
    return np.mean(y_pred*y)

def sharpe_score(y, y_pred):
    return np.mean(y_pred*y)/np.std(y_pred*y)

def active_mean_score(y, y_pred):
    idx = np.abs(y_pred)>0
    return np.mean(y_pred[idx]*y[idx])

def active_sharpe_score(y, y_pred):
    idx = np.abs(y_pred)>0
    return np.mean(y_pred[idx]*y[idx])/np.std(y_pred[idx]*y[idx])

def active_mean_reg_score(y, y_pred):
    idx = np.abs(y_pred)>0
    if np.sum(idx)>0:
        return np.mean(y_pred[idx]*y[idx]) * np.log(np.sum(idx))
    else:
        return -1000000

def ctail_score(y, y_pred):
    strat = y_pred*y
    top_percentile = np.percentile(strat, 90)
    idx = strat>top_percentile
    return np.mean(strat[idx])