from functools import wraps
import numpy as np

def short(fn):
    @wraps(fn)
    def wrapper(x, y):
        return -fn(x, y)
    wrapper.__name__ = 'short_'+wrapper.__name__
    return wrapper

def mixed(x, threshold): #param_grid_func
    return np.less(x, threshold).astype(float)-np.greater(x, threshold).astype(float)

def tent(x, threshold): #param_grid_func
    return np.greater(x, threshold).astype(float)-np.less(x, -threshold).astype(float)

def greater(x, threshold):
    return np.greater(x, threshold)

def less(x, threshold):
    return np.less(x, threshold)

short_mixed = short(mixed)
short_tent = short(tent)
short_greater = short(greater)
short_less = short(less)