import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from symawofo import FeatureFrame, FeatureSeries
from symawofo.ensemble.voting import VotingRegressor
from .clustering import parallel_dendo_windows, dendo_windows, process_dendo_results
from ..clustering import get_d_mat
from ami.common.common_fns import check_in, percentile_return_when_active, sharpe, get_sharpe_whenactive, \
    mean_ex_extremes, drawdown, right_when_active
from ami.common.base_charting import Chart


class SSE_PLChart(Chart):

    charts_to_save = []

    def plot_substrats(self):
        df_pnl = self.strat.get_pnl().copy()
        (df_pnl-1).plot(figsize=(12, 7))
        (self.hold_pnl.get_pnl()-1).plot(color='k')
        plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')


    def view_substrats_table(self):
        pl = check_in(self.strat.get_pnl().copy().diff().dropna())
        pl['Target'] = self.hold_pnl.get_pnl().diff().reindex(pl.index)
        signals = check_in(self.strat.get_signals().copy())
        signals['Target'] = 1
        return self.results_table(pl, signals).round(2)

    @staticmethod
    def results_table(trade, signals=None, PER=52, results_order=None):
        trade = check_in(trade)
        df_ones = pd.DataFrame(np.ones_like(trade), index=trade.index, columns=trade.columns)
        signals = signals if signals is not None else df_ones
        signals = check_in(signals)
        df_results = pd.DataFrame(index=signals.columns)
        df_results['Average_Signal'] = signals.sum() / signals.shape[0]
        df_results['Long'] = signals.apply(lambda x: (x > 0).mean())
        df_results['Flat'] = signals.apply(lambda x: (x == 0).mean())
        df_results['Short'] = signals.apply(lambda x: (x < 0).mean())
        df_results['Right_w_Active'] = signals.apply(lambda x: right_when_active(x, np.sign(trade['Target'])))
        df_results['Active_min_return'] = signals.apply(
            lambda x: percentile_return_when_active(x, trade['Target'], 0)) * 100
        df_results['Active_25_return'] = signals.apply(
            lambda x: percentile_return_when_active(x, trade['Target'], 0.25)) * 100
        df_results['Median_w_active'] = signals.apply(
            lambda x: percentile_return_when_active(x, trade['Target'], 0.5)) * 100
        df_results['Active_75_return'] = signals.apply(
            lambda x: percentile_return_when_active(x, trade['Target'], 0.75)) * 100
        df_results['Active_max_return'] = signals.apply(
            lambda x: percentile_return_when_active(x, trade['Target'], 1)) * 100
        df_results['Mean_w_active'] = signals.apply(
            lambda x: percentile_return_when_active(x, trade['Target'], 'mean')) * 100
        df_results['Mean_ex_extreme'] = signals.apply(lambda x: mean_ex_extremes(x, trade['Target'], 0.15)) * 100
        df_results['Max_Drawdown'] = trade.cumsum().apply(lambda x: drawdown(x, False).min())
        df_results['Mean'] = trade.mean() * 100
        df_results['Median'] = trade.median() * 100

        sh = trade.apply(lambda x: sharpe(x, PER)).to_frame()
        sh2 = get_sharpe_whenactive(trade, signals, freq=PER)
        std = (np.sqrt(PER) * trade.std()).to_frame()
        sharpe_table = pd.concat([sh, sh2, std], axis=1)
        sharpe_table.columns = ['Sharpe', 'Sharpe_w_active', 'Vol']

        df_results = pd.concat([sharpe_table, df_results], axis=1)
        results_order = results_order or ['Average_Signal',
                                          'Long', 'Flat', 'Short',
                                          'Right_w_Active',
                                          'Sharpe', 'Sharpe_w_active',
                                          'Mean', 'Mean_w_active', 'Mean_ex_extreme', 'Median_w_active', 'Median',
                                          'Max_Drawdown']
        return df_results[results_order]


    def plot_substrat_correlation(self, signal=True, corr='pearson'):
        samples = self.strat.wf[0].get_samples()
        feature_names = [i[0].squeeze().name for i in samples]

        df = self.strat.get_signals().copy() if signal else self.strat.get_pnl().copy().diff().dropna()
        df = df.rename({i: j for i, j in zip(df.columns, feature_names)})

        if not signal:
            df['Target'] = self.hold_pnl.get_pnl().diff().reindex(df.index)

        corr = get_d_mat(df, corr, to_score=False)
        if isinstance(corr, np.ndarray):
            corr = pd.DataFrame(columns=df.columns, index=df.columns, data=corr)

        fig, ax = plt.subplots(1, 1, figsize=(11, 11), dpi=150)
        sns.heatmap(corr, cmap='Blues', ax=ax, annot=True, fmt='.2f')
        plt.show()


    def weighted_substrat_performance(self, parallel=True):

        is_signal = self.spec.clustering.is_signal
        corr = self.spec.clustering.corr

        if parallel:
            results = parallel_dendo_windows(self.strat.wf, is_signal, corr)
        else:
            results = dendo_windows(self.strat.wf, is_signal, corr)

        output_weights_2by2, output_weights_2clusters, output_weights_3clusters, output_weights_4clusters, output_rets = process_dendo_results(
            results)
        output_weights_even = pd.DataFrame(np.ones_like(output_weights_2by2) / output_weights_2by2.shape[1],
                                           index=output_weights_2by2.index,
                                           columns=output_weights_2by2.columns)

        weight_scheme_dict = dict([('Equally Weighted', output_weights_even),
                                   ('Equally Weighted AggloCluster (K=2)', output_weights_2clusters),
                                   ('Equally Weighted AggloCluster (K=3)', output_weights_3clusters),
                                   ('Equally Weighted AggloCluster (K=4)', output_weights_4clusters),
                                   ('2by2 AggloCluster', output_weights_2by2)])

        df_portfolios = pd.DataFrame()
        for name, weighting in weight_scheme_dict.items():
            df_portfolios[name] = (output_rets * weighting).sum(axis=1)
        df_portfolios['Target'] = self.hold_pnl.get_pnl().diff().reindex(df_portfolios.index)

        self.df_portfolios = df_portfolios
        self.weight_scheme_dict = weight_scheme_dict
        self.df_portfolios.cumsum().plot(figsize=(14, 7))


    def plot_signal_contribution(self, scheme):
        weight_scheme = self.weight_scheme_dict[scheme]
        renamed_weight_scheme = weight_scheme.rename(columns={i:j for i,j in zip(weight_scheme.columns, self.strat.get_signals().columns)})
        z = (self.strat.get_signals() * renamed_weight_scheme).dropna()
        fig, ax = plt.subplots(figsize=(16, 12))
        # split dataframe df into negative only and positive only values
        df_neg, df_pos = z.clip(upper=0), z.clip(lower=0)
        # stacked area plot of positive values
        df_pos.plot.area(ax=ax, stacked=True, linewidth=0.)
        lines = ax.get_lines()
        # reset the color cycle
        ax.set_prop_cycle(None)
        ax.yaxis.set_ticks_position('both')

        # stacked area plot of negative values, prepend column names with '_' such that they don't appear in the legend
        df_neg.rename(columns=lambda x: '_' + x).plot.area(ax=ax, stacked=True, linewidth=0.)
        # rescale the y axis
        ax.set_ylim([df_neg.sum(axis=1).min(), df_pos.sum(axis=1).max()])
        handles, labels = ax.get_legend_handles_labels()
        z.sum(axis=1).rename('Sum').plot(ax=ax, color='k', linewidth=2)
        handles2, labels2 = ax.get_legend_handles_labels()
        # lines = ax.get_lines()[:len(df_pos.columns)]+[ax.get_lines()[-1]]
        ax.legend(handles + [handles2[0]], labels + [labels2[0]], bbox_to_anchor=(1, 1), loc='upper left')


    def chart_feature_correlations(self, data, start_date="2005"):
        target = self.strat.wf.target  # this should be lead target (i.e. don't shift it after taking from wf)
        substrat_list = self.spec.substrats

        fig, ax = plt.subplots(3, int(np.ceil(len(substrat_list) / 3)), figsize=(12, 8), dpi=100)
        ax = ax.flatten()
        for a in ax:
            a.yaxis.set_ticks_position('both')

        target_name = target.data.name

        for i, meta in enumerate(substrat_list):

            feature_name = meta['feature_name']
            feature_preprocessing = meta['feature_preprocessing']
            features = FeatureFrame(data[[feature_name]].loc[start_date:].copy().dropna())
            if feature_preprocessing is not None:
                features = feature_preprocessing.fit_transform(features)

            temp_target = target.data.reindex(features.data.index)

            sns.regplot(x=temp_target, y=features.data.values, ax=ax[i])
            ax[i].set(xlabel=target_name, ylabel=feature_name)

        plt.tight_layout()
        plt.show()


    def collect_thresholds(self):
        isVotingReg = isinstance(self.strat.wf[0].estimator_, VotingRegressor)
        names = self.strat.wf[0].estimator_._inner_estimator.keys() if isVotingReg else self.strat.wf[0] \
            .estimator_.regressor_._inner_estimator.keys()

        df_thresh = pd.DataFrame()
        df_func = pd.DataFrame()
        df_features = {}

        for w in self.strat.wf[:-1]:
            date = w.training_end
            df_features[date] = []
            pipes = w.estimator_.estimators_ if isVotingReg else w.estimator_.regressor_.estimators_
            for meta, name, pipe in zip(self.spec.substrats, names, pipes):
                est = pipe.steps[-1][-1]
                df_thresh.loc[date, name] = est.thresh
                df_func.loc[date, name] = est.func
                df_features[date].append(self.get_feature(meta, w))
            df_features[date] = pd.concat(df_features[date], axis=1)

        df_features = pd.concat(df_features.values(), axis=0).sort_index()

        feature_names = df_features.columns
        rename_lower_to_features = dict(zip([i.lower() for i in names], feature_names))

        df_thresh = df_thresh.rename(rename_lower_to_features, axis=1)
        df_func = df_func.rename(rename_lower_to_features, axis=1).applymap(lambda x: x.__name__)
        return df_features, df_thresh, df_func


    def plot_substrat_thresholds(self):
        n_strats = len(self.spec.substrats)
        df_features, df_thresh, df_func = self.collect_thresholds()
        pl = self.strat.get_pnl().copy().diff().dropna()
        pl = pl if isinstance(pl, pd.DataFrame) else pl.to_frame()
        rename_pred_to_features = dict(zip(pl.columns, df_features.columns))

        target = self.hold_pnl.diff().get_pnl().reindex(pl.index)

        pl = pl.rename(rename_pred_to_features, axis=1)
        df_signals = self.strat.get_signals().copy().rename(rename_pred_to_features, axis=1)

        fig, axs = plt.subplots(n_strats, 2, figsize=(14, 5 * n_strats))

        for i, name in enumerate(df_thresh.columns):
            ax = axs[i] if n_strats > 1 else axs
            self.chart_threshold_evolution(df_thresh[name], df_func[name], series=df_features[name],
                                      ax=ax[0])  # can use signal=df_signals[i] to plot signals instead
            self.plot_shaded_pl(pl[name], target=target, signal=df_signals[name], ax=ax[1])
        plt.show()


    @staticmethod
    def chart_threshold_evolution(threshold_ser, func_name_ser, series=None, signal=None, ax=None):
        if ax is None:
            f, ax = plt.subplots(figsize=(8, 5))

        x = threshold_ser.index
        y = threshold_ser
        y_func = func_name_ser

        ax.plot(x, y, 'k', linewidth=2)
        ax.yaxis.set_ticks_position('both')

        if series is not None:
            mn , mx = series.quantile(0.01), series.quantile(0.99)
        else:
            difference = (y.max() - y.min()) if y.max() > y.min() else 0.5
            mn = y.min() - 0.1 * difference
            mx = y.max() + 0.1 * difference

        long_color = '#539ecd'
        short_color = 'red'

        ax.set_ylim(mn, mx)

        ax.fill_between(x, y, mx, where=y_func == 'greater', color=long_color)
        ax.fill_between(x, mn, y, where=y_func == 'less', color=long_color)

        ax.fill_between(x, y, mx, where=y_func == 'short_greater', color=short_color)
        ax.fill_between(x, mn, y, where=y_func == 'short_less', color=short_color)

        ax.fill_between(x, mn, y, where=y_func == 'mixed', color=long_color)
        ax.fill_between(x, y, mx, where=y_func == 'mixed', color=short_color)

        ax.fill_between(x, mn, y, where=y_func == 'short_mixed', color=short_color)
        ax.fill_between(x, y, mx, where=y_func == 'short_mixed', color=long_color)

        ax.fill_between(x, mn, -abs(y), where=y_func == 'tent', color=short_color)
        ax.fill_between(x, abs(y), mx, where=y_func == 'tent', color=long_color)

        ax.fill_between(x, mn, -abs(y), where=y_func == 'short_tent', color=long_color)
        ax.fill_between(x, abs(y), mx, where=y_func == 'short_tent', color=short_color)

        if series is not None:
            ax.plot(series.index, series, 'grey', alpha=0.5)

        if signal is not None:
            ax2 = ax.twinx()
            ax2.plot(signal.index, signal, 'k', alpha=0.5)

        ax.grid()
        ax.set_title(threshold_ser.name, fontsize=10)
        return ax


    @staticmethod
    def get_feature(meta, w):
        fitter = meta['feature_preprocessing']
        is_FeatureSeries = isinstance(w.X_test, FeatureSeries)
        X_test = w.X_test.to_frame() if is_FeatureSeries else w.X_test
        if fitter is not None:
            X_train = w.X_train.to_frame() if is_FeatureSeries else w.X_train
            fitter.fit(X_train[meta['feature_name']])
            return fitter.transform(X_test[meta['feature_name']]).data
        else:
            return X_test[meta['feature_name']].data


    @staticmethod
    def plot_shaded_pl(pl, target=None, signal=None, ax=None):
        if ax is None:
            f, ax = plt.subplots(figsize=(8, 5))

        x = pl.index
        y = pl.cumsum()
        ax.plot(x, y, 'k', linewidth=2)

        mn = y.min()
        mx = y.max()

        if target is not None:
            y_target = target.cumsum()
            mn = min(mn, y_target.min())
            mx = max(mx, y_target.max())
            ax.plot(x, y_target, 'dimgrey')

        if signal is not None:
            long_color = '#539ecd'
            short_color = 'red'
            ax.fill_between(x, mn, mx, where=signal > 0, color=long_color, alpha=0.5)
            ax.fill_between(x, mn, mx, where=signal < 0, color=short_color, alpha=0.5)
        return ax

