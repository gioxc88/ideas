import numpy as np
import pandas as pd
from itertools import starmap
from dask import delayed, compute
from ..clustering import effective_weight_even, effective_weight_2by2


def dendo_window_iteration(w, is_signal, corr, plot=False, verbose=False):
    if verbose:
        print(w.training_end)

    X_train = w.X_train
    X_test = w.X_test

    train_preds = w.estimator_.predict(X_train).data.astype(int)
    train_asset = w.y_train.data

    test_preds = w.estimator_.predict(X_test).data.astype(int)
    test_asset = w.y_test.data

    n_train_samples, n_train_features = train_preds.shape
    asset_name = train_asset.name

    # I rename the predictions columns before multiplying by the asset so pandas behaves
    rename_predictions = dict(zip(train_preds.columns, [asset_name] * n_train_features))
    temp = train_preds.rename(rename_predictions, axis='columns')

    train_strat_rets = temp.multiply(train_asset, axis=0)
    train_strat_rets.columns = X_train.columns

    use_strat = train_preds if is_signal else train_strat_rets
    use_strat.columns = train_strat_rets.columns

    weights_2by2 = effective_weight_2by2(use_strat, plot=plot, correlation_method=corr)
    weights_2clusters = effective_weight_even(use_strat, n_clusters=2, correlation_method=corr)
    weights_3clusters = effective_weight_even(use_strat, n_clusters=3, correlation_method=corr)
    weights_4clusters = effective_weight_even(use_strat, n_clusters=4, correlation_method=corr)

    # I rename the predictions columns before multiplying by the asset so pandas behaves
    temp = test_preds.rename(rename_predictions, axis='columns')

    test_strat_rets = temp.multiply(test_asset, axis=0)
    test_strat_rets.columns = X_test.columns

    # This creates a df of ones, which I multiply along columns by the weights
    temp = pd.DataFrame(np.ones_like(test_strat_rets), index=test_strat_rets.index, columns=test_strat_rets.columns)

    result_weights_2by2 = temp.multiply(weights_2by2, axis=1)
    result_weights_2clusters = temp.multiply(weights_2clusters, axis=1)
    result_weights_3clusters = temp.multiply(weights_3clusters, axis=1)
    result_weights_4clusters = temp.multiply(weights_4clusters, axis=1)
    result_output_rets = test_strat_rets

    return result_weights_2by2, result_weights_2clusters, result_weights_3clusters, result_weights_4clusters, result_output_rets


def parallel_dendo_windows(wf, is_signal, corr):
    results = []
    for w in wf[:-1]:
        params_dict = dict(w=w, is_signal=is_signal, corr=corr, plot=False, verbose=False)
        results.append(delayed(dendo_window_iteration)(**params_dict))
    return compute(*results)


def dendo_windows(wf, is_signal, corr):
    params = []
    for w in wf[:-1]:
        params.append((w, is_signal, corr, True, True))
    results = starmap(dendo_window_iteration, params)
    return results


def process_dendo_results(results):
    output_weights_2by2, output_weights_2clusters, output_weights_3clusters, output_weights_4clusters, output_rets = zip(
        *results)
    output_weights_2by2 = pd.concat(output_weights_2by2, axis=0)
    output_weights_2clusters = pd.concat(output_weights_2clusters, axis=0)
    output_weights_3clusters = pd.concat(output_weights_3clusters, axis=0)
    output_weights_4clusters = pd.concat(output_weights_4clusters, axis=0)
    output_rets = pd.concat(output_rets, axis=0)
    return output_weights_2by2, output_weights_2clusters, output_weights_3clusters, output_weights_4clusters, output_rets


