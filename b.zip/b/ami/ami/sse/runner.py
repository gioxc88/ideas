from datetime import datetime

from ami import build
from ami.sse.jobspec import SSEJobspec
from ami.common.base_runner import baseRunner
from ami.common.nb_builder import NotebookBuilder

class SSERunner(baseRunner):

    def __init__(self, asset):
        super().__init__(None)
        self.orig_jobspec = SSEJobspec.load(asset)
        self.jobspec = self.orig_jobspec.clone()

    @classmethod
    def save_notebook(cls, asset, folder=None):

        jobspec = SSEJobspec.load(asset)
        NotebookBuilder(jobspec=jobspec,
                        module=build.sse,
                        template_path='sse/ipynb_gen/sse.jinja2',
                        name=f'SSE_{jobspec.target.name}_{datetime.now():%Y-%m-%d}.ipynb'
                        ).save(folder)