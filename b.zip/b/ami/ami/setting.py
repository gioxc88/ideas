from pathlib import Path

DATA_API_BASE = 'http://awsmbdev02.idm.rivagecapital.com/api'

SRC_PATH = Path(__file__).parent
PROJECT_PATH = Path(__file__).parents[1]
