export PATH="/opt/bh/anaconda3_versions/4.2.0/bin:$PATH"
export http_proxy=http://proxy.rivagecapital.com:8080
export https_proxy=http://proxy.rivagecapital.com:8080

conda create -y -n ami python=3.8.5
source activate ami
pip install -r requirements.txt